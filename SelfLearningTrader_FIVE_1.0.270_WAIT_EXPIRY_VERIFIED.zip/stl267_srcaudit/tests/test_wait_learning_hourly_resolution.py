import json
import time
from pathlib import Path
from types import MethodType

import numpy as np

from app.core.engine import LearningEngine


class FakeExchange:
    def __init__(self, bars):
        self.bars = bars
        self.calls = 0

    def candles(self, tf, limit):
        assert tf == '5min'
        assert limit == 96
        self.calls += 1
        return self.bars


def test_unfinished_wait_is_resolved_after_four_hour_candle_horizon(tmp_path):
    engine = LearningEngine.__new__(LearningEngine)
    engine.logs = Path(tmp_path) / 'logs'
    engine.logs.mkdir(parents=True)
    engine.data = Path(tmp_path) / 'data'
    engine.data.mkdir()
    engine.cfg = {'wait_learning_horizon_bars': 48, 'history_limit': 5000,
                  'long_threshold': 0.003, 'short_threshold': -0.003}
    engine.set_symbol = MethodType(lambda self, symbol: setattr(self, 'symbol', symbol), engine)

    start = int(time.time() // 300 * 300 - 60 * 300)
    times = np.asarray([(start + i * 300) * 1_000_000 for i in range(60)], dtype=np.int64)
    close = np.full(60, 100.0)
    high = np.full(60, 100.1)
    low = np.full(60, 99.9)
    high[2] = 100.5  # crosses the +0.3% direction threshold
    engine.exchange = FakeExchange({'time': times, 'high': high, 'low': low, 'close': close})

    from app.core.features import FEATURES
    prediction = {
        'id': 'wait-1', 'contract': 'AAAUSDTM', 'prediction': 'WAIT',
        'resolved': 0, 'time': int(times[0]), 'price': 100.0,
        'features': {name: 0.0 for name in FEATURES},
    }
    path = engine.logs / 'AAAUSDTM_predictions.json'
    path.write_text(json.dumps([prediction]), encoding='utf-8')

    engine._append_wait_experience = MethodType(lambda self, rows: len(rows), engine)
    engine._load_exp = MethodType(lambda self: None, engine)
    engine._append_learning_audit = MethodType(lambda self, row: None, engine)
    engine._read_json = MethodType(lambda self, path: {}, engine)
    engine._write_json = MethodType(lambda self, path, value: Path(path).write_text(json.dumps(value), encoding='utf-8'), engine)

    changed, diagnostics = engine.resolve_wait_learning()
    saved = json.loads(path.read_text(encoding='utf-8'))[0]

    assert len(changed) == 1
    assert saved['resolved'] == 1
    assert saved['wait_learning_resolved'] is True
    assert saved['wait_learning_state'] == 'COMPLETED'
    assert saved['wait_learning_outcome'] == 'MISSED_LONG'
    assert diagnostics['missed_long'] == 1
    assert engine.exchange.calls == 1


def test_contract_without_unfinished_wait_does_not_fetch_candles(tmp_path):
    engine = LearningEngine.__new__(LearningEngine)
    engine.logs = Path(tmp_path) / 'logs'
    engine.logs.mkdir(parents=True)
    engine.cfg = {'wait_learning_horizon_bars': 48, 'history_limit': 5000}
    engine.exchange = FakeExchange({'time': np.asarray([], dtype=np.int64),
                                    'high': np.asarray([]), 'low': np.asarray([]), 'close': np.asarray([])})
    engine.set_symbol = MethodType(lambda self, symbol: setattr(self, 'symbol', symbol), engine)
    (engine.logs / 'AAAUSDTM_predictions.json').write_text(json.dumps([
        {'id': 'done', 'prediction': 'WAIT', 'resolved': 1, 'wait_learning_resolved': True}
    ]), encoding='utf-8')
    engine._read_json = MethodType(lambda self, path: {}, engine)
    engine._write_json = MethodType(lambda self, path, value: Path(path).write_text(json.dumps(value), encoding='utf-8'), engine)
    engine._append_learning_audit = MethodType(lambda self, row: None, engine)

    changed, diagnostics = engine.resolve_wait_learning()

    assert changed == []
    assert engine.exchange.calls == 0


def test_all_legacy_waits_older_than_eight_hours_are_expired_even_without_features(tmp_path):
    """Legacy WAIT rows must be closed even when they cannot enter candle learning."""
    engine = LearningEngine.__new__(LearningEngine)
    engine.logs = Path(tmp_path) / 'logs'
    engine.logs.mkdir(parents=True)
    engine.data = Path(tmp_path) / 'data'
    engine.data.mkdir()
    engine.cfg = {'wait_learning_horizon_bars': 48}
    engine.set_symbol = MethodType(lambda self, symbol: setattr(self, 'symbol', symbol), engine)
    engine.exchange = FakeExchange({'time': np.asarray([], dtype=np.int64),
                                    'high': np.asarray([]), 'low': np.asarray([]), 'close': np.asarray([])})
    old_time_us = int((time.time() - 10 * 3600) * 1_000_000)
    legacy_waits = [
        {'id': f'legacy-{i}', 'contract': 'AAAUSDTM', 'prediction': 'WAIT',
         'resolved': 0, 'time': old_time_us}
        for i in range(500)
    ]
    predictions_path = engine.logs / 'AAAUSDTM_predictions.json'
    predictions_path.write_text(json.dumps(legacy_waits), encoding='utf-8')
    pending_path = engine.logs / 'AAAUSDTM_pending.json'
    pending_path.write_text(json.dumps([
        {'id': 'legacy-wait-pending', 'prediction': 'WAIT', 'resolved': 0},
        {'id': 'real-short', 'prediction': 'SHORT', 'resolved': 0},
    ]), encoding='utf-8')
    engine._append_learning_audit = MethodType(lambda self, row: None, engine)
    engine._write_json = MethodType(
        lambda self, path, value: Path(path).write_text(json.dumps(value), encoding='utf-8'), engine
    )

    changed, diagnostics = engine.resolve_wait_learning()
    saved = json.loads(predictions_path.read_text(encoding='utf-8'))
    pending = json.loads(pending_path.read_text(encoding='utf-8'))

    assert changed == []  # stale administrative expiry is not a training result
    assert len(saved) == 500
    assert all(row['resolved'] == 1 for row in saved)
    assert all(row['wait_learning_resolved'] is True for row in saved)
    assert all(row['wait_learning_state'] == 'EXPIRED_STALE_UNVERIFIABLE' for row in saved)
    assert all(row['result'] == 'EXPIRED_UNVERIFIABLE' for row in saved)
    assert all(row['statistics_exclude'] is True and row['training_exclude'] is True for row in saved)
    assert [row['id'] for row in pending] == ['real-short']
    assert engine.exchange.calls == 0
