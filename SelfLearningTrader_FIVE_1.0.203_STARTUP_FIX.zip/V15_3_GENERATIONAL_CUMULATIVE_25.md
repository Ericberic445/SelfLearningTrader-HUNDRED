# V15.3 — Cumulative 25-prediction generational learning

## Learning loop

`25 Master observations -> Challenger -> 25 Master vs Challenger -> winner -> immediate new Challenger -> repeat`

- Only one Master and one active Challenger model file are kept.
- Challenger starts from the current Master parameters (warm start), not from zero.
- Challenger is trained on the accumulated resolved experience replay plus current market history.
- Resolved experience receives explicit learning weight; TP1/TP2/TP3 outcomes and confidence influence the stored sample weight.
- After 25 head-to-head resolved observations, the winner is selected using TP1 as the primary success criterion, with TP2/TP3 reward and initial-SL penalty.
- The losing Challenger file is deleted. Its useful experience remains in the bounded replay memory and cumulative experience statistics.
- A new Challenger is created immediately after the comparison batch, so every following 25 observations are again a head-to-head test.
- No second permanent Challenger or historical model archive is stored.

## Market scan

`~700+ -> 50 -> 25 -> TOP-5`

- Stage 1: fast market-wide scan across active futures contracts.
- Stage 2: learned model analysis of the best 50.
- Stage 3: additional mathematical/MTF agreement and historical-experience similarity on the best 25.
- TOP-5 is the final result. There is no extra model stage after TOP-5.

## Storage

The resolved replay memory is bounded (`experience_max_rows`) so phone storage does not grow without limit. Cumulative experience counters remain in `experience_stats.json`, while the Master parameters preserve learned information across generations.
