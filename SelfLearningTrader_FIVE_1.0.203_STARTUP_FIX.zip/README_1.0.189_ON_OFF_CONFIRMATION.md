# SelfLearningTrader FIVE 1.0.189

- Moved the visible scanner START/STOP control from the bottom to the top header.
- The visible control is now `ON` / `OFF`, immediately left of `ОБНОВИТЬ`.
- Every manual ON/OFF press requires explicit `ДА` / `НЕТ` confirmation.
- The old bottom control is hidden and kept only as compatibility state for the background-service code.
- The scanner control is not duplicated in the main menu.
- No scanner/learning logic was changed by this UI-only update.
