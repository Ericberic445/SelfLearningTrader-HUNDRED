# SelfLearningTrader FIVE 1.0.180

## Button color logic
- ЗАПУСТИТЬ СКАНИРОВАНИЕ — green.
- ЗАПУСТИТЬ СКАНИРОВАНИЕ — green.
- СТОП — red.

Only the visual action color was changed; scanner/service logic is inherited from 1.0.178.
