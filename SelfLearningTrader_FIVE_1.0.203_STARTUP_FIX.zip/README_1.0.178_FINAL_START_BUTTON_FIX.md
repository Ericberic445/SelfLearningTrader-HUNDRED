# SelfLearningTrader FIVE 1.0.178 — FINAL START/REFRESH FIX

- Fixed the idle START button no-op: the fixed action button now starts the scanner when idle.
- STOP remains the normal user stop action and persists the user_stopped flag.
- Android foreground service remains the long-running scanner owner.
- ОБНОВИТЬ now refreshes the live KuCoin contract list even while the scanner is idle.
- Continuous background/recovery logic from 1.0.177 is preserved.
