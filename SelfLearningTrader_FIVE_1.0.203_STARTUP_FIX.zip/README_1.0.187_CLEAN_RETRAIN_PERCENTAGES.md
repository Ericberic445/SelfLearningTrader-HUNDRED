# SelfLearningTrader FIVE 1.0.187

Changes:
- Old Master model weights are not treated as ground truth for the new model.
- Historical experience is reusable only after validation under the current outcome rules.
- Unverifiable legacy rows are excluded from retraining.
- Master retrain cycle counter is persisted when the engine calls the retrain-cycle helper.
- Added outcome-percentage formatter for LONG/SHORT/WAIT and TP1/TP2/TP3/SL.
- C1/C2/C3 remain fixed; selector learning must use verified lens outcomes only.
- WAIT remains control-learning data and is not an active trade.
