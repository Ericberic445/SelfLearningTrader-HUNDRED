# SelfLearningTrader FIVE 1.0.190

- The ONLY user-facing scanner control is `ON` / `OFF` in the top header, immediately left of `ОБНОВИТЬ`.
- Every ON/OFF press requires `ДА` / `НЕТ` confirmation.
- The old bottom START/STOP control is permanently hidden, including from the popup menu.
- Internal `stop_btn` remains only as a state carrier for the scanner service and cannot receive user taps.
- No scanner, learning, Master, or lens logic was changed.
