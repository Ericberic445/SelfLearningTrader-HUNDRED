# SelfLearningTrader FIVE 1.0.165 / 65

## Result badge display fix
- TP1 and TP2 are displayed in green because they are already reached results.
- Yellow is reserved for predictions that are genuinely still being checked and have no reached TP result or initial-SL result.
- TP3 remains green (including TP3+).
- Existing TP1/TP2/TP3/SL resolution and learning logic is unchanged.
