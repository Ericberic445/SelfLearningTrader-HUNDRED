# SelfLearningTrader FIVE 1.0.166 / 66

## Result/status synchronization fix

The existing engine resolution logic is preserved.

Display rules now match the actual `resolved` state:
- TP1 reached but prediction continues toward TP2 -> yellow `Проверяется`.
- TP2 reached but prediction continues toward TP3 -> yellow `Проверяется`.
- TP1 reached and protected exit at Entry -> green `TP1` (resolved).
- TP2 reached and protected exit at TP1 -> green `TP2` (resolved).
- SL before TP1 -> red `SL` (resolved failure).
- TP3 -> green `TP3`.
- TP3 followed by extension beyond TP3 -> green `TP3+`.

Statistics already use `resolved` for `Полностью завершено` and `pending` for
`Ожидают события`; this build does not change the underlying TP/SL engine.
Therefore the yellow rows represent unresolved predictions, including those
that have already reached TP1/TP2 but are still being verified.
