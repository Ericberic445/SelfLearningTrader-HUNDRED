# SelfLearningTrader FIVE 1.0.191

UI-only fix:
- ON = RED while scanning/background scanner is running.
- OFF = GREEN when scanning is stopped/idle.
- Existing ON/OFF confirmation (ДА/НЕТ) remains unchanged.
- Scanner and learning logic are unchanged.
