# FIVE 1.0.173 — Full Mathematical Layer

Pipeline: ~700+ → 50 → 25 → TOP-5.

Only the 25 finalists receive the full mathematical layer: Markov, probability of movement, AR, ARIMA, SARIMA, GARCH, Hurst exponent, mean reversion, cointegration, correlation matrix, entropy/information theory, fractal analysis, wavelet analysis, Kalman filter, Monte Carlo, Bayesian layer, change-point detection, plus P(TP1), P(TP2), P(TP3), P(SL).

The mathematical outputs are persisted with each forecast. Resolved outcomes update a compact per-method reliability memory, and the next Challenger receives higher/lower training weight according to whether the mathematical layer agreed with the realized direction. Challenger model files remain disposable; experience is retained. TOP-5 is the final scan stage.
