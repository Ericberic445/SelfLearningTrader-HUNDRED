# SelfLearningTrader FIVE 1.0.168 / 68

## Fix: one canonical forecast set for TOP-5 and statistics

The scanner TOP-5 predictions are now persisted into the same `*_predictions.json` and `*_pending.json` logs used by the background verifier and statistics.

This fixes the mismatch where the UI could show many old yellow `Проверяется` rows while the statistics counted only a smaller number of pending forecasts.

- Every LONG/SHORT TOP-5 prediction gets one canonical record by its `id`.
- Background verification resolves those records normally.
- `engine.stats()` counts the same records shown by TOP-5.
- Old TOP-5 records saved by the previous versions are migrated when the service starts.
- Existing TP1/TP2/TP3/SL logic is unchanged.
- TP1/TP2 remain yellow while the forecast continues; they become green only after the corresponding protected exit.
- TP3 remains green and TP3+ is shown when post-TP3 extension is recorded.
