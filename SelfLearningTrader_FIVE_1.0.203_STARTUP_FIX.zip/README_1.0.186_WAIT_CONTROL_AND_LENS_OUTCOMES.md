# SelfLearningTrader FIVE 1.0.186 — Master trade-outcome learning + 3 fixed lenses + WAIT control learning

This release implements the learning rules agreed for the FIVE architecture.

## 1. Master learning target

Master is no longer trained only on the endpoint direction. It keeps a direction head (LONG/SHORT/WAIT), but the primary trading-learning target is the real path outcome:

- Initial SL before TP1 = `INITIAL_SL` / score 0.
- TP1 reached = `TP1` / score 1.
- TP2 reached = `TP2` / score 2.
- TP3 reached = `TP3` / score 3.
- TP3 and any continuation above it = `TP3_PLUS` / score 4.

The dynamic protection rules are part of the label:

- after TP1, protection moves to Entry;
- after TP2, protection moves to TP1;
- a later protected exit is still a successful TP1/TP2 result, not an SL failure.

TP3 is a milestone, not a ceiling. The maximum extension above TP3 is saved.

## 2. Post-SL recheck

An initial SL remains a real losing trade. It is not rewritten as a win.

For the next 3 five-minute candles, the engine performs a post-SL audit. If price then reaches the predicted direction's TP1/TP2/TP3, the record receives:

- `trade_outcome = INITIAL_SL` (real trade result remains LOSS),
- `post_sl_recovery = true`,
- `direction_confirmed = true`,
- `direction_confirmation_source = POST_SL_RECOVERY`.

The engine stores the SL candle context (volume spike, range, body, wicks), the post-SL recovery context, and the protection-exit context after TP1/TP2. This lets Master distinguish wrong direction from a correct direction that lost continuation or was stopped at a protected level after a momentum change.

## 3. Symbol-safe global experience

Experience is keyed by `contract + time + prediction_id`, not timestamp alone. The global replay memory stores both direction and trade-outcome targets.

Automatic retraining uses the completed global experience across contracts, not one contract's history as the permanent training base.

## 4. Fixed lenses

C1/C2/C3 are deterministic mathematical lenses. They do **not** train, do not keep adaptive weights, and do not change their own equations.

- C1 — market regime
- C2 — direction / entry
- C3 — TP/SL / risk

The Master-owned selector learns which actor (Master/C1/C2/C3) was better for a given market context. Lens performance is stored as Master memory, never fed back as lens self-learning.

## 5. No Challenger / no generation competition

There is one Master only. The old generation/challenger interpretation is disabled. `generation_state.json` remains only as a compatibility/status file and reports competition disabled.

## 6. 25-prediction cycle

- First 25 completed forecasts: Master only.
- After the first 25 and Master batch update: the shared Master base activates C1/C2/C3.
- Next 25: Master + all three fixed lenses.
- After every 25 completed forecasts: Master retrains globally, evaluates the lens outcomes, updates the outcome head and selector, publishes a new shared Master base, and repeats.

## 7. WAIT

WAIT is history only and never occupies the TP/SL verification queue.

After the configured horizon, every WAIT is evaluated separately for control learning:

- endpoint rise by the LONG threshold -> `MISSED_LONG`;
- endpoint fall by the SHORT threshold -> `MISSED_SHORT`;
- otherwise -> `WAIT_CORRECT`.

These observations are stored as direction-learning experience but are never counted as trades, TP/SL results, losses, or pending positions. A missed LONG teaches Master why it waited; a missed SHORT teaches Master why it waited; a sideways result reinforces WAIT.

WAIT is allowed to remain in TOP-5 when it is one of the strongest final candidates. It has no Entry/SL/TP trading plan and never enters `pending.json`.

## 8. Master selector and lens outcomes

After a trade closes, the engine resolves the same market path separately against Master, C1, C2 and C3 plans. These realized outcomes are stored in `lens_outcomes` and accumulated in `master_lens_performance.json`.

The selector target is `best_actor_by_real_trade_outcome`. C1/C2/C3 remain fixed; only Master learns which fixed actor was better in the observed market context.

## 9. Audit and validation

Every resolved forecast and every Master retrain is written to `data/learning_audit.jsonl`. Each retrain also recomputes a held-out validation report where enough global data exists.

UI layout is intentionally unchanged.
