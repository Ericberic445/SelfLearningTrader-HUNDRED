# FIVE 1.0.171 — manual real-position tracking

- The real-position direction is taken automatically from the selected prediction (LONG/SHORT); it is no longer manually selectable.
- The user enters the actual price at which they entered KuCoin and the actual leverage used.
- The app does not open or close the KuCoin position itself.
- While open, the background monitor tracks the real entry and current price and keeps the prediction TP/SL levels.
- The user enters the actual exit price after manually closing the position in KuCoin.
- Closed real positions are stored separately in `real_positions.json` and include actual entry/exit, leverage, prediction direction and leveraged price movement.
- Existing prediction statistics and learning data remain separate from manual real-position records.
