# SelfLearningTrader FIVE 1.0.183 — START / DOWNLOAD BACKUP + RUNTIME LOG FIX

This update is based on FIVE 1.0.182 and changes only the requested logic:

1. **START after STOP**
   - STOP writes `user_stopped=true` to the background control file.
   - The START button now clears that deliberate-stop flag before starting the foreground service.
   - This fixes the loop where the button displayed `ЗАПУСТИТЬ СКАНИРОВАНИЕ` but the start request was immediately rejected by `_start_foreground_scan()`.

2. **Runtime log export**
   - Exports the complete `runtime_diagnostics.log` to the public Android `Download` collection.
   - Uses `MediaStore$Files` instead of the pyjnius-incompatible `MediaStore.Downloads` attribute access.
   - The saved bytes are read back and compared before the UI reports success.
   - File names are `SelfLearningTrader_FIVE_runtime_YYYYMMDD_HHMMSS_mmm.log`.

3. **Learning backup export**
   - The backup is explicitly marked `FULL_LEARNING_STATE`.
   - Export is refused unless the required Master files are present: `champion.npz`, `champion.json`, and `generation_state.json`.
   - The archive manifest records optional learning state such as `global_experience.npz`, `master_decision_experience.npz`, `training_batch_state.json`, `experience_stats.json`, and `math_learning_state.json` when present.
   - The ZIP is verified before saving and read back from Download and verified again after saving.
   - If Download export fails, the app no longer silently substitutes an internal app-folder copy.

4. **Download listing/import**
   - Backup and runtime-log discovery also use `MediaStore$Files`, so the same nested-class issue does not reappear during import.
