# FIVE 1.0.180 — START/STOP ONLY

- One scanner control only.
- Idle/stopped: green `ЗАПУСТИТЬ СКАНИРОВАНИЕ`.
- Running: red `СТОП`.
- No pause/resume command is exposed.
- After user STOP, the next action is START.
- Continuous background/self-learning behavior remains owned by the foreground service.
