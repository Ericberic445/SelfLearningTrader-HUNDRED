# SelfLearningTrader FIVE 1.0.188

Corrected clean-retraining implementation based on the 2026-10-06 runtime backup.

- The previous 1.0.187 helper was not invoked; 1.0.188 actually performs a one-time clean Master reset.
- Old Master, outcome-head, and selector weights are deleted before rebuilding.
- Verified global experience is preserved and reused.
- Direction model is rebuilt from scratch using the existing bootstrap-history + verified global experience path.
- Outcome head is rebuilt from scratch from verified real trade outcomes.
- Master selector is rebuilt from scratch from stored actor/outcome evidence.
- C1/C2/C3 remain fixed and are never trained.
- WAIT entries are removed from pending trade queues; WAIT remains in prediction/history learning.
- TOP-5 TP1/TP2/TP3/SL percentages now come from the Master outcome head as cumulative probabilities:
  TP1+ / TP2+ / TP3+ / initial SL.
- Audit event CLEAN_MASTER_RESET records the reset and dataset sizes.
