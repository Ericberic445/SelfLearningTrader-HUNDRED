# SelfLearningTrader FIVE 1.0.192

- Fixed ON/OFF state synchronization.
- The visible ON/OFF switch is authoritative for the confirmed user action.
- Confirmed STOP immediately changes the switch to OFF/green while the Android service finishes stopping.
- Confirmed START immediately changes the switch to ON/red and remains synchronized with the scanner state.
- Hidden legacy STOP button is never used to determine the visible switch state.
- Scanner/training logic is unchanged.
