# SelfLearningTrader FIVE 1.0.170 / 70

UI-only fix based on 1.0.169.

Changes in this build:
- TOP-100 history timestamps are normalized across legacy seconds, milliseconds, microseconds, 100-ns ticks and nanoseconds without changing already formatted date/time strings.
- Expanded TOP-100 rows resize the outer vertical card/container, so following rows are pushed down instead of overlapping the expanded details on Android.
- No changes to prediction, TP/SL, Master/Challenger, learning, scanner, or background verification logic.
