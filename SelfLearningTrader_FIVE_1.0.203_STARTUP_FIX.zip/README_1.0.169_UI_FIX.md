# SelfLearningTrader FIVE 1.0.169 / 69 — UI fixes

Only the requested interface fixes are included in this build.

- Legacy TOP-100 timestamps such as Unix 100-ns ticks are formatted as normal local date/time.
- Expanding a TOP-100 history row increases the actual parent row height and forces Kivy layout recalculation, preventing following rows from overlapping the expanded details.
- Master / Challenger dashboard shows the current generation, comparison progress (25), both scores, current leader, TP1/TP2/TP3/SL comparison reason, remaining comparisons, and the last completed decision when no challenger is active.
- Existing prediction/result/learning logic is not changed by these UI changes.
