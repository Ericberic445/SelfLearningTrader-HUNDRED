# SelfLearningTrader FIVE 1.0.193 — ON/OFF semantics

Requested scanner switch semantics:
- Scanner WORKING/RUNNING: `OFF` + RED.
- Scanner STOPPED/NOT RUNNING: `ON` + GREEN.
- Press `OFF` (red) -> confirmation -> YES -> scanner stops -> `ON` green.
- Press `ON` (green) -> confirmation -> YES -> scanner starts -> `OFF` red.

The visible switch state remains authoritative for the confirmation action.
