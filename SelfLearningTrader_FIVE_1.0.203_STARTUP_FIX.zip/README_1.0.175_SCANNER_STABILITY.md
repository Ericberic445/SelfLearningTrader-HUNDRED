# FIVE 1.0.175 — Scanner Stability

- Android manual scan no longer calls the native Foreground Service bridge.
- Scan runs in the existing Kivy worker thread with progress/cancellation.
- Automatic Foreground Service startup is disabled in this stability build.
- This isolates the scanner from the Android Activity-collapse path seen when ServiceScanner.start() is invoked.
- Once the scanner is verified, the background service can be reintroduced separately.
