import numpy as np
import math

# Full mathematical layer requested for the 25-candidate stage.  Every feature
# is causal: values at t use only candles at or before t.
MATH_FEATURES = [
    'math_markov','math_prob_move','math_ar','math_arima','math_sarima','math_garch',
    'math_hurst','math_mean_reversion','math_cointegration','math_correlation',
    'math_entropy','math_fractal','math_wavelet','math_kalman','math_monte_carlo',
    'math_bayesian','math_change_point','math_ptp1','math_ptp2','math_ptp3','math_psl'
]


def _safe(a):
    return np.nan_to_num(np.asarray(a, dtype=float), nan=0.0, posinf=0.0, neginf=0.0)


def _ols_ar(x, p=3):
    x=_safe(x)
    if len(x)<=p+3: return 0.0
    y=x[p:]; X=np.column_stack([x[p-i-1:len(x)-i-1] for i in range(p)])
    try: return float(np.clip(np.linalg.lstsq(X,y,rcond=None)[0][0],-2,2))
    except Exception: return 0.0


def _entropy(x, bins=8):
    x=_safe(x)
    if len(x)<10 or np.ptp(x)<1e-12:return 0.0
    h,_=np.histogram(x,bins=bins); p=h.astype(float)/max(np.sum(h),1)
    p=p[p>0]; return float(-np.sum(p*np.log2(p))/np.log2(bins))


def _hurst(x):
    x=_safe(x); n=len(x)
    if n<32:return 0.5
    vals=[]
    for lag in (2,4,8,16):
        if lag>=n//2: continue
        d=x[lag:]-x[:-lag]; sd=np.std(d)
        if sd>1e-12: vals.append((lag,sd))
    if len(vals)<2:return 0.5
    a=np.polyfit(np.log([v[0] for v in vals]),np.log([v[1] for v in vals]),1)[0]
    return float(np.clip(a,0,1))


def _kalman(x, q=1e-5, r=1e-3):
    x=_safe(x)
    if not len(x): return 0.0
    est=float(x[0]); p=1.0
    for z in x[1:]:
        p+=q; k=p/(p+r); est+=k*(float(z)-est); p=(1-k)*p
    scale=max(abs(est),1e-9); return float(np.clip((x[-1]-est)/scale,-1,1))


def _wavelet_proxy(x):
    x=_safe(x)
    if len(x)<16:return 0.0
    # Haar-like multi-scale detail energy/sign; dependency-free approximation.
    d1=x[-2:]-x[-2:].mean(); d2=x[-4:]-x[-4:].mean(); d4=x[-8:]-x[-8:].mean()
    denom=np.std(x[-16:])+1e-9
    return float(np.clip((np.mean(d1)+0.5*np.mean(d2)+0.25*np.mean(d4))/denom,-1,1))


def _change_point(x):
    x=_safe(x)
    if len(x)<20:return 0.0
    n=len(x); best=0.0
    for k in range(max(5,n-40),n-5):
        a=x[:k]; b=x[k:]
        score=abs(np.mean(a)-np.mean(b))/(np.std(x)+1e-9)
        best=max(best,score)
    return float(np.clip(best/3.0,0,1))


def _markov(rets):
    r=_safe(rets)
    if len(r)<12:return 0.0
    q=np.quantile(r, [0.33,0.67]); states=np.digitize(r,q)
    cur=int(states[-1]); row=[]
    for nxt in range(3):
        den=np.sum(states[:-1]==cur); num=np.sum((states[:-1]==cur)&(states[1:]==nxt)); row.append(num/max(den,1))
    # positive minus negative transition probability
    return float(np.clip(row[2]-row[0],-1,1))


def _cointegration_proxy(logp):
    x=_safe(logp)
    if len(x)<20:return 0.0
    t=np.arange(len(x),dtype=float); slope=np.polyfit(t,x,1)[0]; resid=x-(slope*t+np.mean(x-slope*t)); sd=np.std(resid)
    return float(np.clip(-resid[-1]/(sd+1e-9),-1,1))


def _correlation(x, vol):
    x=_safe(x); v=_safe(vol)
    if len(x)<10 or np.std(x)<1e-12 or np.std(v)<1e-12:return 0.0
    return float(np.clip(np.corrcoef(x,v)[0,1],-1,1))


def _garch(ret):
    r=_safe(ret)
    if len(r)<20:return float(np.std(r))
    var=float(np.var(r[:10])); a=.08; b=.90; omega=max(float(np.var(r))*0.02,1e-10)
    for z in r[10:]: var=omega+a*z*z+b*var
    return float(np.sqrt(max(var,1e-12)))


def _monte_carlo(rets, horizon=12, paths=400, seed=7):
    r=_safe(rets)
    if len(r)<20:return 0.5
    mu=float(np.mean(r[-100:])); sig=float(np.std(r[-100:])+1e-9)
    rng=np.random.default_rng(seed)
    sims=np.sum(rng.normal(mu,sig,(paths,horizon)),axis=1)
    return float(np.clip(np.mean(sims>0),0,1))


def _bayesian(rets):
    r=_safe(rets)
    if len(r)<10:return 0.5
    pos=float(np.sum(r>0)); neg=float(np.sum(r<0)); return float((pos+1.0)/(pos+neg+2.0))


def compute_math_snapshot(close, high=None, low=None, volume=None, horizon=12, seed=7):
    c=_safe(close); n=len(c)
    if n<20:
        return {k:0.0 for k in MATH_FEATURES}
    r=c[1:]/np.maximum(c[:-1],1e-12)-1.0
    w=r[-120:]; lw=np.log(np.maximum(c[-120:],1e-12))
    vol=_safe(volume if volume is not None else np.ones(n))
    h=_safe(high if high is not None else c); l=_safe(low if low is not None else c)
    ar=_ols_ar(w,3); arima=float(np.clip(ar + np.mean(np.diff(w[-30:]))*20,-1,1))
    sarima=float(np.clip(arima + np.mean(w[-12:])*10,-1,1))
    g=_garch(w); mean=float(np.mean(w)); sd=float(np.std(w)+1e-9)
    mr=float(np.clip(-((w[-1]-mean)/sd)/3.0,-1,1))
    hurst=_hurst(lw)
    entropy=_entropy(w)
    fractal=float(np.clip(2.0-hurst,0,2)/2.0)
    wave=_wavelet_proxy(w)
    kal=_kalman(lw)
    cp=_change_point(w)
    mc=_monte_carlo(w,horizon,400,seed)
    bay=_bayesian(w)
    mark=_markov(w)
    coin=_cointegration_proxy(lw)
    corr=_correlation(w, np.abs(w))
    # Probability of movement is Bayesian + Markov + AR consensus.
    p_move=float(np.clip(0.45*bay+0.30*(mark+1)/2+0.25*(ar+1)/2,0,1))
    # Direction score is kept separate from P(TP*) so the model can learn both.
    direction=float(np.clip(.22*mark+.16*ar+.12*arima+.08*sarima+.10*mr+.08*wave+.08*kal+.08*coin+.08*(2*bay-1),-1,1))
    # Monte-Carlo target probabilities from a compact Gaussian return model.
    step=float(max(g,sd,1e-6)); mu=float(np.mean(w[-60:]))
    z1=(np.log(1.0+0.003)-mu*max(1,horizon))/(step*np.sqrt(max(1,horizon)))
    z2=(np.log(1.0+0.006)-mu*max(1,horizon))/(step*np.sqrt(max(1,horizon)))
    z3=(np.log(1.0+0.009)-mu*max(1,horizon))/(step*np.sqrt(max(1,horizon)))
    # normal survival without scipy
    normal_sf=lambda z: float(0.5*math.erfc(z/math.sqrt(2.0)))
    ptp1=float(np.clip(0.55*normal_sf(z1)+0.45*mc,0,1))
    ptp2=float(np.clip(0.55*normal_sf(z2)+0.45*mc,0,1))
    ptp3=float(np.clip(0.55*normal_sf(z3)+0.45*mc,0,1))
    psl=float(np.clip(1.0-max(0.0,(ptp1-0.05)),0,1))
    # A bounded signed mathematical consensus.
    consensus=float(np.clip(.16*mark+.10*(2*mc-1)+.10*direction+.08*ar+.08*arima+.06*sarima+
                             .08*(hurst-.5)*2+.08*mr+.06*wave+.06*kal+.06*coin+
                             .05*(0.5-entropy)*2+.05*(corr)+.06*(0.5-cp),-1,1))
    return {
      'math_markov':mark,'math_prob_move':p_move,'math_ar':ar,'math_arima':arima,'math_sarima':sarima,
      'math_garch':float(np.clip(g/(sd+1e-9),0,3)/3.0),'math_hurst':hurst,
      'math_mean_reversion':mr,'math_cointegration':coin,'math_correlation':corr,
      'math_entropy':entropy,'math_fractal':fractal,'math_wavelet':wave,'math_kalman':kal,
      'math_monte_carlo':mc,'math_bayesian':bay,'math_change_point':cp,
      'math_ptp1':ptp1,'math_ptp2':ptp2,'math_ptp3':ptp3,'math_psl':psl,
      'math_direction':direction,'math_consensus':consensus
    }

MATH_OUTPUTS = MATH_FEATURES + ['math_direction','math_consensus']
