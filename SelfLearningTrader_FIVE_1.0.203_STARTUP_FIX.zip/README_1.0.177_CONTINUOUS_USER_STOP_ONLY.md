# FIVE 1.0.177 — continuous background learning

- START activates a persistent desired-running state.
- Activity pause/close does not request service stop.
- Foreground service is sticky and requests automatic service restart.
- On next app start, the service is recovered automatically if the user did not press STOP.
- STOP writes `stop=true` and `user_stopped=true`; this blocks automatic recovery until START is pressed again.
- Battery-optimization exemption is requested when scanning starts/recovery is needed.
- Android force-stop / OEM hard-kill cannot be absolutely overridden by an app; the app requests the strongest supported background persistence.
