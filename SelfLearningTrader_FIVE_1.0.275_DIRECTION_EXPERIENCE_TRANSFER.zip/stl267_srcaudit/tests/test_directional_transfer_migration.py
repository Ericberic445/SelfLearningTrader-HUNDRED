import hashlib
import json
import shutil
from pathlib import Path

from app.core.engine import LearningEngine
from app.core.model import ModelManager


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _engine(tmp_path, assets):
    engine = LearningEngine.__new__(LearningEngine)
    engine.root = tmp_path
    engine.data = tmp_path / 'data'
    engine.data.mkdir(parents=True)
    engine.logs = tmp_path / 'logs'
    engine.logs.mkdir()
    engine.learning_audit = engine.data / 'learning_audit.jsonl'
    engine.challenger_root = engine.data / 'challenger_snapshot'
    engine.challenger_root.mkdir()
    (engine.challenger_root / 'champion.npz').write_bytes(b'old challenger snapshot')
    engine.mm = ModelManager(tmp_path)
    engine.mm._save(engine.mm.champion, engine.mm._new())
    engine.mm._write_json(engine.mm.meta, {'status': 'master_direction', 'old': True})
    engine.mm._write_json(engine.mm.learning_state, {
        'schema_version': 2, 'resolved_total': 1237, 'batch_size': 25,
        'lens_activation_resolved': 25, 'base_version': 115
    })
    engine.mm._write_json(engine.mm.shared_base, {'base_version': 115, 'master_observations': 1237})
    engine._directional_transfer_asset_root = lambda: assets
    engine._write_json(engine.data / 'training_batch_state.json', {
        'challenger_active': True, 'challenger_checked': False,
        'challenger_generation': 17, 'base_version': 115
    })
    return engine


def test_directional_transfer_installs_only_on_exact_source_and_archives_old_master(tmp_path):
    assets = tmp_path / 'assets'
    assets.mkdir()
    source = ModelManager(tmp_path / 'source')
    source_path = assets / 'source.npz'
    source._save(source_path, source._new())
    candidate_path = Path(__file__).resolve().parents[1] / 'app' / 'assets' / 'directional_transfer_candidate.npz'
    bundled_candidate = assets / 'directional_transfer_candidate.npz'
    shutil.copy2(candidate_path, bundled_candidate)
    manifest = {
        'manifest_version': 1,
        'expected_source_master_sha256': _sha(source_path),
        'candidate_sha256': _sha(bundled_candidate),
        'champion_meta': {'learning_type': 'verified_trade_direction_replay_transfer'},
        'validation': {'candidate_balanced_accuracy': 0.35}
    }
    (assets / 'directional_transfer_manifest.json').write_text(json.dumps(manifest), encoding='utf-8')
    engine = _engine(tmp_path / 'runtime', assets)
    # Replace the test runtime's source with the exact source fingerprint.
    shutil.copy2(source_path, engine.mm.champion)
    before = _sha(engine.mm.champion)
    result = engine._apply_directional_transfer_migration()
    assert result['status'] == 'directional_transfer_applied'
    assert _sha(engine.mm.champion) == _sha(bundled_candidate)
    assert _sha(engine.data / 'directional_transfer' / 'pre_transfer_champion.npz') == before
    assert (engine.data / 'directional_transfer' / 'pre_transfer_challenger_snapshot' / 'champion.npz').read_bytes() == b'old challenger snapshot'
    state = engine._training_state()
    assert state['challenger_active'] is False
    assert state['challenger_checked'] is True
    assert state['challenger_last_result'] == 'SUPERSEDED_BY_DIRECTION_TRANSFER'
    assert engine._apply_directional_transfer_migration()['status'] == 'directional_transfer_already_applied'


def test_directional_transfer_does_not_replace_a_different_live_master(tmp_path):
    assets = tmp_path / 'assets'
    assets.mkdir()
    candidate_path = Path(__file__).resolve().parents[1] / 'app' / 'assets' / 'directional_transfer_candidate.npz'
    bundled_candidate = assets / 'directional_transfer_candidate.npz'
    shutil.copy2(candidate_path, bundled_candidate)
    manifest = {
        'manifest_version': 1,
        'expected_source_master_sha256': 'not-the-live-hash',
        'candidate_sha256': _sha(bundled_candidate),
        'champion_meta': {}
    }
    (assets / 'directional_transfer_manifest.json').write_text(json.dumps(manifest), encoding='utf-8')
    engine = _engine(tmp_path / 'runtime', assets)
    before = _sha(engine.mm.champion)
    result = engine._apply_directional_transfer_migration()
    assert result['status'] == 'directional_transfer_source_mismatch'
    assert _sha(engine.mm.champion) == before
    assert not (engine.data / 'directional_transfer' / 'applied.json').exists()
