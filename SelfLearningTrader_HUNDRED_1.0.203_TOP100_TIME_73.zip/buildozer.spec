[app]
title = SelfLearningTrader Generational AI V15.3
package.name = hundred
package.domain = org.selflearningtrader
source.dir = app
source.include_exts = py,json,csv,md
version = 1.0.202
android.numeric_version = 10202
requirements = python3,kivy==2.3.1,numpy,certifi
orientation = portrait,landscape
fullscreen = 1
android.api = 34
android.minapi = 24
android.ndk = 28c
android.permissions = INTERNET,FOREGROUND_SERVICE,FOREGROUND_SERVICE_DATA_SYNC,POST_NOTIFICATIONS,WAKE_LOCK
android.archs = arm64-v8a
android.accept_sdk_license = True

p4a.fork = kivy
p4a.branch = v2026.05.09
p4a.local_recipes = p4a-recipes
services = scanner:services/scanner.py:foreground:sticky:foregroundServiceType=dataSync
# Use the current Kivy/p4a recipe stack with the supported Cython version

[buildozer]
log_level = 2
warn_on_root = 1
