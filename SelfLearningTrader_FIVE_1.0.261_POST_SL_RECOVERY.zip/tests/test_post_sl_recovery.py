import json
from pathlib import Path

import numpy as np

from app.core.post_sl_recovery import _recover_record, run_once, MARKER_NAME


class FakeExchange:
    def __init__(self, bars=None, error=False):
        self.bars = bars
        self.error = error

    def candles_between(self, tf, start, end):
        if self.error:
            raise OSError('network unavailable')
        return self.bars


def _bars(start, count=102):
    # KuCoin adapter returns timestamps in microseconds.
    t = np.asarray([(start + i * 300) * 1_000_000 for i in range(count)], dtype=np.int64)
    op = np.full(count, 100.0); hi = np.full(count, 101.0); lo = np.full(count, 99.0); cl = np.full(count, 100.0)
    return {'time': t, 'open': op, 'high': hi, 'low': lo, 'close': cl, 'volume': np.ones(count)}


def test_recovers_missing_sl_time_and_post_sl_tp_recovery():
    start = 1_800_000_000
    bars = _bars(start)
    # LONG SL at 95 in bar 10; TP1=105 is reached in the next three bars.
    bars['low'][10] = 94
    bars['high'][11] = 106
    item = {'id': 'p1', 'time': start, 'prediction': 'LONG', 'entry': 100, 'sl': 95,
            'tp1': 105, 'tp2': 110, 'tp3': 115, 'resolved': 1,
            'post_sl_recheck_pending': True}
    status, got = _recover_record(item, FakeExchange(bars))
    assert status == 'recovered'
    assert got['sl_event_time'] == start + 10 * 300
    assert got['post_sl_recovery'] is True
    assert got['post_sl_recovery_level'] == 'TP1'
    assert got['post_sl_recheck_pending'] is False


def test_network_error_is_retry_not_delete():
    item = {'id': 'p2', 'time': 1_800_000_000, 'prediction': 'LONG', 'sl': 95,
            'post_sl_recheck_pending': True}
    status, _ = _recover_record(item, FakeExchange(error=True))
    assert status == 'retry'


def test_run_once_removes_only_conclusively_unrecoverable_records(tmp_path, monkeypatch):
    logs = tmp_path / 'logs'; logs.mkdir()
    contract = 'ABCUSDTM'
    row = {'id': 'bad1', 'time': 1_800_000_000, 'prediction': 'LONG', 'entry': 100, 'sl': 90,
           'tp1': 110, 'tp2': 120, 'tp3': 130, 'resolved': 1, 'post_sl_recheck_pending': True}
    (logs / f'{contract}_pending.json').write_text(json.dumps([row]), encoding='utf-8')
    (logs / f'{contract}_predictions.json').write_text(json.dumps([row]), encoding='utf-8')

    # Full contiguous history but no SL touch => conclusive unrecoverable.
    bars = _bars(row['time'], count=102)
    class Factory:
        def __init__(self, symbol): pass
        def candles_between(self, tf, start, end): return bars
    monkeypatch.setattr('app.core.post_sl_recovery.KuCoin', Factory)
    report = run_once(tmp_path)
    assert report['removed'] == 1
    assert report['retry'] == 0
    assert json.loads((logs / f'{contract}_pending.json').read_text()) == []
    assert json.loads((logs / f'{contract}_predictions.json').read_text()) == []
    assert (tmp_path / MARKER_NAME).exists()


def test_retry_does_not_create_completion_marker(tmp_path, monkeypatch):
    logs = tmp_path / 'logs'; logs.mkdir()
    contract = 'ABCUSDTM'
    row = {'id': 'wait1', 'time': 1_800_000_000, 'prediction': 'LONG', 'sl': 90,
           'post_sl_recheck_pending': True}
    (logs / f'{contract}_pending.json').write_text(json.dumps([row]), encoding='utf-8')
    class Factory:
        def __init__(self, symbol): pass
        def candles_between(self, tf, start, end): raise OSError('offline')
    monkeypatch.setattr('app.core.post_sl_recovery.KuCoin', Factory)
    report = run_once(tmp_path)
    assert report['retry'] == 1
    assert not (tmp_path / MARKER_NAME).exists()
    assert json.loads((logs / f'{contract}_pending.json').read_text())[0]['post_sl_recheck_pending'] is True
