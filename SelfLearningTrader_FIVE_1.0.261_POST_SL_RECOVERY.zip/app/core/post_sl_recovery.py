"""One-time repair of legacy post-SL forecasts with a missing SL timestamp.

The routine is intentionally self-disabling: after every eligible record has
been recovered or conclusively proven unrecoverable, it writes a completion
marker and does no further work on later starts. Transient exchange/network
errors are never treated as proof that a record is unrecoverable.
"""
from pathlib import Path
import json
import math
import time

from .exchange import KuCoin
from .engine import _timestamp_seconds

MARKER_NAME = '.post_sl_recovery_v1_done.json'
RECHECK_BARS = 3
BAR_SECONDS = 300
MAX_LIFETIME_BARS = 96


def _read(path, default):
    try:
        value = json.loads(path.read_text(encoding='utf-8'))
        return value if isinstance(value, type(default)) else default
    except Exception:
        return default


def _write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.recovery.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
    tmp.replace(path)


def _first_sl_index(item, bars):
    direction = str(item.get('prediction', '')).upper()
    try:
        sl = float(item.get('sl'))
        entry_time = _timestamp_seconds(item.get('time', 0))
    except (TypeError, ValueError, OverflowError):
        return None
    if direction not in ('LONG', 'SHORT') or not math.isfinite(sl) or sl <= 0 or entry_time <= 0:
        return None
    times = [int(x) for x in bars['time']]
    highs = bars['high']; lows = bars['low']
    start = next((i for i, raw in enumerate(times) if _timestamp_seconds(raw) >= entry_time), None)
    if start is None:
        return None
    stop = min(len(times), start + MAX_LIFETIME_BARS + 1)
    for i in range(start, stop):
        touched = float(lows[i]) <= sl if direction == 'LONG' else float(highs[i]) >= sl
        if touched:
            return i
    return None


def _recover_record(item, exchange):
    """Return (status, updated_record); status is recovered/unrecoverable/retry."""
    if not isinstance(item, dict) or not item.get('post_sl_recheck_pending'):
        return 'skip', item
    sl_ts = _timestamp_seconds(item.get('sl_event_time') or 0)
    try:
        if sl_ts > 0:
            start = sl_ts - 2 * BAR_SECONDS
            end = sl_ts + (RECHECK_BARS + 2) * BAR_SECONDS
            bars = exchange.candles_between('5min', start, end)
            times = list(bars['time'])
            idx = min(range(len(times)), key=lambda i: abs(_timestamp_seconds(times[i]) - sl_ts))
        else:
            issue = _timestamp_seconds(item.get('time', 0))
            if issue <= 0:
                return 'unrecoverable', item
            # Forecasts expire after 8h. Fetch that complete lifecycle plus the
            # three post-SL candles needed by the recovery rule.
            end_time = issue + (MAX_LIFETIME_BARS + RECHECK_BARS + 2) * BAR_SECONDS
            bars = exchange.candles_between('5min', issue, end_time)
            raw_times = [_timestamp_seconds(x) for x in bars['time']]
            # Only conclude 'unrecoverable' after the full expected 8h window is
            # present and contiguous. Partial history/API truncation is retryable.
            if len(raw_times) < MAX_LIFETIME_BARS or raw_times[0] > issue + BAR_SECONDS or raw_times[-1] < issue + MAX_LIFETIME_BARS * BAR_SECONDS:
                return 'retry', item
            if any((raw_times[i] - raw_times[i - 1]) != BAR_SECONDS for i in range(1, len(raw_times))):
                return 'retry', item
            idx = _first_sl_index(item, bars)
            if idx is None:
                return 'unrecoverable', item
            sl_ts = _timestamp_seconds(bars['time'][idx])
            item['sl_event_time'] = sl_ts
            item['sl_event_index'] = int(idx)
        # Ensure three full candles after the SL candle are available.
        if idx + 1 + RECHECK_BARS > len(bars['time']):
            return 'retry', item
        direction = str(item.get('prediction', '')).upper()
        highs = bars['high']; lows = bars['low']
        a, b = idx + 1, idx + 1 + RECHECK_BARS
        levels = []
        for label in ('tp1', 'tp2', 'tp3'):
            try:
                value = float(item.get(label))
                if math.isfinite(value) and value > 0:
                    levels.append((label.upper(), value))
            except (TypeError, ValueError, OverflowError):
                pass
        hit = None
        for label, level in reversed(levels):
            crossed = any(float(highs[j]) >= level for j in range(a, b)) if direction == 'LONG' else any(float(lows[j]) <= level for j in range(a, b))
            if crossed:
                hit = label
                break
        item.update({
            'post_sl_recheck_pending': False,
            'post_sl_recheck_complete': True,
            'post_sl_recheck_bars': RECHECK_BARS,
            'post_sl_recovery': bool(hit),
            'post_sl_recovery_level': hit,
            'post_sl_recovery_bars': None,
            'verification_state': 'COMPLETED_SL_POST_RECHECK',
            'post_sl_recovery_rebuilt': True,
            'post_sl_recovery_rebuilt_at': int(time.time()),
        })
        if hit:
            item['direction_confirmed'] = True
            item['direction_target'] = direction
            item['direction_confirmation_source'] = 'POST_SL_RECOVERY'
            item['learning_interpretation'] = 'DIRECTION_RIGHT_ENTRY_TIMING_WRONG'
        return 'recovered', item
    except Exception:
        # Network/API failures are temporary uncertainty, not evidence of loss.
        return 'retry', item


def run_once(root, log_callback=None):
    """Recover or remove old pending post-SL records. Returns a compact report."""
    root = Path(root)
    marker = root / MARKER_NAME
    if marker.exists():
        return {'status': 'already_complete', 'recovered': 0, 'removed': 0, 'retry': 0}
    logs = root / 'logs'
    pending_paths = sorted(logs.glob('*_pending.json')) if logs.exists() else []
    prediction_paths = {p.stem.replace('_predictions', ''): p for p in logs.glob('*_predictions.json')} if logs.exists() else {}
    wanted = {}
    for path in pending_paths:
        contract = path.name[:-len('_pending.json')]
        rows = _read(path, [])
        if isinstance(rows, list):
            for row in rows:
                if isinstance(row, dict) and row.get('post_sl_recheck_pending'):
                    wanted.setdefault(contract, []).append((str(row.get('id') or ''), row))
    if not wanted:
        _write(marker, {'completed': True, 'completed_at': int(time.time()), 'recovered': 0, 'removed': 0})
        return {'status': 'complete', 'recovered': 0, 'removed': 0, 'retry': 0}

    recovered_ids, removed_ids, retry_ids = set(), set(), set()
    recovered = removed = retry = 0
    for contract, entries in wanted.items():
        exchange = KuCoin(contract)
        for pid, item in entries:
            if not pid:
                retry += 1
                retry_ids.add((contract, pid))
                continue
            status, updated = _recover_record(dict(item), exchange)
            key = (contract, pid)
            if status == 'recovered':
                recovered += 1; recovered_ids.add(key)
                # Update the canonical pending and prediction copies without
                # changing the original direction, confidence or price levels.
                ppath = logs / f'{contract}_pending.json'
                prows = _read(ppath, [])
                for row in prows:
                    if isinstance(row, dict) and str(row.get('id') or '') == pid:
                        row.update(updated)
                _write(ppath, prows)
                predpath = prediction_paths.get(contract)
                if predpath:
                    preds = _read(predpath, [])
                    changed = False
                    for row in preds:
                        if isinstance(row, dict) and str(row.get('id') or '') == pid:
                            row.update(updated); changed = True
                    if changed: _write(predpath, preds)
            elif status == 'unrecoverable':
                removed += 1; removed_ids.add(key)
            elif status == 'retry':
                retry += 1; retry_ids.add(key)
        if log_callback:
            try: log_callback(f'POST-SL recovery {contract}: processed {len(entries)}')
            except Exception: pass

    # Delete only conclusively unrecoverable records from all visible forecast
    # stores. Preserve known initial SL outcome/statistics in experience ledgers.
    if removed_ids:
        for path in pending_paths + list(prediction_paths.values()):
            contract = path.name.split('_')[0] if False else path.name.rsplit('_', 1)[0]
            rows = _read(path, [])
            if not isinstance(rows, list): continue
            kept = [r for r in rows if not (isinstance(r, dict) and (contract, str(r.get('id') or '')) in removed_ids)]
            if len(kept) != len(rows): _write(path, kept)
        for path in (root / 'top5_last100.json', root / 'data' / 'top5_last100.json',
                     root / 'top5_history.json', root / 'data' / 'top5_history.json'):
            rows = _read(path, [])
            if isinstance(rows, list):
                kept = [r for r in rows if not (isinstance(r, dict) and any(str(r.get('id') or '') == pid for _, pid in removed_ids))]
                if len(kept) != len(rows): _write(path, kept)

    # Do not permanently disable while transient network/API failures remain.
    if retry == 0:
        _write(marker, {'completed': True, 'completed_at': int(time.time()), 'recovered': recovered, 'removed': removed})
    return {'status': 'complete' if retry == 0 else 'retry_pending', 'recovered': recovered, 'removed': removed, 'retry': retry}
