# SelfLearningTrader FIVE 1.0.224

Current release: **ledger reconciliation + validated market-regime gate + paired Challenger controls**.

## Current learning architecture

- One learning **Master**. A frozen Challenger snapshot is used only as a control baseline; it never trains or replaces Master.
- First **25 completed forecasts**: Master only.
- After the first 25 and Master update: the common Master Base is exposed to **C1/C2/C3**.
- C1/C2/C3 are **fixed mathematical lenses**. They never train, never keep adaptive weights, and never replace Master.
- Normal Master updates are batched by **25 newly resolved, eligible forecast IDs**. The Challenger control cohort is generation-tagged and scored only on forecasts actually issued under that frozen snapshot. Auxiliary observation batches do not restart this control cycle.
- Master learns from verified outcomes and its selector learns from resolved forecast records; C1/C2/C3 remain fixed mathematical lenses and never train.

## Trade-outcome learning

Master records the complete path of each LONG/SHORT forecast:

- Initial SL before TP1 = real trading loss.
- TP1 = successful forecast.
- After TP1, protection moves to Entry; an exit at Entry remains a successful TP1 result.
- TP2 = successful TP2 result; after TP2 protection moves to TP1.
- An exit at TP1 after TP2 remains a successful TP2 result.
- TP3 = super-successful milestone.
- Price continuing above TP3 is stored as **TP3+**, including the extension beyond TP3.
- TP milestones are never downgraded to an SL because of a later protected exit.

## Post-SL analysis

An initial SL remains an actual losing trade and is never rewritten as a win. The next **3 five-minute candles** are nevertheless checked separately. If price subsequently reaches TP1/TP2/TP3 in the predicted direction, Master records that the **direction was confirmed after the stop** and distinguishes this from a genuinely wrong direction.

The engine also records event context around the stop, recovery and protected exits (volume, volume ratio, candle range/body/wicks and timing) so Master can learn why continuation failed or resumed.

## Global experience

Learning memory is symbol-safe and keyed by **contract + timestamp + prediction_id**. Completed experience from all contracts is used for automatic Master retraining. WAIT is history only and never enters the TP/SL verification queue.

The replay memory stores both:

- auxiliary direction target (SHORT / WAIT / LONG), and
- primary trade-outcome target (INITIAL_SL / TP1 / TP2 / TP3 / TP3_PLUS).

## Validation and audit

After each 25-result retraining batch, the project recomputes held-out validation where enough global data exists and writes detailed learning events to `data/learning_audit.jsonl`.

## Android build

- Package ID: `org.selflearningtrader.selflearningtrader`
- Version: `1.0.224` / Android version code `10224`
- Source: `app/`
- Android API 34, min API 24, arm64-v8a
- Foreground scanner service and existing Stop/Resume/background functionality retained.
- UI layout is not intentionally redesigned in this release.

See `README_1.0.186_WAIT_CONTROL_AND_LENS_OUTCOMES.md` for the release details and the older README/V13/V14/V15 files for historical changes.


## Version 1.0.216 — scan worker reuse and validation audit

- Reuses one KuCoin HTTP client and one engine instance per worker thread during pre-scan and deep model analysis. The Stage-25 and active-forecast recheck workers also reuse their thread-local exchange client. This reduces repeated TLS/client/engine initialization without sharing mutable engines across workers or changing ranking.
- Historical experience validation now uses a chronological timestamp split with an embargo measured in time, not only a fixed number of rows. It reports held-out performance against a majority-class baseline.
- Initial training metadata now records baseline balanced accuracy, directional precision, action rate, and model-minus-baseline deltas.
- Added regression coverage for second/millisecond/microsecond candle timestamps, timestamp-based validation embargo, readiness gates, and Stage-25 client reuse.
- **Not changed:** UI, TP/SL outcome tracking, point-7 same-candle logic, TOP-5 selection policy, background service/OFF-resume behavior, or saved archives.
- Verification: `python -m compileall -q app tests`; `PYTHONPATH=. pytest -q` — 56 passed, 9 subtests passed. Android/GitHub APK build and a live full-market timing benchmark have not been run here; runtime timings are already emitted by the app and should be confirmed from a real scan log.

## Version 1.0.214 — background recovery and scan-cycle fixes

- Bounds runtime log tails to 40 lines / 600 characters and serializes state writes, preventing recursive log-tail growth and heartbeat file contention.
- Heartbeat timeout diagnostics now record only compact state fields and are rate-limited.
- Unexpected service errors/stops and stale heartbeats trigger repeated recovery with bounded backoff until the user explicitly presses OFF.
- Stage-25 math validation runs with a bounded pool of three workers using the same indicators, timeframes, and ranking calculations; progress continues while math validation runs, and OFF cancellation is checked.
- UI layout is unchanged; learning and forecast archives are not modified by this source patch.


## Version 1.0.222 — learned market-regime classification

- Adds a separate four-state market-regime head: `TREND_UP`, `TREND_DOWN`, `RANGE`, and `TRANSITION`. Existing Master direction/outcome model feature shapes remain unchanged.
- Builds causal regime features (directional efficiency/persistence, reversal rate, range width/position, volatility ratio and higher-timeframe alignment) from closed candles. Future path is used only to label training examples, never as an input feature.
- Accumulates a deduplicated, bounded training pool across contracts and trains only after enough rows and distinct contracts are present. Validation is chronological with a horizon-sized purge; per-class metrics and majority baseline are saved.
- When a trained regime head is available, RANGE/TRANSITION increases abstention pressure and raises the LONG/SHORT confidence threshold. Until then, a transparent conservative fallback is used; insufficient features do not invent a learned classification.
- Prediction diagnostics now include regime, class probabilities, confidence, source and WAIT boost.
- UI, original forecast IDs/Entry/SL/TP, existing direction model, TOP-5 policy and background-service controls are unchanged.
- Verification: `python -m compileall -q app tests`; `PYTHONPATH=. pytest -q` — 127 passed, 9 subtests passed. Android APK build and live market validation are not performed in this local test environment.


## Version 1.0.224 — learning ledger and market-regime validation fixes

- A canonical set of unique, eligible resolved prediction IDs now drives the retrain counter, audit reconciliation and current archive statistics. Historical cumulative counters remain separate from current archive sizes.
- Initial-SL forecasts remain excluded from active training while their post-SL recheck is pending. Existing invalid replay rows are preserved in a quarantine archive, then can be reintroduced only after the source prediction becomes eligible.
- Challenger generations missing from older state files are migrated and tagged in both prediction history and pending resolver copies. A control comparison waits for 25 fully paired outcomes; incomplete cohorts do not become a false tie or winner. A bounded cohort size prevents permanent retraining stalls.
- Market-regime validation now reports accuracy, balanced accuracy, per-class precision/recall/F1 and the chronological purge. A regime model is accepted for inference only if it beats the majority baseline, meets a balanced-accuracy threshold and identifies both trend directions. Unvalidated fallback scores are diagnostic only and trigger a conservative WAIT guard instead of a confident RANGE label.
- Independent direction validation now reports per-class SHORT/WAIT/LONG metrics and explicit feature-imputation counts. Non-finite features are neutral-imputed identically for training and held-out evaluation.
- UI and layout are unchanged; original forecast IDs, direction, Entry, SL, TP and horizon are unchanged.
- Verification: `python -m compileall -q app tests`; `PYTHONPATH=. pytest -q` — 135 passed, 9 subtests passed. Android APK build and live-device validation have not been performed in this environment.

## Version 1.0.223 — timestamp, resolved-counter and Challenger-cycle fixes

- Normalizes each timestamp independently to Unix seconds when reading/writing global replay memory, including mixed seconds/milliseconds/microseconds archives. The migration is persisted and recorded in `timestamp_normalization_v1.json`.
- Chronological validation and regime validation normalize mixed-unit timestamps per row before splitting, so the purge gap remains expressed in seconds.
- Training counters, training-batch slices and selector updates use one deduplicated set of eligible resolved forecast IDs in resolution-time order. Stable ID checkpoints prevent late post-SL resolutions from shifting numeric slices or being skipped/retrained twice.
- Auxiliary observation batches no longer force an independent Master retrain or reset the Challenger cycle. They remain pending until the next normal resolved-forecast batch.
- Challenger control rows are tagged with a generation and only forecasts actually issued under that generation can be paired. An incomplete cohort is logged as incomplete rather than falsely scored as a tie; missing paired outcomes are excluded and insufficient sample counts cannot declare a winner.
- UI and original forecast Entry/SL/TP lifecycle are unchanged.
- Verification: `python -m py_compile app/core/engine.py app/core/model.py app/services/scanner.py`; `PYTHONPATH=. pytest -q` — see release verification after final test run. Android APK build and live-market validation are not performed here.
