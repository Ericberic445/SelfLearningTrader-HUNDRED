from pathlib import Path
import json, time
import numpy as np
from .features import FEATURES

NAMES = {0: 'SHORT', 1: 'WAIT', 2: 'LONG'}
OUTCOME_NAMES = {
    0: 'INITIAL_SL',
    1: 'TP1',
    2: 'TP2',
    3: 'TP3',
    4: 'TP3_PLUS',
}
ACTOR_NAMES = {0: 'MASTER', 1: 'C1', 2: 'C2', 3: 'C3'}


class NumpyClassifier:
\
\
    def _outcome_percentages(self, rows):
        """Calculate current Master probabilities from verified historical outcomes."""
        counts = {"TP1": 0, "TP2": 0, "TP3": 0, "SL": 0, "WAIT_CORRECT": 0,
                  "MISSED_LONG": 0, "MISSED_SHORT": 0}
        total = 0
        for row in rows or []:
            outcome = str((row or {}).get("outcome", (row or {}).get("result", ""))).upper()
            if outcome in counts:
                counts[outcome] += 1
                total += 1
        if not total:
            return {k: 0.0 for k in counts}
        return {k: round(v * 100.0 / total, 2) for k, v in counts.items()}

    def _historical_retraining_policy(self):
        """Return the policy for rebuilding Master from validated historical experience.
        Old model weights are never treated as ground truth. Historical rows are
        revalidated against the current outcome rules before reuse.
        """
        return {
            "reset_old_master_weights": True,
            "reuse_validated_historical_experience": True,
            "revalidate_outcomes_before_training": True,
            "exclude_unverifiable_legacy_rows": True,
            "selector_uses_only_verified_lens_outcomes": True,
        }

    def _record_master_retrain_cycle(self, state=None):
        state = state if isinstance(state, dict) else getattr(self, "state", {})
        n = int(state.get("master_retrain_cycles", 0) or 0) + 1
        state["master_retrain_cycles"] = n
        state["last_master_retrain_cycle"] = n
        return n

    def __init__(self, n_features, n_classes=3):
        self.n_features = n_features
        self.n_classes = n_classes
        self.weights = np.zeros((n_features, n_classes))
        self.bias = np.zeros(n_classes)
        self.means = np.zeros(n_features)
        self.stds = np.ones(n_features)

    def _class_weights(self, y, class_weights=None):
        if class_weights is not None:
            return np.asarray(class_weights, float)
        counts = np.bincount(y, minlength=self.n_classes).astype(float)
        w = np.ones(self.n_classes, float)
        for c in range(self.n_classes):
            if counts[c] > 0:
                w[c] = 1.0 / np.sqrt(counts[c])
        return w * self.n_classes / max(np.sum(w), 1e-12)

    def fit(self, X, y, epochs=300, learning_rate=.02, l2=.0005, class_weights=None, sample_weights=None):
        X = np.asarray(X, float)
        y = np.asarray(y, int)
        X = np.nan_to_num(X, nan=0, posinf=0, neginf=0)
        self.means = np.mean(X, axis=0)
        self.stds = np.std(X, axis=0)
        self.stds[self.stds < 1e-8] = 1
        return self._fit_normalized(X, y, epochs, learning_rate, l2, class_weights, sample_weights)

    def fit_incremental(self, X, y, epochs=120, learning_rate=.008, l2=.0005, sample_weights=None):
        X = np.asarray(X, float)
        y = np.asarray(y, int)
        X = np.nan_to_num(X, nan=0, posinf=0, neginf=0)
        if len(X) == 0:
            return self
        if len(self.means) != self.n_features or not np.all(np.isfinite(self.means)):
            self.means = np.mean(X, axis=0)
            self.stds = np.std(X, axis=0)
            self.stds[self.stds < 1e-8] = 1
        return self._fit_normalized(X, y, epochs, learning_rate, l2, None, sample_weights)

    def _fit_normalized(self, X, y, epochs, learning_rate, l2, class_weights=None, sample_weights=None):
        if len(X) == 0:
            return self
        Z = (X - self.means) / np.where(np.abs(self.stds) < 1e-8, 1, self.stds)
        n = max(1, len(Z))
        Y = np.zeros((len(y), self.n_classes))
        Y[np.arange(len(y)), y] = 1
        w = self._class_weights(y, class_weights)
        sw = np.asarray(sample_weights, float) if sample_weights is not None else np.ones(len(y), float)
        if len(sw) != len(y):
            sw = np.ones(len(y), float)
        sw = np.clip(sw, 0.15, 5.0)
        for _ in range(max(1, int(epochs))):
            s = Z @ self.weights + self.bias
            s -= np.max(s, axis=1, keepdims=True)
            p = np.exp(np.clip(s, -50, 50))
            p /= np.sum(p, axis=1, keepdims=True)
            e = (p - Y) * w[np.clip(y, 0, self.n_classes - 1), None] * sw[:, None]
            self.weights -= learning_rate * ((Z.T @ e) / n + l2 * self.weights)
            self.bias -= learning_rate * np.mean(e, axis=0)
        return self

    def predict_proba(self, X):
        X = np.nan_to_num(np.asarray(X, float), nan=0, posinf=0, neginf=0)
        Z = (X - self.means) / np.where(np.abs(self.stds) < 1e-8, 1, self.stds)
        s = Z @ self.weights + self.bias
        s -= np.max(s, axis=1, keepdims=True)
        p = np.exp(np.clip(s, -50, 50))
        return p / np.sum(p, axis=1, keepdims=True)

    def predict(self, X):
        return np.argmax(self.predict_proba(X), axis=1)


class ModelManager:
    """FIVE architecture: one learning Master plus three fixed mathematical lenses.

    The Master has three complementary memories/heads:
      * champion.npz      - direction head (SHORT / WAIT / LONG),
      * outcome_model.npz - trade-outcome head (SL -> TP1 -> TP2 -> TP3+),
      * master_decision.npz - Master-owned selector that learns which actor
        (Master/C1/C2/C3) is more trustworthy in a given market context.

    C1/C2/C3 are deterministic mathematical lenses. They never train, never
    change their own weights, and never keep adaptive reliability state.
    """

    META_CONTEXT = [
        'trend', 'volatility', 'atrpct', 'rsi', 'bbpos', 'volz',
        'trend_15', 'trend_1h', 'trend_4h', 'trend_1d',
        'book_imbalance', 'oi_change', 'funding', 'liquidation_bias'
    ]
    META_NAMES = (
        ['master_p_short', 'master_p_wait', 'master_p_long'] +
        [f'c{i}_p_short' for i in (1, 2, 3)] +
        [f'c{i}_p_wait' for i in (1, 2, 3)] +
        [f'c{i}_p_long' for i in (1, 2, 3)] +
        ['conflict_m_c1', 'conflict_m_c2', 'conflict_m_c3', 'lens_agreement', 'math_consensus'] +
        [f'perf_{a}_{k}' for a in ('master', 'c1', 'c2', 'c3') for k in ('success', 'outcome', 'recovery')] +
        META_CONTEXT
    )
    SELECTOR_SCHEMA_VERSION = 2
    MODEL_SCHEMA_VERSION = 2
    OUTCOME_NAMES = OUTCOME_NAMES

    def __init__(self, root, symbol='XBTUSDTM', config=None):
        self.root = Path(root)
        self.models = self.root / 'models_v8_self_learning' / 'GLOBAL'
        self.models.mkdir(parents=True, exist_ok=True)
        self.champion = self.models / 'champion.npz'
        self.meta = self.models / 'champion.json'
        self.outcome_model = self.models / 'outcome_model.npz'
        self.outcome_meta = self.models / 'outcome_model.json'
        self.generation_state = self.models / 'generation_state.json'
        self.generation_history = self.models / 'generation_history.json'
        self.master_decision = self.models / 'master_decision.npz'
        self.master_decision_meta = self.models / 'master_decision.json'
        self.shared_base = self.models / 'shared_master_base.json'
        self.learning_state = self.models / 'master_learning_state.json'
        self.lens_performance = self.models / 'master_lens_performance.json'
        self.meta_experience = Path(root) / 'data' / 'master_decision_experience.npz'
        self.meta_experience.parent.mkdir(parents=True, exist_ok=True)
        self.config = config or {}
        self.symbol = symbol

    def _new(self):
        return NumpyClassifier(len(FEATURES), 3)

    def _new_outcome(self):
        return NumpyClassifier(len(FEATURES), 5)

    def _new_decision(self):
        return NumpyClassifier(len(self.META_NAMES), 4)

    def _save(self, path, m):
        path = Path(path)
        tmp = path.with_name(path.name + '.tmp.npz')
        np.savez(tmp, weights=m.weights, bias=m.bias, means=m.means, stds=m.stds)
        tmp.replace(path)

    def _load_path(self, path, kind='direction'):
        if not Path(path).exists():
            return None
        try:
            z = np.load(path)
            if kind == 'outcome':
                m = self._new_outcome()
            elif kind == 'selector':
                m = self._new_decision()
            else:
                m = self._new()
            shape = tuple(z['weights'].shape)
            expected = (m.n_features, m.n_classes)
            if shape == expected:
                m.weights = z['weights']; m.bias = z['bias']; m.means = z['means']
                m.stds = np.where(np.abs(z['stds']) < 1e-8, 1, z['stds'])
                return m
            return None
        except Exception:
            return None

    def _read_json(self, path, default):
        try:
            return json.loads(Path(path).read_text(encoding='utf-8')) if Path(path).exists() else default
        except Exception:
            return default

    def _write_json(self, path, obj):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + '.tmp')
        tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')
        tmp.replace(path)

    def _learning_state(self):
        default = {
            'schema_version': self.MODEL_SCHEMA_VERSION,
            'resolved_total': 0,
            'batch_size': 25,
            'lens_activation_resolved': 25,
            'base_version': 0,
            'challenger_enabled': False,
            'generation_competition_enabled': False,
        }
        state = self._read_json(self.learning_state, default)
        if not isinstance(state, dict):
            state = dict(default)
        for k, v in default.items():
            state.setdefault(k, v)
        return state

    def update_learning_state(self, resolved_total=None, base_version=None):
        state = self._learning_state()
        if resolved_total is not None:
            state['resolved_total'] = int(resolved_total)
        if base_version is not None:
            state['base_version'] = int(base_version)
        state['schema_version'] = self.MODEL_SCHEMA_VERSION
        state['batch_size'] = int(self.config.get('retrain_batch_size', 25))
        state['lens_activation_resolved'] = int(self.config.get('lens_activation_resolved', 25))
        state['challenger_enabled'] = False
        state['generation_competition_enabled'] = False
        state['updated'] = int(time.time())
        self._write_json(self.learning_state, state)
        self._write_json(self.generation_state, {
            'generation': 1, 'master_resolved_total': int(state.get('resolved_total',0)),
            'competition_enabled': False, 'challenger_enabled': False,
            'architecture': 'MASTER_FIXED_BASE_PLUS_3_FIXED_LENSES', 'updated': int(time.time())
        })
        return state

    def _load_lens_performance(self):
        default = {
            'schema_version': 1,
            'actors': {
                'master': {'n': 0, 'success': 0, 'outcome_sum': 0.0, 'recovery': 0, 'tp1': 0, 'tp2': 0, 'tp3': 0, 'tp3_plus': 0, 'sl': 0},
                'c1': {'n': 0, 'success': 0, 'outcome_sum': 0.0, 'recovery': 0, 'tp1': 0, 'tp2': 0, 'tp3': 0, 'tp3_plus': 0, 'sl': 0},
                'c2': {'n': 0, 'success': 0, 'outcome_sum': 0.0, 'recovery': 0, 'tp1': 0, 'tp2': 0, 'tp3': 0, 'tp3_plus': 0, 'sl': 0},
                'c3': {'n': 0, 'success': 0, 'outcome_sum': 0.0, 'recovery': 0, 'tp1': 0, 'tp2': 0, 'tp3': 0, 'tp3_plus': 0, 'sl': 0},
            },
            'updated': 0,
        }
        state = self._read_json(self.lens_performance, default)
        if not isinstance(state, dict):
            state = default
        state.setdefault('actors', {})
        for actor in ('master', 'c1', 'c2', 'c3'):
            q = state['actors'].setdefault(actor, {})
            for k, v in default['actors'][actor].items():
                q.setdefault(k, v)
        return state

    def _performance_features(self):
        state = self._load_lens_performance()
        vals = []
        for actor in ('master', 'c1', 'c2', 'c3'):
            q = state['actors'][actor]
            n = float(q.get('n', 0))
            vals.extend([
                float(q.get('success', 0)) / max(1.0, n),
                float(q.get('outcome_sum', 0.0)) / max(1.0, n) / 4.0,
                float(q.get('recovery', 0)) / max(1.0, n),
            ])
        return vals

    def _scores(self, y, p):
        acc = float(np.mean(p == y)) if len(y) else 0.0
        per = []
        for c in range(int(np.max(y) + 1) if len(y) else 0):
            mask = y == c
            per.append(float(np.mean(p[mask] == c)) if np.any(mask) else 0.0)
        bal = float(np.mean(per)) if per else 0.0
        action = (p != 1) if len(p) else np.asarray([], dtype=bool)
        action_count = int(np.sum(action))
        directional_precision = float(np.mean(p[action] == y[action])) if action_count else 0.0
        action_rate = float(np.mean(action)) if len(p) else 0.0
        return acc, bal, per, directional_precision, action_rate

    def generation_info(self):
        state = self._learning_state()
        return {
            'generation': 1,
            'master_resolved_total': int(state.get('resolved_total', 0)),
            'architecture': 'MASTER_FIXED_BASE_PLUS_3_FIXED_LENSES',
            'lenses': ['C1_MARKET_REGIME', 'C2_DIRECTION_ENTRY', 'C3_TP_SL_RISK'],
            'decision_model_ready': self._selector_ready(),
            'outcome_model_ready': self._outcome_ready(),
            'shared_base_present': self.shared_base.exists(),
            'lens_learning_present': False,
            'lens_training_enabled': False,
            'challenger_enabled': False,
            'generation_competition_enabled': False,
        }

    def has_champion(self):
        return self.champion.exists() and self._load_path(self.champion, 'direction') is not None

    def _selector_ready(self):
        meta = self._read_json(self.master_decision_meta, {})
        return bool(meta.get('schema_version') == self.SELECTOR_SCHEMA_VERSION and self._load_path(self.master_decision, 'selector') is not None)

    def _outcome_ready(self):
        meta = self._read_json(self.outcome_meta, {})
        return bool(meta.get('schema_version') == self.MODEL_SCHEMA_VERSION and self._load_path(self.outcome_model, 'outcome') is not None)

    def train(self, x, min_rows=500, test_fraction=.2):
        n = len(x['target'])
        if n < min_rows:
            raise ValueError(f'Not enough training rows: {n}. Minimum is {min_rows}.')
        X = np.column_stack([x[f] for f in FEATURES]); y = np.asarray(x['target'], int)
        cut = max(1, min(n - 1, int(n * (1 - test_fraction))))
        trX, teX = X[:cut], X[cut:]; trY, teY = y[:cut], y[cut:]
        m = self._new().fit(trX, trY)
        pred = m.predict(teX)
        acc, bal, per, dp, ar = self._scores(teY, pred)
        self._save(self.champion, m)
        stamp = time.strftime('%Y%m%d_%H%M%S')
        meta = {
            'schema_version': self.MODEL_SCHEMA_VERSION,
            'engine': 'numpy_softmax_v10_master_multitask_fixed_lenses',
            'generation': 1,
            'accuracy': acc,
            'balanced_accuracy': bal,
            'class_accuracy': per,
            'directional_precision': dp,
            'action_rate': ar,
            'rows': n,
            'train_rows': cut,
            'test_rows': len(teY),
            'created': stamp,
            'feature_count': len(FEATURES),
            'features': FEATURES,
            'accepted': True,
            'status': 'master_direction',
            'learning_type': 'initial_bootstrap',
            'target_note': 'Direction is auxiliary to the trade-outcome head; sample weighting is based on actual TP/SL outcome.',
        }
        self._write_json(self.meta, meta)
        self.update_learning_state(resolved_total=self._learning_state().get('resolved_total', 0), base_version=0)
        return meta

    def train_master_incremental(self, x, min_rows=25):
        n = len(x['target'])
        if n < min_rows:
            return {'status': 'not_enough_rows', 'rows': n}
        m = self._load_path(self.champion, 'direction')
        if m is None:
            return self.train(x, max(500, min_rows), .2)
        X = np.column_stack([x[f] for f in FEATURES]); y = np.asarray(x['target'], int)
        sw = np.asarray(x.get('sample_weight', np.ones(n, float)), float)
        m.fit_incremental(
            X, y,
            epochs=int(self.config.get('master_epochs', 40)),
            learning_rate=float(self.config.get('master_learning_rate', .004)),
            l2=float(self.config.get('master_l2', .0005)),
            sample_weights=sw,
        )
        self._save(self.champion, m)
        meta = self._read_json(self.meta, {})
        meta.update({
            'schema_version': self.MODEL_SCHEMA_VERSION,
            'status': 'master_direction',
            'learning_type': 'continuous_incremental_trade_outcome_weighted',
            'last_retrain': int(time.time()),
            'rows': n,
            'target_note': 'Direction is auxiliary; real trade outcome drives sample weighting and the separate outcome head.',
        })
        self._write_json(self.meta, meta)
        return {'status': 'master_updated', 'rows': n}

    def _softmax3(self, logits):
        z = np.asarray(logits, float); z -= np.max(z)
        e = np.exp(np.clip(z, -30, 30))
        return e / max(np.sum(e), 1e-12)

    def _rowv(self, row, name):
        try:
            if name in row:
                return float(np.asarray(row.get(name, [0.0])).reshape(-1)[0])
            feat = row.get('features') or {}
            return float(feat.get(name, 0.0))
        except Exception:
            return 0.0

    @staticmethod
    def outcome_label(item):
        if item.get('tp3_hit'):
            return 4 if float(item.get('max_extension_beyond_tp3_pct', item.get('post_tp3_extension', 0.0)) or 0.0) > 0 else 3
        if item.get('tp2_hit'):
            return 2
        if item.get('tp1_hit'):
            return 1
        if item.get('initial_sl_failure') or (item.get('sl_hit') and not item.get('tp1_hit')):
            return 0
        return -1

    @staticmethod
    def outcome_score(item):
        y = ModelManager.outcome_label(item)
        return max(0, y)

    def _fixed_lens(self, master, row, math_snapshot=None):
        """Three deterministic lenses. No lens state, no adaptive weights."""
        p = np.asarray(master, float); lp = np.log(np.clip(p, 1e-6, 1.0))
        trend = np.tanh(np.mean([self._rowv(row, k) for k in ('trend', 'trend_15', 'trend_1h', 'trend_4h', 'trend_1d')]) * 18.0)
        vol = float(np.clip(self._rowv(row, 'volatility') * 80.0, 0.0, 2.0))
        volz = float(np.tanh(self._rowv(row, 'volz') / 3.0))
        rsi = float(np.clip((self._rowv(row, 'rsi') - 50.0) / 25.0, -2, 2))
        bb = float(np.clip((self._rowv(row, 'bbpos') - 0.5) * 2.0, -2, 2))
        imb = float(np.tanh(self._rowv(row, 'book_imbalance')))
        oi = float(np.tanh(self._rowv(row, 'oi_change')))
        funding = float(np.tanh(self._rowv(row, 'funding') * 50.0))
        liq = float(np.tanh(self._rowv(row, 'liquidation_bias')))
        math_snapshot = math_snapshot or row.get('math_snapshot') or {}
        groups = {
            'c1': ['math_markov', 'math_hurst', 'math_entropy', 'math_fractal', 'math_wavelet', 'math_change_point'],
            'c2': ['math_ar', 'math_arima', 'math_sarima', 'math_mean_reversion', 'math_cointegration', 'math_correlation', 'math_bayesian', 'math_kalman'],
            'c3': ['math_garch', 'math_monte_carlo', 'math_prob_move', 'math_ptp1', 'math_ptp2', 'math_ptp3', 'math_psl'],
        }
        def group_score(key):
            vals = []
            for name in groups[key]:
                if name not in math_snapshot:
                    continue
                v = float(math_snapshot[name])
                if name in ('math_prob_move', 'math_monte_carlo', 'math_bayesian', 'math_ptp1', 'math_ptp2', 'math_ptp3', 'math_psl'):
                    v = 2 * v - 1
                elif name in ('math_hurst', 'math_fractal', 'math_entropy', 'math_garch', 'math_change_point'):
                    v = (v - 0.5) * 2
                vals.append(float(np.clip(v, -1, 1)))
            return float(np.mean(vals)) if vals else 0.0

        s1, s2, s3 = group_score('c1'), group_score('c2'), group_score('c3')
        # Fixed coefficients are part of the lens definition, not learned state.
        c1 = self._softmax3(lp + np.array([-(0.55 * trend + 0.25 * s1), 0.12 * vol + 0.10 * volz, (0.55 * trend + 0.25 * s1)]))
        directional = 0.45 * trend + 0.18 * rsi + 0.15 * bb + 0.12 * imb + 0.10 * oi + 0.25 * s2
        c2 = self._softmax3(lp + np.array([-directional, 0.05 * vol, directional]))
        risk_signal = 0.30 * trend + 0.15 * imb + 0.15 * oi - 0.20 * abs(funding) - 0.20 * abs(liq) + 0.35 * s3
        confidence = max(0.0, min(1.0, 1.0 - vol * 0.25))
        c3 = self._softmax3(lp + np.array([-risk_signal * confidence, 0.10 * vol, -0.10 * vol + risk_signal * confidence]))
        return {
            'c1': {'probs': c1}, 'c2': {'probs': c2}, 'c3': {'probs': c3},
            'shared_base_version': int(self._learning_state().get('base_version', 0)),
            'specialization_scores': {'c1': s1, 'c2': s2, 'c3': s3},
            'reliability': {'c1': 1.0, 'c2': 1.0, 'c3': 1.0},
        }

    def _selector_vector(self, row, master, lenses, math_consensus=0.0, performance_snapshot=None):
        vals = list(np.asarray(master, float))
        for k in ('c1', 'c2', 'c3'):
            vals.extend(list(np.asarray(lenses[k]['probs'], float)))
        for k in ('c1', 'c2', 'c3'):
            vals.append(abs(float(master[2]) - float(lenses[k]['probs'][2])))
        vals.append(float(np.std([float(lenses[k]['probs'][2]) for k in ('c1', 'c2', 'c3')])))
        vals.append(float(math_consensus or 0.0))
        perf=performance_snapshot if performance_snapshot is not None else self._performance_features()
        vals.extend([float(v) for v in perf])
        vals.extend([self._rowv(row, k) for k in self.META_CONTEXT])
        return np.asarray(vals, float)

    def predict_bundle(self, row, math_consensus=0.0, math_snapshot=None):
        base = self._load_path(self.champion, 'direction')
        if base is None:
            raise FileNotFoundError('Нет совместимой обученной модели.')
        X = np.column_stack([np.asarray(row[f], float).reshape(-1) for f in FEATURES])
        master = base.predict_proba(X)[0]
        state = self._learning_state()
        active = int(state.get('resolved_total', 0)) >= int(state.get('lens_activation_resolved', 25)) and int(state.get('base_version', 0)) >= 1
        if active:
            lenses = self._fixed_lens(master, row, math_snapshot)
        else:
            neutral = np.asarray(master, float)
            lenses = {k: {'probs': neutral.copy()} for k in ('c1', 'c2', 'c3')}
            lenses.update({'shared_base_version': int(state.get('base_version', 0)), 'specialization_scores': {'c1': 0.0, 'c2': 0.0, 'c3': 0.0}, 'reliability': {'c1': 1.0, 'c2': 1.0, 'c3': 1.0}})

        outcome_probs = None
        outcome_model = self._load_path(self.outcome_model, 'outcome')
        if outcome_model is not None:
            outcome_probs = outcome_model.predict_proba(X)[0]

        selector = None
        selector_probs = None
        performance_snapshot = self._performance_features()
        if active and self._selector_ready():
            vec = self._selector_vector(row, master, lenses, math_consensus, performance_snapshot)
            selector = self._load_path(self.master_decision, 'selector')
            selector_probs = selector.predict_proba(vec.reshape(1, -1))[0]
            actors = [master, lenses['c1']['probs'], lenses['c2']['probs'], lenses['c3']['probs']]
            final = np.zeros(3, float)
            for prob, actor_probs in zip(selector_probs, actors):
                final += float(prob) * np.asarray(actor_probs, float)
            final /= max(np.sum(final), 1e-12)
            source = 'master_actor_selector'
        else:
            final = master.copy()
            vec = self._selector_vector(row, master, lenses, math_consensus, performance_snapshot) if active else None
            source = 'master_core' if not active else 'master_plus_fixed_lenses_waiting_selector'

        directional = max(float(final[0]), float(final[2]))
        wait = float(final[1])
        threshold = float(self.config.get('min_direction_confidence', 0.55))
        edge = float(self.config.get('min_direction_edge', 0.06))
        cls = int(np.argmax(final))
        if directional < threshold or directional - wait < edge:
            cls = 1
        return NAMES[cls], {i: float(final[i]) for i in range(3)}, {
            'master_probs': master,
            'lenses': lenses,
            'decision_source': source,
            'meta_vector': vec,
            'selector_probs': selector_probs,
            'performance_snapshot': performance_snapshot,
            'outcome_probs': outcome_probs,
            'outcome_names': OUTCOME_NAMES,
            'lens_active': active,
        }

    def predict(self, row, math_consensus=0.0):
        pred, probs, _ = self.predict_bundle(row, math_consensus)
        return pred, probs

    def prediction_diagnostics(self, row, pred, probs, math_consensus=0.0, math_snapshot=None):
        _, final, extra = self.predict_bundle(row, math_consensus, math_snapshot)
        d = {
            'master_p_short': float(extra['master_probs'][0]),
            'master_p_wait': float(extra['master_probs'][1]),
            'master_p_long': float(extra['master_probs'][2]),
            'decision_source': extra['decision_source'],
            'lens_active': bool(extra.get('lens_active', False)),
        }
        for i, k in enumerate(('c1', 'c2', 'c3'), 1):
            q = extra['lenses'][k]['probs']
            d[f'c{i}_p_short'] = float(q[0]); d[f'c{i}_p_wait'] = float(q[1]); d[f'c{i}_p_long'] = float(q[2])
        d['conflict_m_c1'] = abs(d['master_p_long'] - d['c1_p_long'])
        d['conflict_m_c2'] = abs(d['master_p_long'] - d['c2_p_long'])
        d['conflict_m_c3'] = abs(d['master_p_long'] - d['c3_p_long'])
        d['lens_agreement'] = float(np.std([d['c1_p_long'], d['c2_p_long'], d['c3_p_long']]))
        d['math_consensus'] = float(math_consensus or 0.0)
        d['lens_predictions'] = {k: NAMES[int(np.argmax(extra['lenses'][k]['probs']))] for k in ('c1', 'c2', 'c3')}
        d['lens_specialization_scores'] = dict(extra['lenses'].get('specialization_scores', {}))
        d['lens_reliability'] = {'c1': 1.0, 'c2': 1.0, 'c3': 1.0}
        d['lens_training_enabled'] = False
        d['shared_base_version'] = int(extra['lenses'].get('shared_base_version', 0) or 0)
        d['lens_performance_snapshot']=list(extra.get('performance_snapshot') or [])
        if extra.get('selector_probs') is not None:
            d['selector_p_master'] = float(extra['selector_probs'][0]); d['selector_p_c1'] = float(extra['selector_probs'][1])
            d['selector_p_c2'] = float(extra['selector_probs'][2]); d['selector_p_c3'] = float(extra['selector_probs'][3])
            d['selector_selected_actor'] = ACTOR_NAMES[int(np.argmax(extra['selector_probs']))]
        else:
            d['selector_p_master'] = 1.0; d['selector_p_c1'] = d['selector_p_c2'] = d['selector_p_c3'] = 0.0
            d['selector_selected_actor'] = 'MASTER'
        op = extra.get('outcome_probs')
        if op is not None:
            for i, name in OUTCOME_NAMES.items():
                d[f'outcome_p_{name.lower()}'] = float(op[i])
            d['predicted_trade_outcome'] = OUTCOME_NAMES[int(np.argmax(op))]
            d['predicted_trade_outcome_score'] = int(np.argmax(op))
        else:
            d['predicted_trade_outcome'] = 'UNTRAINED'
            d['predicted_trade_outcome_score'] = -1
        return d

    def learn_trade_outcomes(self, experience):
        """Train the Master trade-outcome head from global resolved experience."""
        if not experience:
            return {'status': 'no_experience'}
        y = np.asarray(experience.get('outcome_target', []), int)
        X = np.column_stack([np.asarray(experience[f], float) for f in FEATURES]) if len(y) else np.empty((0, len(FEATURES)))
        valid = (y >= 0) & (y <= 4)
        X = X[valid]; y = y[valid]
        if len(y) < int(self.config.get('outcome_model_min_rows', 25)):
            return {'status': 'outcome_accumulating', 'rows': int(len(y))}
        sw = np.asarray(experience.get('outcome_sample_weight', np.ones(len(valid))), float)
        if len(sw) == len(valid):
            sw = sw[valid]
        else:
            sw = np.ones(len(y), float)
        m = self._load_path(self.outcome_model, 'outcome')
        if m is None:
            m = self._new_outcome()
            m.fit(X, y, epochs=int(self.config.get('outcome_epochs', 80)), learning_rate=float(self.config.get('outcome_learning_rate', .008)), l2=float(self.config.get('outcome_l2', .001)), sample_weights=sw)
            learning = 'initial'
        else:
            m.fit_incremental(X, y, epochs=int(self.config.get('outcome_epochs_incremental', 35)), learning_rate=float(self.config.get('outcome_learning_rate_incremental', .004)), l2=float(self.config.get('outcome_l2', .001)), sample_weights=sw)
            learning = 'incremental'
        self._save(self.outcome_model, m)
        p = m.predict(X)
        acc = float(np.mean(p == y)) if len(y) else 0.0
        self._write_json(self.outcome_meta, {
            'schema_version': self.MODEL_SCHEMA_VERSION,
            'status': 'ready', 'rows': int(len(y)), 'accuracy': acc,
            'updated': int(time.time()), 'learning': learning,
            'classes': OUTCOME_NAMES,
            'target': 'actual_trade_outcome_with_dynamic_protection_and_TP3_plus',
        })
        return {'status': 'outcome_updated', 'rows': int(len(y)), 'accuracy': acc}

    def learn_from_resolved(self, rows):
        """Master-owned selector learning: choose which actor was best.

        C1/C2/C3 are never modified. Their realized outcomes become evidence for
        this Master selector, which learns when to trust each fixed lens.
        """
        valid = []
        for x in rows:
            outcomes = x.get('lens_outcomes') or {}
            if not x.get('lens_performance_snapshot') or not all(k in outcomes for k in ('c1', 'c2', 'c3')):
                continue
            try:
                actors = [x, outcomes['c1'], outcomes['c2'], outcomes['c3']]
                scores = [self.outcome_score(a) for a in actors]
                best = int(np.argmax(scores))  # ties intentionally prefer Master/C1/C2/C3 order
                v = self._selector_vector(x.get('features') and {'features': x.get('features')} or x, np.asarray([
                    float(x.get('master_p_short', 0.0)), float(x.get('master_p_wait', 0.0)), float(x.get('master_p_long', 0.0))
                ]), {
                    k: {'probs': np.asarray([float(x.get(f'{k}_p_short', 0.0)), float(x.get(f'{k}_p_wait', 0.0)), float(x.get(f'{k}_p_long', 0.0))])}
                    for k in ('c1', 'c2', 'c3')
                }, float(x.get('math_consensus', 0.0) or 0.0), x.get('lens_performance_snapshot'))
                valid.append((v, best, max(scores)))
            except Exception:
                continue
        if not valid:
            return {'status': 'no_selector_rows'}
        cap = max(500, int(self.config.get('master_decision_experience_max', 12000)))
        old = None
        if self.meta_experience.exists():
            try:
                z = np.load(self.meta_experience)
                old = {k: z[k] for k in z.files}
                if old.get('X') is None or np.asarray(old['X']).ndim != 2 or np.asarray(old['X']).shape[1] != len(self.META_NAMES):
                    old = None
            except Exception:
                old = None
        X = np.asarray([a for a, _, _ in valid], dtype=np.float32)
        y = np.asarray([b for _, b, _ in valid], dtype=np.int8)
        sw = np.asarray([1.0 + 0.20 * c for _, _, c in valid], dtype=np.float32)
        if old:
            X = np.concatenate([old['X'], X])
            y = np.concatenate([old['y'], y])
            old_sw = np.asarray(old.get('sample_weight', np.ones(len(old['y']))), float)
            sw = np.concatenate([old_sw, sw])
        if len(X) > cap:
            X = X[-cap:]; y = y[-cap:]; sw = sw[-cap:]
        np.savez(self.meta_experience, X=X, y=y, sample_weight=sw)
        min_rows = max(25, int(self.config.get('master_decision_min_rows', 50)))
        if len(X) < min_rows:
            return {'status': 'selector_accumulating', 'rows': int(len(X))}
        m = self._load_path(self.master_decision, 'selector')
        if m is None:
            m = self._new_decision()
            m.fit(X, y, epochs=int(self.config.get('master_decision_epochs', 80)), learning_rate=float(self.config.get('master_decision_learning_rate', .01)), l2=float(self.config.get('master_decision_l2', .001)), sample_weights=sw)
            learning = 'initial'
        else:
            m.fit_incremental(X, y, epochs=int(self.config.get('master_decision_epochs_incremental', 35)), learning_rate=float(self.config.get('master_decision_learning_rate_incremental', .005)), l2=float(self.config.get('master_decision_l2', .001)), sample_weights=sw)
            learning = 'incremental'
        self._save(self.master_decision, m)
        p = m.predict(X)
        acc = float(np.mean(p == y)) if len(y) else 0.0
        counts = {ACTOR_NAMES[i]: int(np.sum(y == i)) for i in range(4)}
        self._write_json(self.master_decision_meta, {
            'schema_version': self.SELECTOR_SCHEMA_VERSION,
            'status': 'ready', 'rows': int(len(X)), 'accuracy': acc,
            'updated': int(time.time()), 'features': self.META_NAMES,
            'learning': learning, 'target': 'best_actor_by_real_trade_outcome',
            'actor_counts': counts,
        })
        return {'status': 'selector_updated', 'rows': int(len(X)), 'accuracy': acc}
