import json
from pathlib import Path
import numpy as np

from app.core.engine import LearningEngine, _normalize_timestamp_array, _timestamp_seconds


def test_mixed_epoch_units_normalize_individually_to_seconds():
    seconds = 1_800_000_000
    raw = np.asarray([seconds, seconds * 1_000, seconds * 1_000_000,
                      (seconds + 300) * 1_000_000, seconds + 600], dtype=np.int64)
    got = _normalize_timestamp_array(raw)
    np.testing.assert_array_equal(got, [seconds, seconds, seconds, seconds + 300, seconds + 600])
    assert _timestamp_seconds((seconds + 600) * 1_000_000) == seconds + 600


def test_load_experience_migrates_mixed_timestamps_once(tmp_path):
    data = tmp_path / 'data'; data.mkdir()
    exp_path = data / 'global_experience.npz'
    seconds = 1_800_000_000
    raw = np.asarray([seconds, seconds * 1_000, seconds * 1_000_000], dtype=np.int64)
    np.savez(exp_path, time=raw, target=np.asarray([0, 1, 2], dtype=np.int8))
    engine = LearningEngine.__new__(LearningEngine)
    engine.experience = exp_path; engine.data = data
    engine._write_json = lambda path, obj: Path(path).write_text(json.dumps(obj), encoding='utf-8')
    loaded = engine._load_exp()
    np.testing.assert_array_equal(loaded['time'], [seconds, seconds, seconds])
    with np.load(exp_path) as z:
        np.testing.assert_array_equal(z['time'], [seconds, seconds, seconds])
    assert (data / 'timestamp_normalization_v1.json').exists()


def test_resolved_counter_and_batch_slicing_use_resolution_order_and_same_filters(tmp_path):
    logs = tmp_path / 'logs'; logs.mkdir()
    # Creation time order is deliberately opposite to resolution order.
    rows = [
        {'id': 'older-created', 'time': 1_800_000_000_000_000, 'resolved': 1,
         'resolved_at': 1_800_000_300, 'result': 'TP1'},
        {'id': 'newer-created', 'time': 1_800_000_300_000_000, 'resolved': 1,
         'resolved_at': 1_800_000_100_000, 'result': 'TP2'},
        {'id': 'pending-recheck', 'time': 1_800_000_600_000_000, 'resolved': 1,
         'resolved_at': 1_800_000_600_000_000, 'post_sl_recheck_pending': True},
        {'id': 'merged', 'time': 1_800_000_900_000_000, 'resolved': 1, 'state_change_only': True},
    ]
    (logs / 'AAA_predictions.json').write_text(json.dumps(rows), encoding='utf-8')
    engine = LearningEngine.__new__(LearningEngine); engine.logs = logs
    eligible = engine._resolved_learning_rows()
    assert [x['id'] for x in eligible] == ['newer-created', 'older-created']
    assert engine._count_resolved_logs() == 2
    assert [x['id'] for x in engine._learning_rows_since(0, 1)] == ['newer-created']


def test_auxiliary_samples_do_not_force_retrain_or_reset_challenger(tmp_path):
    engine = LearningEngine.__new__(LearningEngine)
    state = {'last_retrain_resolved': 100, 'retrain_batches': 4,
             'clean_master_reset_done': True, 'challenger_active': True,
             'challenger_generation': 7, 'challenger_control_target': 125,
             'challenger_created_at': 12345}
    engine.cfg = {'retrain_batch_size': 25}
    engine._training_state = lambda: dict(state)
    engine._resolved_learning_rows = lambda: []
    engine._save_training_state = lambda value: None
    result = engine.retrain_symbols([], resolved_total=105, force=False, auxiliary_only=True)
    assert result[0][0] == 'AUXILIARY_DEFERRED'
    assert result[0][1]['status'] == 'waiting_for_trade_batch'
    assert state['challenger_generation'] == 7
    assert state['challenger_control_target'] == 125
    assert state['challenger_created_at'] == 12345


def test_challenger_control_rows_only_include_current_generation(tmp_path):
    logs = tmp_path / 'logs'; logs.mkdir()
    rows = [
        {'id': 'g1', 'time': 1_800_000_000, 'resolved_at': 1_800_000_100,
         'resolved': 1, 'challenger_generation': 1, 'challenger_control_active': True,
         'challenger_prediction': 'LONG', 'trade_outcome': 'TP1', 'challenger_outcome': {'trade_outcome':'TP1'}},
        {'id': 'g2', 'time': 1_800_000_200, 'resolved_at': 1_800_000_300,
         'resolved': 1, 'challenger_generation': 2, 'challenger_control_active': True,
         'challenger_prediction': 'SHORT', 'trade_outcome': 'SL', 'challenger_outcome': {'trade_outcome':'TP2'}},
    ]
    (logs / 'AAA_predictions.json').write_text(json.dumps(rows), encoding='utf-8')
    engine = LearningEngine.__new__(LearningEngine); engine.logs = logs
    got = engine._challenger_control_rows({'challenger_generation': 2})
    assert [x['id'] for x in got] == ['g2']


def test_id_checkpoint_finds_late_resolving_old_forecast_without_counter_drift(tmp_path):
    logs = tmp_path / 'logs'; logs.mkdir()
    rows = [
        {'id': 'already-trained', 'time': 1_800_000_000, 'resolved_at': 1_800_000_100,
         'resolved': 1, 'result': 'TP1'},
        {'id': 'new-but-old-created', 'time': 1_799_000_000, 'resolved_at': 1_800_000_200,
         'resolved': 1, 'result': 'TP2'},
    ]
    (logs / 'AAA_predictions.json').write_text(json.dumps(rows), encoding='utf-8')
    engine = LearningEngine.__new__(LearningEngine)
    engine.logs = logs
    state = {'last_retrain_resolved': 1, 'last_retrain_resolved_ids': ['already-trained']}
    fresh = engine._new_learning_rows(state)
    assert [x['id'] for x in fresh] == ['new-but-old-created']


def test_challenger_does_not_report_tie_when_paired_outcomes_are_missing(tmp_path):
    engine = LearningEngine.__new__(LearningEngine)
    engine.cfg = {'retrain_batch_size': 25}
    engine._append_learning_audit = lambda event: None
    state = {'challenger_generation': 1, 'challenger_start_resolved': 100,
             'challenger_control_target': 125}
    rows = [{'id': 'p1', 'challenger_generation': 1, 'challenger_control_active': True,
             'challenger_prediction': 'SHORT', 'trade_outcome': 'TP1',
             'challenger_outcome': {'trade_outcome': 'WAITING'}}]
    result = engine._evaluate_challenger_control(rows, state)
    assert result['result'] == 'INSUFFICIENT_DATA'
    assert result['paired_rows'] == 0
    assert state['challenger_checked'] is False
