from pathlib import Path
import json, time, threading, shutil, zlib
import numpy as np
from .features import add_features, align_mtf, make_labels, FEATURES
from .model import ModelManager, OUTCOME_NAMES, NAMES
from .math_models import (compute_math_snapshot, MATH_FEATURES, MATH_FORMULA_VERSION,
                          fit_math_probability_calibration, compute_correlation_matrix)

_ENGINE_FILE_LOCK=threading.RLock()
_MATH_CALIBRATION_LOCK=threading.RLock()


def _timestamp_seconds(value):
    """Normalize an individual Unix timestamp from seconds/ms/us/ns to seconds.

    Normalize each value independently: replay archives may mix candle timestamps
    in milliseconds/microseconds with online observations in seconds.
    """
    try:
        value = int(value)
    except (TypeError, ValueError, OverflowError):
        return 0
    magnitude = abs(value)
    if magnitude >= 100_000_000_000_000_000:  # nanoseconds
        return value // 1_000_000_000
    if magnitude >= 100_000_000_000_000:      # microseconds
        return value // 1_000_000
    if magnitude >= 100_000_000_000:          # milliseconds
        return value // 1_000
    return value


def _normalize_timestamp_array(values):
    return np.asarray([_timestamp_seconds(v) for v in np.asarray(values).reshape(-1)], dtype=np.int64)


def _stable_contract_seed(contract):
    """Stable per-contract Monte Carlo seed across app/process restarts."""
    return int(zlib.crc32(str(contract).encode('utf-8')) & 0xffffffff) % 100000


def _purged_temporal_split_indices(times, test_fraction=0.2, gap_seconds=3600):
    """Return chronological train/test indices with a timestamp-based embargo.

    Experience is global across contracts and may contain many rows at the same
    timestamp. A row-count gap can therefore leak nearby observations when many
    symbols share a candle time. This split keeps equal timestamps together and
    removes the full time window immediately before the test period.
    """
    ts = _normalize_timestamp_array(times)
    n = len(ts)
    if n < 2:
        return np.asarray([], dtype=int), np.asarray([], dtype=int), 0, 0
    order = np.argsort(ts, kind='stable')
    ordered = ts[order]
    fraction = float(np.clip(test_fraction, 0.05, 0.5))
    cut = max(1, min(n - 1, int(n * (1.0 - fraction))))
    test_start = int(ordered[cut])
    # Timestamps are normalized per row to seconds, so the purge interval has a
    # single stable unit even when the input array originally mixed s/ms/us.
    embargo = max(0, int(gap_seconds))
    train_idx = order[ts[order] < test_start - embargo]
    test_idx = order[ts[order] >= test_start]
    return train_idx, test_idx, test_start, embargo

class LearningEngine:
\
\
    def _outcome_percentages(self, rows):
        """Calculate current Master probabilities from verified historical outcomes."""
        counts = {"TP1": 0, "TP2": 0, "TP3": 0, "SL": 0, "WAIT_CORRECT": 0,
                  "MISSED_LONG": 0, "MISSED_SHORT": 0}
        total = 0
        for row in rows or []:
            outcome = str((row or {}).get("outcome", (row or {}).get("result", ""))).upper()
            if outcome in counts:
                counts[outcome] += 1
                total += 1
        if not total:
            return {k: 0.0 for k in counts}
        return {k: round(v * 100.0 / total, 2) for k, v in counts.items()}

    def _historical_retraining_policy(self):
        """Return the policy for rebuilding Master from validated historical experience.
        Old model weights are never treated as ground truth. Historical rows are
        revalidated against the current outcome rules before reuse.
        """
        return {
            "reset_old_master_weights": True,
            "reuse_validated_historical_experience": True,
            "revalidate_outcomes_before_training": True,
            "exclude_unverifiable_legacy_rows": True,
            "selector_uses_only_verified_lens_outcomes": True,
        }

    def _record_master_retrain_cycle(self, state=None):
        state = state if isinstance(state, dict) else getattr(self, "state", {})
        n = int(state.get("master_retrain_cycles", 0) or 0) + 1
        state["master_retrain_cycles"] = n
        state["last_master_retrain_cycle"] = n
        return n

    def __init__(self,root,exchange,config):
        self.root=Path(root); self.exchange=exchange; self.cfg=config
        self.data=self.root/'data'; self.data.mkdir(exist_ok=True); self.logs=self.root/'logs'; self.logs.mkdir(exist_ok=True)
        self.mm=ModelManager(self.root, self.exchange.futures_symbol, self.cfg)
        self.pending=self.logs/f'{self.exchange.futures_symbol}_pending.json'
        self.predictions=self.logs/f'{self.exchange.futures_symbol}_predictions.json'
        self.experience=self.data/'global_experience.npz'
        self.learning_audit=self.data/'learning_audit.jsonl'
        self.challenger_root=self.data/'challenger_snapshot'
        self._migrate_legacy_master_experience()
    def _migrate_legacy_master_experience(self):
        """Rebuild the global replay memory with symbol-safe, outcome-aware rows.

        Older releases deduplicated only by timestamp and trained primarily on a
        directional `actual` label.  The new schema keeps contract + prediction_id
        and stores the real trade outcome separately.  Historical rows without a
        prediction log remain marked LEGACY_UNKNOWN and are never mixed into the
        new global cross-symbol training set.
        """
        marker=self.data/'experience_schema_v2.json'
        try:
            state=json.loads(marker.read_text(encoding='utf-8')) if marker.exists() else {}
            if state.get('completed') and int(state.get('schema_version',0))>=2:
                self.mm.update_learning_state(resolved_total=self._count_resolved_logs())
                return
        except Exception:
            pass
        rows=[]; seen=set(); legacy_count=0
        for path in sorted(self.logs.glob('*_predictions.json')):
            contract_from_file=path.name[:-len('_predictions.json')]
            try: items=json.loads(path.read_text(encoding='utf-8')) if path.exists() else []
            except Exception: continue
            for idx,item in enumerate(items):
                if not item.get('resolved') or item.get('state_change_only') or item.get('training_exclude') or item.get('statistics_exclude') or not item.get('features'): continue
                if not all(f in (item.get('features') or {}) for f in FEATURES): continue
                outcome=self._infer_trade_outcome(item)
                if outcome<0: continue
                contract=str(item.get('contract') or item.get('exchange_symbol') or contract_from_file or '').strip()
                pid=str(item.get('id') or f'legacy:{contract}:{int(item.get("time",0))}:{idx}')
                key=(contract,int(item.get('time',0)),pid)
                if key in seen: continue
                seen.add(key)
                direction=item.get('direction_target') or item.get('actual') or item.get('prediction')
                if direction not in ('LONG','SHORT','WAIT'): direction='WAIT'
                rows.append(self._experience_row(item,contract,pid,direction,outcome))
        if rows:
            self._save_exp(self._bounded_experience(rows))
        else:
            old=self._load_exp()
            if old:
                n=len(old.get('time',[])); legacy=[]
                for i in range(n):
                    try:
                        f={k:float(old[k][i]) for k in FEATURES}
                        legacy.append({'time':int(old['time'][i]),'contract':'LEGACY_UNKNOWN','prediction_id':f'legacy_unknown:{int(old["time"][i])}:{i}',
                                       'target':int(old.get('target',np.ones(n,dtype=np.int8))[i]),'outcome_target':-1,
                                       'sample_weight':0.25,'outcome_sample_weight':0.0,'math_consensus':float(old.get('math_consensus',np.zeros(n))[i]),**f})
                    except Exception:
                        continue
                if legacy:
                    self._save_exp(self._bounded_experience(legacy)); legacy_count=len(legacy)
        payload={'completed':True,'schema_version':2,'migrated_rows':len(rows),'legacy_unknown_rows':legacy_count,'completed_at':int(time.time()),
                 'purpose':'symbol_safe_global_trade_outcome_experience'}
        tmp=marker.with_suffix('.tmp'); tmp.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8'); tmp.replace(marker)
        self.mm.update_learning_state(resolved_total=self._count_resolved_logs())
    def set_symbol(self, symbol):
        self.exchange.set_symbol(symbol)
        self.mm=ModelManager(self.root, self.exchange.futures_symbol, self.cfg)
        self.pending=self.logs/f'{self.exchange.futures_symbol}_pending.json'
        self.predictions=self.logs/f'{self.exchange.futures_symbol}_predictions.json'
        self.experience=self.data/'global_experience.npz'

    def collect(self):
        return {tf:self.exchange.candles(tf,int(self.cfg.get('history_limit',5000))) for tf in self.cfg['timeframes']}
    def build_training(self,frames):
        base=add_features(frames['5min']); x=align_mtf(base,{k:v for k,v in frames.items() if k!='5min'})
        # Historical order-book imbalance and liquidation-side bias are not
        # available as aligned public series, so they stay neutral. OI-change
        # and funding are used only if KuCoin returns sufficient causal history.
        n=len(x['time'])
        self._market_feature_status={'mode':'neutral','coverage':0.0,'reason':'historical_market_metrics_not_verified'}
        try:
            history_fn=getattr(self.exchange,'historical_market_features',None)
            hist=history_fn(np.asarray(x['time'],dtype=np.int64),300) if callable(history_fn) else None
            if isinstance(hist,dict) and float(hist.get('coverage',0.0) or 0.0) >= float(self.cfg.get('market_feature_min_coverage',0.65)):
                oi=np.asarray(hist.get('oi_change',[]),float).reshape(-1)
                funding=np.asarray(hist.get('funding',[]),float).reshape(-1)
                if len(oi)==n and len(funding)==n and np.mean(np.isfinite(oi)&np.isfinite(funding)) >= float(self.cfg.get('market_feature_min_coverage',0.65)):
                    x['oi_change']=oi; x['funding']=funding
                    self._market_feature_status={'mode':'historical_aligned','coverage':float(hist.get('coverage',0.0)),
                                                 'reason':'KuCoin OI and funding aligned to closed candle times'}
                else:
                    x['oi_change']=np.zeros(n); x['funding']=np.zeros(n)
            else:
                x['oi_change']=np.zeros(n); x['funding']=np.zeros(n)
                if isinstance(hist,dict):
                    self._market_feature_status={'mode':'neutral','coverage':float(hist.get('coverage',0.0) or 0.0),
                                                 'reason':str(hist.get('status','insufficient_coverage')),
                                                 'error':str(hist.get('error',''))[:180]}
        except Exception as exc:
            x['oi_change']=np.zeros(n); x['funding']=np.zeros(n)
            self._market_feature_status={'mode':'neutral','coverage':0.0,'reason':'history_fetch_failed:'+str(exc)[:120]}
        x['book_imbalance']=np.zeros(n,dtype=float)
        x['liquidation_bias']=np.zeros(n,dtype=float)
        x=make_labels(x,int(self.cfg['horizon_bars']),float(self.cfg['long_threshold']),float(self.cfg['short_threshold']))
        for f in FEATURES:
            if f not in x: x[f]=np.zeros(n)
            a=np.asarray(x[f],float).reshape(-1)
            if len(a)!=n: raise ValueError(f'Несовпадение длины признака {f}: {len(a)} вместо {n}')
            x[f]=a
        y=np.asarray(x['target'],float); good=np.isfinite(y)
        for f in FEATURES: good &= np.isfinite(x[f])
        return {f:np.asarray(x[f])[good] for f in FEATURES}|{'target':y[good],'time':np.asarray(x['time'])[good]}
    def _load_exp(self):
        if not self.experience.exists(): return None
        try:
            with np.load(self.experience) as z:
                data={k:z[k] for k in z.files}
            if 'time' in data:
                raw=np.asarray(data['time'],dtype=np.int64).reshape(-1)
                normalized=_normalize_timestamp_array(raw)
                data['time']=normalized
                if not np.array_equal(raw,normalized):
                    tmp=self.experience.with_suffix('.normalized.tmp.npz')
                    np.savez_compressed(tmp,**data)
                    tmp.replace(self.experience)
                    self._write_json(self.data/'timestamp_normalization_v1.json', {
                        'schema_version':1,'unit':'seconds','rows':int(len(normalized)),
                        'normalized_at':int(time.time()),'source':'global_experience.npz'})
            return data
        except Exception:return None
    def _save_exp(self,x):
        data=dict(x)
        if 'time' in data: data['time']=_normalize_timestamp_array(data['time'])
        np.savez(self.experience,**data)

    @staticmethod
    def _infer_trade_outcome(item):
        if item.get('tp3_hit'):
            return 4 if float(item.get('max_extension_beyond_tp3_pct', item.get('post_tp3_extension', 0.0)) or 0.0)>0 else 3
        if item.get('tp2_hit'): return 2
        if item.get('tp1_hit'): return 1
        if item.get('initial_sl_failure') or (item.get('sl_hit') and not item.get('tp1_hit')): return 0
        return -1

    def _resolved_learning_rows(self):
        """Unique eligible resolved forecasts ordered by resolution time.

        All batch counters and batch slices use this exact population. Creation
        time is not resolution order because long-running forecasts may finish late.
        """
        seen={}
        for path in self.logs.glob('*_predictions.json'):
            try: items=json.loads(path.read_text(encoding='utf-8'))
            except Exception: continue
            for item in items:
                if (not item.get('resolved') or item.get('state_change_only') or
                    item.get('statistics_exclude') or item.get('training_exclude') or item.get('training_excluded') or
                    item.get('post_sl_recheck_pending')):
                    continue
                pid=str(item.get('id') or f"{path.name}:{int(item.get('time',0) or 0)}")
                old=seen.get(pid)
                if old is None or _timestamp_seconds(item.get('resolved_at',item.get('time',0))) >= _timestamp_seconds(old.get('resolved_at',old.get('time',0))):
                    saved=dict(item); saved['_learning_id']=pid
                    seen[pid]=saved
        return sorted(seen.values(), key=lambda x: (_timestamp_seconds(x.get('resolved_at',x.get('time',0))), self._learning_id(x)))

    def _count_resolved_logs(self):
        return len(self._resolved_learning_rows())

    @staticmethod
    def _learning_id(row):
        return str(row.get('_learning_id') or row.get('id') or '')

    def _new_learning_rows(self, state, rows=None):
        """Return resolved IDs not included in the last successful retrain.

        ID checkpoints avoid counter drift when delayed SL rechecks become eligible
        later or when forecasts resolve out of creation-time order.
        """
        rows=self._resolved_learning_rows() if rows is None else rows
        checkpoint=state.get('last_retrain_resolved_ids')
        if not isinstance(checkpoint,list):
            # One-time migration from legacy numeric counters. Use the same stable
            # resolution ordering as the new counter to seed the old checkpoint.
            prior=max(0,min(len(rows),int(state.get('last_retrain_resolved',0) or 0)))
            checkpoint=[self._learning_id(row) for row in rows[:prior]]
            state['last_retrain_resolved_ids']=checkpoint
            self._save_training_state(state)
        known=set(str(x) for x in checkpoint)
        return [row for row in rows if self._learning_id(row) not in known]

    def _experience_row(self,item,contract,pid,direction,outcome):
        if bool(item.get('direction_confirmed')):
            direction_target=str(item.get('prediction') or direction).upper()
        else:
            direction_target=str(direction).upper()
        if direction_target not in ('LONG','SHORT','WAIT'): direction_target='WAIT'
        # Do not reinforce an unconfirmed forecast that hit initial SL and did
        # not recover during the post-SL check. Preserve the loss label for the
        # separate outcome head, but teach the direction head to abstain (WAIT).
        if outcome == 0 and bool(item.get('initial_sl_failure') or (item.get('sl_hit') and not item.get('tp1_hit'))) and not bool(item.get('post_sl_recovery')):
            direction_target = 'WAIT'
        # Direction is auxiliary. Give more weight to actual trade quality, but
        # keep a partial directional lesson for an SL that recovered immediately.
        if outcome==0:
            sw=1.0 if bool(item.get('post_sl_recovery')) else 0.65
        elif outcome==1: sw=1.0
        elif outcome==2: sw=1.15
        elif outcome==3: sw=1.30
        elif outcome==4: sw=1.50
        else: sw=0.5
        return {
            'time':int(item.get('time',0)),
            'contract':str(contract or 'UNKNOWN'),
            'prediction_id':str(pid),
            'target':{'SHORT':0,'WAIT':1,'LONG':2}[direction_target],
            'outcome_target':int(outcome),
            'sample_weight':float(sw),
            'outcome_sample_weight':float(1.25 if outcome>=3 else 1.0),
            'math_consensus':float(item.get('math_consensus',0.0) or 0.0),
            'experience_kind':'TRADE',
            **{f:float((item.get('features') or {}).get(f,0.0) or 0.0) for f in FEATURES}
        }

    @staticmethod
    def _rows_to_arrays(rows):
        if not rows: return None
        out={
            'time':_normalize_timestamp_array([x['time'] for x in rows]),
            'contract':np.asarray([str(x.get('contract','UNKNOWN')) for x in rows]),
            'prediction_id':np.asarray([str(x.get('prediction_id','')) for x in rows]),
            'target':np.asarray([int(x['target']) for x in rows],dtype=np.int8),
            'outcome_target':np.asarray([int(x.get('outcome_target',-1)) for x in rows],dtype=np.int8),
            'sample_weight':np.asarray([float(x.get('sample_weight',1.0)) for x in rows],dtype=np.float32),
            'outcome_sample_weight':np.asarray([float(x.get('outcome_sample_weight',0.0)) for x in rows],dtype=np.float32),
            'math_consensus':np.asarray([float(x.get('math_consensus',0.0)) for x in rows],dtype=np.float32),
            'experience_kind':np.asarray([str(x.get('experience_kind','TRADE')) for x in rows]),
        }
        for f in FEATURES: out[f]=np.asarray([float(x[f]) for x in rows],dtype=np.float32)
        return out

    def _bounded_experience(self,rows):
        cap=max(1000,int(self.cfg.get('experience_max_rows',12000)))
        unique={}
        for row in rows:
            key=(str(row.get('contract','UNKNOWN')),int(row.get('time',0)),str(row.get('prediction_id','')))
            unique[key]=row
        rows=list(unique.values())
        rows.sort(key=lambda x:(int(x.get('time',0)),str(x.get('contract','')),str(x.get('prediction_id',''))))
        return self._rows_to_arrays(rows[-cap:])

    def _experience_for_direction_training(self,exp):
        n=len(exp.get('time',[]))
        if not n: return None
        contracts=np.asarray(exp.get('contract',np.asarray(['UNKNOWN']*n))).astype(str)
        target=np.asarray(exp['target'],int)
        valid=np.isfinite(target) & (target>=0) & (target<=2) & (contracts!='LEGACY_UNKNOWN')
        out={k:np.asarray(v)[valid] for k,v in exp.items() if len(np.asarray(v))==n}
        return out

    def _append_learning_audit(self,event):
        try:
            self.learning_audit.parent.mkdir(parents=True,exist_ok=True)
            record={'time':int(time.time()),**event}
            with self.learning_audit.open('a',encoding='utf-8') as f:
                f.write(json.dumps(record,ensure_ascii=False,separators=(',',':'))+'\n')
            # Keep the file bounded so it remains safe on a phone.
            max_rows=int(self.cfg.get('learning_audit_max_rows',5000))
            if self.learning_audit.stat().st_size>5*1024*1024:
                lines=self.learning_audit.read_text(encoding='utf-8').splitlines()[-max_rows:]
                self.learning_audit.write_text('\n'.join(lines)+'\n',encoding='utf-8')
        except Exception:
            pass
    def _merge_experience(self,hist):
        """Bootstrap dataset: current historical candles plus real global experience.

        This path is used only to create the first Master. Once a champion exists,
        automatic retraining uses the resolved global experience only, so one
        contract cannot dominate the global Master forever.
        """
        old=self._load_exp()
        contract=str(self.exchange.futures_symbol or 'UNKNOWN')
        n=len(hist['time'])
        boot={'time':_normalize_timestamp_array(hist['time']),
              'contract':np.asarray([contract]*n),
              'prediction_id':np.asarray([f'history:{contract}:{int(t)}' for t in hist['time']]),
              'target':np.asarray(hist['target'],dtype=np.int8),
              'outcome_target':np.full(n,-1,dtype=np.int8),
              'sample_weight':np.full(n,0.25,dtype=np.float32),
              'outcome_sample_weight':np.zeros(n,dtype=np.float32),
              'math_consensus':np.zeros(n,dtype=np.float32)}
        for f in FEATURES: boot[f]=np.asarray(hist[f],dtype=np.float32)
        if not old or len(old.get('time',[]))==0:
            return boot
        # Resolved experience gets priority on the exact (contract,time) key.
        rows=[]; used=set()
        for i in range(len(old['time'])):
            try:
                contract_old=str(np.asarray(old.get('contract',np.asarray(['LEGACY_UNKNOWN']*len(old['time'])))[i]))
                if contract_old=='LEGACY_UNKNOWN': continue
                key=(contract_old,int(old['time'][i]))
                used.add(key)
                row={'time':int(old['time'][i]),'contract':contract_old,'prediction_id':str(np.asarray(old.get('prediction_id',np.asarray([f'legacy:{contract_old}:{int(old["time"][i])}:{i}']*len(old['time'])))[i])),
                     'target':int(old['target'][i]),'outcome_target':int(old.get('outcome_target',np.full(len(old['time']),-1))[i]),
                     'sample_weight':float(old.get('sample_weight',np.ones(len(old['time'])))[i]),
                     'outcome_sample_weight':float(old.get('outcome_sample_weight',np.zeros(len(old['time'])))[i]),
                     'math_consensus':float(old.get('math_consensus',np.zeros(len(old['time'])))[i])}
                for f in FEATURES: row[f]=float(old[f][i])
                rows.append(row)
            except Exception: continue
        for i in range(n):
            key=(contract,int(boot['time'][i]))
            if key in used: continue
            row={k:(boot[k][i].item() if isinstance(boot[k][i],np.generic) else boot[k][i]) for k in boot.keys()}
            rows.append(row)
        rows.sort(key=lambda x:(int(x.get('time',0)),str(x.get('contract','')),str(x.get('prediction_id',''))))
        return self._rows_to_arrays(rows)
    def _clean_master_reset_if_needed(self):
        """One-time migration: rebuild Master weights from validated experience/history.
        Raw verified experience is preserved; old model weights are not reused.
        """
        state=self._training_state()
        if bool(state.get("clean_master_reset_done", False)):
            return {"status":"already_done"}
        # The first fresh build uses the existing bootstrap-history mechanism plus
        # validated global experience. It creates new weights; it never updates old ones.
        exp=self._load_exp()
        if not exp or len(exp.get("time",[])) < int(self.cfg.get("retrain_min_rows",25)):
            return {"status":"waiting_for_experience","rows":0 if not exp else len(exp.get("time",[]))}
        frames=self.collect()
        hist=self.build_training(frames)
        data=self._merge_experience(hist)
        data=self._apply_market_feature_policy(data, getattr(self,'_market_feature_status',{}).get('mode','neutral'))
        min_rows=int(self.cfg.get("min_training_rows",500))
        if data is None or len(data.get("target",[])) < min_rows:
            return {"status":"waiting_for_fresh_dataset","rows":0 if data is None else len(data.get("target",[]))}
        self.mm.reset_learning_models()
        direction=self.mm.train(data,min_rows=min_rows,test_fraction=float(self.cfg.get("test_fraction",.2)))
        model_meta=self.mm._read_json(self.mm.meta,{})
        model_meta['market_features_mode']=str(getattr(self,'_market_feature_status',{}).get('mode','neutral'))
        model_meta['market_feature_status']=dict(getattr(self,'_market_feature_status',{}))
        self.mm._write_json(self.mm.meta,model_meta)
        exp_for_training={k:np.asarray(v).copy() for k,v in exp.items()}
        exp_for_training=self._apply_market_feature_policy(exp_for_training,model_meta['market_features_mode'])
        outcome=self.mm.train_outcome_from_scratch(exp_for_training)
        selector=self.mm.rebuild_selector_from_scratch()
        state["clean_master_reset_done"]=True
        state["clean_master_reset_at"]=int(time.time())
        state["clean_master_reset_rows"]=int(len(exp.get("time",[])))
        state["last_clean_direction_rows"]=int(len(data.get("target",[])))
        state["base_version"]=int(state.get("base_version",0))+1
        # Keep the model's lens activation/base state synchronized with the
        # training-batch state so the fresh Master is immediately published.
        self.mm.update_learning_state(
            resolved_total=int(len(exp.get("time",[]))),
            base_version=int(state["base_version"])
        )
        self._save_training_state(state)
        self._append_learning_audit({
            "event":"CLEAN_MASTER_RESET",
            "reason":"legacy_weights_not_reused",
            "experience_rows":int(len(exp.get("time",[]))),
            "direction_dataset_rows":int(len(data.get("target",[]))),
            "direction":direction,
            "outcome":outcome,
            "selector":selector,
            "lens_training_enabled":False
        })
        return {"status":"clean_master_reset_done","direction":direction,"outcome":outcome,"selector":selector}

    def _apply_market_feature_policy(self, data, mode=None):
        """Keep OI/funding train and inference schemas consistent.

        If aligned historical OI/funding is unavailable, those columns are
        neutralized in every training path rather than learning from stale live
        snapshots while inference supplies zeros. The original experience archive
        is not mutated.
        """
        if not isinstance(data, dict):
            return data
        if mode is None:
            meta = self.mm._read_json(self.mm.meta,{}) if getattr(self,'mm',None) is not None else {}
            mode = meta.get('market_features_mode','neutral')
        if str(mode) != 'historical_aligned':
            for name in ('oi_change','funding','liquidation_bias'):
                if name in data:
                    data[name] = np.zeros_like(np.asarray(data[name],dtype=float))
        return data

    def train_from_fresh(self):
        """Train Master from scratch once, then continue with validated global experience."""
        reset=self._clean_master_reset_if_needed()
        if reset.get("status")=="waiting_for_experience":
            return reset
        if reset.get("status")=="waiting_for_fresh_dataset":
            return reset
        if reset.get("status")=="clean_master_reset_done":
            return {"status":"clean_master_reset_done","reset":reset}
        exp=self._load_exp()
        if not self.mm.has_champion():
            frames=self.collect(); hist=self.build_training(frames)
            data=self._merge_experience(hist)
            data=self._apply_market_feature_policy(data, getattr(self,'_market_feature_status',{}).get('mode','neutral'))
            min_rows=int(self.cfg.get('min_training_rows',500)); test_fraction=float(self.cfg.get('test_fraction',.2))
            result=self.mm.train(data,min_rows,test_fraction)
            meta=self.mm._read_json(self.mm.meta,{})
            meta['market_features_mode']=str(getattr(self,'_market_feature_status',{}).get('mode','neutral'))
            meta['market_feature_status']=dict(getattr(self,'_market_feature_status',{}))
            self.mm._write_json(self.mm.meta,meta)
            self.mm.update_learning_state(resolved_total=self._count_resolved_logs(), base_version=0)
            return result
        if not exp or len(exp.get('time',[]))<int(self.cfg.get('retrain_min_rows',25)):
            return {'status':'waiting_for_global_experience','rows':0 if not exp else len(exp.get('time',[]))}
        data=self._experience_for_direction_training(exp)
        mode=self.mm._read_json(self.mm.meta,{}).get('market_features_mode','neutral')
        data=self._apply_market_feature_policy(data,mode)
        # Sanitize a working copy for outcome training only; the persisted archive
        # retains the original observed values and is never rewritten by policy.
        exp_for_training={k:np.asarray(v).copy() for k,v in exp.items()}
        exp_for_training=self._apply_market_feature_policy(exp_for_training,mode)
        result=self.mm.train_master_incremental(data,min_rows=int(self.cfg.get('retrain_min_rows',25)))
        outcome=self.mm.learn_trade_outcomes(exp_for_training)
        result['outcome_head']=outcome
        return result
    def live_row(self):
        frames=self.collect(); base=add_features(frames['5min']); x=align_mtf(base,{k:v for k,v in frames.items() if k!='5min'}); n=len(x['time'])
        # Keep the exact closed 5m history in memory for Stage-25. The math
        # stage uses the same data already fetched for this forecast instead of
        # downloading another candle window for every finalist.
        self._last_live_base = {k: np.asarray(frames['5min'][k]).copy() for k in ('time','close','high','low','volume') if k in frames['5min']}
        model_meta=self.mm._read_json(self.mm.meta,{}) if hasattr(self,'mm') else {}
        market_mode=str(model_meta.get('market_features_mode','neutral'))
        # Preserve legacy order-book feature behavior, but only feed OI/funding
        # into inference when the model was trained with aligned historical data.
        if market_mode == 'historical_aligned':
            metrics=self.exchange.current_market_metrics()
        else:
            metrics={'book_imbalance':self.exchange.orderbook_imbalance(),'oi_change':0.0,'funding':0.0,'liquidation_bias':0.0}
            try: self.exchange._market_metrics_status='neutral_model_mode'
            except Exception: pass
        x['book_imbalance']=np.full(n,float(metrics.get('book_imbalance',0.0) or 0.0))
        x['liquidation_bias']=np.zeros(n,dtype=float)
        if market_mode == 'historical_aligned' and str(getattr(self.exchange,'_market_metrics_status','')).startswith('ok'):
            x['oi_change']=np.full(n,float(metrics.get('oi_change',0.0) or 0.0))
            x['funding']=np.full(n,float(metrics.get('funding',0.0) or 0.0))
        else:
            x['oi_change']=np.zeros(n,dtype=float)
            x['funding']=np.zeros(n,dtype=float)
        for f in FEATURES:
            a=np.asarray(x.get(f,[])).reshape(-1)
            if len(a)!=n: raise ValueError(f'Некорректная длина признака {f}: {len(a)}, ожидалось {n}')
        if n==0: raise ValueError('KuCoin не вернул 5min свечи')
        # Build a cross-contract regime dataset from causal features and future
        # path labels. The regime head trains only after enough distinct markets
        # have contributed; until then prediction uses a transparent fallback.
        try:
            self.mm.update_regime_training(
                x, self.exchange.futures_symbol,
                horizon_bars=int(self.cfg.get('horizon_bars',12)),
                long_threshold=float(self.cfg.get('long_threshold',0.003)),
                short_threshold=float(self.cfg.get('short_threshold',-0.003)))
        except Exception:
            pass
        i=n-1; return {k:np.asarray([v[i]]) for k,v in x.items()}
    def _signal_levels(self,row,pred):
        price=float(row['close'][0]); atr=float(row['atrpct'][0])*price; atr=max(atr,price*0.001)
        if pred=='LONG': return price,price-1.2*atr,price+1.8*atr,price+2.7*atr,price+3.6*atr
        if pred=='SHORT': return price,price+1.2*atr,price-1.8*atr,price-2.7*atr,price-3.6*atr
        # WAIT deliberately has no trading plan. Keep only the reference market price;
        # UI/calculator must not turn WAIT into an accidental LONG/SHORT order.
        return price,float('nan'),float('nan'),float('nan'),float('nan')

    def _attach_lens_plans(self,item):
        """Attach fixed-lens plans and all eight Master+lens combination plans."""
        if not bool(item.get('lens_active')):
            item['lens_plans']={}
            item['combination_plans']={}
            item['lens_architecture']='MASTER_ONLY_FIRST_25'
            return item
        preds=item.get('lens_predictions') or {}
        combo_preds=item.get('combination_predictions') or {}
        price=float(item.get('price',0.0) or 0.0)
        atrpct=float((item.get('features') or {}).get('atrpct',0.001) or 0.001)
        atr=max(price*atrpct,price*0.001)
        def plan_for(direction):
            direction=str(direction or 'WAIT').upper()
            if direction not in ('LONG','SHORT'):
                return {'prediction':'WAIT','entry':price,'sl':float('nan'),'tp1':float('nan'),'tp2':float('nan'),'tp3':float('nan')}
            if direction=='LONG':
                return {'prediction':'LONG','entry':price,'sl':price-1.2*atr,'tp1':price+1.8*atr,'tp2':price+2.7*atr,'tp3':price+3.6*atr}
            return {'prediction':'SHORT','entry':price,'sl':price+1.2*atr,'tp1':price-1.8*atr,'tp2':price-2.7*atr,'tp3':price-3.6*atr}
        item['lens_plans']={key:plan_for(preds.get(key,'WAIT')) for key in ('c1','c2','c3')}
        combo_names=('MASTER','MASTER+C1','MASTER+C2','MASTER+C3','MASTER+C1+C2','MASTER+C1+C3','MASTER+C2+C3','MASTER+C1+C2+C3')
        # Pure Master uses the actual final Master plan; every other combination
        # uses the direction produced by the Master-owned combination selector.
        item['combination_plans']={name:plan_for(combo_preds.get(name, item.get('prediction','WAIT'))) for name in combo_names}
        item['lens_architecture']='MASTER_SHARED_BASE_PLUS_3_FIXED_LENSES'
        return item
    @staticmethod
    def _resolve_lens_plan(plan, highs, lows, recheck_bars=3):
        direction=str(plan.get('prediction','WAIT')).upper()
        if direction not in ('LONG','SHORT'):
            return {'result':'WAIT','trade_outcome':'WAIT','outcome_score':-1,'tp1_hit':False,'tp2_hit':False,'tp3_hit':False,'sl_hit':False,'initial_sl_failure':False,'protected_exit':False}
        entry=float(plan.get('entry',float('nan'))); sl=float(plan.get('sl',float('nan'))); tp1=float(plan.get('tp1',float('nan'))); tp2=float(plan.get('tp2',float('nan'))); tp3=float(plan.get('tp3',float('nan')))
        highs=np.asarray(highs,float); lows=np.asarray(lows,float)
        tp1_hit=tp2_hit=tp3_hit=False; sl_hit=False; protected_exit=False; sl_index=None; first_index=None
        for off,(hi,lo) in enumerate(zip(highs,lows)):
            if direction=='LONG':
                original_sl=np.isfinite(sl) and lo<=sl
                protective=entry if tp1_hit and not tp2_hit else (tp1 if tp2_hit and not tp3_hit else None)
                if not tp1_hit and original_sl:
                    sl_hit=True; sl_index=off; break
                # OHLC candles do not reveal intrabar order. If an already-active
                # protective stop and a new target are both inside this candle,
                # conservatively resolve the stop first instead of inventing a win.
                if protective is not None and lo<=protective:
                    protected_exit=True; break
                hit3=np.isfinite(tp3) and hi>=tp3 and not tp3_hit
                hit2=np.isfinite(tp2) and hi>=tp2 and not tp2_hit
                hit1=np.isfinite(tp1) and hi>=tp1 and not tp1_hit
                if hit3:
                    tp1_hit=tp2_hit=tp3_hit=True; first_index=off if first_index is None else first_index; continue
                if hit2: tp1_hit=tp2_hit=True; first_index=off if first_index is None else first_index
                elif hit1: tp1_hit=True; first_index=off if first_index is None else first_index
                protective=entry if tp1_hit and not tp2_hit else (tp1 if tp2_hit and not tp3_hit else None)
                if protective is not None and lo<=protective and not tp3_hit:
                    protected_exit=True; break
            else:
                original_sl=np.isfinite(sl) and hi>=sl
                protective=entry if tp1_hit and not tp2_hit else (tp1 if tp2_hit and not tp3_hit else None)
                if not tp1_hit and original_sl:
                    sl_hit=True; sl_index=off; break
                if protective is not None and hi>=protective:
                    protected_exit=True; break
                hit3=np.isfinite(tp3) and lo<=tp3 and not tp3_hit
                hit2=np.isfinite(tp2) and lo<=tp2 and not tp2_hit
                hit1=np.isfinite(tp1) and lo<=tp1 and not tp1_hit
                if hit3:
                    tp1_hit=tp2_hit=tp3_hit=True; first_index=off if first_index is None else first_index; continue
                if hit2: tp1_hit=tp2_hit=True; first_index=off if first_index is None else first_index
                elif hit1: tp1_hit=True; first_index=off if first_index is None else first_index
                protective=entry if tp1_hit and not tp2_hit else (tp1 if tp2_hit and not tp3_hit else None)
                if protective is not None and hi>=protective and not tp3_hit:
                    protected_exit=True; break
        extension=0.0
        if tp3_hit and np.isfinite(tp3) and tp3:
            if direction=='LONG': extension=max(0.0,float((np.max(highs[max(0,first_index or 0):])-tp3)/tp3))
            else: extension=max(0.0,float((tp3-np.min(lows[max(0,first_index or 0):]))/tp3))
        if tp3_hit: outcome=4 if extension>0 else 3; result='TP3'
        elif tp2_hit: outcome=2; result='TP2'
        elif tp1_hit: outcome=1; result='TP1'
        elif sl_hit: outcome=0; result='SL'
        else: outcome=-1; result='WAITING'
        recovery=False; recovery_level=None
        if sl_hit and sl_index is not None:
            a=sl_index+1; b=min(len(highs),a+int(max(1,recheck_bars)))
            if b-a>=int(max(1,recheck_bars)):
                if direction=='LONG':
                    if np.any(highs[a:b]>=tp3): recovery=True; recovery_level='TP3'
                    elif np.any(highs[a:b]>=tp2): recovery=True; recovery_level='TP2'
                    elif np.any(highs[a:b]>=tp1): recovery=True; recovery_level='TP1'
                else:
                    if np.any(lows[a:b]<=tp3): recovery=True; recovery_level='TP3'
                    elif np.any(lows[a:b]<=tp2): recovery=True; recovery_level='TP2'
                    elif np.any(lows[a:b]<=tp1): recovery=True; recovery_level='TP1'
        return {'result':result,'trade_outcome':OUTCOME_NAMES[outcome] if outcome>=0 else 'WAITING','outcome_score':outcome,
                'tp1_hit':tp1_hit,'tp2_hit':tp2_hit,'tp3_hit':tp3_hit,'sl_hit':sl_hit,'initial_sl_failure':bool(sl_hit and not tp1_hit),
                'protected_exit':protected_exit,'post_sl_recovery':recovery,'post_sl_recovery_level':recovery_level,
                'max_extension_beyond_tp3_pct':extension*100.0}
    def append_online_observation_experience(self, contract, lifecycle_id, observed_time, previous_price, previous_features,
                                             observed_price, math_consensus=0.0, config=None):
        """Label a prior lifecycle snapshot once its next observed price is known.

        This is an intermediate direction-only sample. It is available before the
        original forecast resolves and is excluded from trade-outcome/TP-SL heads.
        """
        cfg = config if isinstance(config, dict) else self.cfg
        try:
            p0 = float(previous_price); p1 = float(observed_price); stamp = int(observed_time)
        except Exception:
            return {'status': 'invalid_observation', 'new_samples': 0}
        if p0 <= 0 or p1 <= 0 or stamp <= 0 or not isinstance(previous_features, dict):
            return {'status': 'invalid_observation', 'new_samples': 0}
        if not all(f in previous_features for f in FEATURES):
            return {'status': 'missing_features', 'new_samples': 0}
        ret = p1 / p0 - 1.0
        up = abs(float(cfg.get('long_threshold', 0.003)))
        down = abs(float(cfg.get('short_threshold', -0.003)))
        target = 'LONG' if ret >= up else 'SHORT' if ret <= -down else 'WAIT'
        pid = f'{lifecycle_id}:online-observation:{stamp}'
        old = self._load_exp(); all_rows=[]
        if old and len(old.get('time', [])):
            n=len(old['time']); existing_ids=set(np.asarray(old.get('prediction_id', np.asarray(['']*n))).astype(str).tolist())
            if pid in existing_ids:
                return {'status': 'already_recorded', 'new_samples': 0}
            for i in range(n):
                try:
                    all_rows.append({'time':int(old['time'][i]), 'contract':str(np.asarray(old.get('contract', np.asarray(['LEGACY_UNKNOWN']*n)))[i]),
                        'prediction_id':str(np.asarray(old.get('prediction_id', np.asarray([f'legacy:{i}']*n)))[i]),
                        'target':int(old['target'][i]), 'outcome_target':int(old.get('outcome_target', np.full(n,-1))[i]),
                        'sample_weight':float(old.get('sample_weight', np.ones(n))[i]),
                        'outcome_sample_weight':float(old.get('outcome_sample_weight', np.zeros(n))[i]),
                        'math_consensus':float(old.get('math_consensus', np.zeros(n))[i]),
                        'experience_kind':str(np.asarray(old.get('experience_kind', np.asarray(['TRADE']*n)))[i]),
                        **{f:float(old[f][i]) for f in FEATURES}})
                except Exception:
                    continue
        clean_features={f:float(previous_features.get(f,0.0) or 0.0) for f in FEATURES}
        if not all(np.isfinite(v) for v in clean_features.values()):
            return {'status': 'non_finite_features', 'new_samples': 0}
        all_rows.append({'time':stamp, 'contract':str(contract), 'prediction_id':pid,
            'target':{'SHORT':0,'WAIT':1,'LONG':2}[target], 'outcome_target':-1,
            'sample_weight':float(cfg.get('online_observation_sample_weight',0.15)),
            'outcome_sample_weight':0.0, 'math_consensus':float(math_consensus or 0.0),
            'experience_kind':'ONLINE_DIRECTION_OBSERVATION', **clean_features})
        self._save_exp(self._bounded_experience(all_rows))
        state_path=self.data/'online_observation_learning_state.json'
        state=self._read_json(state_path) if state_path.exists() else {}
        if not isinstance(state,dict): state={}
        state['pending_samples']=int(state.get('pending_samples',0) or 0)+1
        state['total_samples']=int(state.get('total_samples',0) or 0)+1
        state['last_updated']=int(time.time()); state['last_contract']=str(contract)
        state['last_target']=target; state['last_return_pct']=ret*100.0
        self._write_json(state_path,state)
        return {'status':'added','new_samples':1,'target':target,'return_pct':ret*100.0}

    def persist_scan_predictions(self, rows, allow_new_lifecycle=True):
        """Record 30-minute scan observations without prematurely ending forecasts.

        One active forecast lifecycle is retained per exact futures contract. Later
        scans (including an opposite LONG/SHORT signal) are observations attached
        to that lifecycle; they never close it and never replace its original
        direction, entry, levels, or horizon. The forecast is resolved only by its
        normal TP/SL outcome (directional) or the full WAIT learning horizon.
        Once resolved, a later scan may start a new lifecycle.
        """
        if not rows:
            return []
        returned = []
        with _ENGINE_FILE_LOCK:
            by_contract = {}
            for raw in rows:
                if not isinstance(raw, dict):
                    continue
                signal = str(raw.get('prediction', 'WAIT')).upper().strip()
                if signal not in ('LONG', 'SHORT', 'WAIT') or not raw.get('id'):
                    continue
                contract = str(raw.get('contract') or raw.get('exchange_symbol') or '').strip()
                if not contract:
                    continue
                by_contract.setdefault(contract, []).append(dict(raw))

            for requested_contract, candidates in by_contract.items():
                try:
                    self.set_symbol(requested_contract)
                    contract = str(self.exchange.futures_symbol).upper()
                    preds = self._read_json(self.predictions)
                    pend = self._read_json(self.pending)
                    if not isinstance(preds, list): preds = []
                    if not isinstance(pend, list): pend = []
                    now = int(time.time())

                    def state_of(item):
                        return str(item.get('prediction', 'WAIT')).upper().strip()

                    def is_active(item):
                        state = state_of(item)
                        # Never let a stale/misfiled row for another coin become
                        # this contract's canonical lifecycle. Missing legacy
                        # contract fields are scoped to this per-contract file.
                        record_contract = str(item.get('contract') or item.get('exchange_symbol') or '').upper().replace('-', '').strip()
                        if record_contract.endswith('USDT') and not record_contract.endswith('USDTM'):
                            record_contract += 'M'
                        if record_contract and record_contract != contract:
                            return False
                        if state not in ('LONG', 'SHORT', 'WAIT'):
                            return False
                        if bool(item.get('resolved')) or bool(item.get('state_lifecycle_closed')):
                            return False
                        if item.get('merged_into_prediction_id'):
                            return False
                        if state == 'WAIT' and bool(item.get('wait_learning_resolved')):
                            return False
                        return True

                    # Keep the oldest active lifecycle: it is the original forecast
                    # whose TP/SL or WAIT horizon must still be allowed to resolve.
                    active = [x for x in preds if is_active(x)]
                    active.sort(key=lambda x: (int(x.get('time', 0) or 0), str(x.get('id', ''))))
                    current = active[0] if active else None
                    pred_by_id = {str(x.get('id')): x for x in preds if x.get('id') is not None}

                    # Repair old versions that wrote one new prediction per scan.
                    # Preserve the original lifecycle; fold later active rows into
                    # its observation history instead of closing the original one.
                    if current is not None and len(active) > 1:
                        history = current.get('scan_observations')
                        if not isinstance(history, list): history = []
                        canonical_id = str(current.get('id', ''))
                        for duplicate in active[1:]:
                            duplicate_id = str(duplicate.get('id', ''))
                            prior_history = duplicate.get('scan_observations')
                            if isinstance(prior_history, list):
                                for prior_observation in prior_history:
                                    migrated = dict(prior_observation)
                                    migrated['migrated_from_legacy_prediction'] = True
                                    history.append(migrated)
                            history.append({
                                'time': int(duplicate.get('time', 0) or 0),
                                'scan_prediction_id': duplicate_id,
                                'signal': state_of(duplicate),
                                'price': duplicate.get('price'),
                                'p_long': duplicate.get('p_long'),
                                'p_short': duplicate.get('p_short'),
                                'p_wait': duplicate.get('p_wait'),
                                'features': duplicate.get('features'),
                                'prediction_diagnostics': duplicate.get('prediction_diagnostics'),
                                'migrated_from_legacy_prediction': True,
                            })
                            # Keep the full legacy row for audit, but exclude it from
                            # pending queues and all outcome/retraining statistics.
                            duplicate['resolved'] = 1
                            duplicate['resolved_at'] = now
                            duplicate['state_change_only'] = True
                            duplicate['training_excluded'] = True
                            duplicate['merged_into_prediction_id'] = canonical_id
                            duplicate['state_lifecycle_status'] = 'MERGED_LEGACY_SCAN_DUPLICATE'
                            duplicate['close_reason'] = 'LEGACY_REPEAT_SCAN_RECORD_MERGED_AS_OBSERVATION'
                            duplicate['trade_outcome'] = 'MERGED_SCAN_OBSERVATION'
                            duplicate['outcome_score'] = -1
                            if state_of(duplicate) == 'WAIT':
                                duplicate['wait_learning_resolved'] = True
                                duplicate['wait_learning_state'] = 'MERGED_LEGACY_SCAN_DUPLICATE'
                        current['scan_observations'] = history[-200:]

                    # If there is an active lifecycle, every scan is only an
                    # observation, even when the model changes LONG <-> SHORT/WAIT.
                    # No new prediction record is created until this lifecycle has
                    # its genuine outcome (TP/SL or completed WAIT horizon).
                    r = candidates[-1]
                    signal = state_of(r)
                    incoming_id = str(r.get('id'))
                    if current is not None and is_active(current):
                        history = current.get('scan_observations')
                        if not isinstance(history, list): history = []
                        already_seen = (incoming_id == str(current.get('id', '')) or any(
                            str(x.get('scan_prediction_id')) == incoming_id for x in history))
                        previous_observed = str(current.get('last_scan_signal', state_of(current))).upper()
                        changed = signal != previous_observed
                        previous_price = current.get('last_scan_price', current.get('price'))
                        try:
                            previous_price = float(previous_price)
                            observed_price = float(r.get('price') or 0.0)
                            price_change_pct = ((observed_price / previous_price) - 1.0) * 100.0 if previous_price > 0 and observed_price > 0 else None
                        except Exception:
                            price_change_pct = None
                        previous_probs = current.get('last_scan_probabilities') or {
                            'p_long': current.get('p_long'), 'p_short': current.get('p_short'), 'p_wait': current.get('p_wait')}
                        probability_delta = {}
                        for key in ('p_long', 'p_short', 'p_wait'):
                            try:
                                if r.get(key) is not None and previous_probs.get(key) is not None:
                                    probability_delta[key] = float(r[key]) - float(previous_probs[key])
                            except Exception:
                                continue
                        previous_features = (history[-1].get('features') if history and isinstance(history[-1], dict)
                                             else current.get('features') or {})
                        new_features = r.get('features') or {}
                        feature_delta = {}
                        if isinstance(previous_features, dict) and isinstance(new_features, dict):
                            for key in set(previous_features).intersection(new_features):
                                try:
                                    feature_delta[key] = float(new_features[key]) - float(previous_features[key])
                                except Exception:
                                    continue
                        observation = {
                            'time': now,
                            'elapsed_seconds_since_previous_observation': max(0, now - int(current.get('last_scan_at', current.get('time', now)) or now)),
                            'scan_prediction_id': incoming_id,
                            'signal': signal,
                            'previous_observed_signal': previous_observed,
                            'signal_changed': changed,
                            'price': r.get('price'),
                            'previous_observed_price': previous_price,
                            'price_change_pct_since_previous_observation': price_change_pct,
                            'p_long': r.get('p_long'),
                            'p_short': r.get('p_short'),
                            'p_wait': r.get('p_wait'),
                            'probability_delta': probability_delta,
                            'math_consensus': r.get('math_consensus'),
                            'features': new_features,
                            'feature_delta': feature_delta,
                            'prediction_diagnostics': r.get('prediction_diagnostics'),
                        }
                        if not already_seen:
                            # Label the previous snapshot now that a later market
                            # price is available; this starts learning before TP/SL.
                            try:
                                prior_observation = history[-1] if history and isinstance(history[-1], dict) else current
                                prior_features = prior_observation.get('features') or current.get('features') or {}
                                prior_price = prior_observation.get('price', previous_price)
                                prior_time = prior_observation.get('time', current.get('time', now))
                                self.append_online_observation_experience(
                                    contract, str(current.get('id', '')), prior_time, prior_price,
                                    prior_features, r.get('price'), prior_observation.get('math_consensus', current.get('math_consensus', 0.0)), self.cfg)
                            except Exception:
                                pass
                            history.append(observation)
                        current['scan_observations'] = history[-200:]
                        current['observation_count'] = max(0, int(current.get('observation_count', 0) or 0)) + (0 if already_seen else 1)
                        if changed and not already_seen:
                            changes = current.get('signal_change_observations')
                            if not isinstance(changes, list): changes = []
                            changes.append(observation)
                            current['signal_change_observations'] = changes[-100:]
                            current['signal_change_count'] = max(0, int(current.get('signal_change_count', 0) or 0)) + 1
                        if signal == state_of(current) and not already_seen:
                            current['confirmation_count'] = max(0, int(current.get('confirmation_count', 0) or 0)) + 1
                        current['last_scan_at'] = now
                        current['last_scan_prediction_id'] = incoming_id
                        current['last_scan_signal'] = signal
                        current['last_scan_price'] = r.get('price')
                        current['last_scan_probabilities'] = {
                            'p_long': r.get('p_long'), 'p_short': r.get('p_short'), 'p_wait': r.get('p_wait')}
                        current['last_observed_signal_changed'] = bool(changed)
                        current['state_lifecycle_status'] = 'ACTIVE_SIGNAL_CHANGED' if changed else 'ACTIVE_CONFIRMED'
                        display = dict(current)
                        display['scan_observed_signal'] = signal
                        display['scan_state_changed'] = bool(changed)
                        display['scan_observation_time'] = now
                        display['contract'] = contract
                        returned.append(display)
                    else:
                        # Active-forecast rechecks are observations only: if the original
                        # lifecycle has already resolved, they must not silently create a
                        # fresh forecast. Only the regular TOP-5 scan may start one.
                        if not allow_new_lifecycle:
                            self._write_json(self.predictions, preds[-2000:])
                            self._write_json(self.pending, [x for x in pend if not x.get('resolved')][-2000:])
                            continue
                        # A previous ID in history is never resurrected. Otherwise
                        # this is the first scan after the prior lifecycle resolved.
                        if incoming_id not in pred_by_id:
                            item = dict(r)
                            item['contract'] = contract
                            item.setdefault('source', 'scan')
                            item.setdefault('resolved', 0)
                            item['state_lifecycle_status'] = 'ACTIVE_NEW'
                            item['confirmation_count'] = 0
                            item['observation_count'] = 0
                            item['scan_observations'] = []
                            item['signal_change_observations'] = []
                            item['signal_change_count'] = 0
                            item['last_scan_at'] = now
                            item['last_scan_prediction_id'] = incoming_id
                            item['last_scan_signal'] = signal
                            item['last_scan_price'] = r.get('price')
                            preds.append(item)
                            pred_by_id[incoming_id] = item
                            current = item
                        else:
                            current = pred_by_id[incoming_id]
                        display = dict(current)
                        display['scan_observed_signal'] = signal
                        display['scan_state_changed'] = False
                        display['scan_observation_time'] = now
                        returned.append(display)

                    # Rebuild pending from all true active directional lifecycles.
                    pred_map = {str(x.get('id')): x for x in preds if x.get('id') is not None}
                    new_pending = []
                    seen_pending = set()
                    for old_pending in pend:
                        pid = str(old_pending.get('id', ''))
                        canonical = pred_map.get(pid)
                        if not pid or canonical is None or not is_active(canonical) or state_of(canonical) not in ('LONG', 'SHORT'):
                            continue
                        if pid not in seen_pending:
                            new_pending.append(canonical); seen_pending.add(pid)
                    for item in preds:
                        pid = str(item.get('id', ''))
                        if pid and is_active(item) and state_of(item) in ('LONG', 'SHORT') and pid not in seen_pending:
                            new_pending.append(item); seen_pending.add(pid)
                    self._write_json(self.predictions, preds[-2000:])
                    self._write_json(self.pending, new_pending[-2000:])

                    state_path = self.logs / 'current_scan_state.json'
                    scan_state = self._read_json(state_path)
                    if not isinstance(scan_state, dict): scan_state = {}
                    if current is not None and is_active(current):
                        scan_state[contract] = {
                            'contract': contract,
                            'prediction_id': str(current.get('id', '')),
                            'state': state_of(current),
                            'last_observed_signal': str(current.get('last_scan_signal', state_of(current))),
                            'signal_changed': bool(current.get('last_observed_signal_changed', False)),
                            'created_at': int(current.get('time', 0) or 0),
                            'last_seen_at': int(current.get('last_scan_at', now) or now),
                            'confirmation_count': int(current.get('confirmation_count', 0) or 0),
                            'observation_count': int(current.get('observation_count', 0) or 0),
                            'signal_change_count': int(current.get('signal_change_count', 0) or 0),
                            'status': 'ACTIVE',
                        }
                    else:
                        scan_state.pop(contract, None)
                    self._write_json(state_path, scan_state)
                except Exception as exc:
                    raise RuntimeError(f'Не удалось согласовать прогнозы контракта {requested_contract}: {exc}') from exc
        return returned

    def predict_and_store(self, manual=False, source='auto'):
        row=self.live_row(); pred,probs=self.mm.predict(row); entry,sl,tp1,tp2,tp3=self._signal_levels(row,pred)
        ts=int(row['time'][0])
        item={'id':f"{time.time_ns()}-{self.exchange.futures_symbol}",'symbol':self.exchange.symbol,'exchange_symbol':self.exchange.futures_symbol,
              'contract':self.exchange.futures_symbol,'time':ts,'price':float(row['close'][0]),'prediction':pred,
              'p_short':probs[0],'p_wait':probs[1],'p_long':probs[2],'entry':entry,'sl':sl,'tp1':tp1,'tp2':tp2,'tp3':tp3,
              'horizon_bars':int(self.cfg['horizon_bars']),'resolved':0,'manual':bool(manual),'source':str(source)}
        item['features']={f:float(row[f][0]) for f in FEATURES}
        item.update(self.mm.prediction_diagnostics(row,pred,probs))
        self._attach_challenger_prediction(item, row)
        self._attach_lens_plans(item)
        item['lens_architecture']='MASTER_SHARED_BASE_PLUS_3_FIXED_LENSES' if item.get('lens_active') else 'MASTER_ONLY_FIRST_25'
        self._append_json(self.predictions,item)
        # WAIT is history only. It never occupies the trade-resolution queue.
        if pred in ('LONG','SHORT'):
            self._append_json(self.pending,item)
        return item
    def _read_json(self,path):
        try:return json.loads(path.read_text()) if path.exists() else []
        except Exception:return []
    def _write_json(self,path,data): path.write_text(json.dumps(data,ensure_ascii=False))
    def _append_json(self,path,item): data=self._read_json(path); data.append(item); self._write_json(path,data[-1000:])
    def _verification_slots(self, items):
        """Return IDs allowed to occupy the ten long-running slots."""
        try:
            now_bars=np.asarray(self.exchange.candles('5min',min(int(self.cfg.get('history_limit',5000)),5000))['time'])
        except Exception:
            return {x.get('id') for x in items}
        if len(now_bars)==0:return {x.get('id') for x in items}
        candidates=[]
        for item in items:
            if str(item.get('prediction','WAIT')).upper() not in ('LONG','SHORT'):
                continue
            horizon=int(item.get('horizon_bars',self.cfg.get('horizon_bars',12)))
            idx=int(np.searchsorted(now_bars,int(item.get('time',0)),side='right')); age=max(0,len(now_bars)-idx)
            if age>=horizon:
                candidates.append((int(item.get('time',0)),str(item.get('id',''))))
        candidates.sort()
        return {pid for _,pid in candidates[:10]}

    def _load_math_probability_calibration(self):
        data_dir = getattr(self, 'data', None)
        if data_dir is None:
            return None
        path = data_dir/'math_probability_calibration.json'
        try:
            state = self._read_json(path)
            if not isinstance(state, dict):
                return None
            if int(state.get('formula_version', -1)) != MATH_FORMULA_VERSION:
                return None
            return state
        except Exception:
            return None

    def _record_math_calibration_from_predictions(self, predictions, times, closes, highs, lows):
        """Label math probabilities on the same fixed horizon, without outcome leakage.

        Only predictions produced by this exact math formula version are eligible.
        A sample is recorded after all horizon candles exist, even if the trade's
        managed TP/SL lifecycle ended earlier. Labels use first barrier touch in
        the horizon, conservatively treating TP and SL in the same candle as SL.
        """
        times = np.asarray(times, dtype=np.int64)
        closes = np.asarray(closes, dtype=float)
        highs = np.asarray(highs, dtype=float)
        lows = np.asarray(lows, dtype=float)
        if len(times) < 25 or len(closes) != len(times):
            return False
        changed = False
        fresh = []
        fresh_items = []
        for item in predictions if isinstance(predictions, list) else []:
            if not isinstance(item, dict) or item.get('math_calibration_recorded'):
                continue
            if int(item.get('math_formula_version', -1)) != MATH_FORMULA_VERSION:
                continue
            direction = str(item.get('prediction', 'WAIT')).upper()
            if direction not in ('LONG', 'SHORT'):
                item['math_calibration_recorded'] = True
                changed = True
                continue
            math_values = item.get('math_features') if isinstance(item.get('math_features'), dict) else {}
            if not all(k in math_values for k in ('math_prob_move','math_monte_carlo','math_bayesian','math_ptp1','math_ptp2','math_ptp3','math_psl')):
                continue
            try:
                issue_time = int(item.get('time', 0))
                if issue_time < int(times[0]):
                    item['math_calibration_recorded'] = True
                    changed = True
                    continue
                idx = int(np.searchsorted(times, issue_time, side='right'))
                horizon = max(1, min(240, int(item.get('horizon_bars', self.cfg.get('horizon_bars', 12)))))
                end = idx+horizon
                if idx < 1 or end > len(times):
                    continue
                entry = float(item.get('entry', item.get('price', closes[idx-1])))
                sl = float(item.get('sl', float('nan')))
                targets = [float(item.get(k, float('nan'))) for k in ('tp1','tp2','tp3')]
                if not np.isfinite(entry) or entry <= 0 or not np.isfinite(sl) or any(not np.isfinite(v) for v in targets):
                    continue
                fh = highs[idx:end]; fl = lows[idx:end]
                first_stop = horizon+1
                first_targets = [horizon+1, horizon+1, horizon+1]
                for j, (hi, lo) in enumerate(zip(fh, fl)):
                    if direction == 'LONG':
                        stop_hit = lo <= sl
                        target_hits = [hi >= target for target in targets]
                    else:
                        stop_hit = hi >= sl
                        target_hits = [lo <= target for target in targets]
                    if stop_hit and first_stop > horizon:
                        first_stop = j
                    for k, hit in enumerate(target_hits):
                        if hit and first_targets[k] > horizon:
                            first_targets[k] = j
                y = {
                    'move_hit': False,
                    'positive_return': False,
                    'tp1_before_sl': bool(first_targets[0] < first_stop),
                    'tp2_before_sl': bool(first_targets[1] < first_stop),
                    'tp3_before_sl': bool(first_targets[2] < first_stop),
                    'sl_before_tp1': bool(first_stop <= first_targets[0] and first_stop <= horizon),
                }
                prior = closes[max(0, idx-121):idx]
                if len(prior) >= 20 and prior[0] > 0:
                    log_returns = np.diff(np.log(np.maximum(prior, 1e-12)))
                    sigma = float(np.std(log_returns))
                    actual_move = abs(float(np.log(max(closes[end-1],1e-12)/max(closes[idx-1],1e-12))))
                    y['move_hit'] = bool(actual_move >= max(sigma*np.sqrt(horizon), 1e-12))
                    y['positive_return'] = bool(np.log(max(closes[end-1],1e-12)/max(closes[idx-1],1e-12)) > 0)
                else:
                    y['move_hit'] = False
                    y['positive_return'] = False
                sample = {'id':str(item.get('id','')), 'time':int(issue_time),
                          'cycle':int(item.get('run_id', 0) or 0),
                          'formula_version':MATH_FORMULA_VERSION,
                          'p':{k:float(np.clip(math_values[k],0,1)) for k in ('math_prob_move','math_monte_carlo','math_bayesian','math_ptp1','math_ptp2','math_ptp3','math_psl')},
                          'y':y}
                fresh.append(sample)
                fresh_items.append((item, y))
            except Exception:
                continue
        if not fresh:
            return changed
        path = self.data/'math_probability_calibration.json'
        with _MATH_CALIBRATION_LOCK:
            try:
                state = self._read_json(path) if path.exists() else {}
                if not isinstance(state, dict) or int(state.get('formula_version', -1)) != MATH_FORMULA_VERSION:
                    state = {'formula_version':MATH_FORMULA_VERSION, 'samples':[]}
                samples = list(state.get('samples', []))
                seen = {str(x.get('id')) for x in samples}
                for sample in fresh:
                    if sample['id'] and sample['id'] not in seen:
                        samples.append(sample); seen.add(sample['id'])
                samples = samples[-2000:]
                fitted = fit_math_probability_calibration(samples, MATH_FORMULA_VERSION, min_samples=100)
                state.update(fitted)
                state['samples'] = samples
                state['updated_at'] = int(time.time())
                tmp = path.with_suffix('.tmp')
                tmp.write_text(json.dumps(state, ensure_ascii=False, separators=(',',':')), encoding='utf-8')
                tmp.replace(path)
                for item, labels in fresh_items:
                    item['math_calibration_recorded'] = True
                    item['math_calibration_labels'] = labels
                    changed = True
            except Exception:
                # Do not mark samples consumed unless their calibration row was
                # persisted; a later pass must be able to retry the write.
                return changed
        return changed

    def resolve_pending(self, allowed_ids=None):
        """Resolve real trade outcomes with dynamic protection and post-SL recheck.

        TP1 moves protection to Entry. TP2 moves it to TP1. TP3 is a success
        milestone, not a ceiling; extension beyond TP3 is preserved as TP3+.
        An initial SL is a real trading loss, but the next few candles are also
        checked for an immediate recovery so Master can learn "direction right,
        entry/stop timing wrong" separately from a genuinely wrong direction.
        """
        data=self._read_json(self.pending)
        work=[x for x in data if (not x.get('resolved')) or bool(x.get('post_sl_recheck_pending'))]
        try:
            bars=self.exchange.candles('5min',min(int(self.cfg.get('history_limit',5000)),5000))
        except Exception:
            return []
        t=np.asarray(bars['time']); h=np.asarray(bars['high']); l=np.asarray(bars['low']); c=np.asarray(bars['close'])
        if len(t)==0: return []
        if not work:
            preds=self._read_json(self.predictions)
            if self._record_math_calibration_from_predictions(preds, t, c, h, l):
                self._write_json(self.predictions, preds[-2000:])
            return []
        unresolved=[x for x in work if not x.get('resolved')]
        active_map=self._verification_slots(unresolved) if allowed_ids is None else set(allowed_ids)
        long_running=[]
        for x in unresolved:
            if str(x.get('prediction','WAIT')).upper() in ('LONG','SHORT'):
                age=max(0,int(np.searchsorted(t,int(x.get('time',0)),side='right'))-1)
                if age>=int(x.get('horizon_bars',self.cfg.get('horizon_bars',12))): long_running.append(x)
        long_running.sort(key=lambda x:(int(x.get('time',0)),str(x.get('id',''))))
        queue_pos={x.get('id'):i+1 for i,x in enumerate(long_running) if x.get('id') not in active_map}
        changed=[]; still=[]; recheck_bars=max(1,int(self.cfg.get('post_sl_recheck_bars',3)))

        def event_context(abs_idx,direction):
            a=max(0,abs_idx-20); b=min(len(t),abs_idx+1); prev_v=np.asarray(bars['volume'])[a:abs_idx]
            vol=float(np.asarray(bars['volume'])[abs_idx]) if abs_idx<len(bars['volume']) else 0.0
            mean_v=float(np.mean(prev_v)) if len(prev_v) else vol
            op=float(np.asarray(bars['open'])[abs_idx]); cl=float(np.asarray(bars['close'])[abs_idx]); hi=float(h[abs_idx]); lo=float(l[abs_idx])
            rng=max(abs(cl),1e-12); body=(cl-op)/rng; upper=(hi-max(op,cl))/rng; lower=(min(op,cl)-lo)/rng
            return {'candle_index':int(abs_idx),'time':int(t[abs_idx]),'volume':vol,'volume_ratio_to_prev20':float(vol/max(mean_v,1e-12)),
                    'event_return':float(body),'range_pct':float((hi-lo)/rng),'body_pct':float(body),'upper_wick_pct':float(upper),'lower_wick_pct':float(lower),'direction':direction}

        def finish_common(item,idx,start_idx,sl_index=None):
            direction=str(item.get('prediction','WAIT')).upper(); entry=float(item.get('entry',item.get('price',c[idx])))
            highs=h[idx:]; lows=l[idx:]; closes=c[idx:]
            if len(closes)==0: return False
            ret=float((closes[-1]/entry)-1.0) if entry else 0.0
            if direction=='LONG':
                mfe=float((np.max(highs)-entry)/entry) if len(highs) else 0.0; mae=float((np.min(lows)-entry)/entry) if len(lows) else 0.0
                actual='LONG' if ret>=float(self.cfg['long_threshold']) else ('SHORT' if ret<=float(self.cfg['short_threshold']) else 'WAIT')
            else:
                mfe=float((entry-np.min(lows))/entry) if len(lows) else 0.0; mae=float((entry-np.max(highs))/entry) if len(highs) else 0.0
                actual='SHORT' if ret<=float(self.cfg['short_threshold']) else ('LONG' if ret>=float(self.cfg['long_threshold']) else 'WAIT')
            tp3=float(item.get('tp3',float('nan'))); first_idx=item.get('hit_index')
            extension=0.0
            if bool(item.get('tp3_hit')) and first_idx is not None and np.isfinite(tp3) and tp3:
                rel=max(0,int(first_idx));
                if direction=='LONG': extension=max(0.0,float((np.max(h[idx+rel:])-tp3)/tp3))
                else: extension=max(0.0,float((tp3-np.min(l[idx+rel:]))/tp3))
            outcome=4 if item.get('tp3_hit') and extension>0 else 3 if item.get('tp3_hit') else 2 if item.get('tp2_hit') else 1 if item.get('tp1_hit') else 0 if item.get('initial_sl_failure') else -1
            direction_confirmed=bool(item.get('direction_confirmed',False))
            source=item.get('direction_confirmation_source')
            if not direction_confirmed and actual==direction:
                direction_confirmed=True; source='HORIZON_ENDPOINT'
            item.update({'actual':actual,'direction_target':direction if direction_confirmed else actual,'direction_confirmed':direction_confirmed,
                         'direction_confirmation_source':source or ('TP_MILESTONE' if outcome>=1 else 'NONE'),
                         'return':ret,'mfe':mfe,'mae':mae,'resolved':1,
                         'trade_outcome':OUTCOME_NAMES[outcome] if outcome>=0 else 'UNKNOWN','outcome_score':max(0,outcome),
                         'hit':item.get('hit') or ('TP3' if item.get('tp3_hit') else 'TP2' if item.get('tp2_hit') else 'TP1' if item.get('tp1_hit') else 'SL' if item.get('sl_hit') else None),
                         'result':'TP3' if item.get('tp3_hit') else 'TP2' if item.get('tp2_hit') else 'TP1' if item.get('tp1_hit') else 'SL' if item.get('sl_hit') else None,
                         'max_extension_beyond_tp3_pct':extension*100.0,'post_tp3_extension':extension,'post_tp3_observed':bool(item.get('tp3_hit')),
                         'trade_success':bool(outcome>=1),'resolved_at':int(t[-1]),'verification_elapsed_bars':max(0,len(t)-idx),
                         'waiting_hours':round(max(0,len(t)-idx)*5/60.0,2)})
            return True

        for item in work:
            pid=item.get('id'); direction=str(item.get('prediction','WAIT')).upper()
            if direction not in ('LONG','SHORT'):
                # Safety migration: WAIT is history only.
                continue
            # Already resolved by initial SL: only the post-SL audit remains.
            if item.get('resolved') and item.get('post_sl_recheck_pending'):
                sl_time=int(item.get('sl_event_time',0) or 0)
                sidx=int(np.searchsorted(t,sl_time,side='right'))-1
                sidx=max(0,sidx); a=sidx+1; b=min(len(t),a+recheck_bars)
                if b-a<recheck_bars:
                    still.append(item); continue
                entry=float(item.get('entry',item.get('price',0.0))); tp1=float(item.get('tp1',float('nan'))); tp2=float(item.get('tp2',float('nan'))); tp3=float(item.get('tp3',float('nan')))
                recovery_level=None
                if direction=='LONG':
                    if np.any(h[a:b]>=tp3): recovery_level='TP3'
                    elif np.any(h[a:b]>=tp2): recovery_level='TP2'
                    elif np.any(h[a:b]>=tp1): recovery_level='TP1'
                else:
                    if np.any(l[a:b]<=tp3): recovery_level='TP3'
                    elif np.any(l[a:b]<=tp2): recovery_level='TP2'
                    elif np.any(l[a:b]<=tp1): recovery_level='TP1'
                item['post_sl_recheck_pending']=False; item['post_sl_recheck_complete']=True; item['post_sl_recheck_bars']=recheck_bars
                item['post_sl_recovery']=bool(recovery_level); item['post_sl_recovery_level']=recovery_level
                recovery_target={'TP1':tp1,'TP2':tp2,'TP3':tp3}.get(recovery_level,float('nan')) if recovery_level else float('nan')
                if recovery_level and np.isfinite(recovery_target):
                    mask=(h[a:b]>=recovery_target) if direction=='LONG' else (l[a:b]<=recovery_target)
                    first_rel=int(np.argmax(mask)) if np.any(mask) else 0
                    item['post_sl_recovery_bars']=int((a+first_rel)-sidx)
                else:
                    item['post_sl_recovery_bars']=None
                item['post_sl_event_context']=event_context(sidx,direction)
                pred_idx=max(0,int(np.searchsorted(t,int(item.get('time',0)),side='right')))
                if recovery_level:
                    item['direction_confirmed']=True; item['direction_target']=direction; item['direction_confirmation_source']='POST_SL_RECOVERY'
                    item['learning_interpretation']='DIRECTION_RIGHT_ENTRY_TIMING_WRONG'
                finish_common(item,pred_idx,pred_idx,sidx)
                item['verification_state']='COMPLETED_SL_POST_RECHECK'
                self._annotate_confidence_outcome(item)
                if item.get('lens_plans'):
                    item['lens_outcomes']={lk:self._resolve_lens_plan(plan,h[pred_idx:],l[pred_idx:],recheck_bars) for lk,plan in item['lens_plans'].items()}
                if item.get('combination_plans'):
                    item['combination_outcomes']={ck:self._resolve_lens_plan(plan,h[pred_idx:],l[pred_idx:],recheck_bars) for ck,plan in item['combination_plans'].items()}
                if item.get('challenger_plan'):
                    item['challenger_outcome']=self._resolve_lens_plan(item['challenger_plan'],h[pred_idx:],l[pred_idx:],recheck_bars)
                changed.append(item); continue

            idx=int(np.searchsorted(t,int(item.get('time',0)),side='right'))
            if idx>=len(c):
                still.append(item); continue
            horizon=int(item.get('horizon_bars',self.cfg.get('horizon_bars',12)))
            elapsed=max(0,len(c)-idx)
            if elapsed>=horizon and pid not in active_map:
                item['verification_state']='QUEUED'; item['queue_position']=queue_pos.get(pid); still.append(item); continue
            entry=float(item.get('entry',item.get('price',c[idx]))); sl=float(item.get('sl',float('nan'))); tp1=float(item.get('tp1',float('nan'))); tp2=float(item.get('tp2',float('nan'))); tp3=float(item.get('tp3',float('nan')))
            tp1_hit=bool(item.get('tp1_hit')); tp2_hit=bool(item.get('tp2_hit')); tp3_hit=bool(item.get('tp3_hit')); first_hit=item.get('hit'); first_hit_index=item.get('hit_index'); sl_hit=False; protected_exit=False; terminal=False; sl_abs=None
            highs=h[idx:]; lows=l[idx:]
            for off,(hi,lo) in enumerate(zip(highs,lows)):
                if direction=='LONG':
                    original_stop=np.isfinite(sl) and lo<=sl
                    hit3=np.isfinite(tp3) and hi>=tp3 and not tp3_hit
                    hit2=np.isfinite(tp2) and hi>=tp2 and not tp2_hit
                    hit1=np.isfinite(tp1) and hi>=tp1 and not tp1_hit
                else:
                    original_stop=np.isfinite(sl) and hi>=sl
                    hit3=np.isfinite(tp3) and lo<=tp3 and not tp3_hit
                    hit2=np.isfinite(tp2) and lo<=tp2 and not tp2_hit
                    hit1=np.isfinite(tp1) and lo<=tp1 and not tp1_hit
                if not tp1_hit and original_stop:
                    sl_hit=True; sl_abs=idx+off; terminal=True; item['sl_event_time']=int(t[sl_abs]); item['sl_event_index']=int(sl_abs); item['sl_event_context']=event_context(sl_abs,direction); break
                prior_protective = entry if tp1_hit and not tp2_hit else (tp1 if tp2_hit and not tp3_hit else None)
                prior_protective_hit = (prior_protective is not None and (lo <= prior_protective if direction=='LONG' else hi >= prior_protective))
                if prior_protective_hit:
                    protected_exit=True; terminal=True
                    item['protection_event_index']=int(idx+off); item['protection_event_time']=int(t[idx+off])
                    item['protection_event_context']=event_context(idx+off,direction); item['protection_level']=float(prior_protective)
                    break
                if hit3:
                    tp1_hit=tp2_hit=tp3_hit=True; first_hit=first_hit or 'TP3'; first_hit_index=off if first_hit_index is None else first_hit_index; continue
                if hit2:
                    tp1_hit=tp2_hit=True; first_hit=first_hit or 'TP2'; first_hit_index=off if first_hit_index is None else first_hit_index
                elif hit1:
                    tp1_hit=True; first_hit=first_hit or 'TP1'; first_hit_index=off if first_hit_index is None else first_hit_index
                if direction=='LONG': protective=entry if tp1_hit and not tp2_hit else (tp1 if tp2_hit and not tp3_hit else None); protected_hit=protective is not None and lo<=protective
                else: protective=entry if tp1_hit and not tp2_hit else (tp1 if tp2_hit and not tp3_hit else None); protected_hit=protective is not None and hi>=protective
                if protected_hit and not tp3_hit:
                    protected_exit=True; terminal=True
                    item['protection_event_index']=int(idx+off)
                    item['protection_event_time']=int(t[idx+off])
                    item['protection_event_context']=event_context(idx+off,direction)
                    item['protection_level']=float(protective)
                    break
            item.update({'tp1_hit':tp1_hit,'tp2_hit':tp2_hit,'tp3_hit':tp3_hit,'sl_hit':bool(sl_hit),'initial_sl_failure':bool(sl_hit and not tp1_hit),
                         'hit':first_hit,'hit_index':first_hit_index,'protected_exit':protected_exit})
            if sl_hit and not tp1_hit:
                # Real trade is a loss, but keep it in the verification queue until
                # the next few candles have been observed for a directional recovery.
                item['resolved']=1; item['trade_outcome']='INITIAL_SL'; item['outcome_score']=0; item['trade_success']=False
                item['post_sl_recheck_pending']=True; item['post_sl_recheck_complete']=False; item['verification_state']='COMPLETED_SL_WAITING_POST_RECHECK'
                a=sl_abs+1; b=min(len(t),a+recheck_bars)
                if b-a<recheck_bars:
                    still.append(item); continue
                # Enough future candles are already available; next loop branch will
                # complete the audit without duplicating the trade-resolution logic.
                still.append(item); continue
            if not terminal and not tp3_hit:
                if elapsed<horizon: state='INITIAL_WAIT'
                elif tp2_hit: state='WAITING_TP3'
                elif tp1_hit: state='WAITING_TP2'
                else: state='LONG_RUNNING_WAITING'
                item.update({'verification_state':state,'verification_elapsed_bars':elapsed,'waiting_hours':round(elapsed*5/60.0,2),'resolved':0})
                still.append(item); continue
            item['resolved']=1; item['post_sl_recheck_pending']=False; item['post_sl_recheck_complete']=False
            item['verification_state']='COMPLETED_TP3' if tp3_hit else 'COMPLETED_TP2_PROTECTED' if protected_exit and tp2_hit else 'COMPLETED_TP1_PROTECTED' if protected_exit and tp1_hit else 'COMPLETED_TP'
            item['exit_reason']='PROTECTED_AT_TP1' if protected_exit and tp2_hit else 'BREAKEVEN_AT_ENTRY' if protected_exit and tp1_hit else 'TP3' if tp3_hit else 'TP2' if tp2_hit else 'TP1'
            item['direction_confirmed']=True; item['direction_target']=direction; item['direction_confirmation_source']='TP_MILESTONE'
            finish_common(item,idx,idx)
            self._annotate_confidence_outcome(item)
            if item.get('lens_plans'):
                item['lens_outcomes']={lk:self._resolve_lens_plan(plan,highs,lows,recheck_bars) for lk,plan in item['lens_plans'].items()}
            if item.get('combination_plans'):
                item['combination_outcomes']={ck:self._resolve_lens_plan(plan,highs,lows,recheck_bars) for ck,plan in item['combination_plans'].items()}
            if item.get('challenger_plan'):
                item['challenger_outcome']=self._resolve_lens_plan(item['challenger_plan'],highs,lows,recheck_bars)
            changed.append(item)

        changed_ids={str(x.get('id')) for x in changed}
        # Keep all unresolved and post-SL-audit-pending items. WAIT never enters this list.
        final_pending=[]
        for x in data:
            pid=str(x.get('id'))
            if pid in changed_ids: continue
            if str(x.get('prediction','WAIT')).upper() not in ('LONG','SHORT'): continue
            if not x.get('resolved') or x.get('post_sl_recheck_pending'):
                final_pending.append(x)
        self._write_json(self.pending,final_pending)
        if changed:
            self._append_experience(changed)
            preds=self._read_json(self.predictions); byid={str(x.get('id')):x for x in changed}
            for p in preds:
                if str(p.get('id')) in byid: p.update(byid[str(p.get('id'))])
            self._write_json(self.predictions,preds[-2000:])
        else:
            preds=self._read_json(self.predictions); byid={str(x.get('id')):x for x in final_pending}
            for p in preds:
                if str(p.get('id')) in byid:
                    for k in ('resolved','verification_state','verification_elapsed_bars','waiting_hours','queue_position','tp1_hit','tp2_hit','tp3_hit','sl_hit','initial_sl_failure','protected_exit','exit_reason','result','hit','hit_index','post_sl_recheck_pending','post_sl_recheck_complete'):
                        if k in byid[str(p.get('id'))]: p[k]=byid[str(p.get('id'))][k]
            self._write_json(self.predictions,preds[-2000:])
        if self._record_math_calibration_from_predictions(preds, t, c, h, l):
            self._write_json(self.predictions, preds[-2000:])
        return changed
    @staticmethod
    def _age_bars_from_now(timestamp, now_seconds=None):
        """Age in 5-minute bars, accepting exchange timestamps in us/ms/s."""
        now_seconds = time.time() if now_seconds is None else float(now_seconds)
        ts = int(timestamp or 0)
        if ts >= 100_000_000_000_000:  # microseconds
            created_seconds = ts / 1_000_000.0
        elif ts >= 100_000_000_000:  # milliseconds
            created_seconds = ts / 1_000.0
        else:  # seconds
            created_seconds = float(ts)
        return max(0, int((now_seconds - created_seconds) // 300))

    def resolve_all_pending(self):
        """Advance all active trades plus pending post-SL rechecks."""
        pending_items=[]
        for path in sorted(self.logs.glob('*_pending.json')):
            try: data=json.loads(path.read_text(encoding='utf-8')) if path.exists() else []
            except Exception: data=[]
            contract=path.name[:-len('_pending.json')]
            for item in data:
                if str(item.get('prediction','WAIT')).upper() in ('LONG','SHORT') and (not item.get('resolved') or item.get('post_sl_recheck_pending')):
                    pending_items.append((contract,item))
        now_seconds=time.time(); horizon_default=int(self.cfg.get('horizon_bars',12)); long_running=[]
        for contract,item in pending_items:
            if item.get('post_sl_recheck_pending'): continue
            age=self._age_bars_from_now(item.get('time',0), now_seconds); horizon=int(item.get('horizon_bars',horizon_default))
            if age>=horizon: long_running.append((int(item.get('time',0)),str(item.get('id','')),contract))
        long_running.sort(); max_slots=int(self.cfg.get('max_long_running_predictions',10)); allowed_ids={pid for _,pid,_ in long_running[:max_slots]}; queued={pid:i+1 for i,(_,pid,_) in enumerate(long_running) if pid not in allowed_ids}
        for path in sorted(self.logs.glob('*_pending.json')):
            try:
                pdata=json.loads(path.read_text(encoding='utf-8')) if path.exists() else []; changed_q=False
                for item in pdata:
                    pid=item.get('id')
                    if pid in queued and not item.get('resolved'):
                        item['verification_state']='QUEUED'; item['queue_position']=queued[pid]; changed_q=True
                if changed_q: self._write_json(path,pdata)
            except Exception: pass
        resolved=[]
        for path in sorted(self.logs.glob('*_pending.json')):
            contract=path.name[:-len('_pending.json')]
            if not contract: continue
            try:
                self.set_symbol(contract); pdata=self._read_json(path); local_ids=[]
                for item in pdata:
                    if str(item.get('prediction','WAIT')).upper() not in ('LONG','SHORT'): continue
                    if item.get('post_sl_recheck_pending'):
                        local_ids.append(item.get('id')); continue
                    if item.get('resolved'): continue
                    age=self._age_bars_from_now(item.get('time',0), now_seconds); horizon=int(item.get('horizon_bars',horizon_default))
                    if age<horizon or item.get('id') in allowed_ids: local_ids.append(item.get('id'))
                resolved.extend(self.resolve_pending(allowed_ids=set(local_ids)))
            except Exception: continue
        return resolved
    def _wait_learning_row(self, item, target, outcome, endpoint_return, max_up, max_down, elapsed):
        """Build a direction-learning row from a completed WAIT control observation.

        WAIT is not a trade and therefore never receives TP/SL or `resolved=1`.
        It is nevertheless a supervised direction lesson:
        WAIT -> rise = missed LONG, WAIT -> fall = missed SHORT,
        WAIT -> sideways = correct WAIT.
        """
        contract=str(item.get('contract') or item.get('exchange_symbol') or '').strip()
        pid=str(item.get('id') or f"{contract}:{int(item.get('time',0))}")
        weight=float(self.cfg.get('wait_learning_weight',0.80))
        return {
            'time':int(item.get('time',0)),
            'contract':contract or 'UNKNOWN',
            'prediction_id':pid,
            'target':int(target),
            'outcome_target':-1,
            'sample_weight':weight,
            'outcome_sample_weight':0.0,
            'math_consensus':float(item.get('math_consensus',0.0) or 0.0),
            'experience_kind':'WAIT_CONTROL',
            'outcome':str(outcome),
            **{f:float((item.get('features') or {}).get(f,0.0) or 0.0) for f in FEATURES}
        }

    def _wait_observation_experience_rows(self, item, target, outcome):
        """Low-weight direction-only learning from temporal snapshots of a WAIT lifecycle."""
        observations = item.get('scan_observations')
        if not isinstance(observations, list) or not observations:
            return []
        contract = str(item.get('contract') or item.get('exchange_symbol') or '').strip()
        base_id = str(item.get('id') or f"{contract}:{int(item.get('time', 0))}")
        valid = [o for o in observations if isinstance(o, dict) and isinstance(o.get('features'), dict)
                 and all(f in o.get('features', {}) for f in FEATURES) and int(o.get('time', 0) or 0) > 0]
        cap = max(1, int(self.cfg.get('max_direction_observation_samples_per_forecast', 12)))
        if len(valid) > cap:
            if cap == 1:
                valid = [valid[-1]]
            else:
                indices = sorted({round(i * (len(valid) - 1) / (cap - 1)) for i in range(cap)})
                valid = [valid[i] for i in indices]
        rows = []
        for index, observation in enumerate(valid):
            row = {
                'time': int(observation['time']), 'contract': contract or 'UNKNOWN',
                'prediction_id': f"{base_id}:wait-observation:{observation.get('scan_prediction_id') or observation.get('time')}:{index}",
                'target': int(target), 'outcome_target': -1,
                'sample_weight': float(self.cfg.get('wait_learning_weight', 0.80)) * float(self.cfg.get('direction_observation_sample_weight', 0.05)),
                'outcome_sample_weight': 0.0,
                'math_consensus': float(observation.get('math_consensus', 0.0) or 0.0),
                'experience_kind': 'WAIT_CONTROL_OBSERVATION', 'outcome': str(outcome),
                **{f: float(observation['features'].get(f, 0.0) or 0.0) for f in FEATURES}
            }
            rows.append(row)
        return rows

    def _append_wait_experience(self, rows):
        if not rows:
            return 0
        old=self._load_exp()
        all_rows=[]
        if old and len(old.get('time',[])):
            n=len(old['time'])
            for i in range(n):
                try:
                    all_rows.append({
                        'time':int(old['time'][i]),
                        'contract':str(np.asarray(old.get('contract',np.asarray(['LEGACY_UNKNOWN']*n)))[i]),
                        'prediction_id':str(np.asarray(old.get('prediction_id',np.asarray([f'legacy:{int(old["time"][i])}:{i}']*n)))[i]),
                        'target':int(old['target'][i]),
                        'outcome_target':int(old.get('outcome_target',np.full(n,-1))[i]),
                        'sample_weight':float(old.get('sample_weight',np.ones(n))[i]),
                        'outcome_sample_weight':float(old.get('outcome_sample_weight',np.zeros(n))[i]),
                        'math_consensus':float(old.get('math_consensus',np.zeros(n))[i]),
                        'experience_kind':str(np.asarray(old.get('experience_kind',np.asarray(['TRADE']*n)))[i]),
                        **{f:float(old[f][i]) for f in FEATURES}
                    })
                except Exception:
                    continue
        all_rows.extend(rows)
        self._save_exp(self._bounded_experience(all_rows))
        return len(rows)

    def resolve_wait_learning(self):
        """Resolve WAIT as a direction-control observation over an extended 5m horizon.

        WAIT is not a trade: it receives no TP/SL.  The first 12 bars are an
        intermediate checkpoint; the final learning horizon is 48 bars (4h).
        A transient TP1-style spike that immediately reverses is recorded as
        FALSE_SPIKE rather than a hard missed-direction label.
        """
        changed=[]; rows=[]
        wait_stats={'checked':0,'correct_wait':0,'missed_long':0,'missed_short':0,'false_spike':0,'still_waiting':0}
        final_horizon=max(12, int(self.cfg.get('wait_learning_horizon_bars',48)))
        threshold_up=float(self.cfg.get('long_threshold',0.003)); threshold_down=float(self.cfg.get('short_threshold',-0.003))
        for path in sorted(self.logs.glob('*_predictions.json')):
            try: items=json.loads(path.read_text(encoding='utf-8')) if path.exists() else []
            except Exception: continue
            if not items: continue
            contract_from_file=path.name[:-len('_predictions.json')]
            try:
                self.set_symbol(contract_from_file)
                bars=self.exchange.candles('5min',min(int(self.cfg.get('history_limit',5000)),5000))
                t=np.asarray(bars['time']); h=np.asarray(bars['high']); l=np.asarray(bars['low']); c=np.asarray(bars['close'])
            except Exception: continue
            if len(t)==0: continue
            file_changed=False
            for item in items:
                if str(item.get('prediction','WAIT')).upper()!='WAIT' or item.get('wait_learning_resolved') or not item.get('features'):
                    continue
                try:
                    idx=int(np.searchsorted(t,int(item.get('time',0)),side='right'))
                    if idx>=len(c): continue
                    available=len(c)-idx
                    # Do not close the learning label until the full extended window exists.
                    if available < final_horizon:
                        item['wait_learning_state']='OBSERVING'
                        item['wait_checkpoint_bars']=min(available,12)
                        wait_stats['still_waiting']+=1
                        file_changed=True
                        continue
                    entry=float(item.get('price',c[idx-1] if idx>0 else c[idx]))
                    if not np.isfinite(entry) or entry<=0: continue
                    future_c=c[idx:idx+final_horizon]; future_h=h[idx:idx+final_horizon]; future_l=l[idx:idx+final_horizon]
                    rel_up=future_h/entry-1.0; rel_down=future_l/entry-1.0
                    max_up=float(np.max(rel_up)); max_down=float(np.min(rel_down))
                    first_up=int(np.argmax(rel_up))+1 if max_up>=threshold_up else None
                    first_down=int(np.argmin(rel_down))+1 if max_down<=threshold_down else None
                    candidates=[('LONG',first_up),('SHORT',first_down)]
                    candidates=[x for x in candidates if x[1] is not None]
                    first_direction, first_bar=(min(candidates,key=lambda x:x[1]) if candidates else (None,None))
                    endpoint_return=float(future_c[-1]/entry-1.0)
                    # Spike quality: after first threshold hit, did price remain beyond the level
                    # for at least 2 bars, or continue another 0.15% in the same direction?
                    hold_bars=0; continuation=0.0; return_bar=None
                    if first_direction=='LONG':
                        hit_idx=first_bar-1; post=rel_up[hit_idx:]
                        hold_bars=int(np.sum(post>=threshold_up))
                        continuation=float(np.max(post)-threshold_up) if len(post) else 0.0
                        back=np.where(rel_down[hit_idx:]<=0.0)[0]
                        return_bar=(hit_idx+int(back[0])+1) if len(back) else None
                    elif first_direction=='SHORT':
                        hit_idx=first_bar-1; post=rel_down[hit_idx:]
                        hold_bars=int(np.sum(post<=threshold_down))
                        continuation=float(abs(np.min(post))-abs(threshold_down)) if len(post) else 0.0
                        back=np.where(rel_up[hit_idx:]>=0.0)[0]
                        return_bar=(hit_idx+int(back[0])+1) if len(back) else None
                    # A very brief threshold touch followed by a return to entry is a spike.
                    false_spike=bool(first_direction and hold_bars<2 and return_bar is not None and return_bar<=first_bar+3 and continuation<0.0015)
                    if false_spike:
                        outcome='FALSE_SPIKE'; target=1; wait_stats['false_spike']+=1
                    elif first_direction=='LONG':
                        outcome='MISSED_LONG'; target=2; wait_stats['missed_long']+=1
                    elif first_direction=='SHORT':
                        outcome='MISSED_SHORT'; target=0; wait_stats['missed_short']+=1
                    else:
                        outcome='WAIT_CORRECT'; target=1; wait_stats['correct_wait']+=1
                    item.update({
                        'wait_learning_resolved':True,
                        'resolved':1,
                        'trade_outcome':outcome,
                        'trade_success':bool(outcome=='WAIT_CORRECT'),
                        'resolved_at':int(t[idx+final_horizon-1]),
                        'wait_learning_state':'COMPLETED',
                        'wait_learning_outcome':outcome,
                        'wait_learning_target':int(target),
                        'wait_endpoint_return_pct':endpoint_return*100.0,
                        'wait_max_up_pct':max_up*100.0,
                        'wait_max_down_pct':max_down*100.0,
                        'wait_elapsed_bars':final_horizon,
                        'wait_horizon_bars':final_horizon,
                        'wait_resolved_at':int(t[idx+final_horizon-1]),
                        'wait_first_direction':first_direction or 'NONE',
                        'wait_first_direction_bar':first_bar,
                        'wait_first_direction_minutes':(first_bar*5 if first_bar else None),
                        'wait_tp1_speed_pct_per_min':((threshold_up*100.0)/(first_bar*5) if first_direction=='LONG' and first_bar else (-threshold_down*100.0)/(first_bar*5) if first_direction=='SHORT' and first_bar else 0.0),
                        'wait_tp1_hold_bars':hold_bars,
                        'wait_tp1_hold_minutes':hold_bars*5,
                        'wait_return_to_entry_bar':return_bar,
                        'wait_return_to_entry_minutes':(return_bar*5 if return_bar else None),
                        'wait_continuation_after_tp1_pct':continuation*100.0,
                        'wait_resolution_reason':outcome,
                        'wait_false_spike':false_spike,
                        'wait_learning_interpretation':('WAIT_FALSE_SPIKE' if false_spike else 'WAIT_MISSED_LONG' if outcome=='MISSED_LONG' else 'WAIT_MISSED_SHORT' if outcome=='MISSED_SHORT' else 'WAIT_CORRECT_SIDEWAYS')
                    })
                    rows.append(self._wait_learning_row(item,target,outcome,endpoint_return,max_up,max_down,final_horizon))
                    rows.extend(self._wait_observation_experience_rows(item, target, outcome))
                    changed.append(item); file_changed=True; wait_stats['checked']+=1
                    self._append_learning_audit({'event':'WAIT_CONTROL_RESOLVED','prediction_id':item.get('id'),'contract':item.get('contract') or contract_from_file,'cycle':item.get('run_id'),'master_prediction':'WAIT','wait_learning_outcome':outcome,'wait_learning_target':int(target),'endpoint_return_pct':endpoint_return*100.0,'max_up_pct':max_up*100.0,'max_down_pct':max_down*100.0,'horizon_bars':final_horizon,'first_direction':first_direction or 'NONE','first_direction_bar':first_bar,'first_direction_minutes':(first_bar*5 if first_bar else None),'tp1_hold_bars':hold_bars,'return_to_entry_bar':return_bar,'false_spike':false_spike,'lens_training_enabled':False})
                except Exception: continue
            if file_changed: self._write_json(path,items[-2000:])
        # Close legacy WAIT observations that can no longer be validated because
        # their candle window has fallen out of the exchange history.  These are
        # administrative expirations only: they do not create training rows and
        # are excluded from accuracy/outcome metrics.
        stale_cutoff_bars = max(final_horizon * 2, 96)
        now_seconds = time.time()
        stale_closed = 0
        for path in sorted(self.logs.glob('*_predictions.json')):
            try:
                items = json.loads(path.read_text(encoding='utf-8')) if path.exists() else []
            except Exception:
                continue
            changed_file = False
            contract = path.name[:-len('_predictions.json')]
            for item in items:
                if str(item.get('prediction', 'WAIT')).upper() != 'WAIT':
                    continue
                if item.get('resolved') or item.get('wait_learning_resolved'):
                    continue
                try:
                    created = int(item.get('time', 0))
                    age_bars = self._age_bars_from_now(created, now_seconds)
                except Exception:
                    continue
                if age_bars < stale_cutoff_bars:
                    continue
                item.update({
                    'resolved': 1,
                    'wait_learning_resolved': True,
                    'wait_learning_state': 'EXPIRED_STALE_UNVERIFIABLE',
                    'verification_state': 'EXPIRED_STALE_UNVERIFIABLE',
                    'result': 'EXPIRED_UNVERIFIABLE',
                    'trade_outcome': 'EXPIRED_UNVERIFIABLE',
                    'statistics_exclude': True,
                    'training_exclude': True,
                    'resolved_at': int(now_seconds * 1_000_000),
                    'resolution_reason': 'STALE_WAIT_OUTSIDE_RETAINED_CANDLE_WINDOW',
                })
                changed_file = True
                stale_closed += 1
            if changed_file:
                self._write_json(path, items[-2000:])
            # WAIT is history-only and must never remain in an active queue.
            pending_path = self.logs / f'{contract}_pending.json'
            if pending_path.exists():
                try:
                    pdata = json.loads(pending_path.read_text(encoding='utf-8'))
                    clean = [x for x in pdata if str(x.get('prediction', 'WAIT')).upper() in ('LONG', 'SHORT')]
                    if len(clean) != len(pdata):
                        self._write_json(pending_path, clean)
                except Exception:
                    pass
        if stale_closed:
            self._append_learning_audit({'event':'STALE_WAIT_EXPIRED_NO_TRAINING','count':stale_closed,'cutoff_bars':stale_cutoff_bars,'at':int(now_seconds * 1_000_000)})

        if rows:
            self._append_wait_experience(rows)
            stat_path=self.data/'experience_stats.json'; stats=self._read_json(stat_path) if stat_path.exists() else {}
            if not isinstance(stats,dict): stats={}
            base_wait_rows=[r for r in rows if r.get('experience_kind')=='WAIT_CONTROL']
            snapshot_rows=[r for r in rows if r.get('experience_kind')=='WAIT_CONTROL_OBSERVATION']
            stats['schema_version']=3
            stats['wait_control_observations']=int(stats.get('wait_control_observations',0))+len(base_wait_rows)
            stats['wait_direction_snapshots']=int(stats.get('wait_direction_snapshots',0))+len(snapshot_rows)
            stats['wait_correct']=int(stats.get('wait_correct',0))+sum(r['target']==1 for r in base_wait_rows)
            stats['wait_missed_long']=int(stats.get('wait_missed_long',0))+sum(r['target']==2 for r in base_wait_rows)
            stats['wait_missed_short']=int(stats.get('wait_missed_short',0))+sum(r['target']==0 for r in base_wait_rows)
            stats['wait_false_spike']=int(stats.get('wait_false_spike',0))+sum(str(r.get('outcome'))=='FALSE_SPIKE' for r in base_wait_rows)
            stats['last_wait_learning_at']=int(time.time()); stats['replay_rows']=len((self._load_exp() or {}).get('time',[])); stats['lens_training_enabled']=False
            self._write_json(stat_path,stats)
        return changed, wait_stats

    def _challenger_model(self):
        """Return the frozen pre-training Master snapshot, if a control cycle is active."""
        try:
            state=self._training_state()
            if not bool(state.get('challenger_active')):
                return None
            root=self.challenger_root
            if not (root/'models_v8_self_learning'/'GLOBAL'/'champion.npz').exists():
                return None
            from .model import ModelManager
            return ModelManager(root, self.exchange.futures_symbol, self.cfg)
        except Exception:
            return None

    def _attach_challenger_prediction(self, item, row, math_snapshot=None):
        """Run the frozen pre-training Master on the exact same market input.

        Challenger is a control snapshot only. It never trains and never replaces
        the working Master. Its result is stored so the next control block can
        measure whether the newly trained Master actually improved.
        """
        cm=self._challenger_model()
        if cm is None:
            return item
        try:
            pred, probs, extra = cm.predict_bundle(row, float(item.get('math_consensus',0.0) or 0.0), math_snapshot)
            item['challenger_prediction']=pred
            item['challenger_generation']=int(self._training_state().get('challenger_generation',0) or 0)
            item['challenger_p_short']=float(probs[0]); item['challenger_p_wait']=float(probs[1]); item['challenger_p_long']=float(probs[2])
            item['challenger_selected_combination']=str(extra.get('selected_combination','MASTER'))
            item['challenger_combination_predictions']={name: NAMES[int(np.argmax(v))] for name,v in (extra.get('combination_probs') or {}).items()}
            price=float(item.get('price',0.0) or 0.0); atrpct=float((item.get('features') or {}).get('atrpct',0.001) or 0.001); atr=max(price*atrpct,price*0.001)
            if pred=='LONG': plan={'prediction':'LONG','entry':price,'sl':price-1.2*atr,'tp1':price+1.8*atr,'tp2':price+2.7*atr,'tp3':price+3.6*atr}
            elif pred=='SHORT': plan={'prediction':'SHORT','entry':price,'sl':price+1.2*atr,'tp1':price-1.8*atr,'tp2':price-2.7*atr,'tp3':price-3.6*atr}
            else: plan={'prediction':'WAIT','entry':price,'sl':float('nan'),'tp1':float('nan'),'tp2':float('nan'),'tp3':float('nan')}
            item['challenger_plan']=plan
            item['challenger_control_active']=True
        except Exception as exc:
            item['challenger_error']=str(exc)
        return item

    def _snapshot_current_master(self, state, total):
        """Freeze the current Master before retraining; this is the control baseline."""
        src=self.root/'models_v8_self_learning'/'GLOBAL'; dst=self.challenger_root/'models_v8_self_learning'/'GLOBAL'
        if not (src/'champion.npz').exists():
            return False
        try:
            if self.challenger_root.exists(): shutil.rmtree(self.challenger_root)
            dst.mkdir(parents=True, exist_ok=True)
            for name in ('champion.npz','champion.json','outcome_model.npz','outcome_model.json','master_decision.npz','master_decision.json','master_lens_performance.json','master_learning_state.json','shared_master_base.json'):
                q=src/name
                if q.exists(): shutil.copy2(q,dst/name)
            state['challenger_generation']=int(state.get('challenger_generation',0) or 0)+1
            state['challenger_active']=True
            state['challenger_start_resolved']=int(total)
            state['challenger_control_target']=int(total)+int(self.cfg.get('retrain_batch_size',25))
            state['challenger_checked']=False
            state['challenger_created_at']=int(time.time())
            return True
        except Exception as exc:
            self._append_json(self.data/'learning_errors.json',{'time':int(time.time()),'error':f'challenger_snapshot:{exc}'})
            return False

    def _challenger_control_rows(self, state, limit=None):
        generation=int(state.get('challenger_generation',0) or 0)
        candidates=[]
        for row in self._resolved_learning_rows():
            if (int(row.get('challenger_generation',-1) or -1)==generation and
                row.get('challenger_control_active') and row.get('challenger_prediction')):
                candidates.append(row)
        if limit is not None: candidates=candidates[:max(0,int(limit))]
        return candidates

    def _evaluate_challenger_control(self, rows, state):
        """Compare frozen baseline and updated Master on paired resolved forecasts."""
        generation=int(state.get('challenger_generation',0) or 0)
        candidates=[x for x in rows if int(x.get('challenger_generation',-1) or -1)==generation
                    and x.get('challenger_control_active') and x.get('challenger_prediction')]
        if not candidates:
            return {'status':'no_challenger_control_rows'}
        def score(obj):
            o=str(obj or '').upper()
            return {'TP3_PLUS':4,'TP3':3,'TP2':2,'TP1':1,'INITIAL_SL':0,'SL':0,
                    'WAIT_CORRECT':1,'FALSE_SPIKE':0,'MISSED_LONG':-1,'MISSED_SHORT':-1}.get(o)
        master_scores=[]; challenger_scores=[]; paired=0
        for x in candidates:
            mo=str(x.get('trade_outcome') or x.get('result') or 'WAITING').upper()
            co=x.get('challenger_outcome') or {}
            coo=str(co.get('trade_outcome') or co.get('result') or 'WAITING').upper()
            master_score=score(mo); challenger_score=score(coo)
            if master_score is not None and challenger_score is not None:
                master_scores.append(master_score); challenger_scores.append(challenger_score); paired+=1
        ms=float(np.mean(master_scores)) if master_scores else None
        cs=float(np.mean(challenger_scores)) if challenger_scores else None
        min_pairs=max(5,int(np.ceil(max(1,int(self.cfg.get('retrain_batch_size',25)))*0.8)))
        if paired < min_pairs:
            result='INSUFFICIENT_DATA'
        else:
            result='MASTER_IMPROVED' if ms>cs else 'MASTER_WORSE' if ms<cs else 'TIE'
        audit={'event':'CHALLENGER_CONTROL','start_resolved':int(state.get('challenger_start_resolved',0)),'end_resolved':int(state.get('challenger_control_target',0)),'paired_rows':paired,'master_score':ms,'challenger_score':cs,'result':result,'evaluated_at':int(time.time())}
        self._append_learning_audit(audit)
        state['challenger_last_result']=result; state['challenger_last_master_score']=ms; state['challenger_last_score']=cs
        state['challenger_checked']=bool(result!='INSUFFICIENT_DATA'); state['challenger_active']=False
        return {'status':'challenger_control_complete','result':result,'master_score':ms,'challenger_score':cs,'paired_rows':paired}

    def _training_state_path(self):
        return self.data/'training_batch_state.json'

    def _training_state(self):
        p=self._training_state_path()
        try:
            return json.loads(p.read_text(encoding='utf-8')) if p.exists() else {'last_retrain_resolved':0,'retrain_batches':0,'challenger_active':False,'challenger_checked':False}
        except Exception:
            return {'last_retrain_resolved':0,'retrain_batches':0,'challenger_active':False,'challenger_checked':False}

    def _save_training_state(self,state):
        p=self._training_state_path(); tmp=p.with_suffix('.tmp')
        tmp.write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf-8'); tmp.replace(p)

    def _learning_rows_since(self, start_count, end_count):
        ordered=self._resolved_learning_rows()
        start=max(0,int(start_count)); end=max(start,int(end_count))
        return ordered[start:end]

    def retrain_symbols(self, contracts, resolved_total=None, force=False, auxiliary_only=False):
        """Retrain the single Master every 25 newly resolved forecasts.

        The batch is global across contracts. C1/C2/C3 never retrain; after the
        Master update the new shared base is simply published back to them.
        """
        state=self._training_state(); eligible_rows=self._resolved_learning_rows(); total=len(eligible_rows); batch=max(1,int(self.cfg.get('retrain_batch_size',25)))
        # The clean reset is a one-time migration and is allowed to run immediately
        # once enough verified experience exists; it does not wait for the next +25.
        if not bool(state.get('clean_master_reset_done', False)):
            # If a pre-existing Master exists, freeze it before the one-time clean
            # rebuild. That rebuild is itself the first Challenger candidate; its
            # next 25 forecasts become the first control block.
            pre_reset_snapshot = bool((self.root/'models_v8_self_learning'/'GLOBAL'/'champion.npz').exists()) and self._snapshot_current_master(state,total)
            if pre_reset_snapshot:
                # Persist the generation before the clean-reset helper reloads state.
                self._save_training_state(state)
            reset_result=self._clean_master_reset_if_needed()
            if reset_result.get('status') in ('waiting_for_experience','waiting_for_fresh_dataset'):
                return [('CLEAN_RESET',reset_result)]
            if reset_result.get('status') == 'clean_master_reset_done':
                state=self._training_state()
                state['last_retrain_resolved']=total
                state['last_retrain_resolved_ids']=[self._learning_id(row) for row in self._resolved_learning_rows()]
                state['retrain_batches']=int(state.get('retrain_batches',0))+1
                state['last_retrain_at']=int(time.time())
                state['last_batch_size']=batch
                self._save_training_state(state)
                return [('CLEAN_RESET',reset_result),('CHALLENGER_SNAPSHOT',{'created':bool(pre_reset_snapshot),'control_target':int(state.get('challenger_control_target',0))})]
            state=self._training_state()
        new_resolved_rows=self._new_learning_rows(state,eligible_rows)
        normal_due=len(new_resolved_rows)>=batch
        due=normal_due or (force and not auxiliary_only)
        if not due:
            if auxiliary_only:
                return [('AUXILIARY_DEFERRED',{'status':'waiting_for_trade_batch','pending_auxiliary_samples':True,
                    'resolved_since_retrain':len(new_resolved_rows),
                    'required_resolved_batch':batch})]
            return []
        results=[]
        try:
            # A Challenger cohort is made only from forecasts actually issued while
            # its frozen snapshot was active. Do not reset it for auxiliary updates.
            control_result=None
            if bool(state.get('challenger_active')):
                control_rows=self._challenger_control_rows(state)
                if len(control_rows)<batch:
                    # Some already-active lifecycles may have started before this
                    # challenger generation and therefore have no paired prediction.
                    # Do not falsely score them, but also do not block Master forever.
                    control_result={'status':'control_block_incomplete',
                        'generation':int(state.get('challenger_generation',0) or 0),
                        'paired_candidates_resolved':len(control_rows),'required':batch,
                        'resolved_since_retrain':len(new_resolved_rows)}
                    self._append_learning_audit({'event':'CHALLENGER_CONTROL_INCOMPLETE',**control_result,
                        'evaluated_at':int(time.time())})
                    state['challenger_active']=False
                    state['challenger_checked']=False
                    state['challenger_last_result']='INSUFFICIENT_DATA'
                    state['challenger_last_master_score']=None
                    state['challenger_last_score']=None
                else:
                    control_result=self._evaluate_challenger_control(control_rows[:batch],state)
            # Freeze the current Master BEFORE changing its weights. The trained
            # Master then competes with this frozen baseline on the next 25.
            snapshot_ok=self._snapshot_current_master(state,total)
            trained=self.train_from_fresh()
            batch_rows=new_resolved_rows
            selector=self.mm.learn_from_resolved(batch_rows)
            results.append(('GLOBAL',trained))
            results.append(('MASTER_SELECTOR',selector))
            base_version=int(state.get('base_version',0))+1
            self.mm.update_learning_state(resolved_total=total,base_version=base_version)
            self.mm._write_json(self.mm.shared_base,{
                'schema_version':2,'base_version':base_version,'updated':int(time.time()),
                'master_model':'champion.npz','outcome_model':'outcome_model.npz' if self.mm.outcome_model.exists() else None,
                'master_selector_model':'master_decision.npz' if self.mm.master_decision.exists() else None,
                'master_observations':total,'lens_activation_resolved':int(self.cfg.get('lens_activation_resolved',25)),
                'lens_training_enabled':False,'lenses_fixed':True,'architecture':'MASTER_FIXED_BASE_PLUS_3_FIXED_LENSES'
            })
            validation=self._recompute_validation()
            if isinstance(validation,dict) and validation.get('status')=='ok':
                vm=self.mm._read_json(self.mm.meta,{})
                vm.update({'validation_rows':int(validation.get('validation_rows',0) or 0),'validation_accuracy':float(validation.get('accuracy',0.0) or 0.0),
                           'balanced_accuracy':float(validation.get('balanced_accuracy',0.0) or 0.0),'directional_precision':float(validation.get('directional_precision',0.0) or 0.0),
                           'action_rate':float(validation.get('action_rate',0.0) or 0.0),
                           'baseline_accuracy':validation.get('baseline_accuracy'),
                           'baseline_balanced_accuracy':validation.get('baseline_balanced_accuracy'),
                           'accuracy_minus_baseline':validation.get('accuracy_minus_baseline'),
                           'balanced_accuracy_minus_baseline':validation.get('balanced_accuracy_minus_baseline'),
                           'outcome_validation_rows':validation.get('outcome_validation_rows',0),
                           'outcome_accuracy':validation.get('outcome_accuracy'),
                           'outcome_baseline_accuracy':validation.get('outcome_baseline_accuracy'),
                           'outcome_accuracy_minus_baseline':validation.get('outcome_accuracy_minus_baseline'),
                           'latest_validation_at':int(time.time()),'latest_validation':validation})
                self.mm._write_json(self.mm.meta,vm)
            results.append(('VALIDATION',validation))
            if control_result is not None: results.append(('CHALLENGER_CONTROL',control_result))
            results.append(('CHALLENGER_SNAPSHOT',{'created':bool(snapshot_ok),'control_target':int(state.get('challenger_control_target',0))}))
            self._append_learning_audit({'event':'MASTER_RETRAIN','resolved_total':total,'batch_size':batch,'base_version':base_version,'trained':trained,'selector':selector,'validation':validation,'challenger_control':control_result,'challenger_snapshot_created':bool(snapshot_ok),'lens_training_enabled':False})
        except Exception as exc:
            results.append(('GLOBAL',{'error':str(exc)})); self._append_json(self.data/'learning_errors.json',{'time':int(time.time()),'error':str(exc)})
        checkpoint_ids=set(str(x) for x in state.get('last_retrain_resolved_ids',[]) if str(x))
        checkpoint_ids.update(self._learning_id(row) for row in batch_rows if self._learning_id(row))
        state['last_retrain_resolved_ids']=sorted(checkpoint_ids)
        state['last_retrain_resolved']=len(checkpoint_ids)
        state['retrain_batches']=int(state.get('retrain_batches',0))+1; state['last_retrain_at']=int(time.time()); state['last_batch_size']=len(batch_rows); state['last_generation']=1; state['base_version']=int(base_version)
        self._save_training_state(state)
        return results
    def _annotate_confidence_outcome(self,item):
        """Calibrate confidence against directional confirmation, not only endpoint price."""
        pred=str(item.get('prediction','WAIT')).upper()
        if pred not in ('LONG','SHORT'): return
        p=float(item.get('prediction_probability',item.get('p_long' if pred=='LONG' else 'p_short',0.0)) or 0.0); p=max(0.0,min(1.0,p))
        confirmed=bool(item.get('direction_confirmed')) if 'direction_confirmed' in item else str(item.get('actual','WAIT')).upper()==pred
        opposite=(not confirmed) and str(item.get('actual','WAIT')).upper() in ('LONG','SHORT') and str(item.get('actual')).upper()!=pred
        outcome=1.0 if confirmed else 0.0; signed=outcome-p
        band='HIGH_80_PLUS' if p>=0.80 else 'MEDIUM_60_79' if p>=0.60 else 'LOW_BELOW_60'
        item.update({'confidence_checked':True,'confidence_at_prediction':p,'confidence_band':band,'confidence_confirmed':confirmed,'confidence_opposite':opposite,
                     'confidence_outcome':'CONFIRMED' if confirmed else 'OPPOSITE' if opposite else 'NEUTRAL','calibration_error':float(signed),'brier_error':float((p-outcome)**2),
                     'learning_interpretation':('DIRECTION_CONFIRMED_AFTER_SL' if confirmed and item.get('post_sl_recovery') else 'HIGH_CONFIDENCE_ERROR' if p>=0.80 and not confirmed else 'HIGH_CONFIDENCE_CONFIRMATION' if p>=0.80 else 'PROBABILITY_CONFIRMED' if confirmed else 'PROBABILITY_UNCERTAIN')})
    def confidence_stats(self, items=None):
        if items is None:
            rows=[]
            for path in self.logs.glob('*_predictions.json'):
                try: rows.extend(json.loads(path.read_text(encoding='utf-8')))
                except Exception: pass
            items=rows
        resolved=[x for x in items if x.get('resolved') and not x.get('state_change_only') and x.get('prediction') in ('LONG','SHORT')]
        out={}
        for key,title in (('HIGH_80_PLUS','80%+'),('MEDIUM_60_79','60–79%'),('LOW_BELOW_60','<60%')):
            q=[x for x in resolved if x.get('confidence_band')==key]
            out[key]={'label':title,'total':len(q),
                      'confirmed':sum(bool(x.get('confidence_confirmed')) for x in q),
                      'opposite':sum(bool(x.get('confidence_opposite')) for x in q),
                      'neutral':sum(x.get('confidence_outcome')=='NEUTRAL' for x in q),
                      'confirmation_rate':(sum(bool(x.get('confidence_confirmed')) for x in q)/len(q) if q else None),
                      'mean_confidence':(sum(float(x.get('confidence_at_prediction',0)) for x in q)/len(q) if q else None),
                      'mean_calibration_error':(sum(float(x.get('calibration_error',0)) for x in q)/len(q) if q else None),
                      'mean_brier_error':(sum(float(x.get('brier_error',0)) for x in q)/len(q) if q else None)}
        return out

    def _observation_experience_rows(self, item, contract, prediction_id, outcome):
        """Create low-weight directional lessons from snapshots before the final outcome.

        Snapshots are not separate trades and do not train the TP/SL outcome head.
        They teach the direction head what market features looked like at different
        points during the original forecast lifecycle. A hard cap prevents a long
        lifecycle from dominating the replay buffer.
        """
        observations = item.get('scan_observations')
        if not isinstance(observations, list) or not observations:
            return []
        actual_direction = str(item.get('actual') or item.get('direction_target') or '').upper()
        if actual_direction not in ('LONG', 'SHORT', 'WAIT'):
            return []
        valid = [o for o in observations if isinstance(o, dict) and isinstance(o.get('features'), dict)
                 and all(f in o.get('features', {}) for f in FEATURES) and int(o.get('time', 0) or 0) > 0]
        if not valid:
            return []
        cap = max(1, int(self.cfg.get('max_direction_observation_samples_per_forecast', 12)))
        if len(valid) > cap:
            if cap == 1:
                valid = [valid[-1]]
            else:
                indices = sorted({round(i * (len(valid) - 1) / (cap - 1)) for i in range(cap)})
                valid = [valid[i] for i in indices]
        rows = []
        for index, observation in enumerate(valid):
            snapshot = dict(item)
            snapshot['features'] = dict(observation['features'])
            snapshot['time'] = int(observation['time'])
            snapshot['direction_confirmed'] = False
            snapshot.pop('direction_target', None)
            snapshot['experience_kind'] = 'DIRECTION_OBSERVATION'
            snap_id = str(observation.get('scan_prediction_id') or observation.get('time') or index)
            row = self._experience_row(snapshot, contract, f'{prediction_id}:observation:{snap_id}:{index}', actual_direction, outcome)
            row['target'] = {'SHORT': 0, 'WAIT': 1, 'LONG': 2}[actual_direction]
            row['outcome_target'] = -1
            row['sample_weight'] = float(row.get('sample_weight', 1.0)) * float(self.cfg.get('direction_observation_sample_weight', 0.05))
            row['outcome_sample_weight'] = 0.0
            row['experience_kind'] = 'DIRECTION_OBSERVATION'
            rows.append(row)
        return rows

    def append_real_position_experience(self, position, prediction=None, config=None):
        """Append real-position entry/result and intermediate price-path lessons.

        Real-position samples train the Master direction head only. They never
        fabricate TP/SL outcomes and therefore cannot contaminate forecast outcome
        statistics or the TP/SL outcome head.
        """
        cfg = config if isinstance(config, dict) else self.cfg
        position = position if isinstance(position, dict) else {}
        prediction = prediction if isinstance(prediction, dict) else {}
        observations = position.get('observations')
        if not isinstance(observations, list) or not observations:
            return {'status': 'no_snapshots', 'new_samples': 0}
        contract = str(position.get('contract') or prediction.get('contract') or prediction.get('exchange_symbol') or self.exchange.futures_symbol or '').strip()
        if not contract:
            return {'status': 'missing_contract', 'new_samples': 0}
        direction = str(position.get('direction') or prediction.get('prediction') or 'WAIT').upper()
        if direction not in ('LONG', 'SHORT'):
            return {'status': 'invalid_direction', 'new_samples': 0}
        position_id = str(position.get('position_id') or position.get('opened_from_prediction_id') or position.get('started_at') or time.time_ns())
        threshold_up = float(cfg.get('long_threshold', 0.003))
        threshold_down = float(cfg.get('short_threshold', -0.003))
        valid = []
        for obs in observations:
            if not isinstance(obs, dict):
                continue
            features = obs.get('features')
            try:
                price = float(obs.get('price', 0.0)); stamp = int(obs.get('time', 0))
                if price <= 0 or stamp <= 0 or not isinstance(features, dict) or not all(f in features for f in FEATURES):
                    continue
                clean = {f: float(features.get(f, 0.0) or 0.0) for f in FEATURES}
                if not all(np.isfinite(v) for v in clean.values()):
                    continue
                valid.append({'time': stamp, 'price': price, 'features': clean})
            except Exception:
                continue
        valid.sort(key=lambda row: row['time'])
        if not valid:
            return {'status': 'no_valid_feature_snapshots', 'new_samples': 0}
        old = self._load_exp(); all_rows = []
        if old and len(old.get('time', [])):
            n = len(old['time'])
            for i in range(n):
                try:
                    all_rows.append({'time': int(old['time'][i]),
                        'contract': str(np.asarray(old.get('contract', np.asarray(['LEGACY_UNKNOWN']*n)))[i]),
                        'prediction_id': str(np.asarray(old.get('prediction_id', np.asarray([f'legacy:{i}']*n)))[i]),
                        'target': int(old['target'][i]), 'outcome_target': int(old.get('outcome_target', np.full(n, -1))[i]),
                        'sample_weight': float(old.get('sample_weight', np.ones(n))[i]),
                        'outcome_sample_weight': float(old.get('outcome_sample_weight', np.zeros(n))[i]),
                        'math_consensus': float(old.get('math_consensus', np.zeros(n))[i]),
                        'experience_kind': str(np.asarray(old.get('experience_kind', np.asarray(['TRADE']*n)))[i]),
                        **{f: float(old[f][i]) for f in FEATURES}})
                except Exception:
                    continue
        known = {str(r.get('prediction_id', '')) for r in all_rows}
        new_rows = []
        # One actual entry/result lesson, labelled by the user's realized price move.
        try:
            pnl = float(position.get('realized_move_pct', 0.0) or 0.0)
            if pnl >= float(cfg.get('real_position_direction_label_threshold_pct', 0.05)):
                entry_target = direction
            elif pnl <= -float(cfg.get('real_position_direction_label_threshold_pct', 0.05)):
                entry_target = 'SHORT' if direction == 'LONG' else 'LONG'
            else:
                entry_target = 'WAIT'
            first = valid[0]
            pid = f'real-position:{position_id}:realized-result'
            if pid not in known:
                new_rows.append({'time': first['time'], 'contract': contract, 'prediction_id': pid,
                    'target': {'SHORT': 0, 'WAIT': 1, 'LONG': 2}[entry_target], 'outcome_target': -1,
                    'sample_weight': float(cfg.get('real_position_result_sample_weight', 0.60)),
                    'outcome_sample_weight': 0.0, 'math_consensus': float(prediction.get('math_consensus', 0.0) or 0.0),
                    'experience_kind': 'REAL_POSITION_RESULT', **first['features']})
                known.add(pid)
        except Exception:
            pass
        lookahead = max(2, int(cfg.get('real_position_learning_lookahead_snapshots', 5)))
        move_up = abs(threshold_up); move_down = abs(threshold_down)
        for i in range(max(0, len(valid) - lookahead)):
            current = valid[i]; future = valid[i + 1:i + lookahead + 1]
            if not future:
                continue
            ret = float(future[-1]['price'] / current['price'] - 1.0)
            target = 'LONG' if ret >= move_up else 'SHORT' if ret <= -move_down else 'WAIT'
            pid = f'real-position:{position_id}:path:{current["time"]}'
            if pid in known:
                continue
            new_rows.append({'time': current['time'], 'contract': contract, 'prediction_id': pid,
                'target': {'SHORT': 0, 'WAIT': 1, 'LONG': 2}[target], 'outcome_target': -1,
                'sample_weight': float(cfg.get('real_position_observation_sample_weight', 0.30)),
                'outcome_sample_weight': 0.0, 'math_consensus': float(prediction.get('math_consensus', 0.0) or 0.0),
                'experience_kind': 'REAL_POSITION_OBSERVATION', **current['features']})
            known.add(pid)
        if new_rows:
            all_rows.extend(new_rows)
            self._save_exp(self._bounded_experience(all_rows))
            state_path = self.data / 'real_position_learning_state.json'
            state = self._read_json(state_path) if state_path.exists() else {}
            if not isinstance(state, dict): state = {}
            state['pending_samples'] = int(state.get('pending_samples', 0) or 0) + len(new_rows)
            state['total_samples'] = int(state.get('total_samples', 0) or 0) + len(new_rows)
            state['last_position_id'] = position_id
            state['last_updated'] = int(time.time())
            state['last_realized_move_pct'] = float(position.get('realized_move_pct', 0.0) or 0.0)
            self._write_json(state_path, state)
            self._append_learning_audit({'event': 'REAL_POSITION_EXPERIENCE_ADDED', 'position_id': position_id,
                'contract': contract, 'realized_move_pct': float(position.get('realized_move_pct', 0.0) or 0.0),
                'new_samples': len(new_rows), 'sample_kinds': {kind: sum(r.get('experience_kind') == kind for r in new_rows) for kind in ('REAL_POSITION_RESULT', 'REAL_POSITION_OBSERVATION')}})
        return {'status': 'added' if new_rows else 'already_recorded', 'new_samples': len(new_rows),
                'total_experience_rows': len(self._load_exp().get('time', [])) if self._load_exp() else 0}

    def _append_experience(self,items):
        rows=[]
        for x in items:
            if not x.get('resolved') or x.get('state_change_only') or not x.get('features'): continue
            if not all(f in (x.get('features') or {}) for f in FEATURES): continue
            contract=str(x.get('contract') or x.get('exchange_symbol') or '').strip()
            if not contract: continue
            outcome=self._infer_trade_outcome(x)
            if outcome<0: continue
            pid=str(x.get('id') or f"{contract}:{int(x.get('time',0))}")
            direction=x.get('direction_target') or x.get('actual') or x.get('prediction')
            rows.append(self._experience_row(x,contract,pid,direction,outcome))
            # Once the original forecast has a real outcome, feed selected earlier
            # snapshots to the direction learner. They are low-weight direction-only
            # samples; they never count as extra trades or train the TP/SL outcome head.
            rows.extend(self._observation_experience_rows(x, contract, pid, outcome))
        if not rows: return
        old=self._load_exp(); all_rows=[]
        if old and len(old.get('time',[])):
            n=len(old['time'])
            for i in range(n):
                try:
                    all_rows.append({'time':int(old['time'][i]),'contract':str(np.asarray(old.get('contract',np.asarray(['LEGACY_UNKNOWN']*n)))[i]),'prediction_id':str(np.asarray(old.get('prediction_id',np.asarray([f'legacy:{int(old["time"][i])}:{i}']*n)))[i]),
                                     'target':int(old['target'][i]),'outcome_target':int(old.get('outcome_target',np.full(n,-1))[i]),'sample_weight':float(old.get('sample_weight',np.ones(n))[i]),'outcome_sample_weight':float(old.get('outcome_sample_weight',np.zeros(n))[i]),'math_consensus':float(old.get('math_consensus',np.zeros(n))[i]),
                                     'experience_kind':str(np.asarray(old.get('experience_kind',np.asarray(['TRADE']*n)))[i]),
                                     **{f:float(old[f][i]) for f in FEATURES}})
                except Exception: pass
        all_rows.extend(rows); merged=self._bounded_experience(all_rows); self._save_exp(merged)
        # Master-owned lens performance memory. This is not a lens model and is
        # never fed back into the fixed lens equations as weights.
        perf=self.mm._load_lens_performance()
        actors={'master':None,'c1':None,'c2':None,'c3':None}
        for x in items:
            actors['master']=x
            outcomes=x.get('lens_outcomes') or {}
            for k in ('c1','c2','c3'): actors[k]=outcomes.get(k)
            for actor,obj in actors.items():
                if not obj or str(obj.get('result','WAITING')).upper() in ('WAITING','WAIT'): continue
                q=perf['actors'][actor]; score=int(obj.get('outcome_score',self._infer_trade_outcome(obj)))
                q['n']=int(q.get('n',0))+1; q['success']=int(q.get('success',0))+int(score>=1); q['outcome_sum']=float(q.get('outcome_sum',0.0))+score
                q['recovery']=int(q.get('recovery',0))+int(bool(obj.get('post_sl_recovery'))); q['tp1']=int(q.get('tp1',0))+int(bool(obj.get('tp1_hit'))); q['tp2']=int(q.get('tp2',0))+int(bool(obj.get('tp2_hit'))); q['tp3']=int(q.get('tp3',0))+int(bool(obj.get('tp3_hit'))); q['tp3_plus']=int(q.get('tp3_plus',0))+int(score>=4); q['sl']=int(q.get('sl',0))+int(bool(obj.get('initial_sl_failure')))
            for combo,obj in (x.get('combination_outcomes') or {}).items():
                if not obj or str(obj.get('result','WAITING')).upper() in ('WAITING','WAIT'): continue
                q=perf.setdefault('combinations',{}).setdefault(combo, {'n':0,'success':0,'outcome_sum':0.0,'recovery':0,'tp1':0,'tp2':0,'tp3':0,'tp3_plus':0,'sl':0})
                score=int(obj.get('outcome_score',self._infer_trade_outcome(obj)))
                q['n']=int(q.get('n',0))+1; q['success']=int(q.get('success',0))+int(score>=1); q['outcome_sum']=float(q.get('outcome_sum',0.0))+score
                q['recovery']=int(q.get('recovery',0))+int(bool(obj.get('post_sl_recovery'))); q['tp1']=int(q.get('tp1',0))+int(bool(obj.get('tp1_hit'))); q['tp2']=int(q.get('tp2',0))+int(bool(obj.get('tp2_hit'))); q['tp3']=int(q.get('tp3',0))+int(bool(obj.get('tp3_hit'))); q['tp3_plus']=int(q.get('tp3_plus',0))+int(score>=4); q['sl']=int(q.get('sl',0))+int(bool(obj.get('initial_sl_failure')))
        perf['updated']=int(time.time()); self.mm._write_json(self.mm.lens_performance,perf)
        # Training is intentionally batched. Resolution only records experience;
        # every 25 completed learning samples the retrain loop updates Master,
        # the outcome head, and the Master-owned lens selector.
        self.mm.update_learning_state(resolved_total=self._count_resolved_logs())
        for x in items:
            self._append_learning_audit({'event':'PREDICTION_RESOLVED','prediction_id':x.get('id'),'contract':x.get('contract'),'cycle':x.get('run_id'),
                'master_prediction':x.get('prediction'),'master_result':x.get('result'),'trade_outcome':x.get('trade_outcome'),'outcome_score':x.get('outcome_score'),
                'tp1_hit':bool(x.get('tp1_hit')),'tp2_hit':bool(x.get('tp2_hit')),'tp3_hit':bool(x.get('tp3_hit')),'tp3_plus_pct':float(x.get('max_extension_beyond_tp3_pct',0.0) or 0.0),
                'initial_sl_failure':bool(x.get('initial_sl_failure')),'protected_exit':bool(x.get('protected_exit')),
                'post_sl_recovery':bool(x.get('post_sl_recovery')),'post_sl_recovery_level':x.get('post_sl_recovery_level'),'direction_confirmed':bool(x.get('direction_confirmed')),
                'direction_confirmation_source':x.get('direction_confirmation_source'),'sl_event_context':x.get('sl_event_context'),'post_sl_event_context':x.get('post_sl_event_context'),
                'protection_event_context':x.get('protection_event_context'),'protection_level':x.get('protection_level'),
                'lens_predictions':x.get('lens_predictions'),'lens_outcomes':x.get('lens_outcomes'),'combination_predictions':x.get('combination_predictions'),'combination_outcomes':x.get('combination_outcomes'),'selected_combination':x.get('selected_combination'),'challenger_prediction':x.get('challenger_prediction'),'challenger_outcome':x.get('challenger_outcome'),'challenger_selected_combination':x.get('challenger_selected_combination'),'lens_training_enabled':False})
        stat_path=self.data/'experience_stats.json'; stats=self._read_json(stat_path) if stat_path.exists() else {}
        if not isinstance(stats,dict): stats={}
        stats['schema_version']=2; stats['total_observations']=int(stats.get('total_observations',0))+len(rows); stats['total_tp1']=int(stats.get('total_tp1',0))+sum(bool(x.get('tp1_hit')) for x in rows); stats['total_tp2']=int(stats.get('total_tp2',0))+sum(bool(x.get('tp2_hit')) for x in rows); stats['total_tp3']=int(stats.get('total_tp3',0))+sum(bool(x.get('tp3_hit')) for x in rows); stats['total_tp3_plus']=int(stats.get('total_tp3_plus',0))+sum(int(self._infer_trade_outcome(x)==4) for x in rows); stats['total_initial_sl']=int(stats.get('total_initial_sl',0))+sum(bool(x.get('initial_sl_failure')) for x in rows); stats['total_post_sl_recovery']=int(stats.get('total_post_sl_recovery',0))+sum(bool(x.get('post_sl_recovery')) for x in rows); stats['last_updated']=int(time.time()); stats['replay_rows']=len(merged.get('time',[])); stats['lens_training_enabled']=False
        self._write_json(stat_path,stats)

    def _recompute_validation(self):
        exp=self._load_exp()
        if not exp: return {'status':'no_experience'}
        mode=self.mm._read_json(self.mm.meta,{}).get('market_features_mode','neutral')
        exp=self._apply_market_feature_policy(exp,mode)
        n=len(exp.get('time',[])); contracts=np.asarray(exp.get('contract',np.asarray(['UNKNOWN']*n))).astype(str)
        targets=np.asarray(exp.get('target',np.full(n,-1)),int)
        valid=(contracts!='LEGACY_UNKNOWN') & (targets>=0) & (targets<=2)
        all_times=np.asarray(exp.get('time',np.arange(n)),dtype=np.int64)
        X=np.column_stack([np.asarray(exp[f],float) for f in FEATURES])[valid]; y=targets[valid]
        times=all_times[valid]
        weights=np.asarray(exp.get('sample_weight',np.ones(n)),float)[valid]
        outcome_targets=np.asarray(exp.get('outcome_target',np.full(n,-1)),int)[valid]
        outcome_weights=np.asarray(exp.get('outcome_sample_weight',np.ones(n)),float)[valid]
        if len(X)<max(50,int(self.cfg.get('validation_min_rows',100))): return {'status':'not_enough_validation_rows','rows':int(len(X))}
        train_idx,test_idx,test_start,embargo=_purged_temporal_split_indices(
            times, float(self.cfg.get('test_fraction',.2)),
            max(0,int(self.cfg.get('validation_purge_gap_bars',self.cfg.get('horizon_bars',12))))*300)
        if len(train_idx)<max(50,int(self.cfg.get('validation_min_train_rows',100))) or len(test_idx)<50:
            return {'status':'not_enough_rows_after_temporal_purge','rows':int(len(X)),
                    'train_rows':int(len(train_idx)),'validation_rows':int(len(test_idx)),
                    'purge_gap_units':int(embargo),'test_start_time':int(test_start)}
        shadow=self.mm._new(); shadow.fit(X[train_idx],y[train_idx],epochs=int(self.cfg.get('validation_epochs',35)),learning_rate=float(self.cfg.get('validation_learning_rate',.006)),l2=float(self.cfg.get('master_l2',.0005)),sample_weights=weights[train_idx])
        pred=shadow.predict(X[test_idx]); yt=y[test_idx]; acc,bal,per,dp,ar=self.mm._scores(yt,pred)
        majority=int(np.bincount(y[train_idx],minlength=self.mm._new().n_classes).argmax())
        baseline_pred=np.full(len(yt),majority,dtype=int)
        baseline_acc=float(np.mean(baseline_pred==yt)) if len(yt) else 0.0
        _,baseline_bal,_,baseline_dp,baseline_ar=self.mm._scores(yt,baseline_pred)
        # Trade-outcome quality must be independently measured. Evaluating the
        # persisted outcome model here would leak the held-out outcomes because
        # that model may have been trained incrementally on the entire archive.
        # Fit a throw-away outcome head only on the purged training period.
        out_y=outcome_targets[test_idx]
        out_X=X[test_idx]
        out_pred=None; out_acc=None; out_rows=0; out_baseline_acc=None
        train_out_y=outcome_targets[train_idx]
        train_out_valid=(train_out_y>=0) & (train_out_y<=4)
        test_out_valid=(out_y>=0) & (out_y<=4)
        if int(np.sum(train_out_valid)) >= max(25, int(self.cfg.get('validation_min_outcome_train_rows', 50))) and int(np.sum(test_out_valid)) >= 25:
            shadow_out=self.mm._new_outcome()
            out_sw=outcome_weights[train_idx][train_out_valid]
            shadow_out.fit(X[train_idx][train_out_valid], train_out_y[train_out_valid],
                           epochs=int(self.cfg.get('validation_epochs',35)),
                           learning_rate=float(self.cfg.get('validation_learning_rate',.006)),
                           l2=float(self.cfg.get('master_l2',.0005)), sample_weights=out_sw)
            out_pred=shadow_out.predict(out_X[test_out_valid])
            out_acc=float(np.mean(out_pred==out_y[test_out_valid]))
            out_rows=int(np.sum(test_out_valid))
            majority_out=int(np.bincount(train_out_y[train_out_valid],minlength=self.mm._new_outcome().n_classes).argmax())
            out_baseline_acc=float(np.mean(np.full(out_rows,majority_out)==out_y[test_out_valid]))
        return {'status':'ok','rows':int(len(X)),'train_rows':int(len(train_idx)),'validation_rows':int(len(yt)),
                'test_start_time':int(test_start),'purge_gap_units':int(embargo),
                'accuracy':acc,'balanced_accuracy':bal,'directional_precision':dp,'action_rate':ar,
                'baseline_accuracy':baseline_acc,'baseline_balanced_accuracy':baseline_bal,
                'baseline_directional_precision':baseline_dp,'baseline_action_rate':baseline_ar,
                'accuracy_minus_baseline':float(acc-baseline_acc),
                'balanced_accuracy_minus_baseline':float(bal-baseline_bal),
                'class_accuracy':per,'outcome_accuracy':out_acc,
                'outcome_validation_rows':out_rows,'outcome_baseline_accuracy':out_baseline_acc,
                'outcome_accuracy_minus_baseline':(float(out_acc-out_baseline_acc) if out_acc is not None and out_baseline_acc is not None else None)}

    def stats(self):
        rows=[]
        for path in self.logs.glob('*_predictions.json'):
            try: rows.extend(json.loads(path.read_text(encoding='utf-8')))
            except Exception: pass
        resolved=[x for x in rows if x.get('resolved') and not x.get('state_change_only')]; actionable=[x for x in resolved if x.get('prediction') in ('LONG','SHORT')]
        correct=[x for x in actionable if x.get('trade_success') or bool(x.get('tp1_hit'))]
        return {'predictions':len(rows),'pending':len([x for x in rows if not x.get('resolved') and x.get('prediction') in ('LONG','SHORT')]),
                'wait_pending':len([x for x in rows if x.get('prediction')=='WAIT' and not x.get('wait_learning_resolved') and not x.get('state_change_only')]),
                'wait_learning_resolved':len([x for x in rows if x.get('prediction')=='WAIT' and x.get('wait_learning_resolved') and not x.get('state_change_only')]),
                'resolved':len(resolved),'correct':len(correct),'live_accuracy':(len(correct)/len(actionable) if actionable else None)}
    def global_stats(self):
        rows=[]
        for path in self.logs.glob('*_predictions.json'):
            try: rows.extend(json.loads(path.read_text(encoding='utf-8')))
            except Exception: pass
        # Deduplicate by prediction id, never by timestamp alone.
        uniq={}
        for x in rows:
            if x.get('id') is not None: uniq[str(x.get('id'))]=x
        rows=list(uniq.values()); resolved=[x for x in rows if x.get('resolved') and not x.get('state_change_only')]; learning_ready=[x for x in resolved if not x.get('post_sl_recheck_pending')]; actionable=[x for x in resolved if x.get('prediction') in ('LONG','SHORT')]
        correct=[x for x in actionable if x.get('trade_success') or bool(x.get('tp1_hit'))]
        bs=self._training_state()
        return {'predictions':len(rows),'pending':len([x for x in rows if not x.get('resolved') and x.get('prediction') in ('LONG','SHORT')]),
                'wait_pending':len([x for x in rows if x.get('prediction')=='WAIT' and not x.get('wait_learning_resolved') and not x.get('state_change_only')]),
                'wait_learning_resolved':len([x for x in rows if x.get('prediction')=='WAIT' and x.get('wait_learning_resolved') and not x.get('state_change_only')]),
                'resolved':len(resolved),'learning_ready':len(learning_ready),'retrain_batches':int(bs.get('retrain_batches',0)), 'clean_master_reset_done':bool(bs.get('clean_master_reset_done',False)), 'clean_master_reset_rows':int(bs.get('clean_master_reset_rows',0)),
                'resolved_since_retrain':max(0,len(resolved)-int(bs.get('last_retrain_resolved',0))),'retrain_batch_size':int(self.cfg.get('retrain_batch_size',25)),
                'correct':len(correct),'accuracy':(len(correct)/len(actionable) if actionable else None),'actionable':len(actionable),'action_rate':(len(actionable)/len(resolved) if resolved else None),
                'directional_accuracy':(sum(bool(x.get('direction_confirmed')) for x in actionable)/len(actionable) if actionable else None),
                'tp1':sum(bool(x.get('tp1_hit')) for x in resolved),'tp2':sum(bool(x.get('tp2_hit')) for x in resolved),'tp3':sum(bool(x.get('tp3_hit')) for x in resolved),
                'tp3_plus':sum(self._infer_trade_outcome(x)==4 for x in resolved),'sl':sum(bool(x.get('initial_sl_failure')) for x in resolved),'protected_exits':sum(bool(x.get('protected_exit')) for x in resolved),
                'post_sl_recovery':sum(bool(x.get('post_sl_recovery')) for x in resolved),'lens_training_enabled':False}
    def detailed_stats(self):
        """Return transparent live-verification statistics with explicit denominators."""
        rows=[]
        for path in self.logs.glob('*_predictions.json'):
            try:
                rows.extend(json.loads(path.read_text(encoding='utf-8')))
            except Exception:
                pass
        resolved=[x for x in rows if x.get('resolved') and not x.get('state_change_only')]
        actionable=[x for x in resolved if x.get('prediction') in ('LONG','SHORT')]

        def counts(items):
            long_items=[x for x in items if x.get('prediction')=='LONG']
            short_items=[x for x in items if x.get('prediction')=='SHORT']
            def hit(key, subset): return sum(bool(x.get(key)) for x in subset)
            def acc(subset):
                return (sum(x.get('actual')==x.get('prediction') for x in subset)/len(subset)) if subset else None
            return {
                'total':len(items),
                'long':len(long_items), 'short':len(short_items),
                'correct':sum(bool(x.get('tp1_hit')) for x in items),
                'accuracy':(sum(bool(x.get('tp1_hit')) for x in items)/len(items)) if items else None,
                'directional_accuracy':(sum(bool(x.get('tp1_hit')) for x in items if x.get('prediction') in ('LONG','SHORT'))/len([x for x in items if x.get('prediction') in ('LONG','SHORT')])) if [x for x in items if x.get('prediction') in ('LONG','SHORT')] else None,
                'tp1':hit('tp1_hit',items), 'tp2':hit('tp2_hit',items),
                'tp3':hit('tp3_hit',items), 'sl':sum(bool(x.get('initial_sl_failure', x.get('sl_hit')) and not x.get('tp1_hit')) for x in items),
                'protected_exits':sum(bool(x.get('protected_exit')) for x in items),
                'long_correct':sum(bool(x.get('tp1_hit')) for x in long_items),
                'short_correct':sum(bool(x.get('tp1_hit')) for x in short_items),
                'long_tp1':hit('tp1_hit',long_items), 'short_tp1':hit('tp1_hit',short_items),
                'long_tp2':hit('tp2_hit',long_items), 'short_tp2':hit('tp2_hit',short_items),
                'long_tp3':hit('tp3_hit',long_items), 'short_tp3':hit('tp3_hit',short_items),
                'long_sl':sum(bool(x.get('initial_sl_failure', x.get('sl_hit')) and not x.get('tp1_hit')) for x in long_items),
                'short_sl':sum(bool(x.get('initial_sl_failure', x.get('sl_hit')) and not x.get('tp1_hit')) for x in short_items),
            }

        def rate(n,d): return (n/d) if d else None
        allc=counts(resolved); act=counts(actionable)
        recent100=actionable[-100:] if len(actionable)>=100 else []
        recent500=actionable[-500:] if len(actionable)>=500 else []
        r100=counts(recent100); r500=counts(recent500)
        metas=[]
        for meta_path in (self.root/'models_v8_self_learning').glob('*/champion.json'):
            try:
                m=json.loads(meta_path.read_text(encoding='utf-8'))
                if m.get('accepted'): metas.append(m)
            except Exception:
                pass
        validation_rows=sum(int(m.get('validation_rows',m.get('test_rows',0)) or 0) for m in metas)
        balanced=float(np.mean([float(m.get('balanced_accuracy',0)) for m in metas])) if metas else 0.0
        directional_precision=float(np.mean([float(m.get('directional_precision',0)) for m in metas])) if metas else 0.0
        action_rate=float(np.mean([float(m.get('action_rate',0)) for m in metas])) if metas else 0.0
        pending_rows=[x for x in rows if not x.get('resolved') and x.get('prediction') in ('LONG','SHORT')]
        active_long=[x for x in pending_rows if x.get('verification_state') in ('LONG_RUNNING_WAITING','WAITING_TP2','WAITING_TP3','ACTIVE')]
        queued_long=[x for x in pending_rows if x.get('verification_state')=='QUEUED']
        waiting_tp1=sum(1 for x in pending_rows if not x.get('tp1_hit'))
        waiting_tp2=sum(1 for x in pending_rows if x.get('tp1_hit') and not x.get('tp2_hit'))
        waiting_tp3=sum(1 for x in pending_rows if x.get('tp2_hit') and not x.get('tp3_hit'))
        return {
            'all':allc, 'actionable':act, 'recent100':r100, 'recent500':r500,
            'validation_rows':validation_rows, 'accepted_models':len(metas),
            'balanced_accuracy':balanced, 'directional_precision':directional_precision,
            'validation_action_rate':action_rate,
            'pending':len([x for x in rows if not x.get('resolved')]),
            'active_long_running':len(active_long), 'queued_long_running':len(queued_long),
            'waiting_tp1':waiting_tp1, 'waiting_tp2':waiting_tp2, 'waiting_tp3':waiting_tp3,
            'total_saved':len(rows),
            'confidence':self.confidence_stats(rows),
        }

    def readiness(self):
        """Return a conservative 0-10 readiness score for the whole self-learning system.

        Readiness is a gate, not a promise of future profit. It combines large-sample
        live verification with unseen-test metrics from accepted per-symbol champions.
        WAIT cannot satisfy the directional checks by itself.
        """
        gs=self.global_stats()
        resolved=[]
        for path in self.logs.glob('*_predictions.json'):
            try: resolved.extend(json.loads(path.read_text(encoding='utf-8')))
            except Exception: pass
        resolved=[x for x in resolved if x.get('resolved') and not x.get('state_change_only')]
        actionable=[x for x in resolved if x.get('prediction') in ('LONG','SHORT')]
        recent100=actionable[-100:] if len(actionable)>=100 else []
        recent500=actionable[-500:] if len(actionable)>=500 else []
        recent100_acc=(sum(bool(x.get('tp1_hit')) for x in recent100)/len(recent100)) if recent100 else None
        recent500_acc=(sum(bool(x.get('tp1_hit')) for x in recent500)/len(recent500)) if recent500 else None
        tp1=sum(bool(x.get('tp1_hit')) for x in actionable)/len(actionable) if actionable else None
        sl=sum(bool(x.get('initial_sl_failure', x.get('sl_hit')) and not x.get('tp1_hit')) for x in actionable)/len(actionable) if actionable else None
        metas=[]
        for meta_path in (self.root/'models_v8_self_learning').glob('*/champion.json'):
            try:
                m=json.loads(meta_path.read_text(encoding='utf-8'))
                if m.get('accepted'): metas.append(m)
            except Exception: pass
        val_rows=sum(int(m.get('validation_rows',m.get('test_rows',0)) or 0) for m in metas)
        bal=float(np.mean([float(m.get('balanced_accuracy',0)) for m in metas])) if metas else 0.0
        dp=float(np.mean([float(m.get('directional_precision',0)) for m in metas])) if metas else 0.0
        ar=float(np.mean([float(m.get('action_rate',0)) for m in metas])) if metas else 0.0
        baseline_delta=float(np.mean([float(m.get('balanced_accuracy_minus_baseline',-1.0)) for m in metas])) if metas else -1.0
        min_res=int(self.cfg.get('readiness_min_resolved',1000))
        min_val=int(self.cfg.get('readiness_min_validation_rows',1000))
        min_bal=float(self.cfg.get('readiness_min_balanced_accuracy',0.60))
        min_dp=float(self.cfg.get('readiness_min_directional_precision',0.65))
        min_ar=float(self.cfg.get('readiness_min_action_rate',0.10))
        min_recent=float(self.cfg.get('readiness_min_recent_directional_accuracy',0.90))
        min_tp1=float(self.cfg.get('readiness_min_tp1_rate',0.90))
        max_sl=float(self.cfg.get('readiness_max_sl_rate',0.10))
        min_acc=float(self.cfg.get('readiness_min_accuracy',0.90))
        min_recent_acc=float(self.cfg.get('readiness_min_recent_accuracy',0.90))
        batch_state=self._training_state()
        retrained_batches=int(batch_state.get('retrain_batches',0))
        checks=[
            retrained_batches>=1,
            gs['resolved']>=min_res,
            gs.get('accuracy') is not None and gs['accuracy']>=min_acc,
            recent100_acc is not None and recent100_acc>=min_recent_acc,
            val_rows>=min_val,
            bal>=min_bal,
            # A model must beat a simple majority-class baseline on the same
            # untouched holdout; missing baseline metrics from old model files
            # are not treated as proof of quality.
            bool(metas) and all(
                np.isfinite(float(m.get('balanced_accuracy_minus_baseline',-1.0)))
                and float(m.get('balanced_accuracy_minus_baseline',-1.0)) >= float(self.cfg.get('readiness_min_balanced_delta',0.0))
                for m in metas
            ),
            bool(metas) and all(
                int(m.get('outcome_validation_rows',0) or 0) >= int(self.cfg.get('readiness_min_outcome_validation_rows',25))
                and m.get('outcome_accuracy_minus_baseline') is not None
                and float(m.get('outcome_accuracy_minus_baseline',-1.0)) >= float(self.cfg.get('readiness_min_outcome_delta',0.0))
                for m in metas
            ),
            dp>=min_dp,
            ar>=min_ar,
            recent500_acc is not None and recent500_acc>=min_recent,
            tp1 is not None and tp1>=min_tp1,
            sl is not None and sl<=max_sl,
            bool(metas) and all(
                int(m.get('test_rows', 0) or 0) >= int(self.cfg.get('readiness_min_model_test_rows', 50))
                and float(m.get('directional_precision', 0) or 0) >= min_dp
                and float(m.get('action_rate', 0) or 0) >= min_ar
                for m in metas
            ),
        ]
        reasons=[]
        labels=['было пакетное переобучение','проверено достаточно прогнозов','общая точность TP1','точность последних 100','есть независимая валидация','balanced accuracy','модель превосходит базовый прогноз','модель исходов превосходит базовый прогноз','точность LONG/SHORT','доля активных прогнозов','стабильность последних 500','достижение TP1','контроль SL','принятые модели имеют достаточную независимую выборку и направленные прогнозы']
        for ok,label in zip(checks,labels):
            if not ok: reasons.append(label)
        return {
            'score':int(sum(bool(x) for x in checks)), 'ready':bool(all(checks)), 'checks':checks, 'labels':labels, 'reasons':reasons,
            'resolved':gs['resolved'],'validation_rows':val_rows,'balanced_accuracy':bal,'directional_precision':dp,'action_rate':ar,
            'balanced_accuracy_minus_baseline':baseline_delta,
            'recent100_directional_accuracy':recent100_acc,'recent500_directional_accuracy':recent500_acc,
            'tp1_rate':tp1,'sl_rate':sl,'accepted_models':len(metas),
            'accuracy':gs.get('accuracy'),'recent100_accuracy':recent100_acc,
            'retrain_batches':retrained_batches,'retrain_batch_size':int(self.cfg.get('retrain_batch_size',25)),
        }
    def _cleanup_pending_files(self):
        """Pending queue contains only unresolved LONG/SHORT trades."""
        removed=0
        for path in self.logs.glob("*_pending.json"):
            try:
                data=json.loads(path.read_text(encoding="utf-8"))
                if not isinstance(data,list):
                    continue
                kept=[x for x in data if str(x.get("prediction","")).upper() in ("LONG","SHORT") and not x.get("resolved")]
                removed += len(data)-len(kept)
                if len(kept)!=len(data):
                    path.write_text(json.dumps(kept,ensure_ascii=False),encoding="utf-8")
            except Exception:
                continue
        return removed

    def learning_cycle(self):
        self._cleanup_pending_files()
        resolved=self.resolve_all_pending()
        wait_resolved,_wait_diag=self.resolve_wait_learning()
        total=self._count_resolved_logs()
        contracts=[x.get('contract') or x.get('exchange_symbol') for x in resolved if x.get('contract') or x.get('exchange_symbol')]
        real_state_path = self.data / 'real_position_learning_state.json'
        online_state_path = self.data / 'online_observation_learning_state.json'
        real_state = self._read_json(real_state_path) if real_state_path.exists() else {}
        online_state = self._read_json(online_state_path) if online_state_path.exists() else {}
        if not isinstance(real_state, dict): real_state = {}
        if not isinstance(online_state, dict): online_state = {}
        real_pending = int(real_state.get('pending_samples', 0) or 0)
        online_pending = int(online_state.get('pending_samples', 0) or 0)
        train_state = self._training_state()
        real_batch = max(5, int(self.cfg.get('real_position_retrain_batch_size', 25)))
        can_retrain_aux = (real_pending + online_pending) >= real_batch and self.mm.has_champion() and bool(train_state.get('clean_master_reset_done', False))
        trained=self.retrain_symbols(contracts,resolved_total=total,force=can_retrain_aux) if (contracts or can_retrain_aux) else []
        if can_retrain_aux and trained:
            global_result = next((r[1] for r in trained if isinstance(r, tuple) and len(r) > 1 and r[0] == 'GLOBAL' and isinstance(r[1], dict)), {})
            if global_result.get('status') == 'master_updated':
                for state_path, state_obj in ((real_state_path, real_state), (online_state_path, online_state)):
                    state_obj['pending_samples'] = 0
                    state_obj['last_retrain_at'] = int(time.time())
                    state_obj['last_retrain_result'] = global_result.get('status')
                    self._write_json(state_path, state_obj)
        stats=self.stats()
        stats['real_position_learning_pending_samples'] = real_pending
        stats['real_position_learning_total_samples'] = int(real_state.get('total_samples', 0) or 0)
        stats['online_observation_learning_pending_samples'] = online_pending
        stats['online_observation_learning_total_samples'] = int(online_state.get('total_samples', 0) or 0)
        stats['wait_learning_resolved_this_cycle']=len(wait_resolved)
        stats['wait_learning_diagnostics']=_wait_diag
        return resolved,trained,stats
    def _quick_candidate(self, item):
        # Lightweight market-wide pre-scan: one recent 5m window per contract.
        # This avoids training hundreds of separate models before ranking the market.
        self.set_symbol(item['contract'])
        bars=self.exchange.candles('5min',240)
        x=add_features(bars); i=len(x['time'])-1
        if i<40: raise ValueError('слишком мало 5m свечей')
        close=float(x['close'][i]); rsi=float(x['rsi'][i]); trend=float(x['trend'][i]);
        macd=float(x['macd'][i]); volz=float(x['volz'][i]); atr=float(x['atrpct'][i]);
        # Directional technical score, deliberately bounded to [-1,1].
        score=(0.30*np.tanh(trend*120.0)+0.25*np.tanh(macd*120.0)+
               0.20*np.clip((rsi-50.0)/25.0,-1,1)+0.15*np.tanh(volz/2.0)+
               0.10*np.tanh((float(x['ret3'][i]) if np.isfinite(x['ret3'][i]) else 0.0)*80.0))
        score=float(np.clip(score,-1,1))
        # Liquidity is a ranking factor, not a directional signal.
        liq=float(item.get('turnover',0.0) or 0.0)
        quality=float(np.clip(abs(score)*0.75 + min(1.0,np.log10(max(liq,1.0))/10.0)*0.25,0,1))
        return {'contract':item['contract'],'symbol':item['display'],'price':close,'quick_score':score,
                'quality':quality,'turnover24h':liq,'atrpct':atr,'rsi':rsi}

    def _persist_scan_prediction(self, r):
        """Persist only a selected TOP candidate, never every deep finalist."""
        contract=str(r.get('contract') or r.get('exchange_symbol') or '')
        if not contract:return
        pred_path=self.logs/f'{contract}_predictions.json'
        pending_path=self.logs/f'{contract}_pending.json'
        self._append_json(pred_path,r)
        if str(r.get('prediction','WAIT')).upper() in ('LONG','SHORT'):
            self._append_json(pending_path,r)

    def _scan_train_and_predict(self,item,scan_history=800,run_id=None):
        # Full model validation only for the best pre-scan candidates.
        old_limit=self.cfg.get('history_limit',5000)
        try:
            self.cfg['history_limit']=max(500,int(scan_history))
            self.set_symbol(item['contract'])
            if not self.mm.has_champion():
                self.train_from_fresh()
            row=self.live_row(); pred,probs=self.mm.predict(row)
            entry,sl,tp1,tp2,tp3=self._signal_levels(row,pred)
            r={'id':f"{time.time_ns()}-{self.exchange.futures_symbol}",'symbol':self.exchange.symbol,'exchange_symbol':self.exchange.futures_symbol,
               'contract':self.exchange.futures_symbol,'time':int(row['time'][0]),'price':float(row['close'][0]),
               'prediction':pred,'p_short':probs[0],'p_wait':probs[1],'p_long':probs[2],
               'entry':entry,'sl':sl,'tp1':tp1,'tp2':tp2,'tp3':tp3,'horizon_bars':int(self.cfg['horizon_bars']),'resolved':0,
               'turnover24h':float(item.get('turnover',0.0) or 0.0), 'run_id':run_id,
               'market_features_mode':str(self.mm._read_json(self.mm.meta,{}).get('market_features_mode','neutral')),
               'market_feature_status':dict(self.mm._read_json(self.mm.meta,{}).get('market_feature_status',{}) or {}),
               'market_metrics_status':str(getattr(self.exchange,'_market_metrics_status','not_checked'))}
            r['quality']=float(max(probs.values()))
            r['edge_score']=float(max(probs[0],probs[2])-probs[1])
            r['features']={f:float(row[f][0]) for f in FEATURES}
            cached_base=getattr(self,'_last_live_base',None)
            if isinstance(cached_base,dict) and len(cached_base.get('close',[])) >= 40:
                # Private in-memory payload, removed before TOP-5 persistence.
                r['_stage25_base']=cached_base
            r.update(self.mm.prediction_diagnostics(row,pred,probs))
            self._attach_challenger_prediction(r, row)
            # These are Master outcome-head probabilities, not raw math heuristics.
            p_sl=float(r.get('outcome_p_initial_sl',0.0) or 0.0)
            p_tp1_ex=float(r.get('outcome_p_tp1',0.0) or 0.0)
            p_tp2_ex=float(r.get('outcome_p_tp2',0.0) or 0.0)
            p_tp3_ex=float(r.get('outcome_p_tp3',0.0) or 0.0)
            p_tp3_plus=float(r.get('outcome_p_tp3_plus',0.0) or 0.0)
            r['p_tp1']=max(0.0,min(1.0,p_tp1_ex+p_tp2_ex+p_tp3_ex+p_tp3_plus))
            r['p_tp2']=max(0.0,min(1.0,p_tp2_ex+p_tp3_ex+p_tp3_plus))
            r['p_tp3']=max(0.0,min(1.0,p_tp3_ex+p_tp3_plus))
            r['p_sl']=max(0.0,min(1.0,p_sl))
            r['probability_source']='MASTER_OUTCOME_HEAD_CUMULATIVE'
            self._attach_lens_plans(r)
            r['lens_architecture']='MASTER_SHARED_BASE+C1+C2+C3->MASTER'
            return r
        finally:
            self.cfg['history_limit']=old_limit

    @staticmethod
    def _classify_scan_error(exc):
        """Classify a scanner failure so the UI can explain the error instead of
        showing only one aggregate counter."""
        msg=str(exc or '').lower()
        if any(x in msg for x in ('no address associated with hostname','temporary failure in name resolution','name or service not known','nodename nor servname','getaddrinfo','dns')):
            return 'DNS/сеть'
        if any(x in msg for x in ('http 429','http 408','http 500','http 502','http 503','http 504','timeout','timed out','connection reset','connection aborted','connection refused')):
            return 'HTTP/сеть'
        if 'http ' in msg or 'api' in msg or 'kucoin' in msg and 'не вернул' not in msg:
            return 'API/ответ'
        if any(x in msg for x in ('не вернул свечи','пуст','слишком мало')):
            return 'Свечи/данные'
        return 'Обработка данных'

    def _apply_ready_freshness(self, results, candidate_pool, run_id=None, cancel_event=None):
        """Final freshness gate used only after the model is READY.

        Small price movement is accepted. A material move triggers a fast
        re-analysis of that coin only. If it is still moving materially, the
        candidate is retried a bounded number of times. Invalidated candidates
        are replaced from the already scanned deep candidate pool; the full
        market scan is never restarted.
        """
        if not bool(self.cfg.get('freshness_enabled_when_ready', True)):
            return results, {'enabled': False}
        try:
            if not bool(self.readiness().get('ready')):
                return results, {'enabled': False, 'reason': 'model_not_ready'}
        except Exception:
            return results, {'enabled': False, 'reason': 'readiness_check_failed'}

        small=float(self.cfg.get('freshness_small_move_pct',0.20))
        trigger=float(self.cfg.get('freshness_recheck_move_pct',0.50))
        retries=max(1,int(self.cfg.get('freshness_max_rechecks',2)))
        pool_limit=max(5,int(self.cfg.get('freshness_candidate_pool',50)))
        try:
            tickers=self.exchange.all_tickers()
            price_map={}
            for t in tickers or []:
                sym=str(t.get('symbol','')).upper()
                try:
                    px=float(t.get('price',t.get('markPrice',0)) or 0)
                except Exception:
                    px=0.0
                if sym and px>0: price_map[sym]=px
        except Exception:
            price_map={}

        used=set()
        final=[]
        stats={'enabled':True,'checked':0,'small_move':0,'rechecked':0,'invalidated':0,'retries':0}

        # Keep the original ranking, then fill vacancies from the already
        # scanned deep pool in ranking order.
        pool=[]
        for r in list(results)+list(candidate_pool):
            c=str(r.get('contract') or r.get('exchange_symbol') or '')
            if c and c not in used:
                used.add(c); pool.append(dict(r))
        pool=pool[:max(pool_limit,len(results))]

        for candidate in pool:
            if len(final)>=5: break
            if cancel_event is not None and cancel_event.is_set(): break
            current=dict(candidate)
            for attempt in range(retries+1):
                contract=str(current.get('contract') or current.get('exchange_symbol') or '')
                entry=float(current.get('entry',current.get('price',0)) or 0)
                market_px=float(price_map.get(contract,0) or 0)
                if market_px<=0:
                    # A ticker miss is not a reason to discard a valid signal.
                    current['freshness_status']='ticker_unavailable'
                    current['freshness_checked_at']=int(time.time())
                    break
                delta=abs(market_px/entry-1.0)*100.0 if entry>0 else 0.0
                stats['checked']+=1
                current['freshness_checked_at']=int(time.time())
                current['freshness_market_price']=market_px
                current['freshness_move_pct']=delta
                current['freshness_attempt']=attempt
                # Small movement is acceptable; preserve the original Entry/SL/TP
                # calculated from the prediction snapshot.
                if delta < trigger:
                    current['freshness_status']='fresh' if delta <= small else 'acceptable_move'
                    if delta <= small: stats['small_move']+=1
                    break
                if attempt>=retries:
                    current['freshness_status']='unstable'
                    stats['invalidated']+=1
                    current=None
                    break
                # Re-analyse only this coin using the newest candles.
                stats['rechecked']+=1; stats['retries']+=1
                try:
                    ex=KuCoin(contract,timeout=self.exchange.timeout)
                    ex._request_gap=max(float(getattr(ex,'_request_gap',0.10)), float(self.cfg.get('scan_model_request_gap',0.20)))
                    eng=LearningEngine(self.root,ex,dict(self.cfg))
                    fresh=eng._scan_train_and_predict({'contract':contract,'display':current.get('symbol',ex.display_symbol(contract)),'turnover':current.get('turnover24h',0.0)},800,run_id=run_id)
                    fresh['quick_score']=current.get('quick_score',0.0)
                    fresh['prescan_quality']=current.get('prescan_quality',0.0)
                    current=fresh
                    # Re-read the ticker for this coin immediately after re-analysis.
                    try:
                        latest=ex.all_tickers()
                        for t in latest or []:
                            if str(t.get('symbol','')).upper()==contract:
                                px=float(t.get('price',t.get('markPrice',0)) or 0)
                                if px>0: price_map[contract]=px
                                break
                    except Exception:
                        pass
                    if str(current.get('prediction','WAIT')).upper() not in ('LONG','SHORT','WAIT'):
                        current=None
                        stats['invalidated']+=1
                        break
                except Exception:
                    current=None
                    stats['invalidated']+=1
                    break
            if current is not None and str(current.get('prediction','WAIT')).upper() in ('LONG','SHORT','WAIT'):
                final.append(current)

        # If the market was moving too quickly, return the stable subset rather
        # than looping the complete 670+ symbol scan.
        final.sort(key=lambda r:(r.get('edge_score',-9),r.get('quality',0),r.get('turnover24h',0)),reverse=True)
        return final[:5], stats

    def _load_math_learning(self):
        # Kept only for compatibility with old data. The new architecture never
        # trains or reweights individual mathematical methods/lenses.
        return {'enabled':False,'methods':{},'observations':0}
    def _save_math_learning(self,state):
        # Deliberately disabled: fixed lenses do not learn.
        return None
    def _math_method_scores(self, m, direction):
        sign = 1.0 if direction == 'LONG' else -1.0
        return {
            'markov': float(np.clip(m['math_markov'] * sign, -1, 1)),
            'ar': float(np.clip(m['math_ar'] * sign, -1, 1)),
            'arima': float(np.clip(m['math_arima'] * sign, -1, 1)),
            'sarima': float(np.clip(m['math_sarima'] * sign, -1, 1)),
            'hurst_persistence': float(np.clip((m['math_hurst'] - 0.5) * 2 * float(m.get('math_trend_direction', 0.0)) * sign, -1, 1)),
            'mean_reversion': float(np.clip(m['math_mean_reversion'] * sign, -1, 1)),
            'cointegration': float(np.clip(m['math_cointegration'] * sign, -1, 1)),
            'correlation_with_benchmark_trend': float(np.clip(m['math_correlation'] * float(m.get('math_benchmark_direction', 0.0)) * sign, -1, 1)),
            'trend_deviation': float(np.clip(m.get('math_trend_deviation', 0.0) * sign, -1, 1)),
            'wavelet': float(np.clip(m['math_wavelet'] * sign, -1, 1)),
            'kalman': float(np.clip(m['math_kalman'] * sign, -1, 1)),
            'monte_carlo': float(np.clip((2 * m['math_monte_carlo'] - 1) * sign, -1, 1)),
            'bayesian': float(np.clip((2 * m['math_bayesian'] - 1) * sign, -1, 1)),
        }

    def _stage25_validate(self, rows, progress=None, cancel_event=None):
        """Validate the finalists with the fixed math stack using bounded parallel I/O.

        Each candidate still uses the same five timeframes and the same math/model
        calculations. Only independent market-data fetches are parallelized; this
        removes the serial 25 x 5-timeframe network bottleneck without changing
        candidate scoring or ranking.
        """
        from .exchange import KuCoin
        from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
        rows = list(rows or [])
        self._last_stage25_timed_out = False
        if not rows:
            return []
        math_probability_calibration = self._load_math_probability_calibration()
        correlation_inputs = {}
        for candidate in rows:
            payload = candidate.get('_stage25_base')
            if isinstance(payload, dict) and len(payload.get('close', [])) >= 40 and len(payload.get('time', [])) == len(payload.get('close', [])):
                correlation_inputs[str(candidate.get('contract') or candidate.get('exchange_symbol') or candidate.get('symbol') or '')] = {
                    'time': payload.get('time', []), 'close': payload.get('close', [])}
        correlation_matrix = compute_correlation_matrix(correlation_inputs, min_overlap=30)
        correlation_summary = {}
        symbols = correlation_matrix.get('symbols', [])
        values = np.asarray(correlation_matrix.get('matrix', []), dtype=float) if symbols else np.zeros((0,0))
        if len(symbols) and values.shape == (len(symbols), len(symbols)):
            for i, symbol in enumerate(symbols):
                peers = np.delete(values[i], i)
                correlation_summary[symbol] = {
                    'peer_count':int(len(peers)),
                    'mean_signed_correlation':float(np.mean(peers)) if len(peers) else 0.0,
                    'mean_absolute_correlation':float(np.mean(np.abs(peers))) if len(peers) else 0.0,
                    'max_absolute_correlation':float(np.max(np.abs(peers))) if len(peers) else 0.0,
                }
            data_dir = getattr(self, 'data', None)
            if data_dir is not None:
                try:
                    matrix_path = data_dir/'math_correlation_matrix.json'
                    matrix_state = {'formula_version':MATH_FORMULA_VERSION,
                                    'cycle':int(rows[0].get('run_id', 0) or 0),
                                    'updated_at':int(time.time()), **correlation_matrix}
                    tmp = matrix_path.with_suffix('.tmp')
                    tmp.write_text(json.dumps(matrix_state, separators=(',',':')), encoding='utf-8')
                    tmp.replace(matrix_path)
                except Exception:
                    pass
        scan_timeout = max(5, min(15, int(self.cfg.get('scan_request_timeout_seconds', 8) or 8)))
        scan_attempts = max(1, min(3, int(self.cfg.get('scan_request_attempts', 2) or 2)))
        benchmark_close = None
        try:
            benchmark_ex = KuCoin('XBTUSDTM', timeout=scan_timeout)
            benchmark_ex._max_attempts = scan_attempts
            benchmark_ex._retry_delays = (0.4, 0.8)
            benchmark_ex._request_gap = max(float(getattr(benchmark_ex, '_request_gap', 0.10)), float(self.cfg.get('scan_model_request_gap', 0.20)))
            benchmark_frame = benchmark_ex.candles('5min', min(int(self.cfg.get('history_limit', 5000)), 1200))
            if benchmark_frame is not None and len(benchmark_frame.get('close', [])) >= 40:
                benchmark_close = benchmark_frame['close']
        except Exception:
            benchmark_close = None

        # A worker handles one candidate at a time; retain its KuCoin client so
        # TLS setup and HTTP keep-alive are not repeated for every contract.
        exchange_worker = threading.local()
        def validate_one(index_row):
            index, row = index_row
            if cancel_event is not None and cancel_event.is_set():
                return index, None, 'cancelled'
            try:
                pred = str(row.get('prediction', 'WAIT')).upper()
                if pred not in ('LONG', 'SHORT', 'WAIT'):
                    return index, None, 'invalid_signal'
                contract = str(row.get('contract') or row.get('exchange_symbol') or '')
                if not contract:
                    return index, None, 'missing_contract'
                ex = getattr(exchange_worker, 'exchange', None)
                if ex is None:
                    ex = KuCoin(contract, timeout=scan_timeout)
                    ex._max_attempts = scan_attempts
                    ex._retry_delays = (0.4, 0.8)
                    ex._request_gap = max(float(getattr(ex, '_request_gap', 0.10)), float(self.cfg.get('scan_model_request_gap', 0.20)))
                    exchange_worker.exchange = ex
                else:
                    ex.set_symbol(contract)
                history = min(int(self.cfg.get('history_limit', 5000)), 1200)
                # Prefer the closed 5m frame already downloaded by live_row().
                # This eliminates one extra REST history fetch per finalist.
                cached = row.get('_stage25_base')
                if isinstance(cached, dict) and len(cached.get('close', [])) >= 40:
                    base = {k: np.asarray(v).copy() for k, v in cached.items()}
                else:
                    # Only the 5m frame is consumed below; do not fetch unused
                    # 15m/1h/4h/1d frames in this math-only stage.
                    base = ex.candles('5min', history)
                def path_distances(candidate):
                    try:
                        entry_px = float(candidate.get('entry', candidate.get('price', 0.0)) or 0.0)
                        if entry_px <= 0:
                            return None, None
                        targets = []
                        for key in ('tp1', 'tp2', 'tp3'):
                            px = float(candidate.get(key, float('nan')))
                            if np.isfinite(px) and px > 0 and abs(px-entry_px) > 0:
                                targets.append(abs(float(np.log(px / entry_px))))
                        stop_px = float(candidate.get('sl', float('nan')))
                        stop_distance = abs(float(np.log(stop_px / entry_px))) if np.isfinite(stop_px) and stop_px > 0 and stop_px != entry_px else None
                        return (targets if len(targets) == 3 else None), stop_distance
                    except Exception:
                        return None, None
                r = dict(row)
                decision_row = {f: np.asarray([float((r.get('features') or {}).get(f, 0.0))]) for f in FEATURES}
                current_pred = pred
                seen_directions = []
                converged = False
                final_probs = np.asarray([float(r.get('p_short', 0.0)), float(r.get('p_wait', 1.0)), float(r.get('p_long', 0.0))])
                scores = {}
                consensus = 0.0
                m = {}
                # The final direction affects both the math path probabilities and
                # the Master selector. Iterate a bounded number of times so the
                # persisted direction and its TP/SL metrics describe the same plan.
                for _pass in range(3):
                    candidate_plan = dict(r)
                    candidate_plan['entry'], candidate_plan['sl'], candidate_plan['tp1'], candidate_plan['tp2'], candidate_plan['tp3'] = self._signal_levels(
                        {'close': np.asarray([float(r.get('price', 0.0))]),
                         'atrpct': np.asarray([float((r.get('features') or {}).get('atrpct', 0.001))])}, current_pred)
                    target_distances, stop_distance = path_distances(candidate_plan)
                    m = compute_math_snapshot(
                        base['close'], base.get('high'), base.get('low'), base.get('volume'),
                        int(self.cfg.get('horizon_bars', 12)), seed=_stable_contract_seed(contract),
                        benchmark_close=benchmark_close, forecast_direction=current_pred,
                        target_log_distances=target_distances, stop_log_distance=stop_distance,
                        probability_calibration=math_probability_calibration)
                    if current_pred == 'WAIT':
                        scores = {}
                        consensus = float(np.clip(m.get('math_consensus', 0.0), -1, 1))
                    else:
                        scores = self._math_method_scores(m, current_pred)
                        consensus = float(np.clip(np.mean(list(scores.values())) if scores else 0.0, -1, 1))
                    next_pred, final_probs, _final_extra = self.mm.predict_bundle(decision_row, consensus, m)
                    next_pred = str(next_pred or 'WAIT').upper()
                    if next_pred == current_pred:
                        converged = True
                        break
                    if next_pred in seen_directions:
                        break
                    seen_directions.append(current_pred)
                    current_pred = next_pred

                if not converged:
                    # If math and Master repeatedly disagree on direction, don't
                    # publish a potentially unstable LONG/SHORT as a trade signal.
                    final_pred = 'WAIT'
                    consensus = 0.0
                    scores = {}
                    candidate_plan = dict(r)
                    candidate_plan['entry'], candidate_plan['sl'], candidate_plan['tp1'], candidate_plan['tp2'], candidate_plan['tp3'] = self._signal_levels(
                        {'close': np.asarray([float(r.get('price', 0.0))]),
                         'atrpct': np.asarray([float((r.get('features') or {}).get('atrpct', 0.001))])}, 'WAIT')
                    m = compute_math_snapshot(
                        base['close'], base.get('high'), base.get('low'), base.get('volume'),
                        int(self.cfg.get('horizon_bars', 12)), seed=_stable_contract_seed(contract),
                        benchmark_close=benchmark_close, forecast_direction='WAIT',
                        probability_calibration=math_probability_calibration)
                    _raw_pred, final_probs, _final_extra = self.mm.predict_bundle(decision_row, consensus, m)
                else:
                    final_pred = current_pred
                    candidate_plan = dict(r)
                    candidate_plan['entry'], candidate_plan['sl'], candidate_plan['tp1'], candidate_plan['tp2'], candidate_plan['tp3'] = self._signal_levels(
                        {'close': np.asarray([float(r.get('price', 0.0))]),
                         'atrpct': np.asarray([float((r.get('features') or {}).get('atrpct', 0.001))])}, final_pred)
                    # The last loop's math snapshot was computed for this same
                    # direction and its actual levels, so its path probabilities align.

                r['prediction'] = final_pred
                r['p_short'] = float(final_probs[0]); r['p_wait'] = float(final_probs[1]); r['p_long'] = float(final_probs[2])
                r['entry'], r['sl'], r['tp1'], r['tp2'], r['tp3'] = (candidate_plan[k] for k in ('entry', 'sl', 'tp1', 'tp2', 'tp3'))
                r['math_converged'] = bool(converged)
                if not converged:
                    r['prediction_guard'] = 'math_direction_nonconvergent'
                else:
                    r.pop('prediction_guard', None)
                try:
                    r.update(self.mm.prediction_diagnostics(decision_row, final_pred, final_probs, consensus, m))
                except Exception:
                    pass
                math_direction_prob = float(np.clip(0.5 + 0.5 * consensus, 0, 1))
                if final_pred == 'WAIT':
                    ptp1 = ptp2 = ptp3 = psl = None
                    stage_score = float(np.clip(0.65 * float(r.get('p_wait', 0.0) or 0.0) + 0.35 * (1.0 - abs(consensus)), 0, 1))
                else:
                    ptp1 = float(m['math_ptp1']); ptp2 = float(m['math_ptp2']); ptp3 = float(m['math_ptp3']); psl = float(m['math_psl'])
                    stage_score = float(np.clip(0.50 * (float(r.get('edge_score', 0)) + 1) / 2 + 0.50 * ((consensus + 1) / 2), 0, 1))
                r.pop('_stage25_base', None)
                r['math_formula_version'] = MATH_FORMULA_VERSION
                r['math_correlation_matrix_summary'] = correlation_summary.get(str(r.get('contract') or r.get('exchange_symbol') or r.get('symbol') or ''), {'peer_count':0,'mean_signed_correlation':0.0,'mean_absolute_correlation':0.0,'max_absolute_correlation':0.0})
                r['math_features'] = {k: float(v) for k, v in m.items() if k in MATH_FEATURES}; r['math_method_scores'] = scores
                r['math_consensus'] = consensus; r['math_direction_probability'] = math_direction_prob
                r['p_tp1'] = ptp1; r['p_tp2'] = ptp2; r['p_tp3'] = ptp3; r['p_sl'] = psl; r['stage25_math_score'] = consensus; r['stage25_score'] = stage_score; r['scan_stage'] = '25'
                r['features'] = dict(r.get('features') or {}); r['features']['math_consensus'] = consensus; r['features']['math_direction_probability'] = math_direction_prob; r['features']['math_ptp1'] = ptp1; r['features']['math_ptp2'] = ptp2; r['features']['math_ptp3'] = ptp3; r['features']['math_psl'] = psl
                return index, r, None
            except Exception as exc:
                return index, None, str(exc)[:240]

        workers = max(1, min(3, int(self.cfg.get('scan_math_workers', 3) or 3)))
        completed = 0
        out_by_index = {}
        math_timeout = max(1, min(900, int(self.cfg.get('scan_math_stage_timeout_seconds', 300) or 300)))
        math_deadline = time.monotonic() + math_timeout
        math_pool = ThreadPoolExecutor(max_workers=workers, thread_name_prefix='math25')
        futures = {math_pool.submit(validate_one, (i, row)): (i, row) for i, row in enumerate(rows)}
        pending = set(futures)
        math_pool_shutdown = False
        while pending:
            if cancel_event is not None and cancel_event.is_set():
                for future in pending:
                    future.cancel()
                math_pool.shutdown(wait=False, cancel_futures=True)
                math_pool_shutdown = True
                break
            remaining = math_deadline - time.monotonic()
            if remaining <= 0:
                self._last_stage25_timed_out = True
                for future in pending:
                    future.cancel()
                # Do not wait for a stuck math worker to exit. Results already
                # completed remain usable; unfinished candidates are excluded.
                math_pool.shutdown(wait=False, cancel_futures=True)
                math_pool_shutdown = True
                break
            done_set, pending = wait(pending, timeout=min(0.5, remaining), return_when=FIRST_COMPLETED)
            for future in done_set:
                if future.cancelled():
                    continue
                try:
                    index, result, error = future.result()
                except Exception as exc:
                    index = futures[future][0]
                    result = None
                    error = str(exc)[:240]
                completed += 1
                if result is not None:
                    out_by_index[index] = result
                if progress is not None:
                    source_row = rows[index]
                    progress(completed, len(rows), source_row.get('symbol') or source_row.get('contract') or '—', result,
                             ({'error': error, 'category': 'Математическая проверка'} if error and error != 'cancelled' else None), phase='MODEL')
        if not math_pool_shutdown:
            math_pool.shutdown(wait=True, cancel_futures=False)
        # Preserve original candidate order for exact score ties, matching the
        # prior sequential validator despite parallel completion order.
        out = [out_by_index[i] for i in sorted(out_by_index)]
        out.sort(key=lambda r: (float(r.get('stage25_score', -9) or -9), float(r.get('p_tp1', 0) or 0), float(r.get('p_tp2', 0) or 0), float(r.get('edge_score', -9) or -9), float(r.get('quality', 0) or 0)), reverse=True)
        return out

    def scan_all(self, progress=None, cancel_event=None, run_id=None):
        """Full market scan with a fast parallel pre-scan and a bounded deep stage.

        Every active USDT perpetual is still considered.  The expensive model
        stage is only run for the best pre-scan candidates, while the pre-scan
        itself uses a small worker pool and conservative per-connection pacing.
        """
        from .exchange import KuCoin
        from concurrent.futures import ThreadPoolExecutor, as_completed
        scan_started=time.monotonic()
        scan_cfg=dict(self.cfg)
        scan_timeout = max(5, min(15, int(scan_cfg.get('scan_request_timeout_seconds', 8) or 8)))
        scan_attempts = max(1, min(3, int(scan_cfg.get('scan_request_attempts', 2) or 2)))
        base_exchange=KuCoin(self.exchange.futures_symbol, timeout=scan_timeout)
        base_exchange._max_attempts = scan_attempts
        base_exchange._retry_delays = (0.4, 0.8)
        symbols=base_exchange.active_symbols()
        total=len(symbols)
        quick=[]; errors=0; results=[]; prescan_errors=0; model_errors=0
        error_breakdown={'DNS/сеть':0,'HTTP/сеть':0,'API/ответ':0,'Свечи/данные':0,'Обработка данных':0,'Модель':0}
        error_samples=[]
        seen_contracts=[]; seen=set()
        for item in symbols:
            c=item['contract']
            if c not in seen:
                seen.add(c); seen_contracts.append(item)
        symbols=seen_contracts; total=len(symbols)
        progress_lock=threading.Lock(); completed=0; error_count=0; ok_count=0

        prescan_started=time.monotonic()
        workers=max(1,min(4,int(scan_cfg.get('scan_workers',4))))
        # Reuse one exchange client and engine per worker thread. Each thread
        # processes contracts sequentially, so symbol switching is isolated and
        # TLS/HTTP setup and engine initialization are reused without changing ranking.
        quick_worker=threading.local()
        def quick_one(item):
            ex=getattr(quick_worker,'exchange',None)
            eng=getattr(quick_worker,'engine',None)
            if ex is None or eng is None:
                ex=KuCoin(item['contract'],timeout=scan_timeout)
                ex._max_attempts = scan_attempts
                ex._retry_delays = (0.4, 0.8)
                ex._request_gap=max(float(getattr(ex,'_request_gap',0.10)), float(scan_cfg.get('scan_request_gap',0.20)))
                eng=LearningEngine(self.root,ex,dict(scan_cfg))
                quick_worker.exchange=ex; quick_worker.engine=eng
            return eng._quick_candidate(item)
        with ThreadPoolExecutor(max_workers=workers,thread_name_prefix='quickscan') as pool:
            futs={pool.submit(quick_one,item):item for item in symbols}
            for fut in as_completed(futs):
                item=futs[fut]
                if cancel_event is not None and cancel_event.is_set():
                    break
                try:
                    q=fut.result(); quick.append(q); ok_count+=1
                    err=None
                except Exception as e:
                    errors+=1; prescan_errors+=1; error_count+=1; err=e
                    category=self._classify_scan_error(e); error_breakdown[category]=error_breakdown.get(category,0)+1
                    if len(error_samples)<50: error_samples.append({'symbol':item['display'],'stage':'PRESCAN','category':category,'error':str(e)})
                with progress_lock:
                    completed+=1; d=completed
                if progress: progress(d,total,item['display'],q if err is None else None, None if err is None else {'error':str(err),'category':self._classify_scan_error(err)},phase='PRESCAN')
        if cancel_event is not None and cancel_event.is_set():
            diagnostics={'total_errors':errors,'prescan_errors':errors,'model_errors':0,'breakdown':error_breakdown,'samples':error_samples,'ok':ok_count,'cancelled':True}
            return results,total,ok_count,errors,diagnostics

        prescan_seconds=time.monotonic()-prescan_started
        quick_by_contract={r['contract']:r for r in quick}; quick=list(quick_by_contract.values())
        quick.sort(key=lambda r:(r.get('quality',0),abs(r.get('quick_score',0)),r.get('turnover24h',0)),reverse=True)
        max_finalists=max(25,int(scan_cfg.get('scan_deep_candidates',50)))
        deep=quick[:max_finalists]
        model_workers=max(1,min(3,int(scan_cfg.get('scan_model_workers',2))))
        model_started=time.monotonic()
        model_done=0; next_deep=0
        from concurrent.futures import wait, FIRST_COMPLETED
        model_worker=threading.local()
        def model_one(item):
            # Reuse the HTTP client, but isolate symbol-specific engine state.
            # Whole-engine reuse was introduced in 1.0.216; each engine owns
            # model/prediction/training state and should not span contracts.
            ex=getattr(model_worker,'exchange',None)
            if ex is None:
                ex=KuCoin(item['contract'],timeout=scan_timeout)
                ex._max_attempts = scan_attempts
                ex._retry_delays = (0.4, 0.8)
                ex._request_gap=max(float(getattr(ex,'_request_gap',0.10)), float(scan_cfg.get('scan_model_request_gap',0.20)))
                model_worker.exchange=ex
            else:
                ex.set_symbol(item['contract'])
            eng=LearningEngine(self.root,ex,dict(scan_cfg))
            return eng._scan_train_and_predict({'contract':item['contract'],'display':item['symbol'],'turnover':item['turnover24h']},800,run_id=run_id)
        model_pool = ThreadPoolExecutor(max_workers=model_workers,thread_name_prefix='modelscan')
        pending_futures={}
        model_pool_shutdown=False
        model_stage_timeout=max(1,min(1800,int(scan_cfg.get('scan_model_stage_timeout_seconds',900) or 900)))
        model_deadline=model_started+model_stage_timeout
        model_stage_timed_out=False
        while next_deep < len(deep) and len(pending_futures) < model_workers:
            item=deep[next_deep]; next_deep+=1
            pending_futures[model_pool.submit(model_one,item)]=item
        while pending_futures:
            if cancel_event is not None and cancel_event.is_set():
                for fut in pending_futures:
                    fut.cancel()
                pending_futures.clear()
                model_pool.shutdown(wait=False,cancel_futures=True)
                model_pool_shutdown=True
                break
            remaining=model_deadline-time.monotonic()
            if remaining <= 0:
                model_stage_timed_out=True
                # A stuck model worker must not freeze the service indefinitely.
                # Cancel queued work, record explicit timeouts, and let completed
                # candidates continue through the normal validation/ranking path.
                timeout_items=list(pending_futures.items())
                pending_futures.clear()
                for fut,item in timeout_items:
                    fut.cancel()
                    model_done+=1; model_errors+=1; errors+=1
                    category='Модель'
                    error_breakdown[category]=error_breakdown.get(category,0)+1
                    message=f'MODEL stage deadline exceeded ({model_stage_timeout}s)'
                    if len(error_samples)<50:
                        error_samples.append({'symbol':item['symbol'],'stage':'MODEL_TIMEOUT','category':category,'error':message})
                    if progress:
                        progress(model_done,len(deep),item['symbol'],None,{'error':message,'category':category},phase='MODEL')
                # Contracts not yet submitted are explicitly accounted for too;
                # the scan returns a partial candidate pool instead of hanging.
                while next_deep < len(deep):
                    item=deep[next_deep]; next_deep+=1
                    model_done+=1; model_errors+=1; errors+=1
                    category='Модель'
                    error_breakdown[category]=error_breakdown.get(category,0)+1
                    message=f'Skipped after MODEL stage deadline ({model_stage_timeout}s)'
                    if len(error_samples)<50:
                        error_samples.append({'symbol':item['symbol'],'stage':'MODEL_TIMEOUT','category':category,'error':message})
                    if progress:
                        progress(model_done,len(deep),item['symbol'],None,{'error':message,'category':category},phase='MODEL')
                model_pool.shutdown(wait=False,cancel_futures=True)
                model_pool_shutdown=True
                break
            done_set,_=wait(list(pending_futures),timeout=min(0.5,remaining),return_when=FIRST_COMPLETED)
            if not done_set:
                continue
            for fut in done_set:
                item=pending_futures.pop(fut); model_done+=1
                try:
                    r=fut.result(); r['quick_score']=item['quick_score']; r['prescan_quality']=item['quality']; r['scan_index']=model_done
                    if str(r.get('prediction','WAIT')).upper() in ('LONG','SHORT','WAIT'): results.append(r)
                    err=None
                except Exception as e:
                    model_errors+=1; errors+=1; category=self._classify_scan_error(e); error_breakdown[category]=error_breakdown.get(category,0)+1
                    if len(error_samples)<50: error_samples.append({'symbol':item['symbol'],'stage':'MODEL','category':category,'error':str(e)})
                    err={'error':str(e),'category':category}
                if progress:
                    progress(model_done,len(deep),item['symbol'],None if err else r,err,phase='MODEL')
                if cancel_event is not None and cancel_event.is_set():
                    break
                if next_deep < len(deep):
                    ni=deep[next_deep]; next_deep+=1
                    pending_futures[model_pool.submit(model_one,ni)]=ni
            if cancel_event is not None and cancel_event.is_set():
                for fut in pending_futures:
                    fut.cancel()
                pending_futures.clear()
                model_pool.shutdown(wait=False,cancel_futures=True)
                model_pool_shutdown=True
                break
        if not model_pool_shutdown:
            model_pool.shutdown(wait=True,cancel_futures=False)
        model_seconds=time.monotonic()-model_started
        unique={}
        for r in results:
            c=r.get('contract') or r.get('exchange_symbol')
            if c and c not in unique: unique[c]=r
        unique_pool={}
        for r in results:
            c=r.get('contract') or r.get('exchange_symbol')
            if c and c not in unique_pool: unique_pool[c]=r
        candidate_pool=list(unique_pool.values())
        candidate_pool.sort(key=lambda r:(r.get('edge_score',-9),r.get('quality',0),r.get('turnover24h',0)),reverse=True)
        # Stage 1: best 50 receive the learned model analysis. Stage 2: only
        # the best 25 receive the extra mathematical/MTF/history validation.
        stage25_candidates = candidate_pool[:max(25, int(scan_cfg.get('scan_second_stage_candidates', 25)))]
        # The model phase has already reported model_done/len(deep). Keep the
        # displayed progress moving during math validation instead of leaving it
        # frozen at 100% while hundreds of candle requests are made.
        def math_progress(done, total, name, row, err, phase='MODEL'):
            if progress:
                progress(len(deep) + int(done), len(deep) + int(total), name, row, err, phase='MODEL')
        math_started=time.monotonic()
        stage25_pool = self._stage25_validate(stage25_candidates, progress=math_progress if progress else None, cancel_event=cancel_event)
        math_stage_timed_out = bool(getattr(self, '_last_stage25_timed_out', False))
        math_seconds=time.monotonic()-math_started
        if cancel_event is not None and cancel_event.is_set():
            diagnostics = {'total_errors': errors, 'prescan_errors': prescan_errors, 'model_errors': model_errors,
                           'breakdown': error_breakdown, 'samples': error_samples, 'ok': ok_count,
                           'deep_candidates': len(deep), 'second_stage_candidates': len(stage25_pool),
                           'final_top5': 0, 'cancelled': True}
            return [], total, ok_count, errors, diagnostics
        candidate_pool=stage25_pool
        results=candidate_pool[:5]
        results.sort(key=lambda r:(r.get('stage25_score',-9),r.get('edge_score',-9),r.get('quality',0),r.get('turnover24h',0)),reverse=True)
        freshness_diag={'enabled':False}
        try:
            # Freshness is deliberately applied only to a READY model. Before
            # readiness, the learning scan remains unchanged.
            if bool(self.readiness().get('ready')):
                results,freshness_diag=self._apply_ready_freshness(results,candidate_pool[:max(5,int(scan_cfg.get('freshness_candidate_pool',50)))],run_id,cancel_event)
        except Exception as exc:
            freshness_diag={'enabled':True,'error':str(exc)}
        for r in results:
            try:
                self._persist_scan_prediction(r)
            except Exception as exc:
                errors+=1; model_errors+=1
                if len(error_samples)<50:
                    error_samples.append({'symbol':r.get('symbol',r.get('contract')),'stage':'PERSIST','category':'Обработка данных','error':str(exc)})
        diagnostics={'total_errors':errors,'prescan_errors':prescan_errors,
                      'model_errors':model_errors,'breakdown':error_breakdown,
                      'samples':error_samples,'ok':ok_count,'deep_candidates':len(deep),'second_stage_candidates':len(stage25_pool),'final_top5':len(results),'scan_workers':workers,'model_workers':model_workers,'model_stage_timed_out':model_stage_timed_out,'model_stage_timeout_seconds':model_stage_timeout,'math_stage_timed_out':math_stage_timed_out,'math_stage_timeout_seconds':max(1,min(900,int(scan_cfg.get('scan_math_stage_timeout_seconds',300) or 300))),'freshness':freshness_diag,
                      'timings_seconds':{
                          'prescan':round(prescan_seconds,3),'model':round(model_seconds,3),
                          'math_validation':round(math_seconds,3),'total':round(time.monotonic()-scan_started,3),
                          'prescan_per_symbol':round(prescan_seconds/max(1,total),4),
                          'model_per_candidate':round(model_seconds/max(1,len(deep)),4),
                          'math_per_candidate':round(math_seconds/max(1,len(stage25_candidates)),4),
                          'symbols_per_second':round(total/max(1e-9,time.monotonic()-scan_started),3)}}
        return results,total,ok_count,errors,diagnostics

