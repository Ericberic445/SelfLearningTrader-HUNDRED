# SelfLearningTrader FIVE 1.0.258 — Recheck eligibility and post-SL retention

- Fixed active forecast recheck timestamp normalization for seconds, milliseconds, microseconds, and nanoseconds. The previous single `/1000` conversion could leave microsecond timestamps in the future and cause old forecasts to be filtered out.
- Pending cleanup now retains resolved LONG/SHORT records while `post_sl_recheck_pending` is true, so the three-candle post-SL audit is not deleted before completion.
- Added regression tests for microsecond and nanosecond forecast timestamps.

This patch prevents future cleanup from deleting post-SL records that are still in the pending ledger. It does not reconstruct already-missing SL event timestamps in historical records; those require recovery from historical candles. Runtime behavior still needs confirmation on the Android device after building and installing this ZIP.
