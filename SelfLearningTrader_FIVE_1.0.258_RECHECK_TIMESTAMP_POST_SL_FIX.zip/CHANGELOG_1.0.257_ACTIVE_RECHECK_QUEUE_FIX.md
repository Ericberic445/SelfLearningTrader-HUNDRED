# SelfLearningTrader FIVE 1.0.257 — active direction-recheck queue fix

- Restored scheduling of active LONG/SHORT direction rechecks after the original forecast has remained unresolved for at least 60 minutes.
- Excluded WAIT controls and forecasts younger than one hour from the direction-recheck work queue.
- Coalesced queued hourly requests to the latest pending snapshot, instead of retaining one stale full-market request per cycle. The currently running batch remains checkpointed and resumes after service interruption.
- Schedules the recheck queue after a full scan even when no new valid LONG/SHORT candidates are issued.
- Rechecks remain observation-only. Original prediction direction, Entry, SL, TP, and forecast lifecycle are unchanged; actual outcomes are still determined by the separate TP/SL resolver.
- UI unchanged.
