from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCANNER = (ROOT / 'app' / 'services' / 'scanner.py').read_text(encoding='utf-8')
ENGINE = (ROOT / 'app' / 'core' / 'engine.py').read_text(encoding='utf-8')


def test_active_forecast_recheck_is_scheduled_and_queue_is_coalesced():
    # Rechecks are restored for old unresolved LONG/SHORT forecasts; pending
    # hourly snapshots coalesce rather than accumulating one request per cycle.
    assert 'def _queue_active_forecast_recheck(' in SCANNER
    assert SCANNER.count('_queue_active_forecast_recheck(') == 3
    assert 'requests = [request]' in SCANNER
    assert "signal not in ('LONG', 'SHORT')" in SCANNER
    assert 'active_recheck_after_seconds' in SCANNER
    assert 'ACTIVE_FORECAST_RECHECK_STARTUP_RESUME' not in SCANNER


def test_top5_is_published_and_then_recheck_queue_is_scheduled():
    publish = SCANNER.index("last_top5=rows[:5], last_top5_cycle=cycle, top5_started_at=top5_started_at")
    issued_log = SCANNER.index("runtime_log(f'TOP5_ISSUED cycle={cycle}")
    assert publish < issued_log
    assert "TOP-5 выдан и сохранён: {len(rows)} из 5" in SCANNER
    assert '_queue_active_forecast_recheck(engine.cfg, cancel_event=cancel_event, cycle=cycle)' in SCANNER[issued_log:]


def test_wait_window_does_not_repeat_blocking_resolution_and_retraining():
    wait_start = SCANNER.index("while not cancel_event.is_set() and not stopped() and time.time() < next_scan_at:")
    wait_end = SCANNER.index("if cancel_event.is_set() or stopped():", wait_start)
    wait_block = SCANNER[wait_start:wait_end]
    assert 'resolve_all_pending' not in wait_block
    assert '_retrain_with_real_position_batch' not in wait_block
    assert '_sleep_or_stop' in wait_block


def test_scan_and_recheck_share_prediction_ledger_lock():
    persist = ENGINE.split('    def _persist_scan_prediction(self, r):', 1)[1].split('    def _scan_train_and_predict', 1)[0]
    assert 'with _ENGINE_FILE_LOCK:' in persist
    resolve_wrapper = ENGINE.split('    def resolve_pending(self, allowed_ids=None):', 1)[1].split('    def _resolve_pending_locked', 1)[0]
    assert 'with _ENGINE_FILE_LOCK:' in resolve_wrapper



def test_resolve_all_pending_skips_empty_contracts_and_checks_the_full_pool():
    block = ENGINE.split('    def resolve_all_pending(self):', 1)[1].split('    def _wait_learning_row', 1)[0]
    guard = block.index('if not local_ids:')
    skip = block.index('continue', guard)
    network_resolution = block.index('self.resolve_pending(allowed_ids=set(local_ids))')
    assert guard < skip < network_resolution
    assert 'max_long_running_predictions' not in block
    assert 'full-pool sweep' in block
    assert "if item.get('post_sl_recheck_pending') or not item.get('resolved'):" in block


def test_learning_resolution_has_start_and_duration_diagnostics():
    assert "runtime_log('LEARN_RESOLVE_START: resolving active forecasts from shared hourly-scan candle cache')" in SCANNER
    assert "runtime_log(f'LEARN_RESOLVE_DONE elapsed_seconds=" in SCANNER


def test_hourly_tp_sl_pool_and_priority_analysis_are_wired_into_scan():
    assert 'DEFAULT_SCAN_INTERVAL_SECONDS = 3600' in SCANNER
    assert 'priority_contracts=outcome_priority_contracts' in SCANNER
    assert '_add_outcome_analysis_priority(resolved)' in SCANNER
    assert '_consume_outcome_analysis_priority(analyzed_priority)' in SCANNER
    assert "'priority_analyzed_contracts':sorted(" in ENGINE
    assert 'priority_quick + regular_quick' in ENGINE
    assert 'priority_candidates + ordinary_candidates' in ENGINE
    assert 'self.persist_scan_predictions(priority_analysis_rows, allow_new_lifecycle=False)' in ENGINE


def test_expiry_is_explicitly_sideways_and_sent_to_direction_training_but_not_trade_stats():
    assert "'verification_state':'EXPIRED_AFTER_TP2' if tp2_hit else 'EXPIRED_AFTER_TP1' if tp1_hit else 'EXPIRED_SIDEWAYS'" in ENGINE
    assert "item['training_exclude']=False" in ENGINE
    assert "item['statistics_exclude']=True" in ENGINE
    assert "'experience_kind']='EXPIRED_SIDEWAYS'" in ENGINE
    assert "rows.extend(self._observation_experience_rows(x,contract,pid,-1))" in ENGINE


def test_resolve_all_pending_sends_every_active_forecast_id_to_resolution(tmp_path):
    import json
    from types import MethodType
    from app.core.engine import LearningEngine

    engine = LearningEngine.__new__(LearningEngine)
    engine.logs = tmp_path
    engine.logs.mkdir(parents=True, exist_ok=True)
    rows = [
        {'id': f'old-{i}', 'contract': 'AAAUSDTM', 'prediction': 'LONG', 'resolved': 0,
         'time': 1, 'horizon_bars': 12}
        for i in range(37)
    ]
    (tmp_path / 'AAAUSDTM_pending.json').write_text(json.dumps(rows), encoding='utf-8')
    seen = {}
    engine.set_symbol = MethodType(lambda self, contract: setattr(self, 'current_contract', contract), engine)
    def fake_resolve(self, allowed_ids=None):
        seen.update({self.current_contract: set(allowed_ids or set())})
        return []
    engine.resolve_pending = MethodType(fake_resolve, engine)

    engine.resolve_all_pending()

    assert len(seen['AAAUSDTM']) == 37
    assert seen['AAAUSDTM'] == {f'old-{i}' for i in range(37)}


def test_hourly_scan_precedes_full_pool_outcome_resolution():
    scan_done = SCANNER.index("runtime_log(f'FULL_SCAN_DONE cycle={cycle}")
    resolve = SCANNER.index("runtime_log('LEARN_RESOLVE_START: resolving active forecasts from shared hourly-scan candle cache')")
    no_candidates = SCANNER.index("if not rows:", resolve)
    assert scan_done < resolve < no_candidates
    assert "_queue_active_forecast_recheck(engine.cfg, cancel_event=cancel_event, cycle=cycle)" in SCANNER[no_candidates:]
    assert "DEFAULT_SCAN_INTERVAL_SECONDS = 3600" in SCANNER
