import json
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

APP_DIR = Path(__file__).resolve().parents[1] / 'app'
if str(APP_DIR) not in sys.path:
    sys.path.insert(0, str(APP_DIR))
from services import scanner

class FakeKuCoin:
    def __init__(self, contract): self.contract = contract; self._request_gap = 0.1
    def display_symbol(self, contract): return contract
class FakeMM:
    def has_champion(self): return True
class FakeEngine:
    calls=[]; persist_calls=[]
    def __init__(self, root, exchange, cfg, initialize_ledgers=True): self.mm=FakeMM()
    def set_symbol(self, contract): self.contract=contract
    def _scan_train_and_predict(self, item, scan_history=800, run_id=None, update_regime_training=True):
        self.calls.append(item['contract'])
        return {'id':'new','contract':item['contract'],'exchange_symbol':item['contract'],'prediction':'LONG','features':{}}
    def persist_scan_predictions(self, rows, allow_new_lifecycle=True):
        self.persist_calls.append(rows[0]['contract'])
        return [{'id':'original','contract':rows[0]['contract']}]

class TimestampUnitTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.root=Path(self.tmp.name); (self.root/'logs').mkdir()
        self.old_root=scanner.ROOT; scanner.ROOT=self.root; FakeEngine.calls=[]; FakeEngine.persist_calls=[]
    def tearDown(self): scanner.ROOT=self.old_root; self.tmp.cleanup()
    def test_microsecond_prediction_time_is_normalized_to_seconds(self):
        issued=int(time.time())-7200
        row={'id':'old','contract':'AAAUSDTM','prediction':'LONG','time':issued*1_000_000,'resolved':0}
        (self.root/'logs'/'AAAUSDTM_predictions.json').write_text(json.dumps([row]))
        with patch('core.exchange.KuCoin',FakeKuCoin), patch('core.engine.LearningEngine',FakeEngine):
            stats=scanner.recheck_active_forecasts({},cycle=777)
        self.assertEqual(stats['active_contracts'],1)
        self.assertEqual(stats['checked'],1)
        self.assertEqual(FakeEngine.calls,['AAAUSDTM'])
    def test_nanosecond_prediction_time_is_normalized_to_seconds(self):
        issued=int(time.time())-7200
        row={'id':'old','contract':'AAAUSDTM','prediction':'SHORT','time':issued*1_000_000_000,'resolved':0}
        (self.root/'logs'/'AAAUSDTM_predictions.json').write_text(json.dumps([row]))
        with patch('core.exchange.KuCoin',FakeKuCoin), patch('core.engine.LearningEngine',FakeEngine):
            stats=scanner.recheck_active_forecasts({},cycle=778)
        self.assertEqual(stats['active_contracts'],1)
        self.assertEqual(stats['checked'],1)

if __name__=='__main__': unittest.main()
