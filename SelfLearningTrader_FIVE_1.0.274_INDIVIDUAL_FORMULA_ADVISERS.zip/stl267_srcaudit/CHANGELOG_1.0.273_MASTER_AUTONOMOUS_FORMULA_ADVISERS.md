# SelfLearningTrader FIVE 1.0.273 — Master-autonomous formula advisers

## Required decision architecture

- The trained Master remains the sole primary forecaster and independently produces SHORT / WAIT / LONG probabilities.
- C1, C2 and C3 remain deterministic, independent mathematical lenses. Their individual formula outputs are exposed as separate formula/timeframe candidates; fixed-lens agreement or disagreement is not a voting gate.
- Master may select one, several, or zero individual formula advisers for the current market context. Selection uses each formula's own chronological validation against the Master shadow baseline. A mature contextual rejection overrides a global formula pass.
- Only selected, currently directional advisers contribute a reliability-weighted directional score. If their advice cancels or is not directionally meaningful, Master ignores the advisers for that forecast.
- Formula advice is a bounded directional log-odds nudge. It does not add a formula-disagreement WAIT boost. Master retains the final direction/WAIT gate and its existing trained probabilities.
- Formula candidates and their independent shadow plans continue to be evaluated even when the live Master action is WAIT.

## Removed feedback loop

- Removed the Stage-25 three-pass direction-convergence loop.
- Removed the rule that converted non-convergence between math and Master into a forced WAIT.
- Stage 25 now computes independent formula candidates from a directional shadow plan, then applies at most one bounded adviser pass to the Master.
- The legacy fixed-lens combination selector remains available for diagnostics and compatibility, but it no longer replaces the Master probabilities in live decisions.

## Historical data compatibility

- Existing flat 5m formula keys are retained and aliased to canonical keys such as `C1|MARKOV|5m` and `C2|AR|5m`.
- No history is fabricated for 15m, 1h, 4h or 1d; those formula/timeframe combinations learn from their own subsequent observations.
- Legacy composite `MATH_CONSENSUS_BASELINE` remains intact but is not falsely relabeled as an independent formula.

## Validation requirements

- Individual formula promotion retains the existing minimum of 50 training samples and 30 later validation samples, plus the existing paired-lift and coverage checks.
- The 2026-11-21 18:10 backup contains 31 `math_expert_rows`, no `math_ensemble_rows`, and no individually validated formula. After canonical 5m key migration, the selector correctly remains `collecting`; it must not activate an unvalidated formula merely to make advice available sooner.
- All formula/timeframe candidates continue to receive independent shadow outcome tracking. Existing Master training, trade outcome labels, TP1/TP2/TP3/SL semantics, and UI are not redesigned here.

## Tests

- Added tests for Master independence from fixed-lens selector votes.
- Added tests for one/many/zero dynamically selected formula advisers, contextual rejection, opposing formula advice being ignored rather than converted to WAIT, and legacy 5m formula-history migration.
- Added Stage-25 regression coverage proving the direction-convergence loop is gone and WAIT still retains independent directional formula shadow observations.
