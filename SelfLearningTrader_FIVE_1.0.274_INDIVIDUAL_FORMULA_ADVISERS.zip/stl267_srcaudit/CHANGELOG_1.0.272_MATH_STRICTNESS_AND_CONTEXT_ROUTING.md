# SelfLearningTrader FIVE 1.0.272 — mathematical integrity and contextual expert routing

## Changes

- Bumped `MATH_FORMULA_VERSION` from 8 to 9. Existing probability-calibration maps are invalidated because the directional consensus calculation changed; stale maps cannot be applied to the new formula outputs.
- Added strict candle timestamp alignment in `compute_math_snapshot`: malformed/misaligned timestamp arrays are rejected, and calculations use only the latest contiguous OHLC suffix after a missing, duplicate, or out-of-order candle. Empty OHLC inputs now return the neutral snapshot instead of relying on Python's `[-0:]` slicing behavior.
- Removed the nested `math_direction` composite from the internal primitive-expert consensus. The aggregate now combines each primitive method once and normalizes by the sum of its weights.
- Clarified the distinction between an uncalibrated bounded direction score and a probability. The legacy `math_direction_probability` field remains only as a compatibility alias and is explicitly marked `math_direction_probability_calibrated=false`; the correctly named `math_direction_score` is also exposed.
- Strengthened probability-head admission: the untouched chronological holdout must now pass raw and calibrated Brier Skill, AUC, calibrated LogLoss Skill, and calibration must not worsen LogLoss versus the raw head. Calibration maps remain fit on the purged training partition only.
- Extended the existing Math Expert Selector with regime/relative-volatility context buckets. Each context gets its own chronological train/holdout evaluation and is promoted only when it independently passes the existing gates. Sparse contexts are not promoted; the globally validated expert remains the fallback.
- Added regression tests for candle-gap truncation, empty OHLC inputs, explicit uncalibrated-score metadata, and context-specific expert promotion.

## Preserved

- Fixed mathematical formulas; no per-formula online coefficient learning was introduced.
- Master/Challenger architecture and fixed C1/C2/C3 lenses.
- Original LONG/SHORT/WAIT forecast lifecycle and TP/SL progression.
- Hourly scan cadence, app UI, and Android-only build workflow.

## Important limits

- The mathematical stack currently computes its full set of formulas on the 5-minute Stage-25 candle series. Multi-timeframe mathematical expert selection is not claimed or activated: it requires separately computed formula snapshots and matched outcome ledgers for each timeframe.
- The supplied backup contains model/experience archives and calibration observations but not a complete historical OHLCV candle archive. Therefore a full historical re-run/backtest of every formula cannot be honestly claimed from this backup. Synthetic invariant tests and existing archive-based validation are reported separately.
- Context selectors require at least 50 training and 30 later validation observations in each context, plus the existing lift/coverage/paired-outcome gates. Until then, the global selector or no expert is used.
