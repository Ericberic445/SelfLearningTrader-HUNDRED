# SelfLearningTrader FIVE 1.0.270 — mathematical model repair

## Scope
- Source-only repair. UI and application version remain unchanged (1.0.270).
- No APK build.
- Original runtime experience archive is not rewritten or purged by this change.

## Changes
1. Legacy `WAIT_CONTROL_OBSERVATION` rows are excluded from the directional training selector, chronological validation population, and bootstrap merge. Their raw records remain in `global_experience.npz` for audit/history. Canonical `WAIT_CONTROL` records remain eligible.
2. Automatic inverse-square-root class amplification was removed from the shared classifier default. Current temporal holdout experiments showed it reduced direction accuracy and did not improve balanced accuracy over unweighted training. Per-row sample weights remain in force.
3. Outcome-head inference now requires an independently accepted promotion. A stale model file or rejected legacy candidate cannot activate the outcome head. A previously accepted incumbent remains available if a later challenger is rejected; its accepted evidence is stored separately.
4. New market-regime candidates must reach at least 15% recall on both TREND_DOWN and TREND_UP, while retaining the existing accuracy-lift and balanced-accuracy gates. The existing previously accepted regime model is not overwritten by a rejected candidate.
5. Existing probability-head admission gates remain enforced. No unvalidated probability head is enabled by this repair.
6. Existing TP/SL lifecycle resolution and Master Decision validation gate are preserved; neither is weakened to make metrics appear better.

## Verification
- Full test suite: 281 passed, 24 subtests passed.
- Added regression coverage for repeated WAIT snapshot exclusion from validation, unweighted class defaults, and outcome-head promotion status.
- Existing WAIT horizon remains 48 five-minute bars (4 hours), with a 0.5% movement threshold. LONG/SHORT label thresholds remain unchanged.

## Current-data limitations (not hidden)
- After excluding legacy repeated WAIT snapshots, the current canonical directional archive contains 2,543 rows; the chronological test segment has only 17 WAIT examples. WAIT precision/recall estimates therefore remain statistically unstable.
- The directional canonical holdout remains below the majority-class accuracy baseline; balanced accuracy is better than the majority baseline, but the model is not yet sufficiently reliable for real trading.
- The trade-outcome archive has 1,027 rows and sparse TP2/TP3+ support. The latest outcome model must remain disabled unless a future temporal candidate passes the promotion gate.
- The probability heads have not yet met their independent calibration/admission criteria.
- The Master Decision selector remains in validation accumulation until it has enough independent held-out evidence.
- A regime candidate that misses trend-recall gates is rejected; the last accepted model is retained when available.

## Operational caution
This is a logic/data-quality repair, not proof of profitability or readiness for live trading. Keep paper trading until fresh independent validation demonstrates adequate per-class precision/recall and TP/SL outcome performance.
