import numpy as np
from core.engine import LearningEngine


def test_load_exp_migrates_legacy_wait_snapshots_once(tmp_path):
    engine = LearningEngine.__new__(LearningEngine)
    engine.experience = tmp_path / 'global_experience.npz'
    engine.data = tmp_path
    n=4
    np.savez(engine.experience,
        time=np.asarray([100,101,102,103]),
        resolved_time=np.asarray([110,111,112,113]),
        prediction_id=np.asarray(['trade-a','wait-snap-1','wait-main','trade-b']),
        contract=np.asarray(['AAA','AAA','AAA','BBB']),
        target=np.asarray([2,1,0,0]),
        experience_kind=np.asarray(['TRADE','WAIT_CONTROL_OBSERVATION','WAIT_CONTROL','TRADE']),
        sample_weight=np.asarray([1.0,.04,.8,1.0]),
        feature_x=np.asarray([1.,2.,3.,4.]))
    loaded=engine._load_exp()
    assert loaded['prediction_id'].tolist()==['trade-a','wait-main','trade-b']
    assert loaded['experience_kind'].tolist()==['TRADE','WAIT_CONTROL','TRADE']
    assert loaded['feature_x'].tolist()==[1.,3.,4.]
    import json
    migration=json.loads((tmp_path/'wait_repeat_migration_v1.json').read_text())
    assert migration['removed_legacy_repeat_rows']==1
    assert len(engine._load_exp()['time'])==3
