import numpy as np

from app.core.features import FEATURES
from app.core.model import ModelManager


class _FixedClassifier:
    def __init__(self, probs):
        self.probs = np.asarray(probs, dtype=float)

    def predict_proba(self, X):
        return self.probs.reshape(1, -1)


class _Selector:
    def predict_proba(self, X):
        # Deliberately select MASTER+C1, whose opinion will oppose Master.
        return np.asarray([[0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]])


def _manager(tmp_path, master_probs):
    mm = ModelManager(tmp_path, config={
        'min_direction_confidence': 0.34,
        'min_direction_edge': 0.025,
    })
    base = _FixedClassifier(master_probs)
    selector = _Selector()
    mm._load_path = lambda path, kind='direction': base if kind == 'direction' else selector if kind == 'selector' else None
    mm._learning_state = lambda: {'resolved_total': 1000, 'lens_activation_resolved': 25, 'base_version': 1}
    mm._selector_ready = lambda: True
    mm._outcome_ready = lambda: False
    mm._performance_features = lambda: [0.0] * 36
    mm._fixed_lens = lambda master, row, snapshot: {
        'c1': {'probs': np.asarray([0.90, 0.05, 0.05])},
        'c2': {'probs': np.asarray([0.05, 0.90, 0.05])},
        'c3': {'probs': np.asarray([0.05, 0.05, 0.90])},
        'shared_base_version': 1,
        'specialization_scores': {'c1': 1.0, 'c2': 1.0, 'c3': 1.0},
        'reliability': {'c1': 1.0, 'c2': 1.0, 'c3': 1.0},
    }
    mm.market_regime = lambda row: {
        'label': 'TREND_UP', 'source': 'trained_regime_model',
        'confidence': 0.80,
        'probabilities': {'TREND_DOWN': 0.05, 'RANGE': 0.05, 'TRANSITION': 0.10, 'TREND_UP': 0.80},
        'trend_quality': 'MODERATE_UP', 'trend_strength_long': 0.70,
        'trend_strength_short': 0.0,
    }
    row = {name: np.asarray([0.0], dtype=float) for name in FEATURES}
    row.update({'close': np.asarray([100.0]), 'atrpct': np.asarray([0.01])})
    return mm, row


def test_fixed_lens_selector_cannot_override_independent_master_decision(tmp_path):
    mm, row = _manager(tmp_path, [0.10, 0.20, 0.70])
    prediction, probs, extra = mm.predict_bundle(row)
    assert prediction == 'LONG'
    assert extra['decision_source'] == 'master_core'
    assert extra['selected_combination'] == 'MASTER'
    assert int(np.argmax(extra['selector_probs'])) == 1  # selector preferred C1, but cannot veto Master
    np.testing.assert_allclose(extra['master_probs'], [0.10, 0.20, 0.70])
    assert probs[2] > probs[0]


def test_validated_formula_advice_can_nudge_master_without_creating_wait_vote(tmp_path):
    mm, row = _manager(tmp_path, [0.32, 0.30, 0.38])
    base_prediction, _, base_extra = mm.predict_bundle(row)
    advised_prediction, advised_probs, extra = mm.predict_bundle(
        row, math_consensus=-1.0, math_advice_strength=0.25)
    assert base_prediction == 'LONG'
    assert advised_prediction == 'SHORT'
    assert extra['decision_source'] == 'master_core_with_individual_formula_advisers'
    assert extra['math_advice_delta'] == -0.25
    # Formula disagreement is not converted into a WAIT probability boost.
    assert extra['regime_wait_boost'] == base_extra['regime_wait_boost']
    assert advised_probs[0] > advised_probs[1]



def test_individual_formula_advisers_are_applied_and_audited_separately(tmp_path):
    mm, row = _manager(tmp_path, [0.32, 0.30, 0.38])
    baseline_prediction, baseline_probs, _ = mm.predict_bundle(row)
    advisors = [
        {'name': 'C1|MARKOV|5m', 'score': 0.8, 'prediction': 'LONG',
         'validation_lift': 0.10, 'validation_n': 30, 'advice_strength': 0.12},
        {'name': 'C2|AR|1h', 'score': -0.7, 'prediction': 'SHORT',
         'validation_lift': 0.08, 'validation_n': 30, 'advice_strength': 0.10},
    ]
    advised_prediction, advised_probs, extra = mm.predict_bundle(
        row, math_advisors=advisors)
    assert baseline_prediction == 'LONG'
    assert extra['decision_source'] == 'master_core_with_individual_formula_advisers'
    assert extra['math_advisors_applied_count'] == 2
    assert [x['name'] for x in extra['math_advisors_applied']] == [
        'C1|MARKOV|5m', 'C2|AR|1h']
    assert extra['math_advisors_applied'][0]['applied_delta'] > 0
    assert extra['math_advisors_applied'][1]['applied_delta'] < 0
    assert extra['math_advice_delta'] != 0.0
    assert abs(extra['math_advice_delta']) <= 0.25
    assert np.isfinite(list(advised_probs.values())).all()



def test_explicit_empty_individual_adviser_list_blocks_legacy_consensus(tmp_path):
    mm, row = _manager(tmp_path, [0.32, 0.30, 0.38])
    base_prediction, base_probs, _ = mm.predict_bundle(row)
    explicit_empty_prediction, explicit_empty_probs, extra = mm.predict_bundle(
        row, math_consensus=-1.0, math_advice_strength=0.25, math_advisors=[])
    assert explicit_empty_prediction == base_prediction
    np.testing.assert_allclose(list(explicit_empty_probs.values()), list(base_probs.values()))
    assert extra['math_advice_delta'] == 0.0
    assert extra['math_advisors_applied_count'] == 0
