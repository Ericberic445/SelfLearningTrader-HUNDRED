import json
from core.config import load


def test_271_migrates_only_legacy_default_wait_threshold(tmp_path):
    legacy=tmp_path/'legacy.json'
    legacy.write_text(json.dumps({'wait_direction_threshold':0.005}),encoding='utf-8')
    cfg=load(legacy)
    assert cfg['wait_direction_threshold']==0.0045
    assert json.loads(legacy.read_text())['wait_direction_threshold']==0.0045

    custom=tmp_path/'custom.json'
    custom.write_text(json.dumps({'wait_direction_threshold':0.006}),encoding='utf-8')
    assert load(custom)['wait_direction_threshold']==0.006


def test_272_migrates_only_previous_builtin_direction_wait_gates(tmp_path):
    old=tmp_path/'old_defaults.json'
    old.write_text(json.dumps({'min_direction_confidence':0.55,'min_direction_edge':0.06}),encoding='utf-8')
    cfg=load(old)
    assert cfg['min_direction_confidence']==0.34
    assert cfg['min_direction_edge']==0.025

    custom=tmp_path/'custom_direction.json'
    custom.write_text(json.dumps({'min_direction_confidence':0.47,'min_direction_edge':0.04}),encoding='utf-8')
    cfg=load(custom)
    assert cfg['min_direction_confidence']==0.47
    assert cfg['min_direction_edge']==0.04
