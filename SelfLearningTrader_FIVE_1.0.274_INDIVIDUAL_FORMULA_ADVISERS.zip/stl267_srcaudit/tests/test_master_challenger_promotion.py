from pathlib import Path

from app.core.engine import LearningEngine


class _Exchange:
    futures_symbol = 'BTC-USDTM'


def _paired_rows(master_outcome, challenger_outcome, n=25):
    return [{
        'id': f'p{i}', 'challenger_generation': 4,
        'challenger_control_active': True, 'challenger_prediction': 'LONG',
        'trade_outcome': master_outcome,
        'challenger_outcome': {'trade_outcome': challenger_outcome},
    } for i in range(n)]


def test_candidate_challenger_wins_and_is_marked_for_master_promotion():
    engine = LearningEngine.__new__(LearningEngine)
    engine.cfg = {'retrain_batch_size': 25}
    engine._append_learning_audit = lambda event: None
    state = {'challenger_generation': 4, 'challenger_start_resolved': 100,
             'challenger_control_target': 125}
    result = engine._evaluate_challenger_control(
        _paired_rows('TP1', 'INITIAL_SL'), state)
    assert result['result'] == 'CHALLENGER_IMPROVED'
    assert result['winner'] == 'CHALLENGER_CANDIDATE'
    assert len(result['paired_prediction_ids']) == 25
    assert state['challenger_active'] is False


def test_new_master_candidate_wins_and_is_kept():
    engine = LearningEngine.__new__(LearningEngine)
    engine.cfg = {'retrain_batch_size': 25}
    engine._append_learning_audit = lambda event: None
    state = {'challenger_generation': 4, 'challenger_start_resolved': 100,
             'challenger_control_target': 125}
    result = engine._evaluate_challenger_control(
        _paired_rows('INITIAL_SL', 'TP2'), state)
    assert result['result'] == 'MASTER_IMPROVED'
    assert result['winner'] == 'INCUMBENT_MASTER'


def test_frozen_winner_snapshot_is_restored_to_master_atomically(tmp_path):
    engine = LearningEngine.__new__(LearningEngine)
    engine.root = tmp_path
    engine.data = tmp_path / 'data'
    engine.data.mkdir()
    engine.challenger_root = engine.data / 'challenger_snapshot'
    engine.exchange = _Exchange()
    engine.cfg = {}
    source = engine.challenger_root / 'models_v8_self_learning' / 'GLOBAL'
    target = engine.root / 'models_v8_self_learning' / 'GLOBAL'
    source.mkdir(parents=True)
    target.mkdir(parents=True)
    (source / 'champion.npz').write_bytes(b'incumbent-winner')
    (source / 'champion.json').write_text('{"winner":"incumbent"}')
    (source / 'market_regime.npz').write_bytes(b'incumbent-regime')
    (target / 'champion.npz').write_bytes(b'losing-candidate')
    restored = engine._restore_challenger_snapshot()
    assert (target / 'champion.npz').read_bytes() == b'incumbent-winner'
    assert 'champion.npz' in restored
    assert (target / 'market_regime.npz').read_bytes() == b'incumbent-regime'
    assert engine.mm.root == tmp_path


def test_expired_partial_tp_outcomes_are_comparable():
    engine = LearningEngine.__new__(LearningEngine)
    engine.cfg = {'retrain_batch_size': 25}
    engine._append_learning_audit = lambda event: None
    state = {'challenger_generation': 4, 'challenger_start_resolved': 100,
             'challenger_control_target': 125}
    rows = _paired_rows('EXPIRED_AFTER_TP2', 'EXPIRED_AFTER_TP1')
    result = engine._evaluate_challenger_control(rows, state)
    assert result['result'] == 'CHALLENGER_IMPROVED'
