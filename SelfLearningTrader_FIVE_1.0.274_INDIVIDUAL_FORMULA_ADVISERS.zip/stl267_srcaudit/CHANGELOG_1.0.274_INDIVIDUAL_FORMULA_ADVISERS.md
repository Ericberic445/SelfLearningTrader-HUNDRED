# SelfLearningTrader FIVE 1.0.274 — Individual formula evaluation

## Change

- Replaced live aggregate/weighted formula consensus with a per-formula adviser contract.
- Every formula that independently passes chronological out-of-sample validation is evaluated using its own current directional score, validation lift, sample count, paired wins/losses and timeframe identity.
- Mature context-specific validation takes precedence over global validation; contextual rejection blocks global fallback for that context.
- Opposing validated formulas are retained and applied independently. Disagreement no longer clears the entire adviser set.
- Each formula receives its own bounded log-odds adjustment. Adjustments are applied in deterministic order (largest validation lift first), with a total influence cap of 0.25 log-odds.
- Detailed per-formula evaluation records (including applied vs. cap-limited status) are exposed in prediction diagnostics.
- The live engine passes individual advisers to the Master and does not construct or pass an aggregate math consensus.
- Legacy consensus parameters remain supported only for older replay/compatibility callers; the live FIVE Stage-25 path does not use them.
- If an older model adapter cannot accept the individual-adviser API, Stage 25 falls back to the Master-only path, never to an aggregate vote.

## Preserved

- The Master independently generates the baseline forecast and retains the final direction/WAIT gate.
- C1/C2/C3 formula definitions and formula/timeframe shadow tracking are unchanged.
- Formula promotion thresholds remain unchanged in this release.
- Existing Master training, archives, TP1/TP2/TP3/SL result semantics, UI and background scanning are not intentionally redesigned.

## Validation

- Regression tests cover individual opposing advisers, independent application records, bounded total influence, and Stage-25 transfer of each adviser separately.
