# SelfLearningTrader FIVE 1.0.272 — WAIT / Math Ensemble Fix

## Corrected issues

1. **Over-abstention caused by low-confidence regime output.** The previous logic applied the full RANGE/TRANSITION and RANGE_OR_CHOP WAIT boosts even when the four-class regime model was close to chance confidence (~25%). The boost is now scaled by confidence above the 25% chance baseline. A low-confidence regime label can no longer veto the trained direction model by itself.
2. **Direction gate calibrated for a three-class model.** The previous default gate (0.55 directional probability and 0.06 edge over WAIT) was too high for the saved model's three-class probabilities. The built-in defaults are now 0.34 and 0.025. Only exact old defaults are migrated; user-customized values are preserved. The conservative gate remains for unvalidated regime models and for confidently classified RANGE/TRANSITION regimes.
3. **All MTF formula candidates are preserved.** `prediction_diagnostics()` produced a legacy single-timeframe map and overwrote the Stage-25 lens × formula × timeframe map. The Stage-25 map is now restored after diagnostics. Candidate count and saved predictions therefore stay aligned (up to 90 when all 18 components and all five timeframes are valid).
4. **WAIT forecasts now teach the formula selector.** WAIT remains excluded from the live trade ledger. Its completed 4-hour learning window now resolves each formula's independent shadow plan and records formula/ensemble observations in the Master-owned performance ledger. The actual WAIT outcome (missed LONG, missed SHORT, or correct WAIT) is used as the direction label. A no-touch plan is marked as an observed window with outcome score -1; it is not counted as TP or SL.
5. **Candle continuity is still strict.** No missing candles are fabricated or bridged. Math snapshots now record input rows, invalid OHLC rows, timestamp gaps, contiguous suffix length, and an explicit status/reason. Unusable timeframes are excluded from the expert map instead of being represented as valid zero-score experts.

## Evidence from the supplied 2026-11-21 backup

- Cycles 1090–1099 contained 50 TOP-5 forecasts; all 50 saved final decisions were WAIT.
- Replaying those same 50 saved feature rows through the saved model with the corrected gate produced 45 SHORT and 5 WAIT decisions. This is a deterministic code/model replay, **not** a profitability or out-of-sample accuracy claim.
- The saved WAIT learning totals were 716 observations: 8 correct WAIT, 159 missed LONG, 549 missed SHORT, and 8 false spikes.
- The saved predictions reported five available timeframes and 90 mathematical candidates, but only 15 legacy expert entries survived the diagnostics merge. This overwrite is corrected.
- The backup did not show evidence that all five candle timeframes were unavailable; the continuity rule was therefore kept strict and instrumented rather than loosened.

## Verification

- Python compilation: passed.
- Automated tests: **307 passed**.
- Additional subtests: **24 passed**.
- APK build: not performed.
