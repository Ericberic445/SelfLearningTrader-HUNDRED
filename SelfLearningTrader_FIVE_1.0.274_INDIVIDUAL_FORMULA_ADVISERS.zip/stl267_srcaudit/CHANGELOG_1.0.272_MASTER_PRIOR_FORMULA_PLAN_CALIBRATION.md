# 1.0.272 — Master-prior formula plan calibration

## Problem corrected

Formula/timeframe shadow experts previously received Entry/SL/TP levels from a generic fixed ATR template. Those levels were not derived from the Master plan or from that expert's resolved history.

## New behavior

- Each formula/timeframe expert receives the exact pre-ensemble Master Entry/SL/TP geometry as its cold-start prior.
- The Master geometry is scaled by the expert's own timeframe ATR, preserving the relative distances of the Master plan.
- Every resolved formula shadow plan records favorable/adverse excursion in its own ATR units, along with percentage excursions and observed-bar count.
- The existing Master-owned `math_expert_rows` archive stores those measurements per formula/timeframe together with the actual TP/SL outcome.
- After at least 30 prior resolved outcomes and at least 15 TP1-or-better outcomes, the expert can obtain an empirical plan profile. The profile uses its own historical favorable/adverse excursion distributions and is context-specific when that context has sufficient data.
- The learned profile is shrunk toward the Master prior, with a maximum 80% expert-history weight. This avoids replacing the prior on a small sample.
- Multi-formula ensemble plans are now composed from the selected experts' actual plans in price-distance space, so different timeframe ATRs are retained instead of being collapsed into a generic median ATR.
- The exact original Master baseline plan is preserved for paired comparison.

## Compatibility

- No mathematical formula implementation was changed.
- C1/C2/C3 definitions and their existing behavior were not replaced.
- Master/Challenger, scanner, TOP-5 selection, and UI were not changed.
- Existing historical formula rows without excursion measurements are not fabricated or backfilled; formula-specific calibration begins as new shadow plans resolve.

## Verification

- Python compilation: passed.
- Full test suite: 299 passed, 24 subtests passed.
- APK build: not run.
