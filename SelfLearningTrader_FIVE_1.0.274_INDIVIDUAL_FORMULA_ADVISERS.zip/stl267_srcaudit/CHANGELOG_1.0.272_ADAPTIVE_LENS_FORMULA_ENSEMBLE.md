# SelfLearningTrader FIVE 1.0.272 — Adaptive Lens Formula Ensemble

## Implemented from the original 1.0.272 MATH_STRICT_CONTEXT_AUDIT archive

- Preserved the original scanner, Master model, Challenger, C1/C2/C3 fixed-lens logic, UI, and Master Entry/SL/TP calculation path.
- Exposed every directional/risk formula primitive already present in C1/C2/C3 as a separate expert for each available timeframe: 5m, 15m, 1h, 4h, and 1d.
- The current candidate subset is selected without a fixed formula-count limit. The selector can choose one formula, several formulas, all eligible formulas, or none.
- Formula-level shadow plans use the ATR of their own timeframe. A candidate-combination shadow plan uses the mean formula score and median ATR across its selected timeframes.
- Candidate subsets are shadow-tested before promotion. Only an exact candidate subset with sufficient later resolved combo-plan outcomes and out-of-sample lift over the original Master plan can become an active Master input.
- Active validated formulas influence the trained Master through its existing prediction bundle; they do not replace the Master model. The Master retains its established initial Entry/SL/TP level-generation path.
- Formula and selected-combination plans are resolved using the existing chronological TP1/TP2/TP3/SL resolver, including the post-SL audit and expiry paths.
- Formula outcome records include lens, formula, timeframe, individual outcome score, and candidate-combination outcome. All resolved directional Master forecasts are eligible for this separate formula-learning ledger; the original Master confidence is retained as metadata, not used to discard formula results.

## Validation

- Added regression tests for all lens formulas across all five timeframes.
- Added tests for unbounded subset cardinality, independent plan outcome requirements, shadow-candidate isolation, candidate plan construction, and formula/combination outcome resolution.
- Full test suite: 295 passed, 24 subtests passed.
