# Mathematical audit and fixes — SelfLearningTrader FIVE 1.0.272

## Scope and evidence

Reviewed the actual Python implementations in `app/core/math_models.py`, their use in `app/core/engine.py`, the individual expert selector in `app/core/model.py`, the calibration/first-passage paths, and the existing test suite. The archive backup contains prediction/experience and calibration data but not a complete historical OHLCV candle archive. Consequently, this audit separates (a) implementation/invariant checks, (b) synthetic-data checks, and (c) historical outcome evidence. It does not claim a full historical backtest for every formula.

## Implemented corrections in 1.0.272

1. **Timestamp continuity and OHLC integrity**
   - Empty OHLC arrays no longer trigger `[-0:]` slicing misalignment.
   - Supplied timestamps must align with OHLC arrays. Misaligned timestamps cause a neutral/insufficient-data snapshot rather than positional pairing.
   - Duplicate, out-of-order, or missing candle intervals truncate the input to the latest contiguous suffix; a return is not fabricated across a data gap.
   - Regression tests compare a gapped input with its exact contiguous suffix and test empty OHLC input.

2. **No nested composite double-count in the internal consensus**
   - The internal aggregate previously added `math_direction` (itself a weighted combination) alongside several of its component methods.
   - It now combines the primitive components once, with weights normalized by their sum.
   - The separate `math_direction` remains available as its own directional composite and expert baseline. The Stage-25 live LONG/SHORT consensus is separately built from individual expert scores; it was not the same nested aggregate.

3. **Score is not presented as a calibrated probability**
   - Added `math_direction_score` in the range [-1, 1].
   - Retained the legacy `math_direction_probability` numeric field only for compatibility and explicitly set `math_direction_probability_calibrated=false`. It must not be interpreted as an empirical probability.

4. **Stronger probability calibration admission**
   - Calibration maps continue to be fit only on the purged chronological training partition.
   - The untouched chronological holdout now must pass raw Brier Skill, calibrated Brier Skill, AUC, and calibrated LogLoss Skill.
   - Calibrated LogLoss must also be no worse than raw LogLoss. Metrics and thresholds are written to the validation report.
   - Formula version is now 9, invalidating formula-version-8 calibration maps after the consensus change.

5. **Context-aware math expert selection**
   - Existing global Math Expert Selector remains intact.
   - Resolved expert rows now store a context key: validated market-regime label plus relative GARCH-volatility bucket (LOW/MID/HIGH).
   - Each context is independently evaluated on its own chronological training and later holdout windows using the existing coverage, lift, and paired-outcome gates.
   - A contextual expert is used only if that context passes. Otherwise the validated global expert is the fallback; if no global expert passes, no expert is activated.
   - Sparse contexts are not promoted. No per-formula coefficient learning was introduced.

## Formula inventory and implementation status

The mathematical layer exposes 23 features:

| Formula / method | Implementation | Mathematical interpretation / caveat |
|---|---|---|
| Markov | Three-state empirical transition score | Directional transition score, not a probability of price target |
| Move probability | Monte Carlo absolute-move frequency | Probability estimate for a volatility-scaled move, subject to simulation assumptions |
| AR | Least-squares AR(p) | One-step normalized forecast score |
| ARIMA(1,1,1) | Conditional-sum-of-squares ARMA on log returns | Bounded grid/coordinate fit; score, not probability |
| Seasonal AR | Multiplicative seasonal AR(1)xSAR(1) | Seasonal score; requires sufficient seasonal cycles |
| GARCH(1,1) | Constrained variance-targeted grid fit | Relative conditional-volatility feature; not directional |
| Hurst | Log-log variogram slope | Approximate scaling exponent; finite-sample and nonstationarity sensitive |
| Mean reversion | Detrended OU-like AR estimate | Reversion score; regime-sensitive and not a calibrated chance |
| Cointegration | Engle-Granger residual regression + ADF-style gate | Approximate critical-value gate, not exact finite-sample p-value |
| Correlation | Pearson correlation of aligned returns | Dependence descriptor, not direction by itself |
| Return/volatility correlation | Pearson corr(r, abs(r)) | Descriptive asymmetry/volatility relationship |
| Trend deviation | Linear-trend residual z-score | Contrarian deviation score |
| Entropy | Histogram Shannon entropy | Distributional complexity feature; bin-sensitive |
| Fractal dimension | D = 2 - H | Derived from the Hurst estimate; inherits its uncertainty |
| Wavelet | Multilevel Haar DWT | Signed multiscale detail score |
| Kalman | Two-state local-linear-trend filter | One-step predicted level deviation score; Q/R are heuristic scale rules |
| Monte Carlo | AR(1)-GARCH paths with empirical innovations | Simulation probability; depends on stationarity and historical innovation representativeness |
| Bayesian | Beta-Bernoulli on disjoint horizon blocks | Probability of positive cumulative return under block-independence approximation |
| Change point | Recent split mean-difference scan | Heuristic change score, not a formal posterior probability |
| TP1 / TP2 / TP3 | First-passage simulation with moving stops | Path probabilities; require independent calibration before being trusted as empirical probabilities |
| SL | Initial stop before TP1 in the same path simulation | Event probability; not necessarily complementary to TP1 because paths may touch neither barrier |

## Synthetic-data checks

Deterministic synthetic cases were run for flat returns, positive drift, negative drift, white noise, mean-reverting returns, seasonal returns, and volatility-clustered returns. Observed checks:

- Flat series: directional scores neutral; GARCH risk zero; Bayesian/Monte Carlo direction neutral.
- Positive and negative drift: AR/ARIMA/SARIMA and directional composite changed sign consistently with the generated drift.
- GARCH fit on volatility-clustered data returned nonnegative omega/alpha/beta with alpha+beta below 1.
- TP probabilities remained ordered TP1 >= TP2 >= TP3 and SL-first remained bounded [0,1].
- Same-candle TP/active-stop simulation remains fractional expected credit because path order is unknown from OHLC; realized outcome labels keep unresolved ordering out of training.
- Timestamp gaps were verified not to create artificial returns across the gap.

These are implementation sanity checks, not evidence that the models predict real markets profitably.

## Existing archive evidence

The version-1.0.271 audit contained 432 probability observations across 203 independent cycles. No probability head passed the existing Brier Skill/AUC admission gate. Bayesian and SL showed some ranking signal but did not meet all admission criteria. Formula version 9 invalidates older calibration maps so that the changed consensus cannot silently reuse version-8 calibration.

## Not claimed / remaining data requirement

- The math Stage-25 currently computes the full formula stack from its 5-minute base candle series. Although the direction model has higher-timeframe features, separate full mathematical snapshots and matched outcome ledgers do not yet exist for 15m/1h/4h/1d. Therefore timeframe-specific formula selection is not claimed.
- Full historical backtesting of all 23 formulas requires a timestamped OHLCV archive at the relevant timeframes, with enough history to replay each forecast exactly as it was known at issuance. The supplied backup does not contain that full candle archive.
- A mathematically correct estimator can still be a poor predictor. No formula is declared profitable or accurate solely because it passes synthetic tests.

## Verification

- `python -m compileall -q app tests` — passed.
- `PYTHONPATH=. pytest -q` — **288 passed, 24 subtests passed**.
- ZIP integrity test (`ZipFile.testzip()`) — to be run on the final release archive.
