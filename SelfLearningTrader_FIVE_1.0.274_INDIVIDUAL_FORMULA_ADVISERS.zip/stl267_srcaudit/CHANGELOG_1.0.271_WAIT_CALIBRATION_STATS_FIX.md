# SelfLearningTrader FIVE 1.0.271

- Migrates legacy `WAIT_CONTROL_OBSERVATION` snapshot rows out of the global experience archive; canonical `WAIT_CONTROL` rows remain.
- Keeps WAIT learning at one resolved observation per original forecast and reduces the default neutral corridor from 0.50% to 0.45% (48 closed 5-minute bars remain unchanged).
- Probability calibration maps are now fitted only on the chronological training partition after horizon-overlap purging; held-out cycles are never used to fit deployment maps.
- Adds raw, baseline and calibrated LogLoss to independent probability-head validation alongside Brier Score and AUC. Unvalidated heads remain disabled.
- Hardens `LearningEngine._read_json` for both `Path` and string paths and preserves explicit defaults for dict-backed reports.
- Independent validation report records archive row count, mtime, size and latest data timestamp so its source freshness can be audited.
- No UI, scan cadence, TP/SL lifecycle, or APK changes.
