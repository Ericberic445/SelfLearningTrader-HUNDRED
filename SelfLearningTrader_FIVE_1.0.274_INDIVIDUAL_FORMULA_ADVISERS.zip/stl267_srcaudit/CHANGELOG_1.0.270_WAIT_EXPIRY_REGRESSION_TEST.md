# SelfLearningTrader FIVE 1.0.270 — WAIT expiry regression coverage

- Kept the 1.0.269 hourly WAIT resolver integration and lifecycle behavior unchanged.
- Added a regression test with 500 legacy WAIT records older than 8 hours and without feature payloads.
- Verified all 500 are marked `resolved=1`, `wait_learning_resolved=true`, `EXPIRED_STALE_UNVERIFIABLE`, `EXPIRED_UNVERIFIABLE`, and excluded from statistics and training.
- Verified WAIT entries are removed from the active pending queue while an unresolved SHORT remains untouched.
- Verified stale expiry does not require a candle API request and does not create learning rows.
- Full suite: 273 passed, 24 subtests passed.
