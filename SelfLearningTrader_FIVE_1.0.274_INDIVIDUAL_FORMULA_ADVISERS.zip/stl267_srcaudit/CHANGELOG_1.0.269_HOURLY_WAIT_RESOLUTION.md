# SelfLearningTrader FIVE 1.0.269 — hourly WAIT lifecycle resolution

- Wired `resolve_wait_learning()` into each completed hourly full-scan cycle, directly after the existing LONG/SHORT pending resolver.
- Kept WAIT separate from the active trade queue; WAIT records are resolved from their 48-bar (4-hour) learning horizon.
- Limited WAIT candle history requests to the last 96 closed 5-minute bars (or twice the configured horizon, if larger), reusing the process-wide candle cache populated by the market pre-scan.
- Skip contracts with no unfinished WAIT observations before making candle requests.
- Existing 96-bar (8-hour) stale administrative expiry remains excluded from accuracy statistics and model training.
- Added tests proving a WAIT resolves after its full horizon, completed WAIT contracts cause no candle request, and the hourly scanner calls the resolver.
- UI, scan cadence, and LONG/SHORT TP/SL lifecycle rules unchanged.
- Verification: 272 passed, 24 subtests passed. APK build and live Android/KuCoin execution are not claimed.
