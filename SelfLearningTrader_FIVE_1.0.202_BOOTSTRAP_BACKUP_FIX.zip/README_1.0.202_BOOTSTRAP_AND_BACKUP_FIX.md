# SelfLearningTrader 1.0.202

## Fixes
- Fixed cold-start bootstrap: the first Master model can be created from historical candle data without consuming resolved forecasts or activating C1/C2/C3.
- The first 25 completed forecasts remain the learning bootstrap block.
- Serialized one-time experience migration so concurrent scanner workers cannot race on `experience_schema_v2.tmp`.
- Backup/restore verification no longer requires Champion files to exist; the manifest reports whether Champion is present.
- No UI redesign and no change to the agreed Master/C1/C2/C3 learning architecture.
