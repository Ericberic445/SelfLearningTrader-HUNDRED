# SelfLearningTrader FIVE 1.0.266

## Version 1.0.266 — managed-stop math, purged validation, joint OHLC Monte Carlo and recalibration

- TP1/TP2/TP3 path probabilities now follow the live protective-stop progression: initial SL, breakeven after TP1, TP1 after TP2. Reached targets remain successful after a later protective stop. Same-candle ambiguous stop/target touches remain fractional/unresolved.
- Calibration labels use the same managed-stop lifecycle.
- Chronological calibration validation purges training cycles whose forecast label horizon overlaps validation. Calibration requires at least 80 independent scan cycles (plus 100 matured samples) so the 75/25 holdout can retain at least 20 validation cycles.
- Monte Carlo samples historical upper/lower wick pairs conditionally on simulated return bins, preserving empirical OHLC dependence.
- SARIMA now uses up to 720 returns, requires at least six seasonal cycles and shrinks noisy seasonal estimates instead of requiring only a short history.
- Invalid OHLC rows are not forward/back-filled; math uses only the contiguous valid suffix.
- Math formula version is 8; old v7 probability calibration is invalidated and v8 calibration must accumulate fresh out-of-sample observations. Verification: 265 passed, 24 subtests passed. APK build and live KuCoin execution are not claimed.

## Version 1.0.265 — POST-SL recovery repair

- POST-SL recovery now scans both per-contract `*_predictions.json` archives and `*_pending.json` queues, deduplicating by contract + prediction ID.
- A legacy v1 completion marker no longer hides eligible records that remain in prediction archives. A v2 marker is written only when every eligible record is recovered or conclusively unrecoverable; transient/incomplete history stays retryable.
- Recovered records update every existing copy in both stores. Conclusively unrecoverable records are removed only from matching contract + ID rows; incomplete/malformed history and API failures are retained.
- Historical candle continuity and OHLC validity are checked before a missing SL timestamp can be classified as unrecoverable.
- The startup repair runs before the normal market scan to avoid concurrent writes to the same JSON archives. Scanning still starts after a recovery error, with retryable records retained.
- Added regression tests for prediction-only archives, stale legacy markers, synchronized stores, conclusive deletion, and incomplete history.
- Verification for 1.0.265: 260 passed, 24 subtests passed. APK build and live KuCoin execution were not claimed.

## Version 1.0.264 — unified statistics and outcome denominators

- All statistics views now use one deduplicated forecast population and select the latest persisted state for each prediction ID.
- Completed TP/SL outcomes, unresolved forecasts, post-SL rechecks, and resolved records without a final TP/SL outcome are shown as separate, non-overlapping categories.
- WAIT forecasts are included in the first-check waiting count and shown separately from LONG/SHORT forecasts; WAIT observations already completed for learning are shown in their own category.
- The dashboard now displays the total number of final TP/SL outcomes; the accuracy percentage remains calculated only from the original-confidence >=70% sample.
- The analysis and model-statistics screens expose the same denominators, including the 70%+ accuracy sample, below-70% training-only sample, and >=80% strict sample.
- No forecast direction, Entry/SL/TP, mathematical formula, training rule, or screen layout was changed. Only statistics aggregation and explanatory labels were updated.
- Verification: `PYTHONPATH=. pytest -q` — 256 passed, 24 subtests passed; Python compilation passed.

# SelfLearningTrader FIVE 1.0.257

Current release: **full-pool TP/SL verification plus a rolling, resumable direction-recheck queue**. This release is based on the clean 1.0.252 source lineage; rejected 1.0.253 queue changes are excluded.

## Version 1.0.257 — restore and bound active direction rechecks

- Restores the hourly scheduling call for active LONG/SHORT forecasts that remain unresolved after at least 60 minutes. WAIT controls and forecasts younger than one hour do not consume the direction-recheck queue.
- Rechecks are observations only: they never replace the original direction or alter original Entry/SL/TP, and they do not close the forecast lifecycle.
- The persistent queue is now a rolling queue: only the newest waiting hourly snapshot is retained while a batch is running. This prevents a permanent backlog of one full-market request per scan; the running batch still resumes from its per-contract checkpoint after service interruption.
- If a scan finds no new valid candidates, the recheck queue still runs. The full-market scan cadence remains hourly, and the existing TP/SL outcome resolver remains separate.
- No UI changes. Automated source tests and compilation are run for this source package; APK build and live tablet validation are not claimed.

## Version 1.0.256 — full-pool TP/SL and outcome-priority analysis

- Every hourly pass checks every active LONG/SHORT forecast in the pending pool; the former ten-old-forecast verification cap is removed. One recent candle fetch advances all active forecasts for a contract. Stale forecasts fetch their original bounded eight-hour candle window when it is outside the recent cache.
- TP/SL detection is restricted to the first 96 five-minute bars (8 hours). If neither TP nor SL is reached, the lifecycle closes as `EXPIRED_SIDEWAYS` / `SIDEWAYS`, excluded from win/loss statistics and training. Late TP/SL crossings after expiry cannot retroactively change the result.
- A first TP1/TP2/TP3/SL event queues the contract for priority analysis. Those contracts go first through the deep model stage and math-validation stage, and the result is stored as an observation only; the original direction, Entry, SL and TP levels remain unchanged. The priority queue persists across restarts and is consumed only after analysis completes.
- Direction rechecks are queued for active forecasts after one hour; this behavior is restored and made rolling in version 1.0.257. Full-market scan cadence is one hour, including migration of older persisted 30-minute settings.
- UI layout unchanged. Verification: `PYTHONPATH=. pytest -q` — 223 passed, 9 subtests passed; Python compilation passed. Android APK build and live KuCoin/tablet behavior remain unverified.

## Version 1.0.254 — active recheck speed fix

- Active forecast rechecks no longer rebuild/update the global market-regime training pool for every contract. Rechecks remain observation-only and use the already-available trained model; regular scans continue to maintain the regime pool.
- Regime-pool `new_rows_since_train` now counts only new `(contract, candle-time)` rows that remain inside the bounded retained pool. Old rows discarded by the retention cap no longer trigger needless retraining.
- An unchanged regime pool is not recompressed and rewritten for each contract. Initial training still runs when the existing pool has enough data and the existing training gate says it is due.
- Original Entry/SL/TP, direction immutability, forecast lifecycle rules, scan stages, and existing recheck queue behavior are preserved. No new counters or diagnostic instrumentation added.
- Based directly on the clean 1.0.252 source archive; the rejected 1.0.253 queue changes are not included.


- Math formula version advances to 4. Historical version-3 probability calibration is not reused because the saved samples do not preserve raw, pre-calibration probabilities.
- Saves raw probability heads at issuance separately from calibrated/display values, preventing recursive calibration of already-calibrated probabilities.
- Adds chronological, cycle-grouped holdout validation. Monte Carlo, Bayesian, TP1/TP2/TP3 and SL probability heads are prevented from influencing directional lenses until they beat the training-prevalence baseline in both raw and training-fitted calibrated Brier skill and meet the AUC threshold.
- Aligns Bayesian probability to the configured forecast horizon, uses log returns consistently, aligns benchmark calculations by candle timestamp, and neutralizes Monte Carlo ties instead of interpreting a flat market as bearish.
- Removes deterministic linear trend before estimating mean reversion, avoiding false countertrend signals on perfectly monotonic paths. Invalid prices are forward-filled instead of creating extreme artificial returns.
- Keeps the UI unchanged and preserves the scan funnel, original forecast lifecycle, Entry/SL/TP levels, and TP1/TP2/TP3/SL result definitions.
- Verification: `python -m pytest -q` — 214 passed, 9 subtests passed; `python -m compileall -q app tests` passed. APK build and live KuCoin validation are still required.

## Version 1.0.251 — multi-timeframe scan throughput and consistency

- Keeps the full configured 5-minute base history. Higher-timeframe candle requests now cover the same base interval plus a 200-bar warm-up instead of requesting the same 800/5,000 bars for every timeframe. This avoids downloading years of unused daily candles while preserving the historical feature timeline used by the model and regime learner.
- Active-forecast recheck workers reuse the already-migrated global ledgers instead of redundantly reconciling the complete prediction archive in every worker thread.
- Migrates the TOP-5 last-100 ledger to unique prediction IDs, removes legacy WAIT/under-70% rows from that performance sample, and retains the latest issuance timestamp when a stale forecast is republished. Full cycle history remains intact.
- Synchronizes root and Android config files and corrects release identity to 1.0.251 / 10251.
- Does not change UI, scan funnel (all active contracts → 50 → 25 → TOP-5), scoring, indicators, forecast lifecycle, Entry/SL/TP, TP/SL outcome definitions, or model promotion gates.
- Verification: see `AUDIT_1.0.251_SPEED_AND_INTEGRITY.md`; live KuCoin timing and Android APK build remain to be verified on device.

## Current learning architecture

- One learning **Master**. A frozen Challenger snapshot is used only as a control baseline; it never trains or replaces Master.
- First **25 completed forecasts**: Master only.
- After the first 25 and Master update: the common Master Base is exposed to **C1/C2/C3**.
- C1/C2/C3 are **fixed mathematical lenses**. They never train, never keep adaptive weights, and never replace Master.
- Normal Master updates are batched by **25 newly resolved, eligible forecast IDs**. The Challenger control cohort is generation-tagged and scored only on forecasts actually issued under that frozen snapshot. Auxiliary observation batches do not restart this control cycle.
- Master learns from verified outcomes and its selector learns from resolved forecast records; C1/C2/C3 remain fixed mathematical lenses and never train.

## Trade-outcome learning

Master records the complete path of each LONG/SHORT forecast:

- Initial SL before TP1 = real trading loss.
- TP1 = successful forecast.
- After TP1, protection moves to Entry; an exit at Entry remains a successful TP1 result.
- TP2 = successful TP2 result; after TP2 protection moves to TP1.
- An exit at TP1 after TP2 remains a successful TP2 result.
- TP3 = super-successful milestone.
- Price continuing above TP3 is stored as **TP3+**, including the extension beyond TP3.
- TP milestones are never downgraded to an SL because of a later protected exit.

## Post-SL analysis

An initial SL remains an actual losing trade and is never rewritten as a win. The next **3 five-minute candles** are nevertheless checked separately. If price subsequently reaches TP1/TP2/TP3 in the predicted direction, Master records that the **direction was confirmed after the stop** and distinguishes this from a genuinely wrong direction.

The engine also records event context around the stop, recovery and protected exits (volume, volume ratio, candle range/body/wicks and timing) so Master can learn why continuation failed or resumed.

## Global experience

Learning memory is symbol-safe and keyed by **contract + timestamp + prediction_id**. Completed experience from all contracts is used for automatic Master retraining. WAIT is history only and never enters the TP/SL verification queue.

The replay memory stores both:

- auxiliary direction target (SHORT / WAIT / LONG), and
- primary trade-outcome target (INITIAL_SL / TP1 / TP2 / TP3 / TP3_PLUS).

## Validation and audit

After each 25-result retraining batch, the project recomputes held-out validation where enough global data exists and writes detailed learning events to `data/learning_audit.jsonl`.

## Android build

- Package ID: `org.selflearningtrader.selflearningtrader`
- Version: `1.0.257` / Android version code `10257`
- Source: `app/`
- Android API 34, min API 24, arm64-v8a
- Foreground scanner service and existing Stop/Resume/background functionality retained.
- UI layout is not intentionally redesigned in this release.

See `README_1.0.186_WAIT_CONTROL_AND_LENS_OUTCOMES.md` for the release details and the older README/V13/V14/V15 files for historical changes.


## Version 1.0.216 — scan worker reuse and validation audit

- Reuses one KuCoin HTTP client and one engine instance per worker thread during pre-scan and deep model analysis. The Stage-25 and active-forecast recheck workers also reuse their thread-local exchange client. This reduces repeated TLS/client/engine initialization without sharing mutable engines across workers or changing ranking.
- Historical experience validation now uses a chronological timestamp split with an embargo measured in time, not only a fixed number of rows. It reports held-out performance against a majority-class baseline.
- Initial training metadata now records baseline balanced accuracy, directional precision, action rate, and model-minus-baseline deltas.
- Added regression coverage for second/millisecond/microsecond candle timestamps, timestamp-based validation embargo, readiness gates, and Stage-25 client reuse.
- **Not changed:** UI, TP/SL outcome tracking, point-7 same-candle logic, TOP-5 selection policy, background service/OFF-resume behavior, or saved archives.
- Verification: `python -m compileall -q app tests`; `PYTHONPATH=. pytest -q` — 56 passed, 9 subtests passed. Android/GitHub APK build and a live full-market timing benchmark have not been run here; runtime timings are already emitted by the app and should be confirmed from a real scan log.

## Version 1.0.214 — background recovery and scan-cycle fixes

- Bounds runtime log tails to 40 lines / 600 characters and serializes state writes, preventing recursive log-tail growth and heartbeat file contention.
- Heartbeat timeout diagnostics now record only compact state fields and are rate-limited.
- Unexpected service errors/stops and stale heartbeats trigger repeated recovery with bounded backoff until the user explicitly presses OFF.
- Stage-25 math validation runs with a bounded pool of three workers using the same indicators, timeframes, and ranking calculations; progress continues while math validation runs, and OFF cancellation is checked.
- UI layout is unchanged; learning and forecast archives are not modified by this source patch.


## Version 1.0.222 — learned market-regime classification

- Adds a separate four-state market-regime head: `TREND_UP`, `TREND_DOWN`, `RANGE`, and `TRANSITION`. Existing Master direction/outcome model feature shapes remain unchanged.
- Builds causal regime features (directional efficiency/persistence, reversal rate, range width/position, volatility ratio and higher-timeframe alignment) from closed candles. Future path is used only to label training examples, never as an input feature.
- Accumulates a deduplicated, bounded training pool across contracts and trains only after enough rows and distinct contracts are present. Validation is chronological with a horizon-sized purge; per-class metrics and majority baseline are saved.
- When a trained regime head is available, RANGE/TRANSITION increases abstention pressure and raises the LONG/SHORT confidence threshold. Until then, a transparent conservative fallback is used; insufficient features do not invent a learned classification.
- Prediction diagnostics now include regime, class probabilities, confidence, source and WAIT boost.
- UI, original forecast IDs/Entry/SL/TP, existing direction model, TOP-5 policy and background-service controls are unchanged.
- Verification: `python -m compileall -q app tests`; `PYTHONPATH=. pytest -q` — 127 passed, 9 subtests passed. Android APK build and live market validation are not performed in this local test environment.


## Version 1.0.224 — learning ledger and market-regime validation fixes

- A canonical set of unique, eligible resolved prediction IDs now drives the retrain counter, audit reconciliation and current archive statistics. Historical cumulative counters remain separate from current archive sizes.
- Initial-SL forecasts remain excluded from active training while their post-SL recheck is pending. Existing invalid replay rows are preserved in a quarantine archive, then can be reintroduced only after the source prediction becomes eligible.
- Challenger generations missing from older state files are migrated and tagged in both prediction history and pending resolver copies. A control comparison waits for 25 fully paired outcomes; incomplete cohorts do not become a false tie or winner. A bounded cohort size prevents permanent retraining stalls.
- Market-regime validation now reports accuracy, balanced accuracy, per-class precision/recall/F1 and the chronological purge. A regime model is accepted for inference only if it beats the majority baseline, meets a balanced-accuracy threshold and identifies both trend directions. Unvalidated fallback scores are diagnostic only and trigger a conservative WAIT guard instead of a confident RANGE label.
- Independent direction validation now reports per-class SHORT/WAIT/LONG metrics and explicit feature-imputation counts. Non-finite features are neutral-imputed identically for training and held-out evaluation.
- UI and layout are unchanged; original forecast IDs, direction, Entry, SL, TP and horizon are unchanged.
- Verification: `python -m compileall -q app tests`; `PYTHONPATH=. pytest -q` — 135 passed, 9 subtests passed. Android APK build and live-device validation have not been performed in this environment.

## Version 1.0.223 — timestamp, resolved-counter and Challenger-cycle fixes

- Normalizes each timestamp independently to Unix seconds when reading/writing global replay memory, including mixed seconds/milliseconds/microseconds archives. The migration is persisted and recorded in `timestamp_normalization_v1.json`.
- Chronological validation and regime validation normalize mixed-unit timestamps per row before splitting, so the purge gap remains expressed in seconds.
- Training counters, training-batch slices and selector updates use one deduplicated set of eligible resolved forecast IDs in resolution-time order. Stable ID checkpoints prevent late post-SL resolutions from shifting numeric slices or being skipped/retrained twice.
- Auxiliary observation batches no longer force an independent Master retrain or reset the Challenger cycle. They remain pending until the next normal resolved-forecast batch.
- Challenger control rows are tagged with a generation and only forecasts actually issued under that generation can be paired. An incomplete cohort is logged as incomplete rather than falsely scored as a tie; missing paired outcomes are excluded and insufficient sample counts cannot declare a winner.
- UI and original forecast Entry/SL/TP lifecycle are unchanged.
- Verification: `python -m py_compile app/core/engine.py app/core/model.py app/services/scanner.py`; `PYTHONPATH=. pytest -q` — see release verification after final test run. Android APK build and live-market validation are not performed here.


## Version 1.0.225 — regime inputs, readiness and scan progress

- Stage-25 passes the regime classifier's feature set in a separate `regime_features` namespace. Missing regime features stay NaN; they are not silently replaced by direction-model neutral zeros.
- Readiness counts unique completed actionable outcomes and excludes records still waiting for the post-SL recheck. `training_eligible_resolved` is reported separately because model-training rows also require valid feature columns.
- Market-regime validation metadata records the chronological cutoff, purge interval, horizon and explicit no-future-input/no-test-fit assertions. A regime model remains blocked unless its holdout clears the configured quality gate.
- Scan progress now reports independent stages: quick scan (~700), deep model analysis (50), mathematical validation (25), final TOP-5 (up to 5). The UI no longer combines 50 + 25 into one ambiguous 75-candidate count.
- Model-stage concurrency defaults to 3 bounded workers while retaining the existing timeout guard. This reduces timeout risk but does not guarantee network/API stages will never time out.
- The interface layout and forecast lifecycle rules are unchanged.


## Version 1.0.227 — MODEL-stage performance and timeout migration

- Eliminates redundant global learning-ledger migration/reconciliation from each of the 50 per-contract deep-analysis workers. Per-contract engine isolation remains intact.
- Migrates the legacy saved 900-second MODEL-stage timeout to 1800 seconds without resetting other settings; UI and service use the same migration.
- Logs the effective MODEL-stage timeout at background-service startup.
- Full test suite: 142 passed, 9 subtests passed. APK/live exchange validation remains required.

## Version 1.0.226 — deep MODEL-stage completion

- Runtime backup from 2026-10-16 showed that the 900-second MODEL-stage deadline was being reached repeatedly while analyzing 50 deep candidates; unfinished candidates were then marked as timeout/skipped errors.
- Increased the default MODEL-stage deadline to 1800 seconds, with a hard cap of 2700 seconds. The three-worker limit and request pacing are unchanged to avoid increasing KuCoin API pressure.
- Preserved the 700 → 50 → 25 → TOP-5 pipeline, ranking, signal lifecycle, progress labels, and UI. User-configured shorter deadlines remain respected.
- Verification: `PYTHONPATH=. pytest -q` — 139 passed, 9 subtests passed. Android APK build and live-device verification are not performed here; check the next runtime log for `model_stage_timed_out=False`.


## Version 1.0.228

Master Selector now learns only from unique best outcomes across the eight combinations. Tied outcomes are not falsely labeled MASTER; legacy selector rows from the previous schema are discarded. See `FIX_1.0.228_SELECTOR_LABELS.md`.


## Version 1.0.229 — individual mathematical expert shadow tracking

The deep-analysis stage now records standalone candidate forecasts from the existing Markov, AR, ARIMA, SARIMA, mean-reversion, cointegration, trend-deviation, Haar-wavelet, Kalman, Bayesian-sign, Monte-Carlo-direction, Hurst-persistence, and benchmark-correlation outputs. Composite math-direction and math-consensus outputs are retained as baselines. Risk-only features and TP/SL path probabilities are not treated as directional experts.

Each expert candidate gets the same ATR-based Entry/SL/TP plan and is resolved against the same future OHLC path as the live forecast. Outcomes are stored separately in prediction history and the learning audit. The initial release is shadow-only: it does not replace or alter Master, C1/C2/C3, LONG/SHORT/WAIT, TOP-5, or the UI. Only records whose chosen Master direction has at least 80% directional confidence enter the expert performance learning ledger; raw expert scores are explicitly marked uncalibrated.

This release collects independent-model evidence; it does not yet promote an individual expert to control live signals. Promotion requires sufficient eligible outcomes and a separate out-of-sample validation.

## 1.0.229 — automatic individual math-expert learning

See `FIX_1.0.229_AUTO_MATH_EXPERT_LEARNING.md`. Individual mathematical experts are tracked against a matched Master baseline. The program selects an expert from earlier outcomes, validates it on a later 30-row window with minimum coverage and paired-outcome requirements, and only then enables it as a conservative confirmation gate. If no expert passes, Master continues unchanged.
