# SelfLearningTrader FIVE 1.0.241 — Full scan throughput

- Increased the bounded model-stage worker cap from 3 to 4; default is now 4.
- Increased the bounded Stage-25 math-validation worker cap from 3 to 4; default is now 4.
- Keeps the same scan funnel: all active USDT perpetuals -> deep model analysis of 50 -> Stage-25 validation of 25 -> ranked TOP-5.
- No candidate-count reduction and no scoring/ranking/forecast outcome rule changes.
- Worker counts remain configurable in app/config.json/settings.
- This is a conservative concurrency increase intended to reduce network-bound wall time; Android device/API behavior still needs validation from the next runtime backup.
