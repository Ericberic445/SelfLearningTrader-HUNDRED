# SelfLearningTrader FIVE 1.0.240 — Active recheck queue reliability

- Replaced the lossy `already_running` behavior with a persisted FIFO queue in `active_forecast_recheck_queue.json`.
- Requests arriving during an active recheck are queued instead of discarded; repeated requests for the same cycle are coalesced.
- A single worker drains queued batches serially. Existing per-contract checkpoints remain responsible for resuming interrupted batches after Android service restarts.
- Failed batches are retained on disk for recovery instead of silently disappearing.
- No UI, signal-direction, Entry/SL/TP, or forecast outcome rules changed.

Validation: Python compileall passed; full unittest discovery passed (48 tests).
