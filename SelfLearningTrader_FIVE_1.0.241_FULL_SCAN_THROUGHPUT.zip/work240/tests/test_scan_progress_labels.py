import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_scan_pipeline_keeps_50_and_25_stages_separate_in_config_and_progress():
    config = json.loads((ROOT / 'config.json').read_text(encoding='utf-8'))
    assert config['scan_deep_candidates'] == 50
    assert config['scan_second_stage_candidates'] == 25
    assert config['scan_model_workers'] == 4
    assert config['scan_math_workers'] == 4
    assert config['scan_model_stage_timeout_seconds'] == 1800

    engine = (ROOT / 'app' / 'core' / 'engine.py').read_text(encoding='utf-8')
    assert "progress(int(done), int(total), name, row, err, phase='MATH25')" in engine
    assert 'progress(len(deep) + int(done), len(deep) + int(total)' not in engine

    for filename in ('main.py', 'app/main.py'):
        ui = (ROOT / filename).read_text(encoding='utf-8')
        assert "phase == 'MATH25'" in ui
        assert 'ГЛУБОКИЙ АНАЛИЗ: {done}/{total}' in ui
        assert 'МАТЕМАТИЧЕСКАЯ ПРОВЕРКА: {done}/{total}' in ui
