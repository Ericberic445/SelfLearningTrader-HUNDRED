SelfLearningTrader FIVE 1.0.232 — forecast lifecycle and statistics audit

- Confirmed the active lifecycle merge behavior: one unresolved lifecycle per exact futures contract. Later scan signals, including opposite LONG/SHORT or WAIT changes, are appended as observations and do not replace the original direction, entry, SL, TP1/TP2/TP3, or horizon.
- Confirmed that only the original lifecycle is kept in the active pending queue; a new lifecycle can start after the previous lifecycle resolves.
- Fixed the saved-forecast counter: legacy duplicate rows marked `state_change_only` / `merged_into_prediction_id` remain in JSON history for audit but no longer inflate `predictions`, pending, or resolved forecast counts.
- Statistics now expose `total_records` and `merged_observations` separately so raw stored rows can be distinguished from actual forecast lifecycles.
- Added regression tests for original Entry/SL/TP/horizon immutability and merged-row counting.
- UI layout was not changed.
