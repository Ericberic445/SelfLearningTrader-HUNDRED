import json
from pathlib import Path

from app.core.config import migrate_scan_runtime_settings


def test_legacy_900_second_timeout_is_migrated_and_preserves_other_settings(tmp_path):
    settings = tmp_path / "settings.json"
    original = {"scan_model_stage_timeout_seconds": 900, "scan_workers": 4, "symbol": "ETHUSDTM"}
    settings.write_text(json.dumps(original), encoding="utf-8")
    config = {"scan_model_stage_timeout_seconds": 900, "scan_workers": 4, "symbol": "ETHUSDTM"}

    result = migrate_scan_runtime_settings(config, settings)

    saved = json.loads(settings.read_text(encoding="utf-8"))
    assert result["scan_model_stage_timeout_seconds"] == 1800
    assert saved["scan_model_stage_timeout_seconds"] == 1800
    assert saved["scan_workers"] == 4
    assert saved["symbol"] == "ETHUSDTM"


def test_custom_nonlegacy_timeout_is_preserved(tmp_path):
    settings = tmp_path / "settings.json"
    settings.write_text(json.dumps({"scan_model_stage_timeout_seconds": 1200}), encoding="utf-8")
    config = {"scan_model_stage_timeout_seconds": 1200}

    migrate_scan_runtime_settings(config, settings)

    assert config["scan_model_stage_timeout_seconds"] == 1200
    assert json.loads(settings.read_text(encoding="utf-8"))["scan_model_stage_timeout_seconds"] == 1200


def test_scan_worker_engine_can_skip_global_ledger_migration(tmp_path, monkeypatch):
    from app.core.engine import LearningEngine

    class Exchange:
        futures_symbol = "BTCUSDTM"
        symbol = "BTC-USDT"
        def set_symbol(self, symbol):
            self.futures_symbol = symbol

    def should_not_run(self):
        raise AssertionError("scan worker must not repeat global ledger migration")

    monkeypatch.setattr(LearningEngine, "_migrate_legacy_master_experience", should_not_run)
    monkeypatch.setattr(LearningEngine, "_reconcile_learning_ledgers", should_not_run)
    monkeypatch.setattr(LearningEngine, "_reconcile_challenger_state", should_not_run)

    engine = LearningEngine(tmp_path, Exchange(), {}, initialize_ledgers=False)
    assert engine.exchange.futures_symbol == "BTCUSDTM"
