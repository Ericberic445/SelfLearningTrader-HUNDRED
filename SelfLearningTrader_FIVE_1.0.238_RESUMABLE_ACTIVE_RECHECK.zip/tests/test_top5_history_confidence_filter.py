from app.core.top5_history import eligible_history_items, forecast_probability


def test_selected_direction_probability_uses_issuance_value_and_normalizes_percent():
    assert forecast_probability({'prediction': 'LONG', 'prediction_probability': 0.70, 'p_long': 0.91}) == 0.70
    assert forecast_probability({'prediction': 'SHORT', 'p_short': 72.5, 'p_long': 0.2}) == 0.725
    assert forecast_probability({'prediction': 'WAIT', 'p_wait': 0.82}) == 0.82


def test_last100_menu_filters_below_70_and_includes_exactly_70():
    rows = [
        {'symbol': 'LOWUSDT', 'prediction': 'SHORT', 'prediction_probability': 0.6999},
        {'symbol': 'EDGEUSDT', 'prediction': 'SHORT', 'prediction_probability': 0.70},
        {'symbol': 'HIGHUSDT', 'prediction': 'LONG', 'issued_prediction_probability': 0.83},
        {'symbol': 'WAITUSDT', 'prediction': 'WAIT', 'prediction_probability': 0.99},
    ]
    result = eligible_history_items(rows)
    assert [item['symbol'] for item in result] == ['EDGEUSDT', 'HIGHUSDT']
    assert result[0]['issued_prediction_probability'] == 0.70


def test_last100_menu_uses_original_issuance_confidence_not_rechecked_confidence():
    rows = [
        {'symbol': 'ORIGINALLOW', 'prediction': 'LONG', 'issued_prediction_probability': 0.62},
        {'symbol': 'ORIGINALHIGH', 'prediction': 'SHORT', 'issued_prediction_probability': 0.74},
    ]
    def recover(item):
        return {**item, 'prediction_probability': 0.98 if item['symbol'] == 'ORIGINALLOW' else 0.35}
    result = eligible_history_items(rows, recover=recover)
    assert [item['symbol'] for item in result] == ['ORIGINALHIGH']
    assert result[0]['issued_prediction_probability'] == 0.74


def test_last100_menu_keeps_only_latest_100_eligible_predictions():
    rows = [
        {'symbol': f'C{i}', 'prediction': 'LONG', 'prediction_probability': 0.70}
        for i in range(125)
    ]
    result = eligible_history_items(rows)
    assert len(result) == 100
    assert result[0]['symbol'] == 'C25'
    assert result[-1]['symbol'] == 'C124'
