import numpy as np
from app.core.model import ModelManager


def test_selector_cannot_become_ready_from_in_sample_accuracy_alone(tmp_path):
    manager = ModelManager(tmp_path, config={'master_decision_min_validation_rows': 25,
                                             'master_decision_min_accuracy_delta': 0.02})
    manager._save(manager.master_decision, manager._new_decision())
    manager._write_json(manager.master_decision_meta, {
        'schema_version': manager.SELECTOR_SCHEMA_VERSION,
        'status': 'ready', 'rows': 500, 'accuracy': 0.99,
    })
    assert manager._selector_ready() is False


def test_selector_validation_uses_later_timestamped_rows_and_purge(tmp_path):
    manager = ModelManager(tmp_path, config={
        'horizon_bars': 12, 'master_decision_min_validation_rows': 25,
        'master_decision_validation_epochs': 2,
    })
    rng = np.random.default_rng(2026)
    n = 300
    X = rng.normal(size=(n, len(manager.META_NAMES)))
    y = np.arange(n, dtype=int) % 8
    sw = np.ones(n)
    # Prediction timestamps separated by 30 minutes; the 12-bar (1 hour) purge
    # must remove the rows immediately before the holdout boundary.
    times = 1_800_000_000 + np.arange(n, dtype=np.int64) * 1800
    result = manager._selector_temporal_validation(X, y, sw, times)
    assert result['status'] == 'ok'
    assert result['validation_rows'] >= 25
    assert result['train_rows'] >= 50
    assert result['purge_gap'] == 3600
    assert result['accuracy'] is not None
    assert result['baseline_accuracy'] is not None
