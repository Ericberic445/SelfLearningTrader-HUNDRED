from unittest.mock import patch

from app.core.engine import LearningEngine


class FakeExchange:
    symbol_count = 12
    def __init__(self, symbol='XBTUSDTM', timeout=25):
        self.futures_symbol = symbol
        self.timeout = timeout
        self._request_gap = 0.2

    def set_symbol(self, symbol):
        self.futures_symbol = str(symbol).upper().replace('-', '')

    def active_symbols(self):
        return [{'contract': f'COIN{i}USDTM', 'display': f'COIN{i}-USDT', 'turnover': 1_000_000 + i}
                for i in range(self.symbol_count)]


class WorkerEngine:
    instances = []

    def __init__(self, root, exchange, config, **kwargs):
        self.root = root
        self.exchange = exchange
        self.cfg = config
        self.init_options = kwargs
        type(self).instances.append(self)

    def _quick_candidate(self, item):
        self.exchange.set_symbol(item['contract'])
        return {'contract': item['contract'], 'symbol': item['display'], 'price': 100.0,
                'quick_score': 0.8, 'quality': 0.9, 'turnover24h': item['turnover']}

    def _scan_train_and_predict(self, item, scan_history=800, run_id=None):
        self.exchange.set_symbol(item['contract'])
        return {'contract': item['contract'], 'exchange_symbol': item['contract'],
                'symbol': item['display'], 'prediction': 'LONG', 'price': 100.0,
                'edge_score': 0.8, 'quality': 0.9, 'turnover24h': item['turnover'],
                'features': {}, 'run_id': run_id}


def test_full_scan_reuses_quick_engine_but_isolates_model_engine_per_symbol(tmp_path):
    WorkerEngine.instances = []
    engine = LearningEngine.__new__(LearningEngine)
    engine.root = tmp_path
    engine.cfg = {'scan_workers': 4, 'scan_model_workers': 2,
                  'scan_deep_candidates': 8, 'scan_second_stage_candidates': 5,
                  'history_limit': 1200, 'scan_request_gap': 0.2, 'scan_model_request_gap': 0.2}
    engine.exchange = FakeExchange()
    engine._stage25_validate = lambda rows, progress=None, cancel_event=None: list(rows)
    engine._persist_scan_prediction = lambda row: None
    engine.readiness = lambda: {'ready': False}

    with patch('app.core.exchange.KuCoin', FakeExchange), patch('app.core.engine.LearningEngine', WorkerEngine):
        rows, total, quick_ok, errors, diag = engine.scan_all()

    assert total == 12
    assert quick_ok == 12
    assert errors == 0
    assert len(rows) == 5
    # Quick scan reuses a worker engine, while each MODEL candidate gets an
    # isolated engine; MODEL workers skip the already-completed global ledger scan.
    assert 12 <= len(WorkerEngine.instances) <= 16
    assert diag['timings_seconds']['total'] >= 0


def test_scan_pipeline_scales_to_700_symbols_and_still_returns_top5(tmp_path):
    class Exchange700(FakeExchange):
        symbol_count = 700
    WorkerEngine.instances = []
    engine = LearningEngine.__new__(LearningEngine)
    engine.root = tmp_path
    engine.cfg = {'scan_workers': 4, 'scan_model_workers': 2,
                  'scan_deep_candidates': 50, 'scan_second_stage_candidates': 25,
                  'history_limit': 1200, 'scan_request_gap': 0.2, 'scan_model_request_gap': 0.2}
    engine.exchange = Exchange700()
    engine._stage25_validate = lambda rows, progress=None, cancel_event=None: list(rows)
    engine._persist_scan_prediction = lambda row: None
    engine.readiness = lambda: {'ready': False}
    with patch('app.core.exchange.KuCoin', Exchange700), patch('app.core.engine.LearningEngine', WorkerEngine):
        rows, total, quick_ok, errors, diag = engine.scan_all()
    assert total == 700
    assert quick_ok == 700
    assert errors == 0
    assert len(rows) == 5
    assert len({r['contract'] for r in rows}) == 5
    assert diag['deep_candidates'] == 50
    assert diag['second_stage_candidates'] == 25
    # Exactly 50 MODEL candidates receive isolated engines; quick scan uses
    # at most four worker engines.
    assert 50 <= len(WorkerEngine.instances) <= 54
    assert all(instance.init_options.get('initialize_ledgers') is False for instance in WorkerEngine.instances)
    assert diag['timings_seconds']['total'] >= 0


def test_model_stage_timeout_returns_partial_scan_instead_of_waiting_forever(tmp_path):
    import time

    class SlowWorkerEngine(WorkerEngine):
        def _scan_train_and_predict(self, item, scan_history=800, run_id=None):
            time.sleep(2.0)
            return super()._scan_train_and_predict(item, scan_history, run_id)

    class Exchange12(FakeExchange):
        symbol_count = 12

    engine = LearningEngine.__new__(LearningEngine)
    engine.root = tmp_path
    engine.cfg = {'scan_workers': 4, 'scan_model_workers': 2,
                  'scan_deep_candidates': 8, 'scan_second_stage_candidates': 5,
                  'scan_model_stage_timeout_seconds': 1,
                  'history_limit': 1200, 'scan_request_gap': 0.2, 'scan_model_request_gap': 0.2}
    engine.exchange = Exchange12()
    engine._stage25_validate = lambda rows, progress=None, cancel_event=None: list(rows)
    engine._persist_scan_prediction = lambda row: None
    engine.readiness = lambda: {'ready': False}

    started = time.monotonic()
    with patch('app.core.exchange.KuCoin', Exchange12), patch('app.core.engine.LearningEngine', SlowWorkerEngine):
        rows, total, quick_ok, errors, diag = engine.scan_all()
    elapsed = time.monotonic() - started

    assert total == 12
    assert quick_ok == 12
    assert elapsed < 1.8
    assert diag['model_stage_timed_out'] is True
    assert diag['model_stage_timeout_seconds'] == 1
    assert diag['breakdown']['Модель'] >= 2
    assert errors >= 2


def test_user_cancel_does_not_wait_for_a_slow_model_worker(tmp_path):
    import threading
    import time

    entered = threading.Event()
    cancel_event = threading.Event()

    class SlowWorkerEngine(WorkerEngine):
        def _scan_train_and_predict(self, item, scan_history=800, run_id=None):
            entered.set()
            time.sleep(3.0)
            return super()._scan_train_and_predict(item, scan_history, run_id)

    class Exchange12(FakeExchange):
        symbol_count = 12

    engine = LearningEngine.__new__(LearningEngine)
    engine.root = tmp_path
    engine.cfg = {'scan_workers': 4, 'scan_model_workers': 2,
                  'scan_deep_candidates': 8, 'scan_second_stage_candidates': 5,
                  'scan_model_stage_timeout_seconds': 30,
                  'history_limit': 1200, 'scan_request_gap': 0.2, 'scan_model_request_gap': 0.2}
    engine.exchange = Exchange12()
    engine._stage25_validate = lambda rows, progress=None, cancel_event=None: list(rows)
    engine._persist_scan_prediction = lambda row: None
    engine.readiness = lambda: {'ready': False}

    def request_cancel():
        if entered.wait(3.0):
            time.sleep(0.1)
            cancel_event.set()
    threading.Thread(target=request_cancel, daemon=True).start()

    started = time.monotonic()
    with patch('app.core.exchange.KuCoin', Exchange12), patch('app.core.engine.LearningEngine', SlowWorkerEngine):
        rows, total, quick_ok, errors, diag = engine.scan_all(cancel_event=cancel_event)
    elapsed = time.monotonic() - started

    assert elapsed < 1.8
    assert diag.get('cancelled') is True
