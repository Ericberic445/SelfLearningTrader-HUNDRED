import sys
from pathlib import Path

APP_DIR = Path(__file__).resolve().parents[1] / 'app'
if str(APP_DIR) not in sys.path:
    sys.path.insert(0, str(APP_DIR))

from core.model import ModelManager, MATH_EXPERT_FIELDS


def test_individual_math_experts_are_independent_shadow_candidates():
    snapshot = {
        'math_markov': 0.8,
        'math_ar': -0.4,
        'math_arima': 0.5,
        'math_sarima': -0.3,
        'math_mean_reversion': 0.6,
        'math_cointegration': -0.7,
        'math_trend_deviation': 0.4,
        'math_wavelet': 0.9,
        'math_kalman': -0.5,
        'math_bayesian': 0.8,
        'math_monte_carlo': 0.75,
        'math_hurst': 0.8,
        'math_trend_direction': 0.7,
        'math_correlation': 0.6,
        'math_benchmark_direction': -0.8,
        # Risk-only values must not become independent direction experts.
        'math_garch': 0.99,
        'math_entropy': 0.99,
        'math_psl': 0.99,
        'math_ptp1': 0.99,
    }
    candidates = ModelManager._individual_math_expert_predictions(snapshot)
    assert set(candidates) == set(MATH_EXPERT_FIELDS)
    assert candidates['MARKOV']['prediction'] == 'LONG'
    assert candidates['AR']['prediction'] == 'SHORT'
    assert candidates['BAYESIAN_SIGN']['prediction'] == 'LONG'
    assert candidates['BENCHMARK_CORRELATION']['prediction'] == 'SHORT'
    assert all(v['calibrated'] is False for v in candidates.values())
    assert all(v['score_type'] == 'raw_directional_score' for v in candidates.values())


def test_no_math_snapshot_does_not_create_fake_wait_candidates():
    assert ModelManager._individual_math_expert_predictions(None) == {}
    assert ModelManager._individual_math_expert_predictions({}) == {}


def test_weak_individual_score_abstains():
    candidates = ModelManager._individual_math_expert_predictions({'math_markov': 0.02})
    assert candidates['MARKOV']['prediction'] == 'WAIT'


def test_individual_expert_plans_are_shadow_only_and_work_during_master_warmup():
    from core.engine import LearningEngine

    engine = LearningEngine.__new__(LearningEngine)
    item = {
        'price': 100.0,
        'features': {'atrpct': 0.01},
        'lens_active': False,
        'prediction': 'LONG',
        'math_expert_predictions': {
            'AR': {'score': 0.7, 'prediction': 'LONG'},
            'MARKOV': {'score': -0.6, 'prediction': 'SHORT'},
        },
    }
    engine._attach_lens_plans(item)
    assert item['prediction'] == 'LONG'  # the live Master signal is untouched
    assert item['lens_plans'] == {}
    assert item['math_expert_plans']['AR']['prediction'] == 'LONG'
    assert item['math_expert_plans']['MARKOV']['prediction'] == 'SHORT'
    assert item['math_expert_plans']['AR']['sl'] < item['math_expert_plans']['AR']['entry']
    assert item['math_expert_plans']['MARKOV']['sl'] > item['math_expert_plans']['MARKOV']['entry']


def test_wait_expert_is_not_misclassified_as_short_plan():
    from core.engine import LearningEngine
    engine = LearningEngine.__new__(LearningEngine)
    item = {'price': 100.0, 'features': {'atrpct': 0.01}, 'lens_active': False,
            'prediction': 'LONG', 'math_expert_baseline_prediction': 'LONG',
            'math_expert_predictions': {'AR': {'prediction': 'WAIT', 'score': 0.01}}}
    engine._attach_lens_plans(item)
    assert item['math_expert_plans']['AR']['prediction'] == 'WAIT'
    assert item['math_expert_plans']['MASTER_BASELINE']['prediction'] == 'LONG'
    assert item['math_expert_plans']['AR']['sl'] != item['math_expert_plans']['AR']['sl']  # NaN for WAIT
