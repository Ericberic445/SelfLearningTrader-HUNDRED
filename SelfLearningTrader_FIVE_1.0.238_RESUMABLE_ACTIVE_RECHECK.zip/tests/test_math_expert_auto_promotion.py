import sys
from pathlib import Path

APP_DIR = Path(__file__).resolve().parents[1] / 'app'
if str(APP_DIR) not in sys.path:
    sys.path.insert(0, str(APP_DIR))

from core.model import ModelManager


def _rows(n=80):
    rows = []
    for i in range(n):
        # Training period: expert modestly better than matched baseline.
        if i < 50:
            expert_success = i % 5 != 0  # 80%
            baseline_success = i % 2 == 0  # 50%
        else:
            # Validation: 18 expert successes and 2 baseline successes;
            # most wins are paired against baseline failures.
            j = i - 50
            expert_success = j < 18
            baseline_success = 18 <= j < 20
        rows.append({
            'prediction_id': f'p{i}', 'time': i + 1,
            'baseline_outcome_score': 1 if baseline_success else 0,
            'experts': {'AR': {'prediction': 'LONG', 'score': 0.8,
                               'outcome_score': 1 if expert_success else 0}},
        })
    return rows


def test_math_expert_auto_promotion_requires_train_and_later_validation():
    state = ModelManager._evaluate_math_expert_selector(_rows())
    assert state['status'] == 'validated'
    assert state['active_expert'] == 'AR'
    assert state['experts']['AR']['validation_n'] == 30
    assert state['experts']['AR']['validation_lift'] > 0.05


def test_math_expert_does_not_promote_without_minimum_samples():
    state = ModelManager._evaluate_math_expert_selector(_rows(65))
    assert state['active_expert'] is None
    assert state['status'] == 'collecting'


def test_math_expert_rejected_when_validation_does_not_beat_baseline():
    rows = _rows()
    for i, row in enumerate(rows[50:]):
        row['experts']['AR']['outcome_score'] = row['baseline_outcome_score']
    state = ModelManager._evaluate_math_expert_selector(rows)
    assert state['active_expert'] is None
    assert state['status'] == 'no_expert_passed'


def test_math_expert_cannot_pass_by_abstaining_on_too_many_validation_rows():
    rows = _rows()
    for row in rows[-30:]:
        row['experts']['AR']['prediction'] = 'WAIT'
        row['experts']['AR']['outcome_score'] = -1
    state = ModelManager._evaluate_math_expert_selector(rows)
    assert state['active_expert'] is None
    assert state['experts']['AR']['validation_coverage'] == 0.0
