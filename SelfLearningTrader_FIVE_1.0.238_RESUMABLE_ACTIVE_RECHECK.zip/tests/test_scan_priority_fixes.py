from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCANNER = (ROOT / 'app' / 'services' / 'scanner.py').read_text(encoding='utf-8')
ENGINE = (ROOT / 'app' / 'core' / 'engine.py').read_text(encoding='utf-8')


def test_active_forecast_recheck_is_queued_not_run_inline_in_scan_cycle():
    assert 'def _queue_active_forecast_recheck(' in SCANNER
    assert 'threading.Thread(target=worker, daemon=True' in SCANNER
    assert 'recheck_started = time.monotonic()\n            active_recheck = recheck_active_forecasts' not in SCANNER


def test_top5_is_published_and_logged_before_background_recheck_is_queued():
    publish = SCANNER.index("last_top5=rows[:5], last_top5_cycle=cycle, top5_started_at=top5_started_at")
    issued_log = SCANNER.index("runtime_log(f'TOP5_ISSUED cycle={cycle}")
    queue = SCANNER.index('_queue_active_forecast_recheck(', issued_log)
    assert publish < issued_log < queue
    assert "TOP-5 выдан и сохранён: {len(rows)} из 5" in SCANNER


def test_wait_window_does_not_repeat_blocking_resolution_and_retraining():
    wait_start = SCANNER.index("while not cancel_event.is_set() and not stopped() and time.time() < next_scan_at:")
    wait_end = SCANNER.index("if cancel_event.is_set() or stopped():", wait_start)
    wait_block = SCANNER[wait_start:wait_end]
    assert 'resolve_all_pending' not in wait_block
    assert '_retrain_with_real_position_batch' not in wait_block
    assert '_sleep_or_stop' in wait_block


def test_scan_and_recheck_share_prediction_ledger_lock():
    persist = ENGINE.split('    def _persist_scan_prediction(self, r):', 1)[1].split('    def _scan_train_and_predict', 1)[0]
    assert 'with _ENGINE_FILE_LOCK:' in persist



def test_resolve_all_pending_skips_empty_or_fully_queued_contracts_before_network_resolution():
    block = ENGINE.split('    def resolve_all_pending(self):', 1)[1].split('    def _wait_learning_row', 1)[0]
    guard = block.index('if not local_ids:')
    skip = block.index('continue', guard)
    network_resolution = block.index('self.resolve_pending(allowed_ids=set(local_ids))')
    assert guard < skip < network_resolution
    assert 'Queued status was already persisted above.' in block


def test_learning_resolution_has_start_and_duration_diagnostics():
    assert "runtime_log('LEARN_RESOLVE_START: advancing eligible pending forecasts')" in SCANNER
    assert "runtime_log(f'LEARN_RESOLVE_DONE elapsed_seconds=" in SCANNER
