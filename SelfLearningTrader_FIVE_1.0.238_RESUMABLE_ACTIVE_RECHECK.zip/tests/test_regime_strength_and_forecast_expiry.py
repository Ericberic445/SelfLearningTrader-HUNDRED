import json
from pathlib import Path
import numpy as np

from app.core.engine import LearningEngine
from app.core.model import ModelManager


def test_existing_regime_features_score_strong_uptrend_without_new_classifier():
    mm = ModelManager.__new__(ModelManager)
    row = {
        'trend': 0.012, 'trend_15': 0.010, 'trend_1h': 0.009,
        'trend_4h': 0.008, 'trend_1d': 0.007,
        'regime_efficiency': 0.82, 'regime_persistence': 0.88,
        'regime_reversal_rate': 0.12, 'regime_mtf_alignment': 0.95,
    }
    result = mm._trend_strength_diagnostics(row)
    assert result['trend_strength_long'] > 0.60
    assert result['trend_strength_short'] == 0.0
    assert result['trend_quality'] == 'STRONG_UP'


def test_existing_regime_features_flag_choppy_market():
    mm = ModelManager.__new__(ModelManager)
    row = {
        'trend': 0.0001, 'trend_15': -0.0001, 'trend_1h': 0.0001,
        'trend_4h': 0.0, 'trend_1d': -0.0001,
        'regime_efficiency': 0.08, 'regime_persistence': 0.48,
        'regime_reversal_rate': 0.72, 'regime_mtf_alignment': 0.25,
    }
    result = mm._trend_strength_diagnostics(row)
    assert result['trend_strength_long'] < 0.10
    assert result['trend_strength_short'] < 0.10
    assert result['trend_quality'] == 'RANGE_OR_CHOP'


def test_max_forecast_lifetime_is_configurable_and_defaults_to_96_bars(tmp_path):
    config = json.loads((Path(__file__).parents[1] / 'app' / 'config.json').read_text())
    assert config['max_forecast_lifetime_bars'] == 96
    assert config['max_forecast_lifetime_bars'] * 5 == 480  # 8 hours at 5-minute candles


def test_expired_without_tp_is_not_eligible_as_win_or_loss():
    item = {
        'resolved': 1, 'verification_state': 'EXPIRED_STALE',
        'trade_outcome': 'EXPIRED_STALE', 'statistics_exclude': True,
        'training_exclude': True, 'tp1_hit': False, 'tp2_hit': False,
        'tp3_hit': False, 'initial_sl_failure': False, 'sl_hit': False,
    }
    assert LearningEngine._infer_trade_outcome(item) == -1
    assert item['statistics_exclude'] is True
    assert item['training_exclude'] is True


def test_expired_after_tp1_preserves_success_milestone():
    item = {
        'resolved': 1, 'verification_state': 'EXPIRED_AFTER_TP1',
        'trade_outcome': 'EXPIRED_AFTER_TP1', 'tp1_hit': True,
        'tp2_hit': False, 'tp3_hit': False, 'initial_sl_failure': False,
        'sl_hit': False,
    }
    assert LearningEngine._infer_trade_outcome(item) == 1


def test_strong_aligned_trend_gets_more_time_than_default_lifetime():
    item = {
        'prediction': 'LONG',
        'market_regime': {'trend_quality': 'STRONG_UP', 'trend_strength_long': 0.82},
    }
    assert LearningEngine._max_forecast_lifetime(item, horizon=12, configured=96) == 192


def test_choppy_or_opposite_trend_does_not_extend_forecast_lifetime():
    base = {'prediction': 'LONG', 'market_regime': {'trend_quality': 'RANGE_OR_CHOP', 'trend_strength_long': 0.9}}
    opposite = {'prediction': 'LONG', 'market_regime': {'trend_quality': 'STRONG_DOWN', 'trend_strength_short': 0.9}}
    assert LearningEngine._max_forecast_lifetime(base, horizon=12, configured=96) == 96
    assert LearningEngine._max_forecast_lifetime(opposite, horizon=12, configured=96) == 96
