import json
from pathlib import Path
import numpy as np

from app.core.engine import LearningEngine, _normalize_timestamp_array, _timestamp_seconds
from app.core.features import FEATURES


def _features():
    return {name: 0.01 for name in FEATURES}


def test_mixed_epoch_units_normalize_individually_to_seconds():
    seconds = 1_800_000_000
    raw = np.asarray([seconds, seconds * 1_000, seconds * 1_000_000,
                      (seconds + 300) * 1_000_000, seconds + 600], dtype=np.int64)
    got = _normalize_timestamp_array(raw)
    np.testing.assert_array_equal(got, [seconds, seconds, seconds, seconds + 300, seconds + 600])
    assert _timestamp_seconds((seconds + 600) * 1_000_000) == seconds + 600


def test_load_experience_migrates_mixed_timestamps_once(tmp_path):
    data = tmp_path / 'data'; data.mkdir()
    exp_path = data / 'global_experience.npz'
    seconds = 1_800_000_000
    raw = np.asarray([seconds, seconds * 1_000, seconds * 1_000_000], dtype=np.int64)
    np.savez(exp_path, time=raw, target=np.asarray([0, 1, 2], dtype=np.int8))
    engine = LearningEngine.__new__(LearningEngine)
    engine.experience = exp_path; engine.data = data
    engine._write_json = lambda path, obj: Path(path).write_text(json.dumps(obj), encoding='utf-8')
    loaded = engine._load_exp()
    np.testing.assert_array_equal(loaded['time'], [seconds, seconds, seconds])
    with np.load(exp_path) as z:
        np.testing.assert_array_equal(z['time'], [seconds, seconds, seconds])
    assert (data / 'timestamp_normalization_v1.json').exists()


def test_resolved_counter_and_batch_slicing_use_resolution_order_and_same_filters(tmp_path):
    logs = tmp_path / 'logs'; logs.mkdir()
    # Creation time order is deliberately opposite to resolution order.
    rows = [
        {'id': 'older-created', 'time': 1_800_000_000_000_000, 'resolved': 1,
         'resolved_at': 1_800_000_300, 'result': 'TP1', 'tp1_hit': True, 'features': _features()},
        {'id': 'newer-created', 'time': 1_800_000_300_000_000, 'resolved': 1,
         'resolved_at': 1_800_000_100_000, 'result': 'TP2', 'tp2_hit': True, 'features': _features()},
        {'id': 'pending-recheck', 'time': 1_800_000_600_000_000, 'resolved': 1,
         'resolved_at': 1_800_000_600_000_000, 'post_sl_recheck_pending': True},
        {'id': 'merged', 'time': 1_800_000_900_000_000, 'resolved': 1, 'state_change_only': True},
    ]
    (logs / 'AAA_predictions.json').write_text(json.dumps(rows), encoding='utf-8')
    engine = LearningEngine.__new__(LearningEngine); engine.logs = logs
    eligible = engine._resolved_learning_rows()
    assert [x['id'] for x in eligible] == ['newer-created', 'older-created']
    assert engine._count_resolved_logs() == 2
    assert [x['id'] for x in engine._learning_rows_since(0, 1)] == ['newer-created']


def test_auxiliary_samples_do_not_force_retrain_or_reset_challenger(tmp_path):
    engine = LearningEngine.__new__(LearningEngine)
    state = {'last_retrain_resolved': 100, 'retrain_batches': 4,
             'clean_master_reset_done': True, 'challenger_active': True,
             'challenger_generation': 7, 'challenger_control_target': 125,
             'challenger_created_at': 12345}
    engine.cfg = {'retrain_batch_size': 25}
    engine._training_state = lambda: dict(state)
    engine._resolved_learning_rows = lambda: []
    engine._save_training_state = lambda value: None
    result = engine.retrain_symbols([], resolved_total=105, force=False, auxiliary_only=True)
    assert result[0][0] == 'AUXILIARY_DEFERRED'
    assert result[0][1]['status'] == 'waiting_for_trade_batch'
    assert state['challenger_generation'] == 7
    assert state['challenger_control_target'] == 125
    assert state['challenger_created_at'] == 12345


def test_challenger_control_rows_only_include_current_generation(tmp_path):
    logs = tmp_path / 'logs'; logs.mkdir()
    rows = [
        {'id': 'g1', 'time': 1_800_000_000, 'resolved_at': 1_800_000_100,
         'resolved': 1, 'challenger_generation': 1, 'challenger_control_active': True,
         'challenger_prediction': 'LONG', 'trade_outcome': 'TP1', 'tp1_hit': True, 'features': _features(),
         'challenger_outcome': {'trade_outcome':'TP1'}},
        {'id': 'g2', 'time': 1_800_000_200, 'resolved_at': 1_800_000_300,
         'resolved': 1, 'challenger_generation': 2, 'challenger_control_active': True,
         'challenger_prediction': 'SHORT', 'trade_outcome': 'SL', 'sl_hit': True, 'initial_sl_failure': True,
         'features': _features(), 'challenger_outcome': {'trade_outcome':'TP2'}},
    ]
    (logs / 'AAA_predictions.json').write_text(json.dumps(rows), encoding='utf-8')
    engine = LearningEngine.__new__(LearningEngine); engine.logs = logs
    got = engine._challenger_control_rows({'challenger_generation': 2})
    assert [x['id'] for x in got] == ['g2']


def test_id_checkpoint_finds_late_resolving_old_forecast_without_counter_drift(tmp_path):
    logs = tmp_path / 'logs'; logs.mkdir()
    rows = [
        {'id': 'already-trained', 'time': 1_800_000_000, 'resolved_at': 1_800_000_100,
         'resolved': 1, 'result': 'TP1', 'tp1_hit': True, 'features': _features()},
        {'id': 'new-but-old-created', 'time': 1_799_000_000, 'resolved_at': 1_800_000_200,
         'resolved': 1, 'result': 'TP2', 'tp2_hit': True, 'features': _features()},
    ]
    (logs / 'AAA_predictions.json').write_text(json.dumps(rows), encoding='utf-8')
    engine = LearningEngine.__new__(LearningEngine)
    engine.logs = logs
    state = {'last_retrain_resolved': 1, 'last_retrain_resolved_ids': ['already-trained']}
    fresh = engine._new_learning_rows(state)
    assert [x['id'] for x in fresh] == ['new-but-old-created']


def test_challenger_does_not_report_tie_when_paired_outcomes_are_missing(tmp_path):
    engine = LearningEngine.__new__(LearningEngine)
    engine.cfg = {'retrain_batch_size': 25}
    engine._append_learning_audit = lambda event: None
    state = {'challenger_generation': 1, 'challenger_start_resolved': 100,
             'challenger_control_target': 125}
    rows = [{'id': 'p1', 'challenger_generation': 1, 'challenger_control_active': True,
             'challenger_prediction': 'SHORT', 'trade_outcome': 'TP1',
             'challenger_outcome': {'trade_outcome': 'WAITING'}}]
    result = engine._evaluate_challenger_control(rows, state)
    assert result['result'] == 'INSUFFICIENT_DATA'
    assert result['paired_rows'] == 0
    assert state['challenger_checked'] is False


def test_incomplete_challenger_block_stays_active_and_does_not_retrain_master(tmp_path):
    engine = LearningEngine.__new__(LearningEngine)
    engine.cfg = {'retrain_batch_size': 25}
    state = {'last_retrain_resolved': 100, 'last_retrain_resolved_ids': [],
             'retrain_batches': 4, 'clean_master_reset_done': True,
             'challenger_active': True, 'challenger_generation': 3}
    engine._training_state = lambda: dict(state)
    engine._resolved_learning_rows = lambda: []
    engine._new_learning_rows = lambda state_arg, rows=None: [{'id': f'n{i}'} for i in range(25)]
    engine._challenger_control_rows = lambda state_arg: [
        {'id': f'p{i}', 'challenger_generation': 3, 'challenger_control_active': True,
         'challenger_prediction': 'LONG', 'trade_outcome': 'TP1',
         'challenger_outcome': {'trade_outcome': 'TP1'}} for i in range(12)]
    audits = []
    engine._append_learning_audit = audits.append
    result = engine.retrain_symbols([], force=False)
    assert result[0][0] == 'CHALLENGER_CONTROL_WAIT'
    assert result[0][1]['paired_rows'] == 12
    assert state['challenger_active'] is True
    assert audits and audits[0]['event'] == 'CHALLENGER_CONTROL_WAIT'


def test_ledger_reconciliation_quarantines_pending_sl_without_training_it(tmp_path):
    from app.core.features import FEATURES
    root = tmp_path
    data = root / 'data'; logs = root / 'logs'
    data.mkdir(); logs.mkdir()
    engine = LearningEngine.__new__(LearningEngine)
    engine.root = root; engine.data = data; engine.logs = logs
    engine.experience = data / 'global_experience.npz'
    engine.learning_audit = data / 'learning_audit.jsonl'
    engine.cfg = {'learning_audit_max_rows': 5000}
    common = {'time': 1_800_000_000, 'contract': 'AAA', 'target': 2,
              'outcome_target': 1, 'sample_weight': 1.0, 'outcome_sample_weight': 1.0,
              'math_consensus': 0.0}
    rows = []
    for pid, kind in [('pending-sl', 'TRADE'), ('eligible-tp1', 'TRADE'), ('online-1', 'ONLINE_DIRECTION_OBSERVATION')]:
        rows.append({**common, 'prediction_id': pid, 'experience_kind': kind,
                     **{f: 0.01 for f in FEATURES}})
    np.savez(engine.experience, **engine._rows_to_arrays(rows))
    prediction_rows = [
        {'id': 'pending-sl', 'time': 1_800_000_000, 'resolved_at': 1_800_000_100,
         'resolved': 1, 'sl_hit': True, 'initial_sl_failure': True,
         'post_sl_recheck_pending': True, 'features': {f: 0.01 for f in FEATURES}},
        {'id': 'eligible-tp1', 'time': 1_800_000_300, 'resolved_at': 1_800_000_400,
         'resolved': 1, 'tp1_hit': True, 'result': 'TP1',
         'features': {f: 0.01 for f in FEATURES}},
    ]
    (logs / 'AAA_predictions.json').write_text(json.dumps(prediction_rows), encoding='utf-8')
    engine._reconcile_learning_ledgers()
    with np.load(engine.experience) as z:
        kinds = np.asarray(z['experience_kind']).astype(str)
        ids = np.asarray(z['prediction_id']).astype(str)
    assert 'pending-sl' not in set(ids)
    assert 'eligible-tp1' in set(ids)
    assert 'online-1' in set(ids)
    assert int(np.sum(kinds == 'TRADE')) == 1
    assert (data / 'pending_post_sl_trade_rows.npz').exists()
    report = json.loads((data / 'learning_ledger_reconciliation.json').read_text())
    assert report['eligible_resolved_unique'] == 1
    assert report['active_archive_trade_ids'] == 1
    audit = [json.loads(x) for x in (data / 'learning_audit.jsonl').read_text().splitlines()]
    resolved_ids = {x.get('prediction_id') for x in audit if x.get('event') == 'PREDICTION_RESOLVED'}
    assert resolved_ids == {'eligible-tp1'}


def test_legacy_challenger_generation_migration_updates_pending_copy(tmp_path):
    data = tmp_path / 'data'; logs = tmp_path / 'logs'
    data.mkdir(); logs.mkdir()
    engine = LearningEngine.__new__(LearningEngine)
    engine.root = tmp_path; engine.data = data; engine.logs = logs
    engine.learning_audit = data / 'learning_audit.jsonl'
    engine.cfg = {'learning_audit_max_rows': 5000}
    issued_ns = 1_800_000_001_000_000_000
    item = {'id': f'{issued_ns}-AAA', 'challenger_prediction': 'LONG',
            'challenger_control_active': True, 'challenger_generation': 0}
    (logs / 'AAA_predictions.json').write_text(json.dumps([dict(item)]), encoding='utf-8')
    (logs / 'AAA_pending.json').write_text(json.dumps([dict(item)]), encoding='utf-8')
    (data / 'training_batch_state.json').write_text(json.dumps({
        'challenger_active': True, 'challenger_created_at': 1_800_000_000,
        'challenger_control_target': 125, 'last_retrain_resolved': 100,
    }), encoding='utf-8')
    engine._reconcile_challenger_state()
    state = json.loads((data / 'training_batch_state.json').read_text())
    history = json.loads((logs / 'AAA_predictions.json').read_text())[0]
    pending = json.loads((logs / 'AAA_pending.json').read_text())[0]
    assert state['challenger_generation'] == 1
    assert history['challenger_generation'] == 1
    assert pending['challenger_generation'] == 1
    assert state['challenger_migrated_predictions'] == 1


def test_legacy_challenger_without_creation_time_is_abandoned_not_mixed(tmp_path):
    data = tmp_path / 'data'; logs = tmp_path / 'logs'
    data.mkdir(); logs.mkdir()
    engine = LearningEngine.__new__(LearningEngine)
    engine.root = tmp_path; engine.data = data; engine.logs = logs
    engine.learning_audit = data / 'learning_audit.jsonl'
    engine.cfg = {'learning_audit_max_rows': 5000}
    item = {'id': '1800000001000000000-AAA', 'challenger_prediction': 'LONG',
            'challenger_control_active': True, 'challenger_generation': 0}
    (logs / 'AAA_predictions.json').write_text(json.dumps([dict(item)]), encoding='utf-8')
    (data / 'training_batch_state.json').write_text(json.dumps({
        'challenger_active': True, 'last_retrain_resolved': 100,
    }), encoding='utf-8')
    engine._reconcile_challenger_state()
    state = json.loads((data / 'training_batch_state.json').read_text())
    history = json.loads((logs / 'AAA_predictions.json').read_text())[0]
    assert state['challenger_active'] is False
    assert state['challenger_last_result'] == 'INCOMPLETE_LEGACY_GENERATION'
    assert history['challenger_generation'] == 0


def test_readiness_does_not_count_post_sl_pending_as_completed_learning_rows(tmp_path):
    from app.core.engine import LearningEngine
    from app.core.features import FEATURES
    logs = tmp_path / 'logs'; logs.mkdir()
    rows = []
    for i in range(34):
        rows.append({'id': f'pending-{i}', 'time': 1_800_000_000+i, 'resolved': 1,
                     'prediction': 'LONG', 'initial_sl_failure': True, 'sl_hit': True,
                     'tp1_hit': False, 'post_sl_recheck_pending': True,
                     'features': {name: .01 for name in FEATURES}})
    rows.append({'id': 'eligible-tp1', 'time': 1_800_000_100, 'resolved': 1,
                 'resolved_at': 1_800_000_200, 'prediction': 'LONG', 'p_long': 0.90, 'tp1_hit': True,
                 'result': 'TP1', 'features': {name: .01 for name in FEATURES}})
    (logs / 'AAA_predictions.json').write_text(json.dumps(rows), encoding='utf-8')
    engine = LearningEngine.__new__(LearningEngine)
    engine.logs = logs; engine.root = tmp_path; engine.cfg = {'readiness_min_resolved': 2}
    engine._training_state = lambda: {'retrain_batches': 1}
    engine.global_stats = lambda: {'resolved': 35, 'accuracy': 1.0}
    result = engine.readiness()
    assert result['resolved'] == 1
    assert result['raw_resolved_including_pending_post_sl'] == 35
    assert result['pending_post_sl_rechecks'] == 34
    assert result['checks'][1] is False
