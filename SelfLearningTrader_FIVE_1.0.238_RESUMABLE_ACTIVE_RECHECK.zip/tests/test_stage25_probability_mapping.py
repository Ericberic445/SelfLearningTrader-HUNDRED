import numpy as np

from core.engine import _probability_vector


def test_probability_mapping_is_ordered_short_wait_long():
    result = _probability_vector({0: 0.12, 1: 0.23, 2: 0.65})
    assert np.allclose(result, [0.12, 0.23, 0.65])


def test_probability_sequence_is_preserved():
    result = _probability_vector([0.12, 0.23, 0.65])
    assert np.allclose(result, [0.12, 0.23, 0.65])


def test_probability_vector_rejects_wrong_length():
    try:
        _probability_vector([0.5, 0.5])
    except ValueError as exc:
        assert 'Expected three direction probabilities' in str(exc)
    else:
        raise AssertionError('wrong probability vector length should be rejected')
