from unittest.mock import patch

from app.core.exchange import KuCoin


class FailingConnection:
    attempts = 0
    def __init__(self, *args, **kwargs):
        pass
    def request(self, *args, **kwargs):
        type(self).attempts += 1
        raise OSError('simulated network timeout')
    def close(self):
        pass


def test_scan_client_retry_limit_bounds_failed_http_requests():
    ex = KuCoin('XBTUSDTM', timeout=5)
    ex._max_attempts = 2
    ex._retry_delays = (0.0,)
    FailingConnection.attempts = 0
    with patch('app.core.exchange.http.client.HTTPSConnection', FailingConnection), patch('app.core.exchange.time.sleep'):
        try:
            ex._request_json('https://api.kucoin.com', '/api/test', {})
        except OSError as exc:
            assert 'simulated network timeout' in str(exc)
        else:
            raise AssertionError('request should fail')
    assert FailingConnection.attempts == 2


def test_model_stage_isolates_engine_per_contract():
    from pathlib import Path
    source = (Path(__file__).resolve().parents[1] / 'app' / 'core' / 'engine.py').read_text(encoding='utf-8')
    block = source.split('        model_worker=threading.local()', 1)[1].split('        with ThreadPoolExecutor(max_workers=model_workers', 1)[0]
    assert "eng=getattr(model_worker,'engine',None)" not in block
    assert 'eng=LearningEngine(self.root,ex,dict(scan_cfg),initialize_ledgers=False)' in block


def test_market_refresh_is_debounced():
    from pathlib import Path
    source = (Path(__file__).resolve().parents[1] / 'app' / 'main.py').read_text(encoding='utf-8')
    block = source.split('    def refresh_symbols(self, _, auto=False):', 1)[1].split('    def filter_symbols(', 1)[0]
    assert "getattr(self, '_market_refresh_running', False)" in block
    assert "self._market_refresh_running = True" in block
    assert "self._market_refresh_running = False" in block
