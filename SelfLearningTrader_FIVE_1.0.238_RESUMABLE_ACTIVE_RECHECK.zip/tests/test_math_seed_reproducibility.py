from app.core.engine import _stable_contract_seed


def test_contract_monte_carlo_seed_is_stable_across_restarts():
    assert _stable_contract_seed('XBTUSDTM') == _stable_contract_seed('XBTUSDTM')
    assert _stable_contract_seed('XBTUSDTM') != _stable_contract_seed('ETHUSDTM')
    assert 0 <= _stable_contract_seed('XBTUSDTM') < 100000
