import numpy as np
from app.core.model import ModelManager, COMBINATION_KEYS


def _resolved_row(winner=None, stamp=1):
    outcomes = {}
    for idx, name in enumerate(COMBINATION_KEYS):
        # All non-winners share the same non-success outcome. A unique winner
        # reaches TP1; winner=None deliberately makes every combination tie.
        outcomes[name] = {'tp1_hit': winner is not None and idx == winner,
                          'tp2_hit': False, 'tp3_hit': False,
                          'initial_sl_failure': winner is None or idx != winner,
                          'sl_hit': winner is None or idx != winner}
    return {
        'combination_outcomes': outcomes,
        'lens_performance_snapshot': [{'actor': 'master'}],
        'features': {}, 'master_p_short': .3, 'master_p_wait': .2,
        'master_p_long': .5, 'time': stamp,
    }


def test_selector_skips_ties_instead_of_fabricating_master_winner(tmp_path):
    manager = ModelManager(tmp_path, config={'master_decision_min_rows': 25})
    manager._selector_vector = lambda *args, **kwargs: np.zeros(len(manager.META_NAMES), dtype=np.float32)
    result = manager.learn_from_resolved([_resolved_row(None)])
    assert result['status'] == 'no_unique_combination_winners'
    assert result['ambiguous_rows_skipped'] == 1
    with np.load(manager.meta_experience, allow_pickle=False) as saved:
        assert int(saved['schema_version'][0]) == manager.SELECTOR_SCHEMA_VERSION
        assert len(saved['y']) == 0


def test_selector_records_only_unique_best_combination_and_rejects_legacy_labels(tmp_path):
    manager = ModelManager(tmp_path, config={'master_decision_min_rows': 25})
    manager._selector_vector = lambda *args, **kwargs: np.zeros(len(manager.META_NAMES), dtype=np.float32)
    # Simulate legacy archive where all ties had been recorded as MASTER.
    manager.meta_experience.parent.mkdir(parents=True, exist_ok=True)
    np.savez(manager.meta_experience,
             X=np.zeros((30, len(manager.META_NAMES)), dtype=np.float32),
             y=np.zeros(30, dtype=np.int8), sample_weight=np.ones(30),
             time=np.arange(30, dtype=np.int64) + 1)
    result = manager.learn_from_resolved([_resolved_row(2, 1000), _resolved_row(None, 2000)])
    assert result['status'] == 'selector_accumulating_class_diversity'
    assert result['new_unique_rows'] == 1
    assert result['ambiguous_rows_skipped'] == 1
    with np.load(manager.meta_experience, allow_pickle=False) as saved:
        assert len(saved['y']) == 1
        assert int(saved['y'][0]) == 2
        assert int(saved['schema_version'][0]) == manager.SELECTOR_SCHEMA_VERSION


def test_selector_rebuild_rejects_legacy_argmax_tie_labels(tmp_path):
    manager = ModelManager(tmp_path)
    manager.meta_experience.parent.mkdir(parents=True, exist_ok=True)
    np.savez(manager.meta_experience,
             X=np.zeros((40, len(manager.META_NAMES)), dtype=np.float32),
             y=np.zeros(40, dtype=np.int8), sample_weight=np.ones(40),
             time=np.arange(40, dtype=np.int64) + 1)
    result = manager.rebuild_selector_from_scratch()
    assert result['status'] == 'legacy_selector_experience_rejected'
