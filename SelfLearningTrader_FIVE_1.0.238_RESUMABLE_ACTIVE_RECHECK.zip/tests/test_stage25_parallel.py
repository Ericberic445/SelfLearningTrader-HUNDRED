import unittest
from unittest.mock import patch
import numpy as np

from app.core.engine import LearningEngine
from app.core.features import FEATURES


class FakeExchange:
    calls = []
    instances = []
    def __init__(self, symbol='XBTUSDTM', timeout=25):
        self.futures_symbol = symbol
        self.timeout = timeout
        self._request_gap = 0.2
        type(self).instances.append(self)
    def set_symbol(self, symbol):
        self.futures_symbol = str(symbol).upper().replace('-', '')
    def candles(self, tf, limit=1200):
        self.calls.append((self.futures_symbol, tf, limit))
        n = 160
        x = np.arange(n, dtype=float)
        close = 100 + x * 0.02 + np.sin(x / 4.0)
        return {'time': x.astype(np.int64) * 300000, 'open': close,
                'high': close * 1.002, 'low': close * 0.998,
                'close': close, 'volume': np.full(n, 1000.0)}


class FakeModel:
    def predict_bundle(self, row, consensus, snapshot):
        return 'LONG', np.asarray([0.15, 0.20, 0.65]), {'lens_active': False}
    def prediction_diagnostics(self, row, pred, probs, consensus, snapshot):
        return {'lens_active': False}


class Stage25ParallelTests(unittest.TestCase):
    def test_only_consumed_timeframe_is_fetched_and_progress_advances(self):
        FakeExchange.calls = []
        FakeExchange.instances = []
        engine = LearningEngine.__new__(LearningEngine)
        engine.cfg = {'history_limit': 1200, 'horizon_bars': 12,
                      'scan_model_request_gap': 0.2, 'scan_math_workers': 3}
        engine.exchange = type('BaseExchange', (), {'timeout': 25, 'futures_symbol': 'XBTUSDTM'})()
        engine.mm = FakeModel()
        rows = []
        for i in range(5):
            rows.append({'contract': f'COIN{i}USDTM', 'exchange_symbol': f'COIN{i}USDTM',
                         'symbol': f'COIN{i}-USDT', 'prediction': 'LONG', 'price': 100.0,
                         'edge_score': 0.5, 'quality': 0.7,
                         'features': {f: 0.0 for f in FEATURES}})
        progress = []
        with patch('app.core.exchange.KuCoin', FakeExchange):
            result = engine._stage25_validate(rows, progress=lambda *args, **kwargs: progress.append(args))
        self.assertEqual(len(result), 5)
        self.assertEqual(len(FakeExchange.calls), 6)  # one BTC benchmark + one 5m fetch per candidate
        self.assertLessEqual(len(FakeExchange.instances), 4)  # clients reused by bounded worker threads
        self.assertEqual({tf for _, tf, _ in FakeExchange.calls}, {'5min'})
        self.assertEqual(len(progress), 5)
        self.assertEqual(progress[-1][0:2], (5, 5))

if __name__ == '__main__':
    unittest.main()


def test_stage25_timeout_returns_without_waiting_for_stuck_math_workers():
    import time

    engine = LearningEngine.__new__(LearningEngine)
    engine.cfg = {'history_limit': 1200, 'horizon_bars': 12,
                  'scan_model_request_gap': 0.2, 'scan_math_workers': 3,
                  'scan_math_stage_timeout_seconds': 1}
    engine.exchange = type('BaseExchange', (), {'timeout': 8, 'futures_symbol': 'XBTUSDTM'})()
    engine.mm = FakeModel()
    rows = [{'contract': f'COIN{i}USDTM', 'exchange_symbol': f'COIN{i}USDTM',
             'symbol': f'COIN{i}-USDT', 'prediction': 'LONG', 'price': 100.0,
             'edge_score': 0.5, 'quality': 0.7,
             'features': {f: 0.0 for f in FEATURES}} for i in range(5)]

    def slow_math(*args, **kwargs):
        time.sleep(2.0)
        return {}

    started = time.monotonic()
    with patch('app.core.exchange.KuCoin', FakeExchange), patch('app.core.engine.compute_math_snapshot', slow_math):
        result = engine._stage25_validate(rows)
    elapsed = time.monotonic() - started

    assert result == []
    assert elapsed < 1.8
    assert engine._last_stage25_timed_out is True
