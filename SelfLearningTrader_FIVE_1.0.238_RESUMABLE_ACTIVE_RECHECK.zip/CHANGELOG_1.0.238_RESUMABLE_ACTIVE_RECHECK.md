# SelfLearningTrader FIVE 1.0.238 — resumable active forecast recheck

- Fixed the mass active-forecast recheck being lost when Android restarts the background service: the batch and per-contract completion cursor are now saved in `runtime/active_forecast_recheck_checkpoint.json`.
- On service startup, an unfinished batch resumes immediately instead of restarting from the first contract or waiting for the next full market scan.
- Each completed contract is checkpointed immediately; resolved contracts encountered after downtime are safely marked no longer active. Interrupted contracts remain pending.
- Recheck progress is recorded in runtime diagnostics and shared service state, including completed / total / remaining counts.
- Default recheck parallelism is limited to 3 workers; TOP-5 scan cadence remains independent.
- No UI, forecast direction, original Entry/SL/TP, lifecycle-resolution rules, ranking, or training rules changed.
- Validation: 184 tests passed and 9 subtests passed. Python syntax and release-version consistency checks passed.
