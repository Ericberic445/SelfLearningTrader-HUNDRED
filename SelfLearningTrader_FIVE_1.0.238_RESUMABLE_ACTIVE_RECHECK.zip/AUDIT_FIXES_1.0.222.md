# SelfLearningTrader FIVE 1.0.222 — market-regime learning

## What changed

- Added a separate four-class regime head: `TREND_DOWN`, `RANGE`, `TRANSITION`, `TREND_UP`.
- Kept the existing Master direction/outcome input schema unchanged. The Android UI, original forecast lifecycle, Entry/SL/TP, TOP-5 ranking and background service code were not changed.
- Added causal regime features: 12-bar directional efficiency/persistence/reversal rate, 24-bar range width/position, short-vs-long volatility ratio and higher-timeframe trend alignment.
- Added forward-path regime labels for training only. Training labels use the next configured horizon; future-derived values are not model inputs.
- Added a deduplicated training pool keyed by contract and candle timestamp, bounded to a configurable maximum. The model waits for at least five contracts and sufficient labeled rows before training, then refreshes only after a new-row threshold.
- Added chronological holdout validation with a purge gap at least equal to the forecast horizon, majority-class baseline, and per-class recall metrics.
- Added a conservative causal fallback before the learned head is available. Missing features are reported as insufficient data, not as a confident learned state.
- Added a regime-aware abstention gate: RANGE/TRANSITION increases WAIT pressure and raises direction confidence/edge requirements. The regime head does not directly force LONG or SHORT.
- Prediction diagnostics include regime label/probabilities/confidence/source and the WAIT boost.

## Verification

- `python -m compileall -q app tests` — passed.
- `PYTHONPATH=. pytest -q` — 119 passed, 9 subtests passed.
- Synthetic tests cover causal feature construction, future-path labels, multi-contract training, temporal purge, model persistence and WAIT behavior in a confident range regime.
- Android/GitHub APK build and live KuCoin market validation were not run in this environment. The regime classifier is not a declaration of readiness for real trading.
