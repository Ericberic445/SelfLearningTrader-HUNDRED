# SelfLearningTrader FIVE 1.0.221 — full mathematical estimators and probability calibration

## Scope

This work continues the 1.0.220 scan/history fixes. UI layout, TP/SL trade-management rules, saved prediction history, and training archives are preserved. The mathematical implementation version is `MATH_FORMULA_VERSION = 3`; calibration samples from older formula versions are deliberately excluded.

## Mathematical estimators now used

- **AR(p):** least-squares fit with intercept; use the fitted one-step forecast normalized by residual standard deviation, not a fitted coefficient as a direction signal.
- **ARIMA(1,1,1):** model first-differenced log-price returns as ARMA(1,1), fit AR and MA parameters by bounded conditional sum of squares with coarse initialization and local refinement, and include the estimated mean return in the forecast.
- **SARIMA(1,0,0)(1,0,0,12):** fit a multiplicative seasonal AR specification. The cross-lag coefficient is constrained to `-phi * Phi`, not fitted as an unrelated coefficient. The seasonal period is 12 candles.
- **GARCH(1,1):** estimate nonnegative alpha/beta under alpha+beta<1 using variance-targeted Gaussian quasi-likelihood grid search; use the fitted one-step conditional variance in volatility risk and simulation.
- **Monte Carlo:** simulate the fitted AR drift and GARCH conditional variance, resampling standardized empirical innovations rather than assuming Gaussian returns. The 2,000-path simulation is reproducible for identical input and seed.
- **TP1/TP2/TP3/SL:** first-passage barrier probabilities over the configured forecast horizon. A target counts only if it is touched before the original SL; SL probability counts only if it precedes TP1. Thus `P(TP1)+P(SL-before-TP1) <= 1`, and `P(TP1) >= P(TP2) >= P(TP3)`. Actual plan distances are used.
- **Hurst / fractal dimension:** log-log variogram scaling estimates H; graph dimension is reported as `D = 2 - H` on its natural 1–2 scale.
- **Entropy:** normalized Shannon entropy of the return distribution.
- **Markov:** three-state transition matrix based on down/neutral/up return states; score is the next-state up/down probability difference conditional on the current state.
- **Mean reversion:** fit an AR(1)/OU-like reversion coefficient on trailing log-price deviations; suppress the signal when estimated half-life is not meaningful for the available history.
- **Cointegration:** Engle–Granger two-step regression with residual augmented Dickey–Fuller regression; lag count is selected by AIC. The residual-test significance gate uses an approximate cointegration critical value, not an exact finite-sample p-value.
- **Correlation:** Pearson correlation of aligned asset and BTC returns, plus a full timestamp-aligned pairwise correlation matrix among Stage-25 candidates whose cached 5-minute histories are available. The matrix and per-candidate mean/max absolute correlation summaries are persisted for diagnostics. Raw cross-asset correlation is not used as a directional vote.
- **Kalman:** two-state local-linear-trend Kalman filter (level and slope), with process/observation noise scaled to the input series.
- **Wavelet:** multilevel Haar discrete wavelet transform, using signed recent detail normalized by multiscale detail energy.
- **Bayesian direction:** Beta–Bernoulli posterior predictive probability with Jeffreys Beta(1/2,1/2) prior; flat returns are excluded from the up/down denominator.
- **Change point:** standardized maximum split-mean difference over recent candidate change points.
- **Probability meaning:** `math_prob_move` is now a non-directional probability of a meaningful absolute horizon move. It is not used as a LONG/SHORT vote. Hurst is conditioned on observed trend; BTC correlation is conditioned on BTC trend; entropy, fractal dimension, volatility, change-point strength, and return/volatility correlation do not independently vote for LONG or SHORT.

## Online probability calibration

- New forecasts persist `math_formula_version = 3` with their raw mathematical probabilities.
- After the complete configured horizon is observable, the app labels TP1/TP2/TP3-before-SL, SL-before-TP1, absolute-move, and positive-return events using that exact horizon's OHLC candles.
- The calibration set is persisted in `data/math_probability_calibration.json`, deduplicated by prediction ID, and bounded to the latest 2,000 samples.
- Calibration uses only matching formula-version samples, requires at least 100 labeled observations and 50 distinct scan cycles, uses equal-frequency bins with Beta(1,1) smoothing and a pooled-adjacent-violators monotonic fit, and is applied only to subsequent forecasts.
- TP probability ordering and TP1/SL mutual-exclusion constraints are restored after calibration. Older formula versions are not used to fit the new formula's calibrator.

## Tests and verification

- `python -m compileall -q app main.py` passes.
- `PYTHONPATH=. pytest -q`: **113 passed, 9 subtests passed**.
- Synthetic tests cover ARIMA/SARIMA fit stability, GARCH stationarity constraints, Engle–Granger discrimination, first-passage TP/SL probability coherence, formula-version-isolated calibration, monotonic calibration, fixed-horizon labels, and calibration deduplication.
- A 1,200-return series takes about 0.04–0.05 seconds for a mathematical snapshot in this workspace. This is a local benchmark, not a live Android/KuCoin scan benchmark.

## Important limits

- The supplied four-hour backup has prediction probabilities and outcomes but does not contain the historical OHLC candle series needed to rerun version 3 formulas on the old forecast timestamps. Its older mathematical probabilities are therefore not imported into the new calibrator.
- The new calibration layer starts neutral and becomes active only after at least 100 version-3 horizon-labeled observations across 50 cycles. Until then, path probabilities are model estimates, not empirically calibrated probabilities.
- Engle–Granger critical values are approximate; exact finite-sample p-values are not claimed.
- Only the asset/BTC pairwise correlation is available because the current pipeline supplies one benchmark series; the matrix currently covers the Stage-25 candidate set (up to 25 symbols), not all 700+ contracts, and only includes candidates whose synchronized candle timestamps are available.
- No Android device test, APK build, or live KuCoin full-market benchmark has yet been run. These source tests do not prove trading profitability or real-trading readiness.

## Historical calibration warning (old formula version, not imported)

The supplied backup's 423 resolved predictions contain old mathematical probabilities. Their mean `math_ptp1` was 0.686 versus 0.435 observed TP1 rate; `math_ptp2` was 0.628 versus 0.206 TP2 rate; `math_ptp3` was 0.572 versus 0.073 TP3 rate; mean `math_psl` was 0.574 versus 0.565 initial-SL rate. These are warning indicators, not a clean same-horizon reliability test: the old records did not store version-3 inputs and the historical labels followed the managed trade lifecycle, not a uniformly fixed 12-bar horizon. Therefore those old probabilities are not used to calibrate version 3. The new fixed-horizon calibration must be allowed to collect its own matured observations.
