# SelfLearningTrader FIVE 1.0.234 — confidence-filtered accuracy

- Overall live forecast accuracy includes only completed LONG/SHORT forecasts whose originally issued directional probability is at least 70%.
- Forecasts below 70% remain in the learning/replay flow and do not change the displayed accuracy denominator.
- Forecasts at or above 80% are reported as a separate strict-audit cohort with TP1-or-better successes and misses counted separately.
- The originally selected direction probability is persisted at issuance; legacy records fall back to their matching `p_long`/`p_short` value.
- Training eligibility logic is not gated by the 70%/80% reporting thresholds.
- Added tests for 70%/80% cohort membership and strict outcomes.
