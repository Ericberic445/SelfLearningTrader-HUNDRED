# Mathematical model definitions — SelfLearningTrader FIVE 1.0.221

All price inputs are converted to log prices or log returns where specified. Numerical guards return neutral outputs for insufficient, constant, or invalid input instead of inventing a direction.

1. **AR(p)** — `r_t = c + Σ(phi_i r_(t-i)) + eps_t`; least-squares coefficients, one-step forecast `rhat_(t+1)`, direction score `tanh(rhat / sigma_resid)`.
2. **ARIMA(1,1,1)** — for log price `x_t`, `r_t = Δx_t`; centered return process `r_t - mu = phi(r_(t-1)-mu) + eps_t + theta eps_(t-1)`. Estimate `phi, theta` by conditional sum of squares subject to `|phi|, |theta| < 0.98`; restore `mu` in the one-step forecast.
3. **SARIMA(1,0,0)(1,0,0,12)** — `r_t = c + phi*r_(t-1) + Phi*r_(t-12) - phi*Phi*r_(t-13) + eps_t`, with `|phi|, |Phi| < 0.97`; parameters are fitted to conditional squared error.
4. **GARCH(1,1)** — `h_t = omega + alpha*eps_(t-1)^2 + beta*h_(t-1)`, `omega = variance*(1-alpha-beta)` under variance targeting, `alpha,beta >= 0`, `alpha+beta < 0.995`. Choose the fit minimizing Gaussian quasi-likelihood `mean(log(h_t) + eps_t^2/h_t)`.
5. **Hurst / fractal** — estimate slope `H` in `log(std(x_(t+lag)-x_t)) = a + H*log(lag)` across multiple lags; graph dimension `D=2-H`.
6. **Shannon entropy** — `H = -Σ p_i log2(p_i) / log2(K)` for `K` histogram bins.
7. **Markov score** — from transition counts `P(i→j)`, `score = P(up | current state) - P(down | current state)`.
8. **Bayesian sign probability** — `P(up | data) = (N_up + 1/2)/(N_up + N_down + 1)` under Jeffreys prior.
9. **Mean reversion** — estimate `Δspread_t = a + k*spread_(t-1) + eps_t`; if `k<0`, half-life is derived from the fitted AR coefficient; signal points against current standardized spread, attenuated by half-life relative to sample length.
10. **Engle–Granger** — estimate `y_t = a + b*x_t + u_t`; run ADF on `u_t`: `Δu_t = c + rho*u_(t-1) + Σ gamma_i*Δu_(t-i) + eps_t`; select lag count by AIC. A cointegration signal is enabled only when the residual ADF statistic passes the approximate critical gate.
11. **Pearson / correlation matrix** — `corr(r_asset, r_BTC)` on aligned returns; directional contribution is `corr * BTC trend`, not raw correlation. Separately, compute the symmetric Pearson matrix across Stage-25 candidate return series using exact shared candle timestamps; diagonal is 1, insufficient-overlap off-diagonals are neutral 0. Save the matrix and mean/max absolute peer-correlation summaries for diagnostics, not as direct directional votes.
12. **Kalman local linear trend** — state `[level, slope]`, transition matrix `[[1,1],[0,1]]`, observation `[1,0]`; standard predict/update covariance recursion.
13. **Haar DWT** — approximation `(a+b)/sqrt(2)`, detail `(a-b)/sqrt(2)` at each level; recent signed details are normalized by weighted multiscale detail energy.
14. **Change point** — maximum standardized difference between pre-split and post-split means over recent admissible split points.
15. **Monte Carlo** — fit AR(1) drift and GARCH(1,1) conditional variance, resample standardized empirical innovations, simulate 2,000 paths for the configured horizon.
16. **First-passage target probabilities** — for each simulated cumulative path, record the first index for each TP and SL barrier. `P(TP_k)` is the fraction with `first(TP_k) < first(SL)`; `P(SL)` is the fraction with `first(SL) <= first(TP1)` within the horizon. Same-candle actual OHLC labels resolve conservatively as SL first.
17. **Online calibration** — fit monotone empirical maps from the raw probability to the observed frequency on equal-frequency bins; Beta(1,1) smoothing; pooled-adjacent-violators; activate only with at least 100 outcomes across 50 distinct scan cycles of the same formula version.
