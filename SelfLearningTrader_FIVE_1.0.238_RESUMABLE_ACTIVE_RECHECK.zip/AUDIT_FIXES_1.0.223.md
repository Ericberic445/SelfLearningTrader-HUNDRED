# SelfLearningTrader FIVE 1.0.223 — timestamp, counter and Challenger-cycle fixes

## Fixed

- Mixed timestamp units are normalized per row to Unix seconds in the global experience archive. This covers seconds, milliseconds, microseconds and nanoseconds, and persists a migration marker.
- Temporal purge logic uses a consistent seconds unit after normalization, preventing one large microsecond timestamp from causing second-based online rows to be sorted into a false past.
- Resolved forecast counters and training batches use the same deduplicated eligible population, ordered by `resolved_at` rather than forecast creation time.
- Training now checkpoints resolved prediction IDs. A late-resolving forecast can be picked up even if its creation time predates the last training batch; already-trained IDs are not repeatedly selected merely because list indices shifted.
- Auxiliary observation batches are deferred until the next normal resolved-forecast batch instead of forcing a Master retrain that restarts the Challenger control cycle.
- Challenger forecasts are tagged with a generation. The control block is evaluated only against rows issued under that generation. Missing/unknown outcomes are not scored as zero, and too few paired outcomes yield `INSUFFICIENT_DATA`, not a false tie or winner.
- If a control cohort is incomplete at the next scheduled training point, the event is logged and the model is allowed to continue training; the program does not remain stuck waiting indefinitely for exactly 25 paired forecasts.

## Unchanged

- UI and layout.
- Original forecast ID, direction, Entry, SL, TP and horizon.
- TOP-5 ranking policy, fixed C1/C2/C3 lenses, background scan schedule and existing archives other than one-time replay timestamp normalization.

## Verification

- Python compile check passed.
- Automated test suite: `PYTHONPATH=. pytest -q` — 127 passed, 9 subtests passed.
- Android APK build and live-market validation were not performed in this environment.
