# Version 1.0.229 — automatic math-expert collection, validation, and use

This release is intended as a direct update from 1.0.227. It includes the prior individual-expert shadow instrumentation and adds an automatic, conservative promotion path.

## Workflow

1. For each eligible high-confidence Master forecast (chosen-direction confidence >=80%), record the individual math-expert predictions and a matched `MASTER_BASELINE` plan using the same ATR-based entry/SL/TP geometry.
2. Resolve every candidate against the same subsequent price path. An expert's `WAIT` is stored as an abstention rather than silently dropped from the validation window or turned into a SHORT.
3. Keep a chronological, deduplicated ledger (up to 5,000 rows) and choose candidates using earlier resolved directional samples.
4. Validate the candidate on the latest 30 eligible Master forecasts. Promotion requires at least 50 earlier directional outcomes, >=70% directional coverage in the validation window, >=5 percentage points TP1-or-better lift over the matched baseline, at least 12 discordant paired results, at least 4 net paired wins, and >=60% wins among discordant pairs.
5. If no expert passes, the current Master behavior remains unchanged and the system continues collecting.
6. If an expert passes, the program automatically uses it as a confirmation gate for Master signals whose original directional confidence is >=80%. If the chosen expert disagrees with Master or says WAIT, that candidate becomes WAIT. It never automatically reverses LONG into SHORT, and its raw score is not presented as a calibrated probability.
7. The selector status and active expert are recorded in prediction/audit data. The selector state is cached during scanning to avoid repeated reads of the growing ledger.

## Preserved constraints

- UI and scan funnel remain unchanged.
- Existing Master and Challenger mechanisms remain in place.
- Existing TP1/TP2/TP3/initial-SL outcome rules remain unchanged.
- Confidence below 80% is not added to this core expert-learning ledger as an error.
- No expert is enabled before a later chronological validation window passes.

## Limitations

This release does not guarantee that an expert will pass. Since 1.0.227 did not store the new individual-expert outcomes, the individual expert ledger starts collecting new eligible results after this update; existing aggregate lens history cannot be treated as individual-expert outcomes. Real-device and live KuCoin verification are still required after installation.
