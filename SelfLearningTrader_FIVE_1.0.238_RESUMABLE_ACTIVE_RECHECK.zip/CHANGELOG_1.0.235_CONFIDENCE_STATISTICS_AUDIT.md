# SelfLearningTrader FIVE 1.0.235 — confidence statistics audit

- Keep the existing 80%+ strict audit; strict success/error counts use the final TP/SL outcome consistently.
- Overall accuracy includes only resolved LONG/SHORT forecasts with the original chosen-direction probability at or above 70%, including exactly 70%.
- Forecasts below 70% remain in the training ledger and are excluded from overall and rolling accuracy samples.
- Rolling recent-100/recent-500 samples are ordered by resolution timestamp before selecting the latest rows.
- No UI layout changes.
