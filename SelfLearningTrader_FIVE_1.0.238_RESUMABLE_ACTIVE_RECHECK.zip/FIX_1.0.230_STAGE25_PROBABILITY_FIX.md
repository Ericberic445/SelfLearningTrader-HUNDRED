# SelfLearningTrader FIVE 1.0.230 — Stage-25 probability mapping fix

## Root cause

The 1.0.229 individual-math-expert integration treated `ModelManager.predict_bundle()`'s probability dictionary `{0: SHORT, 1: WAIT, 2: LONG}` as an array. Converting the dictionary directly with `np.asarray(..., dtype=float)` raised `TypeError` for every Stage-25 candidate. Those exceptions were swallowed by the per-candidate worker and omitted from the final aggregate error count, making the scan look like it had no valid candidates.

## Fix

- Normalize probability mappings explicitly to `[SHORT, WAIT, LONG]` after each `predict_bundle()` call.
- Preserve compatibility with sequence/array probabilities.
- Record Stage-25 candidate errors and include them in scan diagnostics/error counts.
- No UI, scan funnel, direction thresholds, or TP/SL semantics changed.
