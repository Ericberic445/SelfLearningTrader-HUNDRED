# SelfLearningTrader FIVE 1.0.237 — pending resolution performance fix

- `resolve_all_pending()` now skips `resolve_pending()` for contracts with no eligible active or post-SL recheck IDs. This avoids unnecessary candle requests for empty or fully queued pending files.
- Existing queued verification status and queue positions are still written before the skip. Eligible active forecasts and pending post-SL rechecks continue through the original resolver unchanged.
- Added runtime start/duration diagnostics around pending resolution to identify future stalls before `FULL_SCAN_START`.
- No UI, TOP-5 ranking, forecast direction, TP/SL, confidence, or model-training rules changed.
