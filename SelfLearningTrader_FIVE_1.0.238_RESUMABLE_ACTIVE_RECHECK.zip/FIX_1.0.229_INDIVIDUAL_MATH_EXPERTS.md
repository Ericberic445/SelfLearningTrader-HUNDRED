# SelfLearningTrader FIVE 1.0.229 — individual mathematical experts

## Why
The existing C1/C2/C3 lenses average several mathematical outputs, so Master cannot measure their individual contribution.

## Added
- 13 standalone directional candidates from existing model outputs: Markov, AR(3), ARIMA(1,1,1), SARIMA, mean reversion, cointegration, trend deviation, Haar wavelet, Kalman trend, Bayesian sign, Monte Carlo direction, Hurst-conditioned trend persistence, and benchmark-conditioned correlation.
- Two composite controls: `MATH_DIRECTION_BASELINE` and `MATH_CONSENSUS_BASELINE`.
- Per-candidate Entry/SL/TP plans and outcome resolution on the same future OHLC path.
- Separate `math_expert_predictions` / `math_expert_outcomes` history fields and `math_experts` performance ledger.
- Expert performance learning ledger accepts only rows whose selected Master direction confidence is at least 80%. Raw expert scores are not presented as calibrated probabilities.

## Safety
This is shadow-only. Individual experts do not change live signals, existing lens equations, selector choices, UI, TOP-5, or the established TP1/TP2/TP3/SL outcome rules. Risk/regime metrics and TP/SL path probabilities are not treated as independent direction votes.

## Promotion gate
Do not use an individual expert to change live forecasts until enough eligible results exist and a time-ordered out-of-sample comparison shows an advantage over Master under the same outcome rules.
