# SelfLearningTrader FIVE 1.0.231 — scan cadence and TOP-5 publication

## Changes

- Publish and persist a validated TOP-5 in service state immediately after lifecycle persistence succeeds; log `TOP5_ISSUED` with cycle, count, and prediction IDs.
- Move active-forecast observation rechecks to a single background worker. The scan loop no longer waits for a 55-minute recheck before updating the displayed TOP-5 or proceeding to the next cycle. A second recheck batch is skipped with a diagnostic while the previous batch is still running, avoiding an unbounded backlog.
- Remove repeated `resolve_all_pending()` and retraining calls from the 20-second scan-wait loop. Those expensive operations were being invoked in the same thread that must honor the 30-minute scan cadence. They still run at the cycle boundary.
- Guard `_persist_scan_prediction()` with the engine's shared ledger lock so a background recheck and the scan cannot concurrently append/reconcile the same prediction ledgers.
- Keep the prior TOP-5 visible if a cycle produces no validated candidates; do not fabricate LONG/SHORT predictions or pad the list with unvalidated rows.

## Validation

- `python -m pytest -q`: **161 passed, 9 subtests passed**.
- Syntax compilation and Android APK build are separate checks; this source archive does not claim an APK was built or device-tested.

## Operational verification

After installing a build from this source, verify in `runtime_diagnostics.log`: `TOP5_ISSUED cycle=N count=...` should appear immediately after each successful persistence, and `ACTIVE_FORECAST_RECHECK_DONE` should be logged separately. Compare scan start timestamps; the target cadence is 1800 seconds from one scan start to the next, subject to Android OS/service interruption and a full scan taking longer than the interval.
