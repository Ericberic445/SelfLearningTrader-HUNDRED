# SelfLearningTrader FIVE 1.0.227 — MODEL-stage performance and timeout migration

## Root cause found in 2026-10-16 backup

The 50-candidate MODEL stage created a new `LearningEngine` for every finalist. Each constructor repeated the global legacy-experience migration, full prediction-ledger reconciliation, and Challenger-state reconciliation over the same runtime archive. The long-lived background-service engine had already performed those operations at startup, so repeating them for each coin was redundant work and a major source of MODEL-stage timeouts.

The backup also contained `scan_model_stage_timeout_seconds=900` in the persisted runtime settings, which overrode the shipped 1800-second default.

## Changes

- Per-contract MODEL engines remain isolated, preserving symbol-specific exchange and prediction paths.
- Added `initialize_ledgers=False` for scan worker engines. The service engine remains responsible for one-time migration/reconciliation; quick/deep scan workers do not repeatedly walk every prediction archive.
- Added a safe settings migration: the known legacy value `900` becomes `1800` in memory and in `settings.json`; other custom timeout values and all other settings remain unchanged.
- Both UI startup and background-service startup apply the same migration. The service logs the effective `model_stage_timeout_seconds` value.
- Kept the scan funnel, ranking, model logic, UI, and forecast semantics unchanged.

## Verification

- Python compileall: passed.
- Full automated suite: 142 tests passed, 9 subtests passed.
- Focused scan/timeout tests: 12 passed.
- ZIP integrity: verified after packaging.
- Not verified in this build: APK installation on the tablet or a live KuCoin scan. A live scan must confirm `deep=50`, `stage25=25`, `top5=5`, and `model_stage_timed_out=False`.
