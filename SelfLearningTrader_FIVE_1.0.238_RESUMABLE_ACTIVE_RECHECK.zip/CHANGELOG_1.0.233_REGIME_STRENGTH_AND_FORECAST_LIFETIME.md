# SelfLearningTrader FIVE 1.0.233 — regime-strength and forecast-lifetime improvements

## Existing regime logic improved (no duplicate classifier)
- Reuses the current causal regime features: local and higher-timeframe trend, efficiency, persistence, reversals, and MTF alignment.
- Adds diagnostic trend-strength values for LONG and SHORT and a quality label (`STRONG_UP`, `STRONG_DOWN`, `MODERATE_*`, `RANGE_OR_CHOP`, or `WEAK_OR_TRANSITIONAL`).
- A chop estimate modestly increases WAIT probability.
- A strong aligned trend modestly reinforces the existing Master direction; unvalidated heuristic evidence receives only a small nudge. It cannot reverse or override Master.
- Exposes the confirmation/chop boosts in prediction diagnostics.

## Forecast lifecycle
- Adds configurable `max_forecast_lifetime_bars` (default 96 five-minute bars = 8 hours).
- A forecast with no TP/SL terminal event expires after its maximum lifetime instead of occupying an active slot indefinitely.
- If TP1/TP2 was already reached, expiry preserves that milestone as partial success; it does not imply TP3 success.
- If no TP milestone was reached, the forecast is archived as `EXPIRED_STALE`, excluded from training and not counted as a win or loss.
- A strong, aligned issue-time trend may receive up to twice the default lifetime; choppy/opposite regimes do not receive the extension.
- Original Entry, SL, TP levels, and initial LONG/SHORT direction are not rewritten.

## Validation
- Python compileall passed.
- Test suite: 169 passed, 9 subtests passed.
- APK/device build was not performed in this environment.
