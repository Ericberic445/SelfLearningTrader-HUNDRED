# SelfLearningTrader FIVE 1.0.224 — ledger reconciliation and market-regime validation

## Changes

- One canonical population of unique, eligible resolved forecast IDs now drives retraining, resolved counters, audit reconciliation and current archive statistics.
- Resolved forecasts with `post_sl_recheck_pending=true` are not eligible training samples. Existing replay rows for these forecasts are moved to `data/pending_post_sl_trade_rows.npz` and remain recoverable; they can enter active experience only after the post-SL recheck finishes.
- Replay rows that do not correspond to eligible resolved forecast IDs are quarantined separately. Missing eligible archive rows are rebuilt from prediction logs, and missing audit events are backfilled idempotently.
- Current archive counts and outcome counts are written separately from cumulative historical counters. `replay_rows` now reflects the current active archive size.
- Legacy active Challenger states with no generation field are migrated. Both prediction-history and pending-resolver copies are tagged with the same generation.
- Challenger comparisons require paired resolved outcomes. The engine waits for a full 25-pair control cohort; if a bounded cohort of 75 resolved candidates still cannot provide 25 pairs, it records an incomplete control rather than inventing a score. Auxiliary observations do not reset the cohort.
- Regime-model validation includes per-class precision/recall/F1, balanced accuracy and comparison against the majority baseline. Poorly validated candidates are not deployed. The saved backup model did not pass validation, so its weights are not promoted.
- Missing regime descriptors are no longer silently converted to zero. The old behavior could produce the same confident RANGE result for unrelated coins. An unvalidated fallback is now diagnostic only and activates a conservative WAIT guard until a regime model passes its independent validation gate.
- Direction validation reports SHORT/WAIT/LONG class metrics and counts neutral imputations. The same neutral imputation is applied to training and held-out rows.

## Replay against the supplied backup (2026-10-13 18:42)

- Active experience before reconciliation: 564 rows (547 `TRADE`, 17 `ONLINE_DIRECTION_OBSERVATION`).
- 35 `TRADE` rows corresponded to resolved initial-SL forecasts whose post-SL recheck was still pending. They were quarantined rather than trained prematurely.
- Active experience after reconciliation: 529 rows (512 eligible `TRADE`, 17 online direction observations).
- Canonical eligible resolved forecast IDs: 512. Resolved audit IDs: 512. Missing eligible archive IDs: 0. Missing audit IDs: 0.
- Challenger legacy generation was migrated to generation 1; 25 prediction records were tagged. At replay time 10 eligible paired results were available and 12 new eligible outcomes remained since the last retrain checkpoint of 500. The control result remains pending; no winner was declared.
- Direction/WAIT independent chronological validation on the reconciled archive: 529 rows, 423 train rows, 106 validation rows, 3,600-second purge. Accuracy 39.62% vs 48.11% majority baseline; balanced accuracy 51.54% vs 33.33% baseline; directional precision 39.42%; action rate 98.11%. WAIT recall was 1.96%, confirming that the current direction model rarely abstains.
- Outcome-head validation: 37.08% vs 53.93% majority baseline.
- Regime model pool: 60,000 rows across 217 contracts. Chronological purged validation: 7,562 rows. Accuracy 29.15% vs 35.29% baseline; balanced accuracy 26.88% vs 25.00% baseline. TREND_DOWN recall 31.63%, RANGE 36.83%, TRANSITION 26.15%, TREND_UP 12.90%. This candidate is rejected and must not be used as a trusted learned regime classifier.
- The simple causal fallback was also replayed against the same held-out period: accuracy 32.94%, below the 35.29% baseline, with TREND_UP recall 2.13%. It is therefore diagnostic only; until a regime model passes validation, the decision layer uses the conservative WAIT guard.

## Verification

- `python -m compileall -q app tests` — passed.
- `PYTHONPATH=. pytest -q` — 135 passed, 9 subtests passed.
- ZIP integrity checked after packaging.
- Android APK build and live-device runtime validation were not performed. Do not treat the source tests as proof of live trading readiness.

## Unchanged

- UI/layout and controls.
- Original forecast direction, ID, Entry, SL, TP and horizon.
- TP1/TP2/TP3 success semantics.
- TOP-5 ranking policy and fixed C1/C2/C3 lens equations.
