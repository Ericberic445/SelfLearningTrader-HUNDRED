"""Helpers for the confidence-filtered TOP-5 history view."""


def forecast_probability(data):
    """Return the issuance probability of the selected direction as 0..1."""
    data = data or {}
    value = data.get('issued_prediction_probability')
    if value in (None, ''):
        value = data.get('prediction_probability')
    pred = str(data.get('prediction') or 'WAIT').upper()
    if value in (None, ''):
        key = 'p_long' if pred == 'LONG' else 'p_short' if pred == 'SHORT' else 'p_wait'
        value = data.get(key)
    try:
        probability = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    if probability > 1.0 and probability <= 100.0:
        probability /= 100.0
    if not 0.0 <= probability <= 1.0:
        return None
    return probability


def eligible_history_items(items, recover=None, minimum=0.70, limit=100):
    """Return eligible LONG/SHORT rows, retaining their original issuance confidence."""
    eligible = []
    for original in list(items or []):
        item = dict(original)
        probability = forecast_probability(item)
        if probability is None and recover is not None:
            recovered = recover(item)
            probability = forecast_probability(recovered)
        direction = str(item.get('prediction') or 'WAIT').upper()
        if direction in ('LONG', 'SHORT') and probability is not None and probability >= float(minimum):
            item['issued_prediction_probability'] = probability
            item['prediction_probability'] = probability
            eligible.append(item)
    return eligible[-max(0, int(limit)):]
