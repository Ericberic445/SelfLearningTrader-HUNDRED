# SelfLearningTrader FIVE 1.0.220 — post-run regression fixes (work in progress)

## Findings from the supplied four-hour runtime/backup
- `top5_history.json` contained 20 events, but repeated the same five persisted prediction IDs across 19 entries for cycle 60; only cycle 71 added another five predictions.
- `top5_last100.json` contained 100 rows but only 10 unique prediction IDs. The repeated rows were not 100 new selections.
- The service state had advanced to cycle 139 while `last_top5_cycle` remained 60. The supplied runtime also contained a MODEL phase that had remained at 45/50 for an extended period before recovery.

## Changes in this work copy
- TOP-5 history loading removes exact replay duplicates from the history and flat 100-position list, keeping the newest copy. It does not fabricate positions to refill 100 slots and does not delete prediction, pending, or training archives.
- `_last_saved_cycle` is restored from persisted history.
- `_record_top5_history` is idempotent by completed cycle; legacy/manual calls without a cycle deduplicate only when the exact persisted prediction IDs match. It does not suppress legitimate future scans that select the same symbols with new prediction IDs.
- The MODEL stage has a configurable bounded deadline (`scan_model_stage_timeout_seconds`, default 900 seconds, maximum 1800). If exceeded, pending/unsubmitted contracts are recorded as timeout errors and the scan continues with candidates already completed instead of waiting forever.
- Stage-25 math validation also has a bounded deadline (`scan_math_stage_timeout_seconds`, default 300 seconds, maximum 900); completed candidates remain usable if another validation worker stalls. User cancellation no longer waits for stuck MODEL or Stage-25 workers.
- Diagnostics and the `FULL_SCAN_DONE` runtime event include both timeout statuses.
- Android package version was advanced consistently to `1.0.220` / numeric version code `10220`; both config files now report the same version.
- No UI layout changes were made. TP/SL execution and result definitions remain unchanged. TOP-5 persistence and bounded scan-stage timeout logic were changed; the Android foreground-service startup implementation itself was not rewritten.

## Verification
- `python -m compileall -q app main.py` — passed.
- `PYTHONPATH=. pytest -q` — final result **102 passed, 9 subtests passed**.
- Regression tests with deliberately slow MODEL and Stage-25 workers confirm that the scan returns after the configured timeout rather than waiting for a slow worker; a separate test confirms user cancellation does not wait for a slow MODEL worker.
- Replaying the supplied backup through the history cleanup yields 2 distinct scan cycles and 10 actual positions, rather than 100 repeated rows.

## Not claimed
- No Android device run or GitHub Actions APK build has been performed for these changes.
- The live KuCoin scan has not been benchmarked in this work copy.
- The supplied validation metrics do not support marking the model ready for real trading.

## Full mathematical / self-learning audit additions (2026-10-12)

### Source-level defects corrected in this work copy
- The AR feature previously returned only the first fitted regression coefficient. That coefficient is not a one-step forecast and its sign was being used as if it were directional. `_ols_ar` now returns a bounded volatility-normalized one-step forecast signal.
- Hurst/fractal, entropy, GARCH volatility, change-point strength, return/absolute-return correlation, and raw asset/BTC correlation were previously mixed into directional consensus as if they were LONG/SHORT signals. Risk/regime-only metrics no longer directly bias direction. Hurst is interacted with observed trend; asset/BTC correlation is conditioned on benchmark trend; volatility/entropy/change-point stay in the risk/WAIT layer.
- Stage-25 TP1/TP2/TP3/SL path probabilities previously used fixed 0.3/0.6/0.9% targets and 0.3% stop distance regardless of the actual ATR-based plan. Stage-25 now passes the current forecast's actual log-price distances into the Monte Carlo path-touch calculation.
- Stage-25 now performs a bounded direction/math consistency loop. If the model and direction-conditioned math fail to converge within three passes, it forces WAIT and records `prediction_guard=math_direction_nonconvergent` instead of publishing an unstable directional signal.
- Selector feature labels did not match the actual selector-vector order (the lens probability names were grouped differently and a duplicate long-probability group was present). The names now match the vector layout. Numeric vector order and feature count remain unchanged.
- An unrecovered initial-SL failure previously taught the direction head to repeat the original LONG/SHORT label at reduced weight. It now teaches WAIT for the direction head while preserving the true initial-SL label for the separate trade-outcome head. If post-SL recovery confirms the direction, that confirmation remains learnable.
- The Master-owned 8-combination selector now records prediction timestamps and requires a later chronological holdout with a 12-bar purge and a minimum improvement over the majority baseline before it is used for live decisions. Legacy selector rows without timestamps remain available for training but are not counted as independent validation evidence. Until enough new timestamped outcomes validate the selector, the Master falls back to the non-selector path.

### Verification run after changes
- `python -m compileall -q app main.py`: passed.
- `PYTHONPATH=. pytest -q`: final result **102 passed, 9 subtests passed**.
- Mathematical stress test: 180 synthetic cases across input lengths 0, 1, 19, 20, 32, 40, 120, 500 and 1200; no non-finite outputs, probability bounds violations, or TP probability ordering violations.
- Selector feature-name/vector dimensions: 67/67 and regression test passed.

### What the model actually learns
- The global Master direction head updates from resolved forecast/observation experience in batches; default resolved-trade batch size is 25.
- The separate outcome head learns the verified SL/TP1/TP2/TP3/TP3+ outcome class. Online direction observations are excluded from that outcome head.
- The Master-owned selector learns among the eight Master+C1/C2/C3 combinations using their recorded outcomes on the same observed price path.
- C1/C2/C3 themselves are fixed mathematical lenses; they do not individually train their own weights. The Master and selector learn how to use them. This is the current architecture, not autonomous learning of every formula.
- ARIMA/SARIMA, GARCH and cointegration remain deterministic lightweight proxies. They are not full maximum-likelihood ARIMA/SARIMA fits, a fitted GARCH model, or a formal Engle-Granger/ADF cointegration test. Monte Carlo TP/SL estimates are path-model estimates and have not been probability-calibrated on a large untouched live sample.

### Real-world forecast quality from the supplied four-hour backup
- 423 unique resolved outcomes in the audit: INITIAL_SL 239; TP1 97; TP2 56; TP3_PLUS 31.
- TP1 or better: 184/423 = 43.5%. Initial SL before TP1: 239/423 = 56.5%.
- Latest independent directional validation recorded in the backup: 102 validation rows, accuracy 0.50, balanced accuracy 0.461, directional precision 0.521, action rate 0.941.
- These metrics do **not** support real-trading readiness. The stricter readiness gate should remain closed.

### Still not verified
- No live KuCoin full-market benchmark has been run from this offline workspace.
- No Android device run and no GitHub Actions/APK build has been performed for this work copy.
- Real profitability after fees, funding, slippage, leverage and liquidation risk is not established by these code tests or by the four-hour sample.
- Additional selector validation tests verify that in-sample accuracy alone cannot activate the selector and that the chronological validation applies the horizon purge.
- Monte Carlo seeds are now derived from a stable contract hash, so the same contract/data produces reproducible simulations across Android process restarts.
- The Kalman residual is normalized by price-series variation, not the absolute log-price level. This prevents the same relative movement from appearing artificially weaker on a higher-priced coin.
- A newly completed TOP-5 cycle now overwrites stale issuance timestamps copied from older rows; manual legacy history without a new cycle still preserves the original issue time.
- Final verification after these additions: **102 tests passed, 9 subtests passed**; compileall passed; 180 mathematical stress cases had zero failures.
