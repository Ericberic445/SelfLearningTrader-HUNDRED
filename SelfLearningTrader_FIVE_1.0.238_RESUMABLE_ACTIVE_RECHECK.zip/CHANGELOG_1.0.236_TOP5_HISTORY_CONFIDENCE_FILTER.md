# SelfLearningTrader FIVE 1.0.236 — TOP-5 history confidence filter

- The menu `ПОСЛЕДНИЕ 100 МОНЕТ TOP-5` displays only issued LONG/SHORT forecasts with selected-direction probability >= 70%, including exactly 70%. WAIT/sideways predictions are excluded from this actionable history view, even when their WAIT probability is high.
- The displayed row now includes the issuance-time probability beside the coin and direction.
- Expanded history details also show the probability at forecast creation.
- The issuance-time probability is frozen in history so later verification/rechecks cannot change the percentage that the user originally saw.
- Low-confidence forecasts remain in the full prediction/training data and do not consume slots in the filtered 100-item view.
- WAIT predictions and forecasts below 70% remain available in the underlying prediction/training history; only this actionable LONG/SHORT menu excludes them. The separate accuracy/learning records are not changed by this menu filter.
- The live TOP-5 selection, scanner logic, and UI layout are otherwise unchanged.
