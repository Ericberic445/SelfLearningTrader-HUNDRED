# SelfLearningTrader FIVE 1.0.228 — Selector learning integrity

- Master Selector training labels are now created only when one of the eight Master/fixed-lens combinations has a uniquely better realized outcome.
- Ties are skipped rather than silently labeled `MASTER` by `argmax` ordering.
- Legacy selector experience without schema 4 is discarded because its historical labels may contain artificial MASTER wins.
- The selector remains unavailable until timestamped out-of-sample validation beats the configured baseline by the required margin.
- New diagnostics report `new_unique_rows`, `ambiguous_rows_skipped`, and class-diversity accumulation status.
- UI, fixed C1/C2/C3 formulas, LONG/SHORT/WAIT semantics, and TP/SL outcome rules are unchanged.

This is a data-integrity correction, not a claim that forecast accuracy has already improved. The selector must accumulate enough non-tied, timestamped outcomes and pass temporal holdout validation before it is used.
