# SelfLearningTrader FIVE 1.0.225 — regime handoff, readiness and progress audit

## Changes

1. **Regime feature handoff:** Stage-25 re-evaluation now passes all `REGIME_FEATURES` through a separate `regime_features` namespace. Missing values remain NaN. The direction Master retains its existing neutral-zero fallback. `ModelManager._regime_scalar()` prioritizes this explicit namespace.
2. **Post-SL readiness accounting:** readiness uses unique, final LONG/SHORT outcomes, excluding `post_sl_recheck_pending`, administrative/statistics exclusions, state-change-only rows and invalid outcomes. `training_eligible_resolved` is reported separately because training also requires feature-complete rows.
3. **Independent regime validation:** validation metadata now records the chronological cutoff, 3,600-second purge gap for the 12-bar horizon, and confirms future labels are not inputs and held-out rows are not used to fit the validation model.
4. **Progress labels:** the engine emits `MODEL` progress as its own 0/50 stage and `MATH25` as its own 0/25 stage. Both UI entry files show the stage name and stage-local denominator. They no longer display a combined 75-candidate pool.
5. **Timeout mitigation:** `scan_model_workers` is set to 3 in both config files; the bounded 900-second model-stage timeout remains in place. This is a mitigation, not a claim that live network timeouts are eliminated.
6. **Release identity:** version 1.0.225, Android version code 10225. UI layout unchanged.

## Verification on the supplied 2026-10-14 backup

- Eligible completed actionable outcomes: **532**.
- Feature-complete training-eligible resolved rows: **532**.
- Resolved records awaiting post-SL recheck: **34**. These are excluded from the completed readiness denominator.
- The five saved TOP-5 rows include three rows with current regime feature sets and two older preserved rows without the three derived regime descriptors. The latter correctly remain `TRANSITION` with `insufficient_data`; old immutable forecasts were not rewritten. Current feature-complete rows reach the regime gate and are marked `unvalidated_fallback_wait_guard` because the saved model has not passed validation.

## Independent regime holdout

Re-ran training/validation in an isolated temporary directory using the saved 60,000-row, 330-contract regime pool and the code's chronological purged holdout:

- Validation accuracy: **33.17%**
- Majority-class baseline: **38.17%**
- Balanced accuracy: **24.52%**
- `TREND_UP` recall: **0.30%**
- Decision: **rejected_validation**

The classifier is intentionally **not** promoted to live inference. The code now passes its features correctly and records validation protocol, but the current data/model combination still fails the quality gate. This release does not claim that market-regime recognition is solved or that the app is ready for real trading.

## Automated checks

- `PYTHONPATH=. pytest -q`: **139 passed, 9 subtests passed**.
- Python syntax compilation: `main.py`, `app/main.py`, `app/core/engine.py`, `app/core/model.py` succeeded.
- Release identity check: version and numeric code consistent.
- ZIP integrity: checked after packaging.

## Not verified here

- No Android APK was built in this environment.
- No live KuCoin scan was run; therefore the 3-worker change has not been confirmed to eliminate runtime timeouts.
- The regime classifier remains rejected until a future independent holdout beats baseline and clears trend-recall gates.
