# SelfLearningTrader FIVE 1.0.229 — automatic individual math-expert learning

## What this release does

- Starts collecting per-prediction outcomes for individual mathematical experts and a matched `MASTER_BASELINE` plan.
- Records only learning rows where the original Master directional confidence is at least 80%, preserving the configured training rule.
- Keeps expert WAIT predictions in the chronological ledger as abstentions; they cannot disappear from the validation window and inflate apparent accuracy.
- Automatically selects a candidate using earlier resolved rows, then checks it on the latest 30 eligible rows that were not used for that candidate's training ranking.
- Requires at least 50 earlier directional outcomes, at least 70% directional coverage in the 30-row validation window, at least a 5 percentage-point TP1-or-better lift over the matched baseline, at least 12 discordant outcomes, at least 4 net paired wins, and at least 60% wins among discordant pairs.
- If no expert passes, Master stays unchanged and collection continues.
- If an expert passes, it is automatically used as a conservative confirmation gate on Master signals with original directional confidence >=80%. An expert disagreement or WAIT converts that candidate to WAIT; it never automatically reverses LONG to SHORT or claims the expert's raw score is a calibrated probability.
- Selector state is cached in memory during scanning to avoid repeatedly reading the growing ledger and slowing the scan.
- Individual model outcome records are deduplicated by prediction ID and capped at 5,000 chronological rows.
- WAIT from an individual expert is correctly recorded as WAIT, not misclassified as SHORT.

## Preserved behavior

- Existing UI is unchanged.
- Existing Master/Challenger learning is not replaced.
- TP1 counts as success; TP2/TP3 and initial SL retain the existing outcome semantics.
- The expert learner does not treat confidence below 80% as an error for core training.
- No expert is activated before its independent chronological validation passes.

## Verification

Run the complete test suite and Python compilation before release. Runtime promotion still requires live resolved forecasts; this release cannot guarantee that any expert will pass validation, and Master remains the fallback if none does.
