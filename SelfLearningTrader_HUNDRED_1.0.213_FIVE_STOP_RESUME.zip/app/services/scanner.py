import json
import os
import time
from pathlib import Path
import threading
import uuid
import traceback

STATE_NAME = 'background_scan_state.json'
CONTROL_NAME = 'background_scan_control.json'
LOCK_NAME = 'background_scan.lock'
MANUAL_REQUEST_NAME = 'manual_prediction_request.json'
MONITOR_REQUEST_NAME = 'prediction_monitor_request.json'
POSITION_REQUEST_NAME = 'position_monitor_request.json'
MONITOR_EVENTS_DIR = 'monitor_events'
HEARTBEAT_SECONDS = 2.0
STALE_SECONDS = 12


def app_private_dir():
    # The UI and the Android service MUST use exactly the same persistent
    # runtime directory.  ANDROID_PRIVATE is the app's private root; the UI
    # stores runtime state under stl_generational_v15_3/runtime.  Keeping the
    # same path here is critical: otherwise the service can be alive and
    # writing heartbeats while the UI reads a different directory and shows
    # "В фоне — Ожидание" forever.
    p = os.environ.get('ANDROID_PRIVATE')
    if p:
        return Path(p) / 'stl_generational_v15_3'
    p = os.environ.get('ANDROID_APP_PATH')
    if p:
        return Path(p) / 'stl_generational_v15_3'
    return Path.home() / '.stl_generational_v15_3'

ROOT = app_private_dir() / 'runtime'
ROOT.mkdir(parents=True, exist_ok=True)
STATE = ROOT / STATE_NAME
CONTROL = ROOT / CONTROL_NAME
LOCK = ROOT / LOCK_NAME
MANUAL_REQUEST = ROOT / MANUAL_REQUEST_NAME
MONITOR_REQUEST = ROOT / MONITOR_REQUEST_NAME
POSITION_REQUEST = ROOT / POSITION_REQUEST_NAME
REAL_POSITIONS = ROOT / 'real_positions.json'
MONITOR_EVENTS = ROOT / MONITOR_EVENTS_DIR
MONITOR_EVENTS.mkdir(parents=True, exist_ok=True)
STATE_LOCK = threading.Lock()
RUNTIME_LOG = ROOT / 'runtime_diagnostics.log'
RUNTIME_LOG_LOCK = threading.Lock()

def runtime_log(message, level='INFO'):
    """Append a timestamped runtime diagnostic line without ever crashing the service."""
    try:
        line = f"{time.strftime('%Y-%m-%d %H:%M:%S')} [{level}] {message}"
        with RUNTIME_LOG_LOCK:
            with RUNTIME_LOG.open('a', encoding='utf-8') as fh:
                fh.write(line + '\n')
            try:
                lines = RUNTIME_LOG.read_text(encoding='utf-8').splitlines()[-120:]
                data = read_json(STATE, {})
                data['runtime_log_tail'] = lines
                data['runtime_log_path'] = str(RUNTIME_LOG)
                write_json(STATE, data)
            except Exception:
                pass
    except Exception:
        pass



def write_json(path, data):
    tmp = path.with_suffix(path.suffix + '.tmp')
    try:
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
        tmp.replace(path)
    except Exception:
        try:
            path.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
        except Exception:
            pass


def read_json(path, default=None):
    try:
        return json.loads(path.read_text(encoding='utf-8')) if path.exists() else (default if default is not None else {})
    except Exception:
        return default if default is not None else {}


def control_data():
    return read_json(CONTROL, {})


def stopped():
    return bool(control_data().get('stop'))


def set_state(**kwargs):
    with STATE_LOCK:
        data = read_json(STATE, {})
        data.update(kwargs)
        now=int(time.time())
        data['updated_at'] = now
        data['heartbeat_at'] = now
        write_json(STATE, data)


def acquire_service_lock(instance_id):
    payload={'instance_id':instance_id,'created_at':int(time.time())}
    try:
        fd=os.open(str(LOCK), os.O_CREAT|os.O_EXCL|os.O_WRONLY)
        os.write(fd, json.dumps(payload).encode('utf-8'))
        os.close(fd)
        return True
    except FileExistsError:
        old=read_json(LOCK,{})
        state=read_json(STATE,{})
        try:
            engine.persist_scan_predictions(list(state.get('last_top5') or [])[:5])
        except Exception:
            pass
        heartbeat=int(state.get('heartbeat_at',0) or 0)
        owner=str(old.get('instance_id',''))
        if heartbeat and int(time.time())-heartbeat <= STALE_SECONDS and owner:
            return False
        try: LOCK.unlink()
        except Exception: pass
        try:
            fd=os.open(str(LOCK), os.O_CREAT|os.O_EXCL|os.O_WRONLY)
            os.write(fd, json.dumps(payload).encode('utf-8')); os.close(fd)
            return True
        except Exception:
            try:
                if 'fd' in locals(): os.close(fd)
            except Exception: pass
            return False
    except Exception:
        return False


def release_service_lock(instance_id):
    try:
        owner=read_json(LOCK,{}).get('instance_id')
        if owner == instance_id:
            LOCK.unlink()
    except Exception:
        pass


def acquire_wakelock():
    try:
        from jnius import autoclass
        PythonActivity = autoclass('org.kivy.android.PythonActivity')
        Context = autoclass('android.content.Context')
        activity = PythonActivity.mActivity
        pm = activity.getSystemService(Context.POWER_SERVICE)
        lock = pm.newWakeLock(1, 'SelfLearningTraderHundredV15_3::ContinuousLearning')
        lock.setReferenceCounted(False)
        lock.acquire()
        return lock
    except Exception:
        return None


def _prediction_map(ids):
    wanted=set(ids)
    found={}
    if not wanted:
        return found
    for path in ROOT.joinpath('logs').glob('*_predictions.json'):
        try:
            rows=json.loads(path.read_text(encoding='utf-8'))
        except Exception:
            continue
        for row in rows:
            if row.get('id') in wanted:
                found[row['id']]=row
    return found


def _sleep_or_stop(seconds, cancel_event):
    end=time.monotonic()+seconds
    while time.monotonic()<end:
        if stopped():
            cancel_event.set(); return False
        time.sleep(min(2.0, max(0.1,end-time.monotonic())))
    return True


def process_manual_request(cfg, request):
    """Run one user-requested coin prediction in an isolated engine.

    It deliberately uses a separate exchange/engine instance, so it does not
    change the coin currently being scanned by the automatic market worker.
    Model files are replaced atomically by ModelManager, making a concurrent
    read safe while automatic retraining is happening.
    """
    req_id=str(request.get('request_id',''))
    symbol=str(request.get('symbol','')).strip().upper()
    if not req_id or not symbol:
        raise ValueError('Пустой запрос ручного прогноза')
    ex=KuCoin(symbol)
    ex._request_gap=max(float(getattr(ex,'_request_gap',0.10)),0.20)
    eng=LearningEngine(ROOT,ex,cfg)
    eng.set_symbol(ex.futures_symbol)
    if not eng.mm.has_champion():
        eng.train_from_fresh()
    row=eng.predict_and_store(manual=True,source='manual')
    row['request_id']=req_id
    return row


def manual_worker_loop(cfg, heartbeat_state=None):
    active=False
    while True:
        if stopped(): return
        try:
            if MANUAL_REQUEST.exists() and not active:
                req=read_json(MANUAL_REQUEST,{})
                if req:
                    try: MANUAL_REQUEST.unlink()
                    except Exception: pass
                    active=True
                    set_state(manual_prediction_active=True, manual_prediction_result={'request_id':req.get('request_id'),'symbol':req.get('symbol'),'started_at':int(time.time())})
                    try:
                        result=process_manual_request(cfg,req)
                        set_state(manual_prediction_active=False, manual_prediction_result={'request_id':req.get('request_id'),'symbol':req.get('symbol'),'prediction':result,'completed_at':int(time.time())})
                    except Exception as exc:
                        set_state(manual_prediction_active=False, manual_prediction_result={'request_id':req.get('request_id'),'symbol':req.get('symbol'),'error':str(exc),'completed_at':int(time.time())})
                    active=False
        except Exception as exc:
            set_state(manual_prediction_active=False, manual_prediction_error=str(exc))
            active=False
        time.sleep(1.0)


def _append_real_position(position, prediction, status='CLOSED'):
    """Persist manual real-position results separately from model prediction statistics."""
    try:
        rows=read_json(REAL_POSITIONS,[])
        if not isinstance(rows,list): rows=[]
        item=dict(position or {})
        item['status']=status
        item['prediction_id']=(prediction or {}).get('id')
        item['symbol']=(prediction or {}).get('symbol')
        item['prediction']= (prediction or {}).get('prediction')
        item['recorded_at']=int(time.time())
        rows.append(item)
        write_json(REAL_POSITIONS,rows[-1000:])
    except Exception:
        pass

def _append_monitor_event(prediction_id, event):
    try:
        path=MONITOR_EVENTS / f'{prediction_id}_events.json'; rows=read_json(path,[])
        if not isinstance(rows,list): rows=[]
        rows.append(event)
        try: max_events=int(read_json(ROOT/'settings.json',{}).get('monitor_max_events_per_prediction',500))
        except Exception: max_events=500
        write_json(path,rows[-max_events:])
    except Exception: pass


def _monitor_metrics(ex, symbol):
    """Live snapshot used by the selected-signal and real-position monitor."""
    ex.set_symbol(symbol)
    candles = ex.candles('5min', limit=80)
    close = float(candles['close'][-1])
    volume = float(candles['volume'][-1])
    prev_volume = float(candles['volume'][-2]) if len(candles['volume']) >= 2 else 0.0
    prev_close = float(candles['close'][-2]) if len(candles['close']) >= 2 else close
    book = float(ex.orderbook_imbalance())
    rsi = macd = atrpct = trend = volz = ret3 = 0.0
    try:
        from core.features import add_features
        x = add_features(candles)
        i = len(x['time']) - 1
        rsi = float(x['rsi'][i]); macd = float(x['macd'][i]); atrpct = float(x['atrpct'][i])
        trend = float(x['trend'][i]); volz = float(x['volz'][i]); ret3 = float(x['ret3'][i])
    except Exception:
        pass
    return {
        'time': int(time.time()), 'price': close, 'volume_5m': volume,
        'prev_volume_5m': prev_volume,
        'price_change_pct_from_prev_5m': ((close / prev_close) - 1.0) * 100.0 if prev_close else 0.0,
        'orderbook_imbalance': book, 'rsi': rsi, 'macd': macd, 'atrpct': atrpct,
        'trend': trend, 'volz': volz, 'ret3': ret3,
    }


def _monitor_alerts(prev, cur, prediction, cfg):
    if not prev:
        return []
    alerts = []
    p0 = float(prev.get('price', cur['price']) or cur['price']); p1 = float(cur['price'])
    price_delta = (p1 / p0 - 1.0) * 100.0 if p0 else 0.0
    v0 = float(prev.get('volume_5m', 0.0) or 0.0); v1 = float(cur.get('volume_5m', 0.0) or 0.0)
    vol_pct = ((v1 / v0) - 1.0) * 100.0 if v0 > 0 else 0.0
    b0 = float(prev.get('orderbook_imbalance', 0.0) or 0.0); b1 = float(cur.get('orderbook_imbalance', 0.0) or 0.0)
    bdelta = b1 - b0
    vol_thr = float(cfg.get('monitor_volume_change_pct', 50.0)); price_thr = float(cfg.get('monitor_price_change_pct', 0.20)); book_thr = float(cfg.get('monitor_orderbook_change', 0.20))
    direction = str(prediction.get('prediction', 'WAIT')).upper()
    if abs(vol_pct) >= vol_thr:
        alerts.append({'type':'volume_change','severity':'high' if abs(vol_pct)>=vol_thr*2 else 'medium','message':f'Изменился объём 5m: {vol_pct:+.0f}%','value':vol_pct})
    if abs(price_delta) >= price_thr:
        aligned=(direction=='LONG' and price_delta>0) or (direction=='SHORT' and price_delta<0)
        alerts.append({'type':'price_acceleration','severity':'high' if aligned else 'medium','message':f'Цена изменилась: {price_delta:+.2f}%','value':price_delta})
    if abs(bdelta) >= book_thr:
        aligned=(direction=='LONG' and bdelta>0) or (direction=='SHORT' and bdelta<0)
        alerts.append({'type':'orderbook_shift','severity':'high' if not aligned else 'medium','message':f'Изменилось давление в стакане: {bdelta:+.2f}','value':bdelta})
    prev_rsi=float(prev.get('rsi',cur.get('rsi',50.0)) or 50.0); rsi=float(cur.get('rsi',50.0) or 50.0)
    prev_macd=float(prev.get('macd',cur.get('macd',0.0)) or 0.0); macd=float(cur.get('macd',0.0) or 0.0)
    weakening=(direction=='LONG' and rsi < prev_rsi and macd < prev_macd) or (direction=='SHORT' and rsi > prev_rsi and macd > prev_macd)
    if weakening:
        alerts.append({'type':'momentum_weakening','severity':'high','message':'⚠️ Импульс ослабевает: RSI и MACD движутся против позиции. Возможен разворот/откат.','value':1})
    if len(alerts)>=2:
        adverse=(direction=='LONG' and price_delta<0 and bdelta<0) or (direction=='SHORT' and price_delta>0 and bdelta>0)
        if adverse:
            alerts.append({'type':'possible_reversal','severity':'high','message':'⚠️ Одновременно изменились цена, объём/давление и импульс — возможен разворот.','value':1})
    return alerts


def prediction_monitor_loop(cfg, cancel_event):
    """Monitor selected signal and, after VOIN, the user's real position."""
    last={}; last_alert_at=0.0
    while not cancel_event.is_set() and not stopped():
        try:
            req=read_json(MONITOR_REQUEST,{})
            if req:
                try: MONITOR_REQUEST.unlink()
                except Exception: pass
                action=str(req.get('action','')).lower()
                if action=='stop':
                    set_state(monitor={'active':False,'prediction':None,'position':None,'alerts':[],'message':'Мониторинг остановлен.'}); last={}; continue
                if action=='start':
                    prediction=dict(req.get('prediction') or {})
                    if prediction.get('id') and prediction.get('contract'):
                        set_state(monitor={'active':True,'prediction':prediction,'position':None,'alerts':[],'started_at':int(time.time()),'last_check_at':0,'message':f'Наблюдение за {prediction.get("symbol",prediction.get("contract"))} запущено.'}); last={}; last_alert_at=0.0
                if action=='start_position':
                    prediction=dict(req.get('prediction') or {}); pos=dict(req.get('position') or {})
                    if prediction.get('id') and prediction.get('contract') and float(pos.get('entry_price',0) or 0)>0:
                        pos['status']='OPEN'; pos['started_at']=int(time.time())
                        set_state(monitor={'active':True,'prediction':prediction,'position':pos,'alerts':[],'started_at':int(time.time()),'last_check_at':0,'message':f'Позиция {prediction.get("symbol",prediction.get("contract"))} открыта.'}); last={}; last_alert_at=0.0
                if action=='close_position':
                    state=read_json(STATE,{ }); mon=dict(state.get('monitor') or {}); pos=dict(mon.get('position') or {})
                    if pos.get('status')=='OPEN' and float(req.get('exit_price',0) or 0)>0:
                        pos['exit_price']=float(req['exit_price']); pos['closed_at']=int(time.time()); pos['status']='CLOSED'
                        direction=str(pos.get('direction') or (mon.get('prediction') or {}).get('prediction') or 'LONG').upper()
                        entry=float(pos.get('entry_price')); exitp=float(pos.get('exit_price'))
                        pnl_pct=((exitp/entry)-1)*100 if direction=='LONG' else ((entry/exitp)-1)*100
                        pos['realized_move_pct']=pnl_pct
                        lev=max(1.0,float(pos.get('leverage',1) or 1))
                        pos['realized_leveraged_move_pct']=pnl_pct*lev
                        _append_monitor_event(str((mon.get('prediction') or {}).get('id','position')), {'type':'position_closed','time':int(time.time()),'position':pos,'prediction':mon.get('prediction')})
                        _append_real_position(pos, mon.get('prediction') or {}, status='CLOSED')
                        mon['position']=pos; mon['message']=f'Позиция закрыта по фактической цене {exitp:.10g}. Результат движения: {pnl_pct:+.2f}%'; set_state(monitor=mon)
            state=read_json(STATE,{}); mon=state.get('monitor') or {}
            if not mon.get('active'):
                cancel_event.wait(1); continue
            prediction=dict(mon.get('prediction') or {}); symbol=prediction.get('contract') or prediction.get('exchange_symbol')
            if not symbol: cancel_event.wait(1); continue
            ex=KuCoin(symbol); ex._request_gap=max(float(getattr(ex,'_request_gap',0.10)),0.20)
            cur=_monitor_metrics(ex,symbol); alerts=_monitor_alerts(last,cur,prediction,cfg) if last else []
            position=dict(mon.get('position') or {}); direction=str(position.get('direction') or prediction.get('prediction') or 'WAIT').upper()
            if position.get('status')=='OPEN':
                ep=float(position.get('entry_price',0) or 0); px=float(cur['price']);
                move=((px/ep)-1)*100 if ep and direction=='LONG' else ((ep/px)-1)*100 if ep and direction=='SHORT' else 0.0
                position['current_price']=px; position['unrealized_move_pct']=move; position['last_metrics']=cur
                tp3=float(prediction.get('tp3') or 0); reached_tp3=(direction=='LONG' and px>=tp3) or (direction=='SHORT' and px<=tp3) if tp3 else False
                sl=float(prediction.get('sl') or 0); crossed_sl=(direction=='LONG' and sl and px<=sl) or (direction=='SHORT' and sl and px>=sl)
                if reached_tp3:
                    position['tp3_reached_at']=position.get('tp3_reached_at') or int(time.time())
                    ext=((px/tp3)-1)*100 if direction=='LONG' else ((tp3/px)-1)*100
                    position['max_extension_beyond_tp3_pct']=max(float(position.get('max_extension_beyond_tp3_pct',0) or 0),ext)
                    position['post_tp3_learning']=True
                    if not position.get('tp3_alerted'):
                        alerts.append({'type':'tp3_reached','severity':'high','message':'🎯 Достигнут TP3 — позицию следует закрыть в KuCoin и затем ввести фактическую цену выхода.','value':px})
                        position['tp3_alerted']=True
                if crossed_sl and not position.get('sl_alerted'):
                    alerts.append({'type':'sl_reached','severity':'high','message':'🛑 Цена достигла уровня SL прогноза — проверь и закрой/зафиксируй позицию в KuCoin согласно своему плану.','value':px})
                    position['sl_alerted']=True
                if alerts and (time.time()-last_alert_at)>=float(cfg.get('monitor_alert_cooldown_seconds',60)):
                    for a in alerts: _append_monitor_event(str(prediction.get('id')), {'type':'alert','time':int(time.time()),'prediction_id':prediction.get('id'),'position':position,'before':last,'after':cur,'alert':a})
                    last_alert_at=time.time()
            mon=dict(mon); mon.update({'active':True,'prediction':prediction,'position':position or None,'last_check_at':int(time.time()),'metrics':cur,'alerts':alerts,'alerted_at':int(last_alert_at) if last_alert_at else 0,'message':alerts[-1]['message'] if alerts else ('Позиция контролируется. Существенных изменений не обнаружено.' if position.get('status')=='OPEN' else 'Существенных изменений не обнаружено.')})
            set_state(monitor=mon); last=cur
        except Exception as exc:
            state=read_json(STATE,{}); mon=dict(state.get('monitor') or {}); mon.update({'active':bool(mon.get('prediction')),'alerts':[],'message':'Ошибка мониторинга: '+str(exc)}); set_state(monitor=mon)
        try: delay=max(5,int(cfg.get('monitor_poll_seconds',20)))
        except Exception: delay=20
        cancel_event.wait(delay)

def main():
    wake_lock = None
    runtime_log('SERVICE ENTRY: scanner.py main() called')
    cancel_event = threading.Event()
    heartbeat_stop = threading.Event()
    instance_id = str(uuid.uuid4())
    lock_acquired = False
    try:
        # Mark the service alive BEFORE importing the heavy trading stack.
        # On a cold Android start numpy/Kivy/Python imports can take several
        # seconds; the UI must not mistake that startup window for a dead service.
        try:
            runtime_log('PHASE: importing PythonService')
            from jnius import autoclass
            PythonService = autoclass('org.kivy.android.PythonService')
            PythonService.mService.setAutoRestartService(True)
        except Exception as exc:
            runtime_log('PythonService init failed: ' + repr(exc), 'ERROR')
        if not acquire_service_lock(instance_id):
            runtime_log('SERVICE LOCK: another live instance owns the service', 'WARN')
            return
        lock_acquired = True
        runtime_log(f'SERVICE LOCK acquired: {instance_id}')
        ctl=control_data()
        if bool(ctl.get('stop')) or bool(ctl.get('user_stopped')):
            runtime_log('SERVICE START blocked by user stop flag', 'WARN')
            # Do not let Android/p4a immediately resurrect a deliberately
            # stopped service. An explicit RESUME from the UI starts a fresh
            # service and re-enables auto-restart.
            try:
                PythonService.mService.setAutoRestartService(False)
            except Exception:
                pass
            set_state(status='stopped', running=False, paused=True, done=False,
                      phase='STOPPED', service_alive=False, user_stopped=True)
            return
        runtime_log('PHASE: publishing STARTING heartbeat')
        set_state(status='starting', running=True, paused=False, done=False, phase='STARTING',
                  service_alive=True, service_instance_id=instance_id,
                  message='Фоновый сервис запущен. Загружаю самообучение.')

        # Keep the heartbeat alive during cold start too. Heavy numpy/engine
        # initialization can take long enough on Android that a one-time
        # startup heartbeat becomes stale and the UI incorrectly declares the
        # service dead. The heartbeat must start before heavy imports.
        def heartbeat_loop():
            while not heartbeat_stop.wait(HEARTBEAT_SECONDS):
                try:
                    current = read_json(STATE, {})
                    set_state(service_alive=True, service_instance_id=instance_id,
                              phase=current.get('phase', 'STARTING'))
                except Exception:
                    pass

        heartbeat_thread=threading.Thread(target=heartbeat_loop, daemon=True, name='service-heartbeat')
        heartbeat_thread.start()
        runtime_log('HEARTBEAT thread started')

        # Import the application stack only after the service has published a
        # continuously refreshed heartbeat. If an import fails, the exception
        # is written to state below instead of leaving the UI with a generic
        # "service did not start".
        runtime_log('PHASE: importing trading stack')
        from core.config import load
        runtime_log('IMPORT OK: core.config')
        from core.engine import LearningEngine
        runtime_log('IMPORT OK: core.engine')
        from core.exchange import KuCoin
        runtime_log('IMPORT OK: core.exchange')
        cfg_path = Path(__file__).resolve().parent.parent / 'config.json'
        cfg = load(cfg_path)
        settings = ROOT / 'settings.json'
        if settings.exists():
            try: cfg.update(json.loads(settings.read_text(encoding='utf-8')))
            except Exception: pass

        set_state(status='starting', running=True, paused=False, done=False, phase='STARTING',
                  service_alive=True, service_instance_id=instance_id,
                  message='Фоновый сервис запущен. Подготавливаю самообучение.')
        runtime_log('PHASE: creating KuCoin client')
        exchange=KuCoin(cfg['symbol'])
        runtime_log('KuCoin client created')
        runtime_log('PHASE: creating LearningEngine')
        engine=LearningEngine(ROOT, exchange, cfg)
        runtime_log('LearningEngine created')
        wake_lock=acquire_wakelock()
        runtime_log('WakeLock: ' + ('ACQUIRED' if wake_lock is not None else 'UNAVAILABLE'), 'INFO' if wake_lock is not None else 'WARN')
        session_id=int(ctl.get('run_id',0) or int(time.time()))
        state=read_json(STATE,{})
        def heartbeat_loop():
            while not heartbeat_stop.wait(HEARTBEAT_SECONDS):
                set_state(service_alive=True, service_instance_id=instance_id, phase=read_json(STATE,{}).get('phase','RUNNING'))
        manual_thread=threading.Thread(target=manual_worker_loop,args=(cfg,),daemon=True,name='manual-predict')
        manual_thread.start()
        monitor_thread=threading.Thread(target=prediction_monitor_loop,args=(cfg,cancel_event),daemon=True,name='prediction-monitor')
        monitor_thread.start()
        cycle=int(state.get('cycle',0) or 0)
        runtime_log('PHASE: entering RUNNING loop')
        set_state(status='running', running=True, paused=False, done=False, phase='LEARN',
                  session_id=session_id, cycle=cycle, total=0, done_count=0, rows=[], errors=0,
                  learning='continuous', service_alive=True, service_instance_id=instance_id,
                  message='Проверяю старые прогнозы и обновляю модели.')

        while not stopped():
            # First resolve everything that has become testable and learn from
            # both successful and failed predictions. This runs even when the
            # model is already ready, so the readiness score stays current.
            resolved=engine.resolve_all_pending()
            resolved_contracts=[x.get('contract') or x.get('exchange_symbol') for x in resolved if x.get('contract') or x.get('exchange_symbol')]
            # Results are recorded immediately, but model retraining is deliberately
            # batched. One anomalous prediction must not immediately rewrite the model.
            global_resolved=engine.global_stats().get('resolved',0)
            retrained=engine.retrain_symbols(resolved_contracts, resolved_total=global_resolved) if resolved_contracts else []
            readiness=engine.readiness()
            ctl=control_data()
            prediction_request=bool(ctl.get('prediction_request'))

            if readiness.get('ready') and not prediction_request:
                # Ready means automatic learning has reached all configured
                # gates. The service stays alive in the foreground and keeps
                # resolving pending predictions, but it does not manufacture
                # new live TOP-5 predictions until the user explicitly asks.
                if wake_lock is not None:
                    try: wake_lock.release()
                    except Exception: pass
                    wake_lock=None
                set_state(status='ready_idle', running=True, paused=False, done=False,
                          phase='READY', cycle=cycle, readiness=readiness,
                          resolved_count=len(resolved), retrained_count=len(retrained),
                          message='Модель готова. Жду команды «Получить 5 прогнозов».')
                if not _sleep_or_stop(max(5,int(engine.cfg.get('verification_poll_seconds',20))),cancel_event):
                    break
                continue

            if readiness.get('ready') and prediction_request:
                # Consume the explicit request exactly once.
                ctl['prediction_request']=False
                write_json(CONTROL,ctl)

            if wake_lock is None:
                wake_lock=acquire_wakelock()
            runtime_log('WakeLock: ' + ('ACQUIRED' if wake_lock is not None else 'UNAVAILABLE'), 'INFO' if wake_lock is not None else 'WARN')
            cycle += 1
            # Start a new market cycle, but preserve the latest TOP-5 in service state
            # so the UI never loses the last real predictions while the next scan runs.
            previous_top5 = list(state.get('last_top5') or [])[:5]
            previous_top5_cycle = int(state.get('last_top5_cycle', 0) or 0)
            set_state(status='running', running=True, paused=False, done=False, phase='PRESCAN', cycle=cycle,
                      resolved_count=len(resolved), retrained_count=len(retrained), readiness=readiness,
                      done_count=0, total=0, name='', row=None, rows=[], prediction_ids=[],
                      last_top5=previous_top5, last_top5_cycle=previous_top5_cycle,
                      quick_count=0, errors=0,
                      message=('Получена команда. Начинаю полный проход рынка для нового TOP-5.' if prediction_request
                               else 'Начинаю новый полный проход рынка для следующего TOP-5.'))

            def progress(done,total,name,row,err,phase='PRESCAN'):
                if stopped(): cancel_event.set()
                current=read_json(STATE,{})
                errors=int(current.get('errors',0) or 0)+(1 if err is not None else 0)
                set_state(status='stopping' if cancel_event.is_set() else 'running',
                          running=not cancel_event.is_set(), paused=cancel_event.is_set(), done=False,
                          phase=phase, done_count=int(done), total=int(total), name=str(name), row=row,
                          errors=errors, cycle=cycle, readiness=readiness)

            rows,total,quick_count,errors,diagnostics=engine.scan_all(progress=progress, cancel_event=cancel_event, run_id=cycle)
            if cancel_event.is_set() or (isinstance(diagnostics,dict) and diagnostics.get('cancelled')) or stopped():
                if stopped():
                    try:
                        PythonService.mService.setAutoRestartService(False)
                    except Exception:
                        pass
                set_state(status='stopped', running=False, paused=True, done=False, phase='STOPPED',
                          total=int(total), quick_count=int(quick_count), errors=int(errors),
                          diagnostics=diagnostics or {}, rows=[], cycle=cycle, readiness=engine.readiness())
                break

            unique={r.get('contract'):r for r in rows if r.get('contract')}
            rows=list(unique.values())[:5]
            # TOP-5 is a maximum, not a requirement to manufacture WAIT rows.
            # If the full market pass finds only 1-4 real LONG/SHORT
            # opportunities, verify those real predictions without padding the
            # list. Verification is asynchronous and does not block new scans.
            if not rows:
                diag=dict(diagnostics or {})
                diag['no_trade_candidates']=True
                diag['valid_predictions']=0
                set_state(status='running', running=True, paused=False, done=False,
                          phase='NO_CANDIDATES', cycle=cycle, total=int(total),
                          quick_count=int(quick_count), errors=int(errors),
                          diagnostics=diag, rows=[], prediction_ids=[],
                          readiness=engine.readiness(),
                          message='Полный проход завершён: торговых LONG/SHORT кандидатов нет. Жду следующий цикл.')
                if not _sleep_or_stop(30,cancel_event):
                    break
                continue

            # TOP-5 scan rows are canonical forecasts so verification and statistics see the same set.
            try:
                engine.persist_scan_predictions(rows)
            except Exception:
                pass
            prediction_ids=[r.get('id') for r in rows if r.get('id')]
            # TOP-5 is saved immediately. Verification continues globally in the
            # background and never blocks the next market scan. Once four of five
            # predictions are terminal, the unfinished prediction(s) continue to
            # be tracked by resolve_all_pending() while a new full market scan starts.
            # If fewer than four real predictions were produced, wait only for all
            # real predictions so a short TOP-5 is never blocked indefinitely.
            required_completed=min(4,len(prediction_ids))
            set_state(status='running', running=True, paused=False, done=False, phase='VERIFY',
                      cycle=cycle, total=int(total), quick_count=int(quick_count), errors=int(errors),
                      diagnostics=diagnostics or {}, rows=rows, prediction_ids=prediction_ids,
                      last_top5=rows[:5], last_top5_cycle=cycle,
                      resolved_count=int(engine.global_stats().get('resolved',0) or 0), resolved_total=len(prediction_ids), readiness=engine.readiness(),
                      next_scan_in=0,
                      message=(f'TOP-5 сохранён. Жду завершения {required_completed} из {len(prediction_ids)} прогнозов; остальные продолжают проверяться в фоне.'
                               if prediction_ids else 'TOP-5 сохранён.'))

            # There is deliberately NO mandatory one-hour delay here. The next
            # market scan starts as soon as four of five forecasts are complete.
            # Any unfinished forecast remains in the global pending/background
            # verification pool and is not cancelled or discarded.
            while not cancel_event.is_set() and not stopped():
                try:
                    resolved_wait=engine.resolve_all_pending()
                    contracts_wait=[x.get('contract') or x.get('exchange_symbol') for x in resolved_wait if x.get('contract') or x.get('exchange_symbol')]
                    total_resolved=engine.global_stats().get('resolved',0)
                    retrained_wait=engine.retrain_symbols(contracts_wait, resolved_total=total_resolved) if contracts_wait else []
                    readiness_wait=engine.readiness()
                except Exception:
                    resolved_wait=[]; retrained_wait=[]; readiness_wait=engine.readiness()

                resolved_ids=set()
                try:
                    for pred_path in engine.logs.glob('*_predictions.json'):
                        data=read_json(pred_path,[])
                        for item in data:
                            if item.get('id') in prediction_ids and item.get('resolved'):
                                resolved_ids.add(item.get('id'))
                except Exception:
                    pass

                completed_count=sum(1 for pid in prediction_ids if pid in resolved_ids)
                remaining_ids=[pid for pid in prediction_ids if pid not in resolved_ids]

                set_state(status='running', running=True, paused=False, done=False, phase='WAIT_TOP5',
                          cycle=cycle, total=int(total), quick_count=int(quick_count), errors=int(errors),
                          rows=rows, prediction_ids=prediction_ids, last_top5=rows[:5], last_top5_cycle=cycle,
                          resolved_count=completed_count, resolved_total=len(prediction_ids),
                          retrained_count=len(retrained_wait), readiness=readiness_wait,
                          next_scan_in=0,
                          message=(f'Завершено прогнозов: {completed_count}/{len(prediction_ids)}. Начинаю новый полный скан.'
                                   if completed_count >= required_completed else
                                   f'Проверяю TOP-5 в фоне. Завершено: {completed_count}/{len(prediction_ids)}. Новый скан после {required_completed} завершённых.'))

                if completed_count >= required_completed:
                    break

                if readiness_wait.get('ready') and not bool(control_data().get('prediction_request')):
                    set_state(status='ready_idle', running=True, paused=False, done=False, phase='READY',
                              cycle=cycle, rows=rows, last_top5=rows[:5], last_top5_cycle=cycle,
                              readiness=readiness_wait, next_scan_in=0,
                              message='Модель готова. Старые прогнозы продолжают проверяться. Жду команды «Получить 5 прогнозов».')
                    break

                if not _sleep_or_stop(20, cancel_event):
                    break
            if cancel_event.is_set() or stopped():
                break
            if engine.readiness().get('ready') and not bool(control_data().get('prediction_request')):
                continue

        if stopped():
            try:
                PythonService.mService.setAutoRestartService(False)
            except Exception:
                pass
        set_state(status='stopped', running=False, paused=True, done=False, phase='STOPPED',
                  service_alive=False, service_instance_id=instance_id,
                  user_stopped=bool(control_data().get('user_stopped', False)))
        if wake_lock is not None:
            try: wake_lock.release()
            except Exception: pass
    except Exception as exc:
        runtime_log('FATAL SERVICE EXCEPTION: ' + repr(exc), 'ERROR')
        runtime_log(traceback.format_exc(), 'ERROR')
        set_state(status='error', running=False, paused=False, done=False, phase='ERROR',
                  service_alive=False, service_instance_id=instance_id, error=str(exc),
                  traceback=traceback.format_exc())
        if wake_lock is not None:
            try: wake_lock.release()
            except Exception: pass
    finally:
        runtime_log('SERVICE EXIT: releasing resources')
        heartbeat_stop.set()
        if lock_acquired:
            release_service_lock(instance_id)


if __name__ == '__main__':
    main()
