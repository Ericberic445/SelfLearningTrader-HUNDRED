from pathlib import Path
import json, time
import numpy as np
from .features import FEATURES

NAMES={0:'SHORT',1:'WAIT',2:'LONG'}

class NumpyClassifier:
    def __init__(self,n_features,n_classes=3):
        self.n_features=n_features; self.n_classes=n_classes
        self.weights=np.zeros((n_features,n_classes)); self.bias=np.zeros(n_classes)
        self.means=np.zeros(n_features); self.stds=np.ones(n_features)

    def fit(self,X,y,epochs=300,learning_rate=.02,l2=.0005,class_weights=None):
        X=np.asarray(X,float); y=np.asarray(y,int)
        X=np.nan_to_num(X,nan=0,posinf=0,neginf=0)
        self.means=np.mean(X,axis=0); self.stds=np.std(X,axis=0); self.stds[self.stds<1e-8]=1
        Z=(X-self.means)/self.stds; n=max(1,len(Z))
        Y=np.zeros((len(y),self.n_classes)); Y[np.arange(len(y)),y]=1
        if class_weights is None:
            counts=np.bincount(y,minlength=self.n_classes).astype(float)
            # Inverse-square-root weighting reduces the tendency to learn WAIT
            # simply because neutral historical bars are numerous.
            w=np.ones(self.n_classes,float)
            for c in range(self.n_classes):
                if counts[c] > 0: w[c]=1.0/np.sqrt(counts[c])
            w*=self.n_classes/max(np.sum(w),1e-12)
        else:
            w=np.asarray(class_weights,float)
        sample_w=w[np.clip(y,0,self.n_classes-1)]
        for _ in range(epochs):
            s=Z@self.weights+self.bias; s-=np.max(s,axis=1,keepdims=True)
            p=np.exp(np.clip(s,-50,50)); p/=np.sum(p,axis=1,keepdims=True)
            e=(p-Y)*sample_w[:,None]
            self.weights-=learning_rate*((Z.T@e)/n+l2*self.weights)
            self.bias-=learning_rate*np.mean(e,axis=0)
        return self

    def predict_proba(self,X):
        X=np.nan_to_num(np.asarray(X,float),nan=0,posinf=0,neginf=0); Z=(X-self.means)/self.stds
        s=Z@self.weights+self.bias; s-=np.max(s,axis=1,keepdims=True)
        p=np.exp(np.clip(s,-50,50)); return p/np.sum(p,axis=1,keepdims=True)
    def predict(self,X): return np.argmax(self.predict_proba(X),axis=1)

class ModelManager:
    """Champion/challenger model lifecycle.

    One symbol keeps one working champion and at most one challenger. A challenger
    is trained only after a batch of resolved observations, then both models are
    evaluated on the same next batch of fresh market situations. Only after that
    head-to-head comparison may the challenger replace the champion.
    """
    def __init__(self,root,symbol='XBTUSDTM',config=None):
        # One shared market model is used across all futures symbols. This is
        # required for generation-to-generation learning to accumulate the
        # errors of the whole market rather than creating isolated models per coin.
        self.models=Path(root)/'models_v8_self_learning'/'GLOBAL'; self.models.mkdir(parents=True,exist_ok=True)
        self.champion=self.models/'champion.npz'; self.meta=self.models/'champion.json'
        self.challenger=self.models/'challenger.npz'; self.challenger_meta=self.models/'challenger.json'
        self.generation_state=self.models/'generation_state.json'
        self.generation_history=self.models/'generation_history.json'
        self.config=config or {}

    def _new(self): return NumpyClassifier(len(FEATURES),3)
    def _save(self,path,m):
        path=Path(path); tmp=path.with_name(path.name+'.tmp.npz')
        np.savez(tmp,weights=m.weights,bias=m.bias,means=m.means,stds=m.stds)
        tmp.replace(path)
    def _load_path(self,path):
        if not Path(path).exists(): return None
        try:
            z=np.load(path); m=self._new()
            if z['weights'].shape!=(len(FEATURES),3): return None
            m.weights=z['weights'];m.bias=z['bias'];m.means=z['means'];m.stds=np.where(np.abs(z['stds'])<1e-8,1,z['stds'])
            return m
        except Exception:return None
    def _read_json(self,path,default):
        try:return json.loads(Path(path).read_text(encoding='utf-8')) if Path(path).exists() else default
        except Exception:return default
    def _write_json(self,path,obj):
        path=Path(path); tmp=path.with_suffix(path.suffix+'.tmp'); tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8'); tmp.replace(path)
    def _scores(self,y,p):
        acc=float(np.mean(p==y)) if len(y) else 0.0
        per=[]
        for c in range(3):
            mask=y==c; per.append(float(np.mean(p[mask]==c)) if np.any(mask) else 0.0)
        bal=float(np.mean(per)) if per else 0.0
        action=p!=1; action_count=int(np.sum(action))
        directional_precision=float(np.mean(p[action]==y[action])) if action_count else 0.0
        action_rate=float(np.mean(action)) if len(p) else 0.0
        return acc,bal,per,directional_precision,action_rate
    @staticmethod
    def _champion_score(meta):
        return (0.55*float(meta.get('balanced_accuracy',0.0)) + 0.35*float(meta.get('directional_precision',0.0)) + 0.10*float(meta.get('action_rate',0.0)))

    def _generation(self):
        return self._read_json(self.generation_state,{'generation':1,'comparison_count':0,'comparison_started_at':None,'champion_resolved_total':0})
    def _save_generation(self,s): self._write_json(self.generation_state,s)
    def generation_info(self):
        s=self._generation(); s['has_challenger']=self.challenger.exists() and self._load_path(self.challenger) is not None
        return s

    def train_challenger(self,x,min_rows=500,test_fraction=.2):
        n=len(x['target'])
        if n<min_rows: raise ValueError(f'Not enough training rows: {n}. Minimum is {min_rows}.')
        X=np.column_stack([x[f] for f in FEATURES]); y=np.asarray(x['target'],int)
        cut=max(1,min(n-1,int(n*(1-test_fraction))))
        trX,teX=X[:cut],X[cut:]; trY,teY=y[:cut],y[cut:]
        m=self._new().fit(trX,trY)
        pred=m.predict(teX); acc,bal,per,dp,ar=self._scores(teY,pred)
        s=self._generation(); generation=int(s.get('generation',1))+1
        stamp=time.strftime('%Y%m%d_%H%M%S')
        self._save(self.challenger,m)
        meta={'engine':'numpy_softmax_v8_self_learning','generation':generation,'accuracy':acc,'balanced_accuracy':bal,
              'class_accuracy':per,'directional_precision':dp,'action_rate':ar,'rows':n,'train_rows':cut,
              'test_rows':len(teY),'created':stamp,'feature_count':len(FEATURES),'features':FEATURES,
              'status':'challenger','accepted':False}
        self._write_json(self.challenger_meta,meta)
        s.update({'generation':generation,'comparison_count':0,'comparison_started_at':int(time.time()),'challenger_generation':generation})
        self._save_generation(s)
        return meta

    def has_challenger(self): return self.challenger.exists() and self._load_path(self.challenger) is not None
    def has_champion(self): return self.champion.exists() and self._load_path(self.champion) is not None

    def predict(self,row): return self._predict_from(self.champion,row)
    def predict_challenger(self,row): return self._predict_from(self.challenger,row)
    def _predict_from(self,path,row):
        m=self._load_path(path)
        if m is None: raise FileNotFoundError('Нет совместимой обученной модели.')
        X=np.column_stack([np.asarray(row[f],float).reshape(-1) for f in FEATURES]); p=m.predict_proba(X)[0]
        directional=max(float(p[0]),float(p[2])); wait=float(p[1]); threshold=float(self.config.get('min_direction_confidence',0.55)); edge=float(self.config.get('min_direction_edge',0.06))
        cls=int(np.argmax(p))
        if directional < threshold or directional-wait < edge: cls=1
        return NAMES[cls],{i:float(p[i]) for i in range(3)}

    def record_head_to_head(self, champion_item, shadow_item):
        s=self._generation();
        if not self.has_challenger(): return None
        s['comparison_count']=int(s.get('comparison_count',0))+1
        s.setdefault('comparison',{'champion':{'n':0,'tp1':0,'tp2':0,'tp3':0,'sl':0,'mfe_sum':0.0,'actionable':0},'challenger':{'n':0,'tp1':0,'tp2':0,'tp3':0,'sl':0,'mfe_sum':0.0,'actionable':0}})
        for name,item in (('champion',champion_item),('challenger',shadow_item)):
            q=s['comparison'][name]; q['n']+=1
            q['tp1']+=int(bool(item.get('tp1_hit'))); q['tp2']+=int(bool(item.get('tp2_hit'))); q['tp3']+=int(bool(item.get('tp3_hit')))
            q['sl']+=int(bool(item.get('initial_sl_failure'))); q['mfe_sum']+=float(item.get('mfe',0.0) or 0.0)
            q['actionable']+=int(str(item.get('prediction','WAIT')).upper() in ('LONG','SHORT'))
        batch=int(self.config.get('comparison_batch_size',100)); result=None
        if s['comparison_count']>=batch:
            c=s['comparison']['champion']; n=s['comparison']['challenger']
            def score(q):
                den=max(1,q['n']); act=max(1,q['actionable'])
                tp1=q['tp1']/act if q['actionable'] else 0.0; tp2=q['tp2']/act if q['actionable'] else 0.0; tp3=q['tp3']/act if q['actionable'] else 0.0
                sl=q['sl']/act if q['actionable'] else 1.0; mfe=q['mfe_sum']/act if q['actionable'] else 0.0
                ar=q['actionable']/den
                return {'tp1':tp1,'tp2':tp2,'tp3':tp3,'sl':sl,'mfe':mfe,'action_rate':ar,
                        'score':0.30*tp1+0.30*tp2+0.25*tp3+0.10*min(mfe,1.0)-0.20*sl+0.05*ar}
            cs,ns=score(c),score(n)
            challenger_wins=ns['score']>cs['score']+float(self.config.get('challenger_min_improvement',0.01))
            old_meta=self._read_json(self.meta,{})
            new_meta=self._read_json(self.challenger_meta,{})
            history=self._read_json(self.generation_history,[])
            history.append({'generation':new_meta.get('generation'),'champion':cs,'challenger':ns,'challenger_won':challenger_wins,'timestamp':int(time.time())})
            self._write_json(self.generation_history,history[-100:])
            if challenger_wins:
                # Keep old champion as an archived generation snapshot before promotion.
                if self.champion.exists(): self.champion.with_name(f"champion_gen_{int(new_meta.get('generation',0))-1}.npz").write_bytes(self.champion.read_bytes())
                self._save(self.champion,self._load_path(self.challenger))
                new_meta.update({'status':'champion','accepted':True,'promoted_at':int(time.time()),'head_to_head':{'champion':cs,'challenger':ns}})
                self._write_json(self.meta,new_meta)
                result='challenger'
            else:
                result='champion'
            self.challenger.unlink(missing_ok=True); self.challenger_meta.unlink(missing_ok=True)
            s={'generation':int(new_meta.get('generation',s.get('generation',1))) if result=='challenger' else int(s.get('generation',1)),
               'comparison_count':0,'comparison_started_at':None,'champion_resolved_total':int(s.get('champion_resolved_total',0))+batch,
               'last_head_to_head':{'winner':result,'champion':cs,'challenger':ns}}
            self._save_generation(s); return s['last_head_to_head']
        self._save_generation(s); return None

    def train(self,x,min_rows=500,test_fraction=.2):
        # Backward-compatible initial training only. Subsequent retraining creates
        # a challenger; it never silently replaces the champion.
        n=len(x['target'])
        if n<min_rows: raise ValueError(f'Not enough training rows: {n}. Minimum is {min_rows}.')
        X=np.column_stack([x[f] for f in FEATURES]); y=np.asarray(x['target'],int)
        cut=max(1,min(n-1,int(n*(1-test_fraction))))
        trX,teX=X[:cut],X[cut:]; trY,teY=y[:cut],y[cut:]
        m=self._new().fit(trX,trY); pred=m.predict(teX); acc,bal,per,dp,ar=self._scores(teY,pred)
        stamp=time.strftime('%Y%m%d_%H%M%S'); self._save(self.champion,m)
        meta={'engine':'numpy_softmax_v8_self_learning','generation':1,'accuracy':acc,'balanced_accuracy':bal,'class_accuracy':per,'directional_precision':dp,'action_rate':ar,'rows':n,'train_rows':cut,'test_rows':len(teY),'created':stamp,'feature_count':len(FEATURES),'features':FEATURES,'accepted':True,'status':'champion'}
        self._write_json(self.meta,meta); self._save_generation({'generation':1,'comparison_count':0,'comparison_started_at':None,'champion_resolved_total':0})
        return meta
