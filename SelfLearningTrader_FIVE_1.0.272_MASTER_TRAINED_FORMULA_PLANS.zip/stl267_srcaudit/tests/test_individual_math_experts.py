import sys
from pathlib import Path

APP_DIR = Path(__file__).resolve().parents[1] / 'app'
if str(APP_DIR) not in sys.path:
    sys.path.insert(0, str(APP_DIR))

from core.model import ModelManager, MATH_EXPERT_FIELDS


def test_individual_math_experts_are_independent_shadow_candidates():
    snapshot = {
        'math_markov': 0.8,
        'math_ar': -0.4,
        'math_arima': 0.5,
        'math_sarima': -0.3,
        'math_mean_reversion': 0.6,
        'math_cointegration': -0.7,
        'math_trend_deviation': 0.4,
        'math_wavelet': 0.9,
        'math_kalman': -0.5,
        'math_bayesian': 0.8,
        'math_monte_carlo': 0.75,
        'math_hurst': 0.8,
        'math_trend_direction': 0.7,
        'math_correlation': 0.6,
        'math_benchmark_direction': -0.8,
        # Risk-only values must not become independent direction experts.
        'math_garch': 0.99,
        'math_entropy': 0.99,
        'math_psl': 0.99,
        'math_ptp1': 0.99,
    }
    candidates = ModelManager._individual_math_expert_predictions(snapshot)
    assert set(candidates) == set(MATH_EXPERT_FIELDS)
    assert candidates['MARKOV']['prediction'] == 'LONG'
    assert candidates['AR']['prediction'] == 'SHORT'
    assert candidates['BAYESIAN_SIGN']['prediction'] == 'LONG'
    assert candidates['BENCHMARK_CORRELATION']['prediction'] == 'SHORT'
    assert all(v['calibrated'] is False for v in candidates.values())
    assert all(v['score_type'] == 'raw_directional_score' for v in candidates.values())


def test_no_math_snapshot_does_not_create_fake_wait_candidates():
    assert ModelManager._individual_math_expert_predictions(None) == {}
    assert ModelManager._individual_math_expert_predictions({}) == {}


def test_weak_individual_score_abstains():
    candidates = ModelManager._individual_math_expert_predictions({'math_markov': 0.02})
    assert candidates['MARKOV']['prediction'] == 'WAIT'


def test_individual_expert_plans_are_shadow_only_and_work_during_master_warmup():
    from core.engine import LearningEngine

    engine = LearningEngine.__new__(LearningEngine)
    item = {
        'price': 100.0,
        'features': {'atrpct': 0.01},
        'lens_active': False,
        'prediction': 'LONG',
        'math_expert_predictions': {
            'AR': {'score': 0.7, 'prediction': 'LONG'},
            'MARKOV': {'score': -0.6, 'prediction': 'SHORT'},
        },
    }
    engine._attach_lens_plans(item)
    assert item['prediction'] == 'LONG'  # the live Master signal is untouched
    assert item['lens_plans'] == {}
    assert item['math_expert_plans']['AR']['prediction'] == 'LONG'
    assert item['math_expert_plans']['MARKOV']['prediction'] == 'SHORT'
    assert item['math_expert_plans']['AR']['sl'] < item['math_expert_plans']['AR']['entry']
    assert item['math_expert_plans']['MARKOV']['sl'] > item['math_expert_plans']['MARKOV']['entry']


def test_wait_expert_is_not_misclassified_as_short_plan():
    from core.engine import LearningEngine
    engine = LearningEngine.__new__(LearningEngine)
    item = {'price': 100.0, 'features': {'atrpct': 0.01}, 'lens_active': False,
            'prediction': 'LONG', 'math_expert_baseline_prediction': 'LONG',
            'math_expert_predictions': {'AR': {'prediction': 'WAIT', 'score': 0.01}}}
    engine._attach_lens_plans(item)
    assert item['math_expert_plans']['AR']['prediction'] == 'WAIT'
    assert item['math_expert_plans']['MASTER_BASELINE']['prediction'] == 'LONG'
    assert item['math_expert_plans']['AR']['sl'] != item['math_expert_plans']['AR']['sl']  # NaN for WAIT


def test_selected_formula_subset_gets_own_shadow_plan_without_changing_master_levels():
    from core.engine import LearningEngine
    engine = LearningEngine.__new__(LearningEngine)
    item = {
        'price': 100.0, 'features': {'atrpct': 0.01}, 'lens_active': False,
        'prediction': 'LONG', 'math_ensemble_selected_experts': ['C1|MARKOV|5m', 'C2|AR|1h', 'C3|KALMAN|4h'],
        'math_expert_predictions': {
            'C1|MARKOV|5m': {'score': 0.8, 'prediction': 'LONG', 'timeframe': '5m'},
            'C2|AR|1h': {'score': 0.6, 'prediction': 'LONG', 'timeframe': '1h'},
            'C3|KALMAN|4h': {'score': 0.7, 'prediction': 'LONG', 'timeframe': '4h'},
        },
        'math_timeframe_atrpct': {'5m': 0.01, '1h': 0.02, '4h': 0.03},
    }
    original = item['prediction']
    engine._attach_lens_plans(item)
    assert item['prediction'] == original
    assert item['math_ensemble_plan']['prediction'] == 'LONG'
    assert item['math_ensemble_plan']['selected_experts'] == item['math_ensemble_selected_experts']
    assert item['math_ensemble_plan']['sl'] < item['math_ensemble_plan']['entry']
    assert item['math_ensemble_plan']['tp1'] > item['math_ensemble_plan']['entry']


def test_math_shadow_outcomes_resolve_individual_formulas_and_selected_subset():
    from core.engine import LearningEngine
    item = {
        'math_expert_plans': {'C1|MARKOV|5m': {'prediction': 'LONG', 'entry': 100,
            'sl': 98, 'tp1': 102, 'tp2': 103, 'tp3': 104}},
        'math_ensemble_plan': {'prediction': 'LONG', 'entry': 100,
            'sl': 98, 'tp1': 102, 'tp2': 103, 'tp3': 104},
    }
    engine = LearningEngine.__new__(LearningEngine)
    engine._resolve_math_shadow_outcomes(item,
        [100.5, 102.2, 103.2], [99.5, 101.0, 102.5], 1)
    assert item['math_expert_outcomes']['C1|MARKOV|5m']['result'] == 'TP2'
    assert item['math_ensemble_outcome']['result'] == 'TP2'


def test_cold_formula_plan_inherits_exact_master_levels_and_scales_by_its_timeframe_atr():
    from core.engine import LearningEngine
    engine = LearningEngine.__new__(LearningEngine)
    item = {
        'price': 100.0, 'entry': 100.0, 'sl': 98.0, 'tp1': 103.0, 'tp2': 104.0, 'tp3': 106.0,
        'features': {'atrpct': 0.01}, 'lens_active': False,
        'prediction': 'LONG', 'math_expert_baseline_prediction': 'LONG',
        'math_expert_baseline_plan': {'entry': 100.0, 'sl': 98.0, 'tp1': 103.0, 'tp2': 104.0, 'tp3': 106.0},
        'math_expert_predictions': {'C1|MARKOV|1h': {'score': 0.8, 'prediction': 'SHORT', 'timeframe': '1h'}},
        'math_timeframe_atrpct': {'1h': 0.02},
    }
    engine._attach_lens_plans(item)
    plan = item['math_expert_plans']['C1|MARKOV|1h']
    assert plan['plan_source'] == 'master_learned_prior'
    assert plan['calibrated'] is False
    assert plan['training_samples'] == 0
    assert plan['entry'] == 100.0
    # Master SL distance is 2% of price on a 1% base ATR = 2 ATR;
    # the 1h plan therefore inherits 2% * 2 ATR scaling = 4% price distance.
    assert abs(plan['sl'] - 104.0) < 1e-9


def test_resolver_records_excursions_for_future_formula_plan_calibration():
    from core.engine import LearningEngine
    outcome = LearningEngine._resolve_lens_plan(
        {'prediction': 'LONG', 'entry': 100.0, 'sl': 98.0, 'tp1': 102.0,
         'tp2': 103.0, 'tp3': 104.0, 'atr_price': 1.0},
        [100.5, 102.2], [99.5, 101.0], 1)
    assert outcome['result'] == 'TP1'
    assert outcome['mfe_atr'] >= 2.0
    assert outcome['mae_atr'] >= 0.5
    assert outcome['bars_observed'] == 2
