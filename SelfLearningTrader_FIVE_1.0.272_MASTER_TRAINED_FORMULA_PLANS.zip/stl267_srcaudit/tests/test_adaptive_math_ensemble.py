import sys
from pathlib import Path

APP_DIR = Path(__file__).resolve().parents[1] / 'app'
if str(APP_DIR) not in sys.path:
    sys.path.insert(0, str(APP_DIR))

from core.model import ModelManager, MATH_LENS_FORMULAS, MATH_TIMEFRAMES


def test_every_directional_formula_in_all_three_lenses_expands_over_all_timeframes():
    by_tf = {}
    for tf in MATH_TIMEFRAMES:
        snap = {
            'math_markov': 0.7, 'math_hurst': 0.8, 'math_wavelet': 0.5,
            'math_ar': 0.6, 'math_arima': -0.4, 'math_sarima': 0.3,
            'math_mean_reversion': -0.2, 'math_cointegration': 0.4,
            'math_correlation': 0.5, 'math_trend_deviation': -0.3,
            'math_bayesian': 0.7, 'math_kalman': 0.2,
            'math_direction': 0.55, 'math_monte_carlo': 0.7,
            'math_ptp1': 0.8, 'math_ptp2': 0.7, 'math_ptp3': 0.6,
            'math_psl': 0.2, 'math_trend_direction': 0.8,
            'math_benchmark_direction': 0.6, 'math_target_sign': 1.0,
        }
        by_tf[tf] = snap
    candidates = ModelManager._individual_math_expert_predictions({'_by_timeframe': by_tf})
    expected = sum(len(v) for v in MATH_LENS_FORMULAS.values()) * len(MATH_TIMEFRAMES)
    assert len(candidates) == expected
    assert any(k.startswith('C1|MARKOV|') for k in candidates)
    assert any(k.startswith('C2|ARIMA_111|') for k in candidates)
    assert any(k.startswith('C3|TP1_PROBABILITY|') for k in candidates)
    assert candidates['C2|ARIMA_111|1h']['prediction'] == 'SHORT'
    assert candidates['C3|SL_PROBABILITY|4h']['score'] > 0


def test_ensemble_selector_can_select_any_number_of_independently_validated_formulas():
    rows = []
    names = [f'C{i%3+1}|FORMULA_{i}|{tf}' for i, tf in enumerate(
        ('5m','15m','1h','4h','1d','15m','1h','4h','1d'), 1)]
    for i in range(180):
        actual = 'LONG' if i % 2 == 0 else 'SHORT'
        sign = 1.0 if actual == 'LONG' else -1.0
        experts = {name: {'score': 0.7 * sign, 'prediction': actual,
                          'outcome_score': 3, 'resolved': True}
                   for name in names}
        rows.append({'prediction_id': str(i), 'time': i + 1,
                     'baseline_prediction': 'SHORT' if actual == 'LONG' else 'LONG',
                     'baseline_outcome_score': 0, 'candidate_experts': list(names),
                     'candidate_ensemble_outcome_score': 3,
                     'actual_direction': actual, 'experts': experts})
    state = ModelManager._evaluate_math_ensemble_selector(rows)
    assert state['status'] == 'validated'
    assert state['candidate_combo_validation_rows'] == 30
    assert len(state['candidate_experts']) == len(names)
    assert len(state['selected_experts']) == len(names)
    assert state['selected_count'] > 3
    assert set(state['selected_experts']) == set(names)


def test_ensemble_selector_requires_individual_plan_outcomes():
    rows = []
    for i in range(100):
        actual = 'LONG' if i % 2 == 0 else 'SHORT'
        sign = 1.0 if actual == 'LONG' else -1.0
        rows.append({'prediction_id': str(i), 'time': i + 1,
                     'baseline_prediction': 'SHORT' if actual == 'LONG' else 'LONG',
                     'baseline_outcome_score': 0, 'actual_direction': actual,
                     'experts': {'C1|MARKOV|5m': {'score': 0.9 * sign,
                                                  'prediction': actual}}})
    state = ModelManager._evaluate_math_ensemble_selector(rows)
    assert state['status'] == 'no_ensemble_passed'
    assert state['selected_experts'] == []


def test_ensemble_selector_stays_inactive_without_temporal_validation_rows():
    rows = [{'time': i, 'actual_direction': 'LONG', 'baseline_prediction': 'LONG',
             'baseline_outcome_score': 1, 'experts': {'C1|MARKOV|5m': {'score': 0.8, 'outcome_score': 1}}} for i in range(79)]
    state = ModelManager._evaluate_math_ensemble_selector(rows)
    assert state['status'] == 'collecting'
    assert state['selected_experts'] == []


def test_shadow_candidate_is_not_live_until_exact_combo_outcomes_validate():
    manager = ModelManager.__new__(ModelManager)
    manager._math_ensemble_selector_cache = {
        'status': 'shadow_candidate',
        'candidate_experts': ['C1|MARKOV|5m', 'C2|AR|1h', 'C3|KALMAN|4h'],
        'selected_experts': [],
        'contextual_ensembles': {},
    }
    assert manager.candidate_math_ensemble('TREND_UP|MID') == [
        'C1|MARKOV|5m', 'C2|AR|1h', 'C3|KALMAN|4h']
    assert manager.active_math_ensemble('TREND_UP|MID') == []


def test_formula_plan_profile_uses_only_prior_resolved_expert_outcomes_and_context():
    manager = ModelManager.__new__(ModelManager)
    rows = []
    for i in range(40):
        rows.append({
            'time': i + 1,
            'context_key': 'TREND_UP|MID',
            'experts': {
                'C1|MARKOV|1h': {
                    'resolved': True,
                    'outcome_score': 2 if i % 4 else 0,
                    'mfe_atr': 2.0 + (i % 5) * 0.1,
                    'mae_atr': 0.5 + (i % 3) * 0.1,
                }
            },
        })
    manager._load_lens_performance = lambda: {'math_expert_rows': rows}
    profile = manager.math_expert_plan_profile('C1|MARKOV|1h', 'TREND_UP|MID')
    assert profile['status'] == 'validated'
    assert profile['source'] == 'context'
    assert profile['n'] == 40
    assert 0.25 <= profile['sl'] <= 4.0
    assert profile['tp1'] < profile['tp2'] < profile['tp3']


def test_formula_plan_profile_stays_cold_without_enough_resolved_master_samples():
    manager = ModelManager.__new__(ModelManager)
    manager._load_lens_performance = lambda: {'math_expert_rows': [
        {'time': i, 'experts': {'C2|AR|4h': {'resolved': True, 'outcome_score': 1,
         'mfe_atr': 1.8, 'mae_atr': 0.7}}} for i in range(29)
    ]}
    profile = manager.math_expert_plan_profile('C2|AR|4h')
    assert profile['status'] == 'collecting'
    assert profile['n'] == 29
