# SelfLearningTrader FIVE 1.0.277 — Persistent Master direction pool

- Added a persistent cross-contract direction archive built from closed 5-minute candles and the configured fixed forward horizon.
- The archive stores only completed labels, records `resolved_time = candle_time + horizon`, deduplicates by contract/candle timestamp, and retains up to 120,000 recent rows.
- Direction labels use the existing `make_labels` SHORT/WAIT/LONG semantics. The separate 4-class regime labels are not substituted for direction labels.
- The Master retraining dataset now combines this persistent candle pool with only online observations inside the configured horizon tolerance. Trade outcomes, 4-hour WAIT controls, and variable-horizon snapshots remain excluded from the direction head.
- Directional retraining waits for at least 1,500 rows from at least 5 contracts. Candidate promotion still requires the strict chronological quality gate; incumbent Master weights remain unchanged when a candidate fails.
- The pool neutralizes book imbalance, OI, funding, and liquidation fields because historical candle rows do not contain time-aligned values for them.
- Challenger, C1/C2/C3, and UI are unchanged.

## Verification

- Added persistence, fixed-horizon, deduplication, neutral-feature, and dataset-merging tests.
- Full suite results are recorded in the release audit after execution.
- No new Master candidate is claimed to have passed live-market validation from the supplied backup: the new multi-contract pool must first accumulate from scans in the app.
