# SelfLearningTrader FIVE 1.0.281 — restore last known-good Master

## Purpose

Undo the Master regression introduced by the 1.0.275 directional-transfer migration.

## Evidence from supplied backups

- Last known-good checkpoint: `SelfLearningTrader_backup_20261118_182602_928.slbackup.zip`.
- Master checkpoint SHA-256: `b14941e0c03ab7512c7c2a8b72801351edc5598be3e4b03b08e2d9191dbbccf4`.
- Installed transfer candidate SHA-256: `7473664ef9ba86817fe545fdf4f9871bf87b4313060ce0d122c14fce1bf30cc0`.
- Transfer candidate holdout accuracy: 39.92%; majority baseline: 45.35%.
- The 1.0.275 manifest stored validation under nested `candidate.accuracy` and `majority_baseline.accuracy`, while the later source migration looked for flat `candidate_accuracy` and `baseline_accuracy`. The phone backup nevertheless records the transfer as applied. This is consistent with stale/different compiled runtime code applying the migration without the later source guard.
- The active 1.0.278/1.0.280 decision guard then required 55% directional confidence and 6 percentage points of edge when the accepted Master was below the majority baseline. The saved TOP-5 rows had LONG probabilities around 36–38%, so the guard returned WAIT for all five.

## 1.0.281 changes

- Remove the one-shot directional-transfer migration and its bundled candidate/manifest assets.
- On startup, restore the exact 2026-11-18 Master checkpoint only if the live Master SHA-256 matches one of the two known regression hashes. Unknown or user-trained Master weights are never overwritten.
- Restore the matching Master metadata, which has no accepted failed transfer record; the 55%/6pp emergency guard therefore remains inactive for this known-good checkpoint.
- Preserve the 1.0.280 historical candle pool, per-contract history, walk-forward validation, current training archives and all other runtime data.
- Do not modify Challenger, C1, C2, C3, shared lens state or UI.
- Keep the ordinary Master promotion gate: future candidates must beat both the majority baseline and incumbent in raw and balanced accuracy, pass class coverage and walk-forward checks.

## Safety

The displaced Master weights and metadata are copied to `data/master_rollback_20261118/` before replacement. The rollback is idempotent. If the live Master hash is unknown, no replacement occurs.

## Offline replay on the five rows that were all WAIT

The exact feature rows saved in the 2026-11-23 backup were replayed through the restored 2026-11-18 Master checkpoint. Results: ARC LONG 65.5%, PUMP LONG 54.2%, KAS LONG 51.8%, PIEVERSE SHORT 45.7%, ELSA LONG 63.3%. The same five rows under the transfer candidate were all WAIT. This confirms the rollback restores the prior directional decision behavior on those saved inputs; it is not a live profitability guarantee.

Verification: Python compileall passed; pytest **335 passed, 24 subtests passed**. APK not built locally.
