# 1.0.282 Master promotion-lock audit

## Defects addressed

1. The one-time clean reset previously called `reset_learning_models()` whenever its state flag was absent. That could erase an already-installed/restored incumbent Master and bootstrap-train a replacement through the older random-split path before the incremental temporal gate ran.
2. The Challenger paired-outcome result could mark the current candidate as `CHALLENGER_TO_MASTER` without a final, promotion-time verification that the candidate's accepted chronological Master validation belonged to the current generation.

## Changes

- Existing `champion.npz` now causes the clean reset to be skipped and audited. The incumbent is preserved; later candidates use the incremental temporal validation path.
- Added `_master_candidate_temporal_promotion_gate()`. Challenger paired outcomes cannot independently authorize a Master promotion. The candidate must have a fresh accepted validation report, adequate rows, walk-forward pass counts, class coverage, holdout integrity, and gains over both incumbent and majority baseline.
- If that proof is absent, stale, incomplete, or fails any metric, the frozen incumbent snapshot is restored and the rejection is audited.
- No UI files or layouts changed. No Challenger/C1/C2/C3 model source or weights were edited.

## Test results

- `python -m compileall -q app tests`: passed.
- Targeted Master promotion / rollback / Challenger cohort tests: 33 passed.
- Full test suite: 338 passed, 24 subtests passed (6.92 seconds).

## Build status

Source ZIP only. No local APK build is claimed. GitHub Actions remains configured to build the APK from the repository ZIP.
