# SelfLearningTrader FIVE 1.0.279 — Master directional recovery

- Add Master-only directional class weighting based on an offline evaluation of the 2026-11-23 runtime direction pool.
- Use the same Master-specific weights in the independent validation replay.
- Keep the original confidence/edge guard and all chronological promotion requirements.
- No UI changes.
- No Challenger, C1, C2, or C3 code or state changes.
- The release does not force LONG/SHORT or inflate displayed probabilities.
