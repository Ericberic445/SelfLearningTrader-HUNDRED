# SelfLearningTrader FIVE 1.0.285

## Current release: 1.0.285 — confidence early-stop scan and 40-minute TOP-5 recheck

This release preserves the existing 50 → 25 → TOP-5 selection stages and ranking rules. The fast preliminary pass still ranks the active market; the expensive Master stage now stops after 50 LONG/SHORT predictions with Master `prediction_probability` ≥90% are ready, then passes those 50 to the existing 25-candidate stage. If the full ranked candidate pool is exhausted before 50 qualifying forecasts are found, the existing all-results fallback remains.

A separate background candle check runs 40 minutes after TOP-5 publication. It checks the TOP-5 and includes unresolved forecasts from the same contracts, plus the existing long-running queue. If all actionable TOP-5 forecasts are terminally resolved, the next full scan starts immediately; otherwise the hourly schedule remains. The existing long-running scheduler interval is unchanged.

No UI/layout changes. No Master weights or Challenger snapshots/weights were modified or retrained while preparing this source release. C1/C2/C3 state and existing TP1/TP2/TP3/SL outcome rules are preserved.

Verification: `python -m compileall -q app tests` passed; `python -m pytest -q --disable-warnings` — **354 passed, 24 subtests passed**. APK build and live Android/KuCoin execution are not claimed; see `CHANGELOG_1.0.285_CONFIDENCE_EARLY_STOP_AND_TOP5_40M.md`.

## Historical releases

See the versioned README, CHANGELOG and AUDIT files below for prior implementation decisions and compatibility history.
