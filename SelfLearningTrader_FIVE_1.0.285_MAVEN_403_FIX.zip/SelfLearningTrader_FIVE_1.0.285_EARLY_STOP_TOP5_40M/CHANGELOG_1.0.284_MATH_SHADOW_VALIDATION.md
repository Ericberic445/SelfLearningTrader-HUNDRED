# SelfLearningTrader FIVE 1.0.284 — independent mathematical shadow validation

## Agreed architecture retained

1. The market scan and TOP-5 are produced from the Master candidate pool. The mathematical Stage-25 worker is not called on the live TOP-5 path and cannot veto or delay publication.
2. The same Stage-25 candidates are sent to the mathematical lens worker after TOP-5 persistence. The worker computes formula predictions and stores them in `math_shadow_observations.json`; it does not overwrite the issued Master direction, probabilities, entry, SL or TP levels. If a previous shadow batch is still running, the next cycle is queued with its own candidate snapshot and TOP-5 IDs instead of being discarded.
3. Shadow observations now retain the frozen Master baseline plan, formula plans, candidate time and context. A separate resolver evaluates each candidate on its complete forward 5m candle window. Partial windows are not scored; old windows can be recovered with a bounded historical candle request.
4. Resolved shadow observations are added idempotently to `math_expert_rows`, then the existing chronological train/holdout selector evaluates formula-specific performance. Only selectors with validated status and positive validation lift are eligible to supply advisers through the existing Master adviser API.
5. Rejected or still-collecting formulas remain in the observation/training history. They are not deleted, do not become active advisers, and do not veto Master forecasts. New resolved observations cause the chronological selector to evaluate them again as the holdout window advances.

## Integrity boundaries

- No UI changes.
- No Challenger weights, snapshots, state or training changes.
- No C1/C2/C3 formula definitions or weights changed.
- Shadow formula outcomes are kept outside the live prediction and pending ledgers; they do not inflate trade statistics.
- TOP-5 publication remains independent of math-worker completion and math timeout. A queued shadow batch retains its original cycle and lifecycle IDs, preventing cross-cycle ledger enrichment.

## Verification

- `python -m compileall -q app tests`
- `PYTHONPATH=. pytest -q`: 351 passed, 24 subtests passed.
- APK build, Android-device execution and live KuCoin timing were not performed in this environment.
