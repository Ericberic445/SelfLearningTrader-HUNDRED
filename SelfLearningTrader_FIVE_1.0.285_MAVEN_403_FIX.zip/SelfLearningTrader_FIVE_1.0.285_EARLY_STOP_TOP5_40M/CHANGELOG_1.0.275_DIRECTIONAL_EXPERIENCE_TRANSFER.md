# SelfLearningTrader FIVE 1.0.275 — Directional experience transfer

## What changed

- Restored verified resolved `TRADE` experience to the Master direction-training dataset. A TP1/TP2/TP3/TP3+ result teaches the original forecast direction; an unrecovered initial SL teaches WAIT. These are single original-forecast rows, not scan snapshots.
- Kept `DIRECTION_OBSERVATION` lifecycle snapshots excluded from direction training because they are repeated views of the same forecast, not independent market events.
- Added training-partition-only SHORT/WAIT/LONG class balancing (power 1.5 by default).
- Rebuilt direction validation to use the same eligible experience kinds and class-balancing policy as training.
- Tightened Master promotion: a direction candidate must beat the majority baseline and incumbent on balanced accuracy, retain total accuracy versus incumbent, and demonstrate nontrivial validation coverage of all three classes. A candidate that collapses to SHORT, WAIT, or LONG is rejected.
- Added a one-time, SHA-256-guarded transfer migration. It installs the bundled historical-direction candidate only when the live Master exactly matches the source checkpoint used to build it. The previous Master and active Challenger snapshot are archived first. If the live model differs, the migration skips without changing it.
- The active Challenger cohort is closed at transfer so its old snapshot cannot later roll back the transferred Master. The next Challenger generation will snapshot the transferred Master.
- No UI, scanning, TP/SL semantics, formula definitions, or lens training behavior were changed.

## Transfer candidate validation

The candidate was trained from 3,440 pre-checkpoint verified direction rows: resolved `TRADE`, `ONLINE_DIRECTION_OBSERVATION`, and `WAIT_CONTROL`. It was evaluated on 258 later resolved rows, separated by a 4,388-second temporal gap. Feature columns unavailable as aligned historical data were neutralized exactly as in the live direction-training policy.

| Metric | Current Master | Transfer candidate | Always-SHORT baseline |
|---|---:|---:|---:|
| Accuracy | 29.46% | 39.92% | 45.35% |
| Balanced accuracy | 24.90% | 34.69% | 33.33% |

| Actual class recall | Current Master | Transfer candidate |
|---|---:|---:|
| SHORT | 55.56% | 52.99% |
| WAIT | 14.89% | 14.89% |
| LONG | 4.26% | 36.17% |

The transfer candidate predicts all three classes (125 SHORT, 27 WAIT, 106 LONG). Its balanced accuracy is 9.78 percentage points above the incumbent and 1.35 points above the majority baseline. In five rolling chronological windows, balanced accuracy was higher than the incumbent in all five.

**Limitations:** this is directional classification validation, not proof of profitability. On the 258-row final holdout, raw accuracy remains below the always-SHORT baseline; precision is 49.60% for SHORT, 25.93% for WAIT, and 32.08% for LONG. The candidate is installed as a direction-learning improvement, not certified for automatic real-money trading. Continue validating actual TP1/TP2/TP3/SL outcomes.

## Challenger handling

The in-progress pre-transfer Challenger generation is archived and marked superseded. It is not compared against the new Master because its frozen snapshot predates this transfer. The next normal retraining cycle starts a fresh Challenger snapshot from the transferred Master.
