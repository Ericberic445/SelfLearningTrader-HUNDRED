# SelfLearningTrader FIVE 1.0.278 — Master confidence and regime validation

## Master-only improvements

- Direction-training sample weights are normalized to a mean of 1.0 within each training batch. Relative weights remain unchanged. This prevents batches consisting only of 0.15-weight online observations from shrinking every gradient update by approximately 6.7x.
- The same normalization is applied to initial Master training, incremental direction candidates, and the direction validation replay. Outcome, selector, and regime model weighting is unchanged.
- Master candidates still must beat both the majority baseline and the incumbent on chronological raw accuracy and balanced accuracy, while satisfying SHORT / WAIT / LONG coverage. No existing Master weights are reset or overwritten by a rejected candidate.
- Master probability calibration was evaluated using time-ordered out-of-fold predictions. Temperature scaling worsened the latest untouched fold's log-loss and Brier score, so no probability inflation or unvalidated calibration map is enabled.
- Feature-group ablation was evaluated across four chronological folds. The complete 30-feature set was strongest overall; no feature was removed based on a single favorable period.

## Regime reliability repair

- Regime model acceptance now requires the existing purged chronological holdout plus three sequential purged walk-forward folds.
- Aggregate accuracy must beat the majority baseline; balanced accuracy and both trend-class recalls must pass; each fold must retain minimum recall for both TREND_DOWN and TREND_UP.
- The saved 60,000-row runtime regime pool fails this robust test: 24,761 walk-forward rows yielded 35.39% accuracy vs 30.26% baseline, but only 26.25% balanced accuracy; TREND_DOWN recall was 0.00% and TREND_UP recall 0.94%. The legacy single-holdout regime model is therefore not allowed to influence Master probabilities.
- When no regime model passes, the causal fallback is diagnostic only. It no longer adds an arbitrary 12-point WAIT boost or raises Master confidence/edge thresholds. The independent Master quality guard remains in force.

## Challenger immutability

- Removed the legacy Challenger cohort reconciliation call from Master startup. That migration could rewrite Challenger cohort state and prediction-log metadata.
- Challenger weights, snapshot files, comparison logic, and C1/C2/C3 were not modified. Added a startup regression test that fails if Master startup invokes Challenger reconciliation.
- Corrected the Master retraining policy metadata so it explicitly preserves existing Master weights rather than requesting a reset.

## Verification

- Full test suite: 332 passed, 24 subtests passed.
- Python compilation: passed.
- The 503 eligible direction observations in the supplied runtime backup still do not support a replacement Master. After weight normalization, the chronological candidate scored 19.80% accuracy vs 41.58% baseline and 33.66% incumbent; it was rejected. Existing Master weights remain unchanged.
- A shallow nonlinear MLP prototype and alternative linear hyperparameters were tested offline; neither beat the incumbent on the latest untouched temporal fold. They were not added to the app.
- No Master probability calibration was activated because it failed the untouched-fold quality check.
- Android APK build and live Android / KuCoin execution are not claimed.
- Additional offline tree-model checks (RandomForest, ExtraTrees, GradientBoosting, HistGradientBoosting) did not beat the incumbent on the latest untouched direction fold. The best ExtraTrees variant averaged 43.06% accuracy / 42.03% balanced accuracy across four folds but reached only 35.21% accuracy on the latest fold, below the incumbent's 40.85%; it was not integrated.
