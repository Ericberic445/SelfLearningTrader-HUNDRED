# SelfLearningTrader FIVE 1.0.280 — Master directional history and walk-forward validation

## Master-only changes

- Replaced the single globally truncated direction archive with per-contract compressed shards. Each contract retains up to 1,500 completed fixed-horizon candle labels; the merged training view is bounded to 300,000 rows.
- Added resumable migration from the existing `master_direction_training.npz` archive. The original archive is retained as a recovery source; migration completion is marked only after all contract shards are safely written.
- Added pool health metadata: row count, contract count, SHORT/WAIT/LONG counts, time coverage, and configured retention limits.
- Added three expanding chronological walk-forward validation windows with a one-hour purge. Candidate promotion now requires the existing independent holdout gate plus aggregate walk-forward superiority over the majority baseline and incumbent, at least two passing windows, and non-collapsed SHORT/WAIT/LONG coverage.
- Added auditable Master direction-pool update results and errors. The previous broad silent exception handling no longer hides failures in this path.
- Kept the existing Master class weights `[2.0, 0.8, 2.0]`; no probability inflation or relaxed signal thresholds were introduced.

## Explicitly unchanged

- Challenger weights, state, training, promotion, and comparison logic.
- C1, C2, and C3.
- UI/layout and forecast lifecycle rules.
- Existing TP/SL and LONG/SHORT/WAIT label definitions.

## Verification

- Source tests and compile checks are recorded in the release audit.
- This ZIP is a source project; no APK is claimed unless an Android build is completed separately.
- After a candidate passes the untouched holdout and all walk-forward gates, the final Master weights are refit on all eligible rows. The recorded holdout/fold metrics remain untouched validation metrics.
