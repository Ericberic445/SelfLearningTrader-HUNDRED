# 1.0.281 rollback audit

This release is a targeted rollback, not a new training experiment.

| Item | Verified value |
|---|---|
| Last known-good backup | 2026-11-18 18:26:02 |
| Restored Master SHA-256 | `b14941e0c03ab7512c7c2a8b72801351edc5598be3e4b03b08e2d9191dbbccf4` |
| Replaced transfer SHA-256 | `7473664ef9ba86817fe545fdf4f9871bf87b4313060ce0d122c14fce1bf30cc0` |
| Transfer validation accuracy | 39.92% |
| Majority baseline accuracy | 45.35% |
| Standard direction gate | 34% minimum probability; 2.5pp edge, unless a valid weak-model guard is active |

The restored checkpoint has 30 input features and three classes in the exact current model schema. The rollback writes only `models_v8_self_learning/GLOBAL/champion.npz` and `champion.json`; it does not touch Challenger snapshots, C1/C2/C3 state, shared lens metadata, historical experience, or the UI.

Automated source tests and compilation must be run before release. No APK is claimed unless the Android workflow actually builds it.

## Replay of the exact five saved TOP-5 rows from the 2026-11-23 backup

Using the restored 2026-11-18 Master weights and the exact feature snapshots stored in the 2026-11-23 08:03 backup:

| Contract | Restored Master signal | SHORT | WAIT | LONG |
|---|---:|---:|---:|---:|
| ARCUSDTM | LONG | 10.2% | 24.4% | 65.5% |
| PUMPUSDTM | LONG | 14.6% | 31.2% | 54.2% |
| KASUSDTM | LONG | 17.6% | 30.6% | 51.8% |
| PIEVERSEUSDTM | SHORT | 45.7% | 19.2% | 35.1% |
| ELSAUSDTM | LONG | 16.3% | 20.5% | 63.3% |

The currently installed transfer candidate on those same feature rows had returned WAIT for all five, with directional probabilities clustered around 30–38%. This is a deterministic offline replay of saved rows, not a claim about future live-market accuracy.

## Verification

- `python -m compileall -q app tests` — passed.
- `PYTHONPATH=. pytest -q` — **335 passed, 24 subtests passed**.
- Integration replay using the actual 2026-11-23 installed Master and the 2026-11-18 checkpoint asset — restored the exact checkpoint SHA-256, confirmed the emergency guard inactive, and preserved Challenger/shared lens state.
- Android APK was not built in this environment. The GitHub Actions workflow remains included for the user's normal automatic build/install process.
