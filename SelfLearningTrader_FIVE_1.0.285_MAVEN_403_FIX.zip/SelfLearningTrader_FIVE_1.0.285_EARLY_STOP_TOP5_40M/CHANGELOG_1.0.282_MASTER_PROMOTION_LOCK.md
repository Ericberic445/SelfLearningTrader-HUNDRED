# SelfLearningTrader FIVE 1.0.282 — incumbent preservation and Master promotion lock

## Scope

- Core learning logic only. No UI/layout changes.
- The existing Master is treated as the incumbent and is never erased by the one-time clean-reset migration.
- A fresh candidate may replace the incumbent only after the existing chronological Master validation has passed and a second promotion-time check confirms the accepted report is fresh for the current candidate generation.
- The paired 25-outcome Challenger comparison is now secondary evidence. It cannot authorize promotion by itself.
- A failed/missing/stale temporal proof restores the frozen incumbent snapshot and records the rejection reason.
- Challenger/C1/C2/C3 model code and weights are not modified by this release.

## Required promotion proof

The Master promotion lock checks:

1. An explicitly accepted `last_accepted_promotion_check` / `last_promotion_check` report.
2. At least the configured minimum direction-training rows and 100 independent validation rows.
3. Three chronological walk-forward windows with at least the configured passing-fold count.
4. Three-class coverage and validation on rows excluded from candidate fitting.
5. Candidate accuracy and balanced accuracy both beat the majority baseline and the incumbent by configured minimum lifts.
6. The validation/retrain timestamp is later than the current incumbent-snapshot generation.

## Clean-reset protection

If `champion.npz` already exists, `_clean_master_reset_if_needed()` records that the migration was skipped and preserves all current model files. It does not call `reset_learning_models()` or bootstrap-train over an existing Master. Incremental training proceeds through the temporal candidate gate.

## Validation

- `python -m compileall -q app tests`
- Targeted Master promotion / rollback / Challenger cohort tests: recorded separately in the release audit after execution.
- APK is not claimed as built locally; the GitHub Actions workflow remains the APK build path.
