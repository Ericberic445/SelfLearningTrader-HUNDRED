# SelfLearningTrader FIVE 1.0.276 — Master audit and repair

## Findings from the 2026-11-22 18:35 runtime backup

- Active Master weights match the directional-transfer candidate (`7473664e…`). The backup was read-only during this audit.
- The transfer validation stored in `champion.json` reports 39.92% candidate accuracy against a 45.35% majority baseline; balanced accuracy was 34.69% against 33.33%. The candidate was nevertheless recorded as accepted because the prior direction gate required balanced-accuracy improvement and non-regression only against the incumbent.
- The active Master emits raw three-class Softmax probabilities. No Master probability calibration table is present; the separate math calibration file is not a Master calibrator.
- The previous high-confidence Top-5 sample contains 56 forecasts with completed TP/SL outcomes. Mean issued confidence was 77.29%; 26 reached TP1 or better and 30 ended at INITIAL_SL. This does not validate 77% confidence as a real success probability.
- The previous direction-training population mixed `TRADE`, `ONLINE_DIRECTION_OBSERVATION`, and `WAIT_CONTROL`. Their targets do not represent the same task/horizon: trade success vs. initial SL, variable scan-to-scan movement intervals, and 4-hour WAIT controls.
- Of 1,893 online direction observations in the current archive, 503 fall within 1,800–5,400 seconds of the intended 3,600-second horizon. The unfiltered intervals ranged from 78 seconds to more than 22 days.

## Changes in 1.0.276

- Master direction training is restricted to independent fixed-horizon labels: `HISTORICAL_CANDLE` and online observations within the configured horizon tolerance.
- TP/SL trade outcomes remain in the separate outcome head. Four-hour WAIT controls and variable-horizon position samples remain archived but are not mixed into the 1-hour direction classifier.
- Temporal validation splits by `resolved_time` and uses the same filtered rows as training.
- Master promotion now requires raw accuracy and balanced accuracy to beat both the majority baseline and incumbent, plus minimum recall/coverage for SHORT, WAIT and LONG.
- The bundled 1.0.275 transfer candidate is rejected on older installs because 39.92% is below its 45.35% majority baseline.
- When the accepted Master is below its raw-accuracy baseline, the Master decision gate uses at least 55% confidence and 0.06 directional edge. It does not inflate probabilities; weak signals become WAIT.
- The directional-transfer migration no longer copies, closes, resets, or rewrites Challenger state. No Challenger model or comparison logic was edited.
- No UI changes.

## Verification on the supplied backup (isolated scratch copy)

- Filtered independent 1-hour direction rows: 503 (SHORT 173, WAIT 195, LONG 135).
- New candidate on a purged 101-row holdout: accuracy 20.79%, balanced accuracy 27.23%; majority baseline accuracy 41.58%; incumbent accuracy 33.66%, balanced accuracy 36.42%.
- Candidate rejected. The active Master weights remained byte-for-byte unchanged (`7473664e…`).
- The Master validation guard is active because the installed model's accepted validation is below its majority baseline. A sample signal previously shown as LONG at 38.18% becomes WAIT under the new guard.
- Test suite: 325 passed, 24 subtests passed.

## Important limitation

This release repairs the Master learning/acceptance pipeline and prevents weak low-confidence signals from being treated as trade directions. It does not claim that a stronger replacement Master has already been trained. The available fixed-horizon independent direction sample is still too weak; the current Master is preserved until a candidate passes the stricter chronological validation.
