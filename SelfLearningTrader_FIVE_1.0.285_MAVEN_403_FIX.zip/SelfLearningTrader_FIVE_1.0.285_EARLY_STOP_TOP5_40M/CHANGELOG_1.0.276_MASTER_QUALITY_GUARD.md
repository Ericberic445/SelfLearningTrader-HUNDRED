# SelfLearningTrader FIVE 1.0.276 — Master quality guard

## Master-only changes

- Direction training now uses only independent, fixed-horizon market-direction labels: `HISTORICAL_CANDLE` and `ONLINE_DIRECTION_OBSERVATION`. Online observations outside the configured 1-hour horizon tolerance are excluded.
- TP/SL `TRADE` outcomes remain available to the separate outcome head; they are no longer mixed into the direction classifier. Four-hour `WAIT_CONTROL`, variable-horizon real-position observations, and PnL-derived real-position results remain archived but are excluded from the 1-hour direction head.
- Direction validation now uses the same filtered training population and the label-availability (`resolved_time`) timestamp.
- A new Master candidate must beat both the majority baseline and incumbent on ordinary accuracy AND balanced accuracy, and retain minimum recall across SHORT/WAIT/LONG.
- The 1.0.275 transfer candidate is rejected on older installs because its recorded 39.92% accuracy is below its 45.35% majority baseline.
- If the currently accepted Master is below its raw-accuracy baseline, the Master confidence/edge gate becomes conservative (0.55 / 0.06), so weak 38–40% signals become WAIT rather than trade directions. No probability is inflated.
- Master metrics are reconciled from the last accepted Master validation instead of retaining stale metadata from a previous weight set.

## Challenger preservation

- No Challenger model weights, snapshot files, generation state, or comparison logic are changed by this release's Master transfer or training-policy code. The directional transfer migration is Master-only.
- No UI changes.

## Validation notes

- Existing Master weights are not replaced by this release. Candidates that do not pass the stricter chronological holdout remain rejected.
- Current archived data has only about 503 independent online observations within the 1-hour tolerance; that is not enough evidence to claim a new Master is ready.
