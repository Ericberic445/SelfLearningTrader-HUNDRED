# SelfLearningTrader FIVE 1.0.278 — Master quality audit

## Source material

- Source project: `SelfLearningTrader_FIVE_1.0.277_PERSISTENT_MASTER_DIRECTION_POOL.zip`.
- Runtime data: `SelfLearningTrader_backup_20261122_183524_824.slbackup.zip`.
- All experiments used isolated extracted copies. The supplied runtime backup was not modified.

## 1. Direction model and weight-scale defect

The exact 1.0.277 direction filter produced 503 rows from 95 contracts: SHORT 173, WAIT 195, LONG 135. All 503 were `ONLINE_DIRECTION_OBSERVATION`; each had `sample_weight=0.15`. No `HISTORICAL_CANDLE` rows were present in this backup's global experience archive.

`NumpyClassifier` multiplies the cross-entropy gradient by sample weights and divides by row count, without normalizing the overall weight scale. A batch whose weights are all 0.15 therefore applies approximately 15% of the intended gradient magnitude. Version 1.0.278 normalizes direction batch weights to mean 1.0 while preserving their ratios.

The 503-row candidate was re-evaluated with the 1.0.278 code using a 1-hour purge and a chronological holdout:

| Metric | Candidate | Majority baseline | Incumbent |
|---|---:|---:|---:|
| Accuracy | 19.80% | 41.58% | 33.66% |
| Balanced accuracy | 26.36% | 33.33% | 36.42% |

The candidate failed and was rejected. Current Master weights remain unchanged.

## 2. Probability calibration

Four expanding-window, purged temporal folds produced 255 out-of-fold predictions. The raw model's mean maximum class probability was 36.61%; median 36.01%, 90th percentile 40.51%, 99th percentile 44.83%, and maximum 47.23%. Mean accuracy was 42.35%. Confidence bins were not monotonic, so maximum Softmax probability did not behave as a reliable success probability.

A temperature fitted on the first three folds worsened the latest untouched fold:

- Latest-fold raw log-loss: 1.1032; calibrated: 1.1159.
- Latest-fold raw Brier score: 0.6706; calibrated: 0.6814.

No Master probability calibration was activated. Raising displayed percentages by sharpening Softmax would be misleading.

## 3. Feature ablation

Four purged chronological folds were used. Mean results:

| Feature set | Accuracy | Balanced accuracy | Log-loss |
|---|---:|---:|---:|
| All 30 features | 43.01% | 43.54% | 1.0811 |
| Without `trend_1d` | 40.43% | 41.75% | 1.0829 |
| Without market-only columns | 42.96% | 43.48% | 1.0811 |
| Core 14 only | 36.43% | 38.17% | 1.0926 |
| MTF-only | 42.10% | 41.37% | 1.0847 |

The full 30-feature set performed best overall. No feature removal was justified.

## 4. Regime model

The previous regime gate accepted a model using one holdout. The 1.0.278 gate adds three sequential purged walk-forward folds and checks trend recall in every fold.

On the saved 60,000-row pool, the three-fold aggregate was:

- Accuracy: 35.39%; majority baseline: 30.26%.
- Balanced accuracy: 26.25%.
- TREND_DOWN recall: 0.00%.
- TREND_UP recall: 0.94%.

It fails the new gate. The old single-holdout metadata is not sufficient to keep the model active. The fallback no longer dilutes Master probabilities with an arbitrary WAIT boost.

## 5. Alternative model experiments

A shallow one-hidden-layer MLP and a linear hyperparameter search were evaluated on the same chronological folds. The best MLP selected on earlier folds achieved only 36.62% accuracy on the latest untouched fold, below the incumbent's 40.85%; its log-loss was also substantially worse. The best linear candidate also failed to beat the incumbent. Neither was integrated.

## 6. Challenger protection

Master startup no longer calls `_reconcile_challenger_state`, which was capable of mutating legacy Challenger cohort metadata and prediction logs. The reconciliation function itself and Challenger prediction/comparison logic were not modified. A regression test ensures Master startup cannot invoke that migration. No Challenger snapshot or weights were copied, reset, retrained, or replaced during this work.

## 7. Test and release checks

- `python -m pytest -q`: 332 passed, 24 subtests passed.
- `python -m compileall -q app tests`: passed.
- Release identity: 1.0.278 / Android numeric version 10278.
- Root `config.json` and `app/config.json` are identical.
- ZIP integrity checked at packaging time.
- APK build not run; Buildozer is not available in this environment.

## Conclusion

Version 1.0.278 repairs a real Master training-scale defect, prevents an unstable regime model from distorting Master probabilities, and makes Master startup leave Challenger state untouched. It does not claim a higher-accuracy replacement Master: every tested candidate failed the incumbent/baseline gate, so the existing Master weights were preserved. Further directional accuracy gains require more valid fixed-horizon examples in the persistent pool or a candidate that demonstrably passes future temporal tests.

### Additional model-family comparison

RandomForest, ExtraTrees, GradientBoosting, and HistGradientBoosting were also tested offline using the same four chronological folds. The strongest aggregate tree result was ExtraTrees (500 trees): 43.06% mean accuracy, 42.03% mean balanced accuracy, and 1.0426 mean log-loss. On the latest untouched fold it achieved 35.21% accuracy and 39.41% balanced accuracy, below the incumbent Master on that same latest 20% holdout (40.85% accuracy, 41.30% balanced accuracy). It was not integrated. Class-weight experiments on the four-state regime model also failed to bring walk-forward balanced accuracy to the acceptance threshold.

The pre-transfer Master snapshot was compared on the same latest fixed-horizon direction holdout: 32.67% accuracy and 28.53% balanced accuracy, versus the current Master at 33.66% and 36.42%. The older snapshot was not restored.
