import json
import os
import time
from pathlib import Path
import threading
import uuid
import traceback

STATE_NAME = 'background_scan_state.json'
CONTROL_NAME = 'background_scan_control.json'
LOCK_NAME = 'background_scan.lock'
MANUAL_REQUEST_NAME = 'manual_prediction_request.json'
MONITOR_REQUEST_NAME = 'prediction_monitor_request.json'
POSITION_REQUEST_NAME = 'position_monitor_request.json'
MONITOR_EVENTS_DIR = 'monitor_events'
HEARTBEAT_SECONDS = 2.0
STALE_SECONDS = 12
DEFAULT_SCAN_INTERVAL_SECONDS = 3600  # fixed hourly market scan cadence


def app_private_dir():
    # The UI and the Android service MUST use exactly the same persistent
    # runtime directory.  ANDROID_PRIVATE is the app's private root; the UI
    # stores runtime state under stl_generational_v15_3/runtime.  Keeping the
    # same path here is critical: otherwise the service can be alive and
    # writing heartbeats while the UI reads a different directory and shows
    # "В фоне — Ожидание" forever.
    p = os.environ.get('ANDROID_PRIVATE')
    if p:
        return Path(p) / 'stl_generational_v15_3'
    p = os.environ.get('ANDROID_APP_PATH')
    if p:
        return Path(p) / 'stl_generational_v15_3'
    return Path.home() / '.stl_generational_v15_3'

ROOT = app_private_dir() / 'runtime'
ROOT.mkdir(parents=True, exist_ok=True)
STATE = ROOT / STATE_NAME
CONTROL = ROOT / CONTROL_NAME
LOCK = ROOT / LOCK_NAME
MANUAL_REQUEST = ROOT / MANUAL_REQUEST_NAME
MONITOR_REQUEST = ROOT / MONITOR_REQUEST_NAME
POSITION_REQUEST = ROOT / POSITION_REQUEST_NAME
REAL_POSITIONS = ROOT / 'real_positions.json'
MONITOR_EVENTS = ROOT / MONITOR_EVENTS_DIR
MONITOR_EVENTS.mkdir(parents=True, exist_ok=True)
STATE_LOCK = threading.Lock()
RUNTIME_LOG = ROOT / 'runtime_diagnostics.log'
RUNTIME_LOG_LOCK = threading.Lock()
_ACTIVE_RECHECK_LOCK = threading.Lock()
_ACTIVE_RECHECK_THREAD = None

MAX_RUNTIME_TAIL_LINES = 40
MAX_RUNTIME_TAIL_LINE_CHARS = 600
OUTCOME_ANALYSIS_PRIORITY = ROOT / 'outcome_analysis_priority.json'


def _priority_contract_key(value):
    return str(value or '').upper().replace('-', '').strip()


def _load_outcome_analysis_priority_state():
    state = read_json(OUTCOME_ANALYSIS_PRIORITY, {'contracts': [], 'triggered_forecast_ids': []})
    if not isinstance(state, dict):
        state = {}
    contracts = list(dict.fromkeys(_priority_contract_key(c) for c in state.get('contracts', []) if _priority_contract_key(c)))
    triggered = list(dict.fromkeys(str(pid) for pid in state.get('triggered_forecast_ids', []) if str(pid)))
    return contracts, triggered


def _load_outcome_analysis_priority():
    return _load_outcome_analysis_priority_state()[0]


def _add_outcome_analysis_priority(resolved):
    """Persist contracts whose original forecast first reaches a TP/SL milestone."""
    queue, triggered_ids = _load_outcome_analysis_priority_state()
    seen = set(queue)
    triggered = set(triggered_ids)
    triggered_order = list(triggered_ids)

    def add_contract(contract):
        contract = _priority_contract_key(contract)
        if contract and contract not in seen:
            queue.append(contract)
            seen.add(contract)

    for item in resolved or []:
        if not isinstance(item, dict):
            continue
        result = str(item.get('result') or item.get('hit') or '').upper()
        reached_tp_sl = result.startswith('TP') or result == 'SL' or bool(item.get('sl_hit')) or bool(item.get('initial_sl_failure')) or bool(item.get('protected_exit'))
        if reached_tp_sl:
            add_contract(item.get('contract') or item.get('exchange_symbol'))

    # Pending records catch TP1/SL events even while the original lifecycle is
    # still open. Keep event IDs in the separate queue file rather than rewriting
    # pending JSON here, because the background observation worker can be active.
    logs_dir = ROOT / 'logs'
    for pending_path in sorted(logs_dir.glob('*_pending.json')) if logs_dir.exists() else []:
        contract = _priority_contract_key(pending_path.name[:-len('_pending.json')])
        try:
            rows = json.loads(pending_path.read_text(encoding='utf-8'))
        except Exception:
            continue
        for item in rows if isinstance(rows, list) else []:
            if not isinstance(item, dict):
                continue
            pid = str(item.get('id') or '')
            if not pid or pid in triggered:
                continue
            reached = bool(item.get('tp1_hit') or item.get('tp2_hit') or item.get('tp3_hit') or item.get('sl_hit') or item.get('initial_sl_failure') or item.get('protected_exit'))
            if not reached:
                continue
            triggered.add(pid)
            triggered_order.append(pid)
            add_contract(contract or item.get('contract') or item.get('exchange_symbol'))

    # Bound the persisted dedupe set while retaining recent event identities.
    triggered_ids = triggered_order[-10000:]
    write_json(OUTCOME_ANALYSIS_PRIORITY, {'version': 1, 'contracts': queue,
        'triggered_forecast_ids': triggered_ids, 'updated_at': int(time.time())})
    return queue

def _consume_outcome_analysis_priority(processed_contracts):
    queue, triggered_ids = _load_outcome_analysis_priority_state()
    processed = {_priority_contract_key(c) for c in (processed_contracts or []) if _priority_contract_key(c)}
    if processed:
        queue = [c for c in queue if c not in processed]
        write_json(OUTCOME_ANALYSIS_PRIORITY, {'version': 1, 'contracts': queue,
            'triggered_forecast_ids': triggered_ids[-10000:], 'updated_at': int(time.time())})
    return queue

def _compact_runtime_tail(lines):
    """Keep diagnostic state bounded; never re-embed a dumped state inside itself."""
    compact = []
    for item in list(lines or [])[-MAX_RUNTIME_TAIL_LINES:]:
        line = str(item).replace('\x00', '')
        if len(line) > MAX_RUNTIME_TAIL_LINE_CHARS:
            line = line[:MAX_RUNTIME_TAIL_LINE_CHARS] + ' …[truncated]'
        compact.append(line)
    return compact

def _read_runtime_tail():
    """Read only a small tail from the log file, not the full growing log."""
    try:
        with RUNTIME_LOG.open('rb') as fh:
            fh.seek(0, os.SEEK_END)
            size = fh.tell()
            fh.seek(max(0, size - 65536), os.SEEK_SET)
            chunk = fh.read().decode('utf-8', errors='replace')
        return _compact_runtime_tail(chunk.splitlines())
    except Exception:
        return []

def runtime_log(message, level='INFO'):
    """Append a timestamped diagnostic without recursively bloating service state."""
    try:
        line = f"{time.strftime('%Y-%m-%d %H:%M:%S')} [{level}] {str(message)[:MAX_RUNTIME_TAIL_LINE_CHARS]}"
        with RUNTIME_LOG_LOCK:
            with RUNTIME_LOG.open('a', encoding='utf-8') as fh:
                fh.write(line + '\n')
            lines = _read_runtime_tail()
        # Serialize this update with heartbeat/state updates. The previous
        # implementation wrote the same .tmp file concurrently and copied full
        # state dumps into runtime_log_tail, causing a 900KB recursive log line.
        with STATE_LOCK:
            data = read_json(STATE, {})
            data['runtime_log_tail'] = lines
            data['runtime_log_path'] = str(RUNTIME_LOG)
            write_json(STATE, data)
    except Exception:
        pass



def write_json(path, data):
    tmp = path.with_suffix(path.suffix + '.tmp')
    try:
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
        tmp.replace(path)
    except Exception:
        try:
            path.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
        except Exception:
            pass


def read_json(path, default=None):
    try:
        return json.loads(path.read_text(encoding='utf-8')) if path.exists() else (default if default is not None else {})
    except Exception:
        return default if default is not None else {}


def control_data():
    return read_json(CONTROL, {})


def stopped():
    return bool(control_data().get('stop'))


def set_state(**kwargs):
    with STATE_LOCK:
        data = read_json(STATE, {})
        data.update(kwargs)
        now=int(time.time())
        data['updated_at'] = now
        data['heartbeat_at'] = now
        write_json(STATE, data)


def acquire_service_lock(instance_id):
    payload={'instance_id':instance_id,'created_at':int(time.time())}
    try:
        fd=os.open(str(LOCK), os.O_CREAT|os.O_EXCL|os.O_WRONLY)
        os.write(fd, json.dumps(payload).encode('utf-8'))
        os.close(fd)
        return True
    except FileExistsError:
        old=read_json(LOCK,{})
        state=read_json(STATE,{})
        # Migrate any TOP-5 created by older versions into the canonical logs so
        # old yellow rows can finally be resolved and counted by the same stats.
        try:
            engine.persist_scan_predictions(list(state.get('last_top5') or [])[:5])
        except Exception:
            pass
        heartbeat=int(state.get('heartbeat_at',0) or 0)
        owner=str(old.get('instance_id',''))
        if heartbeat and int(time.time())-heartbeat <= STALE_SECONDS and owner:
            return False
        try: LOCK.unlink()
        except Exception: pass
        try:
            fd=os.open(str(LOCK), os.O_CREAT|os.O_EXCL|os.O_WRONLY)
            os.write(fd, json.dumps(payload).encode('utf-8')); os.close(fd)
            return True
        except Exception:
            try:
                if 'fd' in locals(): os.close(fd)
            except Exception: pass
            return False
    except Exception:
        return False


def release_service_lock(instance_id):
    try:
        owner=read_json(LOCK,{}).get('instance_id')
        if owner == instance_id:
            LOCK.unlink()
    except Exception:
        pass


def acquire_wakelock():
    """Acquire a PARTIAL_WAKE_LOCK from the service process, not only the UI Activity.

    The scanner must keep CPU time while the user switches to games/video or locks
    the display. PythonService.mService is the correct Android Context for this
    foreground service; PythonActivity may be unavailable in the service process.
    """
    try:
        from jnius import autoclass
        Context = autoclass('android.content.Context')
        PythonService = autoclass('org.kivy.android.PythonService')
        service = getattr(PythonService, 'mService', None)
        if service is None:
            # Defensive fallback for p4a builds where the service bridge is not
            # initialized yet. The main path must remain service-context based.
            try:
                PythonActivity = autoclass('org.kivy.android.PythonActivity')
                service = PythonActivity.mActivity
            except Exception:
                service = None
        if service is None:
            runtime_log('WakeLock: no Android Context available', 'WARN')
            return None
        pm = service.getSystemService(Context.POWER_SERVICE)
        if pm is None:
            runtime_log('WakeLock: PowerManager unavailable', 'WARN')
            return None
        lock = pm.newWakeLock(1, 'SelfLearningTraderFiveV15_3::ContinuousLearning')
        lock.setReferenceCounted(False)
        lock.acquire()
        return lock
    except Exception as exc:
        try:
            runtime_log('WakeLock acquire failed: ' + repr(exc), 'WARN')
        except Exception:
            pass
        return None


def _retrain_with_real_position_batch(engine, contracts, resolved_total):
    """Retrain Master for normal forecast batches or queued auxiliary observations."""
    contracts = list(contracts or [])
    real_path = engine.data / 'real_position_learning_state.json'
    online_path = engine.data / 'online_observation_learning_state.json'
    real_state = read_json(real_path, {})
    online_state = read_json(online_path, {})
    if not isinstance(real_state, dict): real_state = {}
    if not isinstance(online_state, dict): online_state = {}
    real_pending = int(real_state.get('pending_samples', 0) or 0)
    online_pending = int(online_state.get('pending_samples', 0) or 0)
    pending = real_pending + online_pending
    batch = max(5, int(engine.cfg.get('real_position_retrain_batch_size', 25)))
    training_state = engine._training_state()
    auxiliary_due = pending >= batch and engine.mm.has_champion() and bool(training_state.get('clean_master_reset_done', False))
    if not contracts and not auxiliary_due:
        return []
    results = engine.retrain_symbols(contracts, resolved_total=engine._count_resolved_logs(), force=False, auxiliary_only=auxiliary_due)
    if auxiliary_due and results:
        global_result = next((r[1] for r in results if isinstance(r, tuple) and len(r) > 1 and r[0] == 'GLOBAL' and isinstance(r[1], dict)), {})
        if global_result.get('status') == 'master_updated':
            real_state['pending_samples'] = 0
            real_state['last_retrain_at'] = int(time.time())
            real_state['last_retrain_result'] = 'master_updated'
            online_state['pending_samples'] = 0
            online_state['last_retrain_at'] = int(time.time())
            online_state['last_retrain_result'] = 'master_updated'
            write_json(real_path, real_state)
            write_json(online_path, online_state)
            runtime_log(f'AUXILIARY_EXPERIENCE_RETRAIN real_samples={real_pending} online_observations={online_pending} result=master_updated')
    return results


def _prediction_map(ids):
    wanted=set(ids)
    found={}
    if not wanted:
        return found
    for path in ROOT.joinpath('logs').glob('*_predictions.json'):
        try:
            rows=json.loads(path.read_text(encoding='utf-8'))
        except Exception:
            continue
        for row in rows:
            if row.get('id') in wanted:
                found[row['id']]=row
    return found


def _sleep_or_stop(seconds, cancel_event):
    end=time.monotonic()+seconds
    while time.monotonic()<end:
        if stopped():
            cancel_event.set(); return False
        time.sleep(min(2.0, max(0.1,end-time.monotonic())))
    return True


def process_manual_request(cfg, request):
    """Run one user-requested coin prediction in an isolated engine.

    It deliberately uses a separate exchange/engine instance, so it does not
    change the coin currently being scanned by the automatic market worker.
    Model files are replaced atomically by ModelManager, making a concurrent
    read safe while automatic retraining is happening.
    """
    req_id=str(request.get('request_id',''))
    symbol=str(request.get('symbol','')).strip().upper()
    if not req_id or not symbol:
        raise ValueError('Пустой запрос ручного прогноза')
    ex=KuCoin(symbol)
    ex._request_gap=max(float(getattr(ex,'_request_gap',0.10)),0.20)
    eng=LearningEngine(ROOT,ex,cfg)
    eng.set_symbol(ex.futures_symbol)
    if not eng.mm.has_champion():
        eng.train_from_fresh()
    row=eng.predict_and_store(manual=True,source='manual')
    row['request_id']=req_id
    return row


def manual_worker_loop(cfg, heartbeat_state=None):
    active=False
    while True:
        if stopped(): return
        try:
            if MANUAL_REQUEST.exists() and not active:
                req=read_json(MANUAL_REQUEST,{})
                if req:
                    try: MANUAL_REQUEST.unlink()
                    except Exception: pass
                    active=True
                    set_state(manual_prediction_active=True, manual_prediction_result={'request_id':req.get('request_id'),'symbol':req.get('symbol'),'started_at':int(time.time())})
                    try:
                        result=process_manual_request(cfg,req)
                        set_state(manual_prediction_active=False, manual_prediction_result={'request_id':req.get('request_id'),'symbol':req.get('symbol'),'prediction':result,'completed_at':int(time.time())})
                    except Exception as exc:
                        set_state(manual_prediction_active=False, manual_prediction_result={'request_id':req.get('request_id'),'symbol':req.get('symbol'),'error':str(exc),'completed_at':int(time.time())})
                    active=False
        except Exception as exc:
            set_state(manual_prediction_active=False, manual_prediction_error=str(exc))
            active=False
        time.sleep(1.0)


def _monitor_metrics(ex, symbol):
    """Live snapshot for position tracking, alerts, and risk-model learning."""
    ex.set_symbol(symbol)
    candles = ex.candles('5min', limit=80)
    close = float(candles['close'][-1])
    volume = float(candles['volume'][-1])
    prev_volume = float(candles['volume'][-2]) if len(candles['volume']) >= 2 else 0.0
    prev_close = float(candles['close'][-2]) if len(candles['close']) >= 2 else close
    book = float(ex.orderbook_imbalance())
    rsi = macd = atrpct = trend = volz = ret3 = 0.0
    risk_features = {}
    try:
        from core.features import add_features
        from core.position_learning import RISK_FEATURES
        x = add_features(candles)
        i = len(x['time']) - 1
        rsi = float(x['rsi'][i]); macd = float(x['macd'][i]); atrpct = float(x['atrpct'][i])
        trend = float(x['trend'][i]); volz = float(x['volz'][i]); ret3 = float(x['ret3'][i])
        for name in RISK_FEATURES:
            if name in x:
                value = float(x[name][i])
                risk_features[name] = value if value == value and abs(value) != float('inf') else 0.0
    except Exception:
        pass
    price_delta = ((close / prev_close) - 1.0) * 100.0 if prev_close else 0.0
    risk_features['book_imbalance'] = book
    risk_features['price_change_pct_from_prev_5m'] = price_delta
    return {
        'time': int(time.time()), 'price': close, 'volume_5m': volume,
        'prev_volume_5m': prev_volume, 'price_change_pct_from_prev_5m': price_delta,
        'orderbook_imbalance': book, 'rsi': rsi, 'macd': macd, 'atrpct': atrpct,
        'trend': trend, 'volz': volz, 'ret3': ret3, 'risk_features': risk_features,
    }


def _monitor_alerts(prev, cur, prediction, cfg, position=None, risk_result=None):
    alerts = []
    position = position if isinstance(position, dict) else {}
    direction = str(position.get('direction') or prediction.get('prediction', 'WAIT')).upper()
    if prev:
        p0 = float(prev.get('price', cur['price']) or cur['price']); p1 = float(cur['price'])
        price_delta = (p1 / p0 - 1.0) * 100.0 if p0 else 0.0
        v0 = float(prev.get('volume_5m', 0.0) or 0.0); v1 = float(cur.get('volume_5m', 0.0) or 0.0)
        vol_pct = ((v1 / v0) - 1.0) * 100.0 if v0 > 0 else 0.0
        b0 = float(prev.get('orderbook_imbalance', 0.0) or 0.0); b1 = float(cur.get('orderbook_imbalance', 0.0) or 0.0)
        bdelta = b1 - b0
        vol_thr = float(cfg.get('monitor_volume_change_pct', 50.0)); price_thr = float(cfg.get('monitor_price_change_pct', 0.20)); book_thr = float(cfg.get('monitor_orderbook_change', 0.20))
        if abs(vol_pct) >= vol_thr:
            alerts.append({'type':'volume_change','severity':'high' if abs(vol_pct)>=vol_thr*2 else 'medium','message':f'Изменился объём 5m: {vol_pct:+.0f}%','value':vol_pct})
        if abs(price_delta) >= price_thr:
            aligned=(direction=='LONG' and price_delta>0) or (direction=='SHORT' and price_delta<0)
            alerts.append({'type':'price_acceleration','severity':'high' if aligned else 'medium','message':f'Цена изменилась: {price_delta:+.2f}%','value':price_delta})
        if abs(bdelta) >= book_thr:
            aligned=(direction=='LONG' and bdelta>0) or (direction=='SHORT' and bdelta<0)
            alerts.append({'type':'orderbook_shift','severity':'high' if not aligned else 'medium','message':f'Изменилось давление в стакане: {bdelta:+.2f}','value':bdelta})
        prev_rsi=float(prev.get('rsi',cur.get('rsi',50.0)) or 50.0); rsi=float(cur.get('rsi',50.0) or 50.0)
        prev_macd=float(prev.get('macd',cur.get('macd',0.0)) or 0.0); macd=float(cur.get('macd',0.0) or 0.0)
        weakening=(direction=='LONG' and rsi < prev_rsi and macd < prev_macd) or (direction=='SHORT' and rsi > prev_rsi and macd > prev_macd)
        if weakening:
            alerts.append({'type':'momentum_weakening','severity':'high','message':'⚠️ Импульс ослабевает: RSI и MACD движутся против реальной позиции. Возможен разворот/откат.','value':1})
        if len(alerts)>=2:
            adverse=(direction=='LONG' and price_delta<0 and bdelta<0) or (direction=='SHORT' and price_delta>0 and bdelta>0)
            if adverse:
                alerts.append({'type':'possible_reversal','severity':'high','message':'⚠️ Цена и давление в стакане движутся против позиции одновременно с другими неблагоприятными признаками. Возможен разворот.','value':1})
    if position.get('status') == 'OPEN':
        move = float(position.get('unrealized_move_pct', 0.0) or 0.0)
        adverse_signals = any(a.get('type') in ('possible_reversal', 'momentum_weakening') for a in alerts)
        if adverse_signals:
            advice = ('Рассмотри защиту прибыли или перенос стопа к безубытку по своему плану.' if move > 0
                      else 'Проверь исходный стоп и риск позиции; рассмотри выход по своему торговому плану.')
            alerts.append({'type':'position_action_advice','severity':'high',
                           'message':'🧭 Рекомендация помощника: обнаружены признаки ослабления/разворота. ' + advice})
        if isinstance(risk_result, dict) and risk_result.get('ready'):
            probability = float(risk_result.get('probability', 0.0) or 0.0)
            threshold = float(cfg.get('position_risk_alert_threshold', 0.65))
            if probability >= threshold:
                if move > 0:
                    advice = 'Рассмотри защиту прибыли или перенос стопа к безубытку по своему плану.'
                else:
                    advice = 'Проверь исходный стоп и риск позиции; рассмотри выход по своему торговому плану.'
                alerts.append({'type':'learned_position_risk','severity':'high' if probability >= 0.80 else 'medium',
                               'value':probability, 'training_rows':int(risk_result.get('training_rows', 0) or 0),
                               'message':f'⚠️ Индекс риска по обученной модели: {probability*100:.0f}/100 (по {int(risk_result.get("training_rows",0) or 0)} обучающим примерам). {advice}'})
    return alerts


def _append_real_position(position, prediction, status='CLOSED'):
    """Persist manual real-position results separately from model prediction statistics."""
    try:
        rows=read_json(REAL_POSITIONS,[])
        if not isinstance(rows,list): rows=[]
        item=dict(position or {})
        item['status']=status
        item['prediction_id']=(prediction or {}).get('id')
        item['symbol']=(prediction or {}).get('symbol')
        item['prediction']= (prediction or {}).get('prediction')
        item['recorded_at']=int(time.time())
        rows.append(item)
        write_json(REAL_POSITIONS,rows[-1000:])
    except Exception:
        pass


def _append_monitor_event(prediction_id, event):
    try:
        path=MONITOR_EVENTS / f'{prediction_id}_events.json'; rows=read_json(path,[])
        if not isinstance(rows,list): rows=[]
        rows.append(event)
        try: max_events=int(read_json(ROOT/'settings.json',{}).get('monitor_max_events_per_prediction',500))
        except Exception: max_events=500
        write_json(path,rows[-max_events:])
    except Exception: pass


def prediction_monitor_loop(cfg, cancel_event):
    """Monitor selected signal and, after VOIN, the user's real position."""
    last={}; last_alert_at=0.0
    while not cancel_event.is_set() and not stopped():
        try:
            req=read_json(MONITOR_REQUEST,{})
            if req:
                try: MONITOR_REQUEST.unlink()
                except Exception: pass
                action=str(req.get('action','')).lower()
                if action=='stop':
                    set_state(monitor={'active':False,'prediction':None,'position':None,'alerts':[],'message':'Мониторинг остановлен.'}); last={}; continue
                if action=='start':
                    prediction=dict(req.get('prediction') or {})
                    if prediction.get('id') and prediction.get('contract'):
                        set_state(monitor={'active':True,'prediction':prediction,'position':None,'alerts':[],'started_at':int(time.time()),'last_check_at':0,'message':f'Наблюдение за {prediction.get("symbol",prediction.get("contract"))} запущено.'}); last={}; last_alert_at=0.0
                if action=='start_position':
                    prediction=dict(req.get('prediction') or {}); pos=dict(req.get('position') or {})
                    if prediction.get('id') and prediction.get('contract') and float(pos.get('entry_price',0) or 0)>0:
                        pos['status']='OPEN'; pos['started_at']=int(time.time())
                        pos['position_id'] = str(pos.get('position_id') or uuid.uuid4().hex)
                        pos['contract'] = str(prediction.get('contract') or prediction.get('exchange_symbol') or '')
                        pos['observations'] = list(pos.get('observations') or [])
                        set_state(monitor={'active':True,'prediction':prediction,'position':pos,'alerts':[],'started_at':int(time.time()),'last_check_at':0,'message':f'Позиция {prediction.get("symbol",prediction.get("contract"))} открыта.'}); last={}; last_alert_at=0.0
                if action=='close_position':
                    state=read_json(STATE,{ }); mon=dict(state.get('monitor') or {}); pos=dict(mon.get('position') or {})
                    if pos.get('status')=='OPEN' and float(req.get('exit_price',0) or 0)>0:
                        pos['exit_price']=float(req['exit_price']); pos['closed_at']=int(time.time()); pos['status']='CLOSED'
                        direction=str(pos.get('direction') or (mon.get('prediction') or {}).get('prediction') or 'LONG').upper()
                        entry=float(pos.get('entry_price')); exitp=float(pos.get('exit_price'))
                        pnl_pct=((exitp/entry)-1)*100 if direction=='LONG' else ((entry/exitp)-1)*100
                        pos['realized_move_pct']=pnl_pct
                        lev=max(1.0,float(pos.get('leverage',1) or 1))
                        pos['realized_leveraged_move_pct']=pnl_pct*lev
                        try:
                            from core.exchange import KuCoin
                            from core.engine import LearningEngine, _ENGINE_FILE_LOCK
                            contract = str(pos.get('contract') or (mon.get('prediction') or {}).get('contract') or (mon.get('prediction') or {}).get('exchange_symbol') or '')
                            if contract:
                                with _ENGINE_FILE_LOCK:
                                    learner = LearningEngine(ROOT, KuCoin(contract), dict(cfg))
                                    learner.set_symbol(contract)
                                    pos['main_model_learning'] = learner.append_real_position_experience(pos, mon.get('prediction') or {}, cfg)
                            else:
                                pos['main_model_learning'] = {'status': 'missing_contract', 'new_samples': 0}
                        except Exception as learning_exc:
                            pos['main_model_learning'] = {'status': 'error', 'error': str(learning_exc)[:240]}
                        try:
                            from core.position_learning import finalize_position
                            pos['risk_model_learning'] = finalize_position(ROOT, pos, cfg)
                        except Exception as learning_exc:
                            pos['risk_model_learning'] = {'status': 'error', 'error': str(learning_exc)[:240]}
                        pos['observation_count'] = len(pos.get('observations') or [])
                        pos.pop('observations', None)
                        _append_monitor_event(str((mon.get('prediction') or {}).get('id','position')), {'type':'position_closed','time':int(time.time()),'position':pos,'prediction':mon.get('prediction')})
                        _append_real_position(pos, mon.get('prediction') or {}, status='CLOSED')
                        mon['position']=pos; mon['message']=f'Позиция закрыта по фактической цене {exitp:.10g}. Результат движения: {pnl_pct:+.2f}%'; set_state(monitor=mon)
            state=read_json(STATE,{}); mon=state.get('monitor') or {}
            if not mon.get('active'):
                cancel_event.wait(1); continue
            prediction=dict(mon.get('prediction') or {}); symbol=prediction.get('contract') or prediction.get('exchange_symbol')
            if not symbol: cancel_event.wait(1); continue
            ex=KuCoin(symbol); ex._request_gap=max(float(getattr(ex,'_request_gap',0.10)),0.20)
            cur=_monitor_metrics(ex,symbol)
            position=dict(mon.get('position') or {}); direction=str(position.get('direction') or prediction.get('prediction') or 'WAIT').upper()
            risk_result = None
            if position.get('status')=='OPEN':
                ep=float(position.get('entry_price',0) or 0); px=float(cur['price'])
                move=((px/ep)-1)*100 if ep and direction=='LONG' else ((ep/px)-1)*100 if ep and direction=='SHORT' and px else 0.0
                position['current_price']=px; position['unrealized_move_pct']=move; position['last_metrics']=cur
                # Keep full model context, replacing same-timeframe features with live values.
                snapshot_features = dict(prediction.get('features') or {})
                snapshot_features.update(cur.get('risk_features') or {})
                observations = list(position.get('observations') or [])
                last_observation = observations[-1] if observations else None
                sample_interval = max(20, int(cfg.get('position_learning_snapshot_seconds', 60)))
                price_change_threshold = float(cfg.get('position_learning_snapshot_price_change_pct', 0.10))
                time_due = not last_observation or int(cur['time']) - int(last_observation.get('time', 0) or 0) >= sample_interval
                try:
                    prior_snapshot_price = float(last_observation.get('price', px)) if last_observation else px
                    move_due = prior_snapshot_price > 0 and abs(px / prior_snapshot_price - 1.0) * 100.0 >= price_change_threshold
                except Exception:
                    move_due = False
                if not last_observation or time_due or move_due:
                    observations.append({'time':int(cur['time']), 'price':px, 'features':snapshot_features,
                                         'risk_features':dict(cur.get('risk_features') or {}), 'atrpct':float(cur.get('atrpct',0.0) or 0.0)})
                    position['last_learning_snapshot_at'] = int(cur['time'])
                position['observations'] = observations[-500:]
                try:
                    from core.position_learning import predict_risk
                    risk_result = predict_risk(ROOT, cur.get('risk_features') or {})
                except Exception:
                    risk_result = {'ready':False,'probability':None,'training_rows':0}
                tp3=float(prediction.get('tp3') or 0); reached_tp3=(direction=='LONG' and px>=tp3) or (direction=='SHORT' and px<=tp3) if tp3 else False
                if reached_tp3:
                    position['tp3_reached_at']=position.get('tp3_reached_at') or int(time.time())
                    ext=((px/tp3)-1)*100 if direction=='LONG' else ((tp3/px)-1)*100
                    position['max_extension_beyond_tp3_pct']=max(float(position.get('max_extension_beyond_tp3_pct',0) or 0),ext)
                    position['post_tp3_learning']=True
            alerts = _monitor_alerts(last,cur,prediction,cfg,position,risk_result) if last or (position.get('status')=='OPEN' and risk_result and risk_result.get('ready') and risk_result.get('probability',0)>=float(cfg.get('position_risk_alert_threshold',0.65))) else []
            if position.get('status')=='OPEN' and risk_result:
                position['risk_assessment'] = risk_result
            if position.get('status')=='OPEN' and alerts and (time.time()-last_alert_at)>=float(cfg.get('monitor_alert_cooldown_seconds',60)):
                for a in alerts:
                    _append_monitor_event(str(prediction.get('id')), {'type':'alert','time':int(time.time()),'prediction_id':prediction.get('id'),'position':{k:v for k,v in position.items() if k!='observations'},'before':last,'after':cur,'alert':a})
                last_alert_at=time.time()
            mon=dict(mon); mon.update({'active':True,'prediction':prediction,'position':position or None,'last_check_at':int(time.time()),'metrics':cur,'risk_assessment':risk_result,'alerts':alerts,'alerted_at':int(last_alert_at) if last_alert_at else 0,'message':alerts[-1]['message'] if alerts else ('Позиция контролируется. Существенных изменений не обнаружено.' if position.get('status')=='OPEN' else 'Существенных изменений не обнаружено.')})
            set_state(monitor=mon); last=cur
        except Exception as exc:
            state=read_json(STATE,{}); mon=dict(state.get('monitor') or {}); mon.update({'active':bool(mon.get('prediction')),'alerts':[],'message':'Ошибка мониторинга: '+str(exc)}); set_state(monitor=mon)
        try: delay=max(5,int(cfg.get('monitor_poll_seconds',20)))
        except Exception: delay=20
        cancel_event.wait(delay)


def _active_recheck_checkpoint_path():
    """Persistent cursor for the global recheck, surviving Android service restarts."""
    return ROOT / 'active_forecast_recheck_checkpoint.json'


def recheck_active_forecasts(cfg, skip_contracts=None, cancel_event=None, cycle=None):
    """Recheck active forecast contracts with a durable per-contract checkpoint.

    Rechecks are observation-only: they never replace the original direction or
    create/close a forecast lifecycle. Completed contracts are checkpointed as
    soon as each result returns, so a killed Android service resumes the same
    batch instead of restarting at contract one on every launch.
    """
    from core.exchange import KuCoin
    from core.engine import LearningEngine
    from concurrent.futures import ThreadPoolExecutor, as_completed

    logs = ROOT / 'logs'
    skipped = {str(x).upper().replace('-', '').strip() for x in (skip_contracts or set())}
    active_contracts = {}
    now_epoch = int(time.time())
    # A direction recheck is due only after the original LONG/SHORT forecast
    # has remained unresolved for at least one hour. WAIT controls are not trade
    # forecasts and must not consume this queue's limited capacity.
    recheck_after_seconds = max(3600, int(cfg.get('active_recheck_after_seconds', 3600) or 3600))
    for path in sorted(logs.glob('*_predictions.json')):
        contract = path.name[:-len('_predictions.json')].upper().replace('-', '').strip()
        if not contract:
            continue
        try:
            rows = json.loads(path.read_text(encoding='utf-8'))
        except Exception:
            continue
        if not isinstance(rows, list):
            continue
        active = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            signal = str(row.get('prediction', 'WAIT')).upper()
            if signal not in ('LONG', 'SHORT'):
                continue
            if row.get('resolved') or row.get('state_lifecycle_closed') or row.get('merged_into_prediction_id'):
                continue
            try:
                # Prediction ledgers may contain seconds, milliseconds,
                # microseconds, or nanoseconds. Normalize all the way to
                # seconds; a single /1000 leaves microsecond timestamps in
                # the future and silently excludes old forecasts from recheck.
                issued_at = int(float(row.get('time', 0) or 0))
                magnitude = abs(issued_at)
                if magnitude >= 100_000_000_000_000_000:  # nanoseconds
                    issued_at //= 1_000_000_000
                elif magnitude >= 100_000_000_000_000:  # microseconds
                    issued_at //= 1_000_000
                elif magnitude >= 100_000_000_000:  # milliseconds
                    issued_at //= 1_000
            except Exception:
                continue
            if issued_at <= 0 or now_epoch - issued_at < recheck_after_seconds:
                continue
            row_contract = str(row.get('contract') or row.get('exchange_symbol') or contract).upper().replace('-', '').strip()
            if row_contract.endswith('USDT') and not row_contract.endswith('USDTM'):
                row_contract += 'M'
            if row_contract != contract:
                continue
            active.append(row)
        if active:
            active.sort(key=lambda x: (int(x.get('time', 0) or 0), str(x.get('id', ''))))
            active_contracts[contract] = active[0]

    checkpoint_path = _active_recheck_checkpoint_path()
    checkpoint = read_json(checkpoint_path, {})
    # Prefer resuming an interrupted batch over replacing it with a newer cycle.
    # Only reuse a checkpoint that has a concrete unfinished contract list.
    resume = (isinstance(checkpoint, dict)
              and checkpoint.get('status') in ('queued', 'running', 'interrupted')
              and isinstance(checkpoint.get('contracts'), list)
              and bool(set(checkpoint.get('contracts') or []) - set(checkpoint.get('completed') or [])))
    if resume:
        batch_contracts = [str(c).upper().replace('-', '').strip() for c in checkpoint.get('contracts', [])]
        batch_contracts = list(dict.fromkeys(c for c in batch_contracts if c))
        completed = set(str(c).upper().replace('-', '').strip() for c in checkpoint.get('completed', []))
        batch_cycle = checkpoint.get('cycle', cycle)
        runtime_log(f'ACTIVE_FORECAST_RECHECK_RESUME cycle={batch_cycle} remaining={len(set(batch_contracts)-completed)}')
    else:
        batch_contracts = sorted(c for c in active_contracts if c not in skipped)
        completed = set()
        batch_cycle = cycle
        checkpoint = {'version': 1, 'status': 'queued', 'cycle': batch_cycle,
                      'contracts': batch_contracts, 'completed': [], 'results': {},
                      'started_at': int(time.time()), 'updated_at': int(time.time())}
        write_json(checkpoint_path, checkpoint)

    remaining = [c for c in batch_contracts if c not in completed]
    stats = {'active_contracts': len(batch_contracts), 'checked': 0, 'observations_saved': 0,
             'skipped': 0, 'resumed': bool(resume), 'remaining': len(remaining), 'errors': []}
    if not remaining:
        checkpoint.update({'status': 'completed', 'completed': batch_contracts,
                           'updated_at': int(time.time()), 'finished_at': int(time.time())})
        write_json(checkpoint_path, checkpoint)
        return stats

    # If a forecast resolved while the app was down, mark it complete without
    # issuing another network request. Keep unresolved contracts in the batch.
    work = {c: active_contracts[c] for c in remaining if c in active_contracts}
    vanished = [c for c in remaining if c not in work]
    for contract in vanished:
        completed.add(contract)
        checkpoint.setdefault('results', {})[contract] = {'status': 'no_longer_active', 'at': int(time.time())}
    if vanished:
        checkpoint.update({'status': 'running', 'completed': sorted(completed), 'updated_at': int(time.time())})
        write_json(checkpoint_path, checkpoint)
    if not work:
        checkpoint.update({'status': 'completed', 'completed': batch_contracts,
                           'updated_at': int(time.time()), 'finished_at': int(time.time())})
        write_json(checkpoint_path, checkpoint)
        stats['skipped'] += len(vanished)
        stats['remaining'] = 0
        return stats

    workers = max(1, min(4, int(cfg.get('active_recheck_workers', 4) or 4)))
    worker_local = threading.local()
    checkpoint_lock = threading.Lock()
    checkpoint.update({'status': 'running', 'updated_at': int(time.time())})
    write_json(checkpoint_path, checkpoint)

    def one(contract, active_row):
        if (cancel_event is not None and cancel_event.is_set()) or stopped():
            return contract, 'cancelled', None
        ex = getattr(worker_local, 'exchange', None)
        eng = getattr(worker_local, 'engine', None)
        if ex is None or eng is None:
            ex = KuCoin(contract)
            ex._request_gap = max(float(getattr(ex, '_request_gap', 0.10)), float(cfg.get('scan_model_request_gap', 0.20)))
            # The long-lived service engine already migrated/reconciled the
            # global ledgers. Recheck workers only need the contract-specific
            # model and must not repeat the full archive walk on each thread.
            eng = LearningEngine(ROOT, ex, dict(cfg), initialize_ledgers=False)
            worker_local.exchange = ex
            worker_local.engine = eng
        eng.set_symbol(contract)
        if not eng.mm.has_champion():
            return contract, 'no_model', None
        row = eng._scan_train_and_predict({'contract': contract, 'display': active_row.get('symbol') or ex.display_symbol(contract),
                                           'turnover': active_row.get('turnover24h', 0.0)},
                                          int(cfg.get('active_recheck_history', 800)), run_id=batch_cycle,
                                          update_regime_training=False)
        row['source'] = 'active_forecast_recheck'
        row['observation_kind'] = 'MODEL_DIRECTION_RECHECK'
        saved = eng.persist_scan_predictions([row], allow_new_lifecycle=False)
        return contract, 'saved' if saved else 'no_active_lifecycle', saved[0] if saved else None

    try:
        with ThreadPoolExecutor(max_workers=workers, thread_name_prefix='active-recheck') as pool:
            futures = {pool.submit(one, contract, row): contract for contract, row in work.items()}
            for future in as_completed(futures):
                contract = futures[future]
                try:
                    _, status, _ = future.result()
                    if status == 'cancelled':
                        # Do not checkpoint cancellation as completion; next service resumes it.
                        stats['skipped'] += 1
                        continue
                    if status == 'saved':
                        stats['checked'] += 1
                        stats['observations_saved'] += 1
                    else:
                        stats['skipped'] += 1
                        if status == 'no_model':
                            stats['errors'].append({'contract': contract, 'error': 'no_champion_model'})
                    with checkpoint_lock:
                        completed.add(contract)
                        checkpoint.setdefault('results', {})[contract] = {'status': status, 'at': int(time.time())}
                        checkpoint['completed'] = sorted(completed)
                        checkpoint['updated_at'] = int(time.time())
                        write_json(checkpoint_path, checkpoint)
                        if len(completed) % 10 == 0 or len(completed) == len(batch_contracts):
                            progress = {'cycle': batch_cycle, 'completed': len(completed),
                                        'total': len(batch_contracts),
                                        'remaining': len(set(batch_contracts)-completed),
                                        'updated_at': int(time.time()), 'status': 'running'}
                            set_state(active_recheck_progress=progress)
                            runtime_log('ACTIVE_FORECAST_RECHECK_PROGRESS cycle={} completed={}/{} remaining={}'.format(batch_cycle, len(completed), len(batch_contracts), progress['remaining']))
                except Exception as exc:
                    stats['errors'].append({'contract': contract, 'error': str(exc)[:240]})
                    with checkpoint_lock:
                        completed.add(contract)
                        checkpoint.setdefault('results', {})[contract] = {'status': 'error', 'error': str(exc)[:240], 'at': int(time.time())}
                        checkpoint['completed'] = sorted(completed)
                        checkpoint['updated_at'] = int(time.time())
                        write_json(checkpoint_path, checkpoint)
                        if len(completed) % 10 == 0 or len(completed) == len(batch_contracts):
                            progress = {'cycle': batch_cycle, 'completed': len(completed),
                                        'total': len(batch_contracts),
                                        'remaining': len(set(batch_contracts)-completed),
                                        'updated_at': int(time.time()), 'status': 'running'}
                            set_state(active_recheck_progress=progress)
                            runtime_log('ACTIVE_FORECAST_RECHECK_PROGRESS cycle={} completed={}/{} remaining={}'.format(batch_cycle, len(completed), len(batch_contracts), progress['remaining']))
    finally:
        checkpoint.update({'completed': sorted(completed), 'updated_at': int(time.time())})
        if set(batch_contracts).issubset(completed):
            checkpoint.update({'status': 'completed', 'finished_at': int(time.time())})
        elif (cancel_event is not None and cancel_event.is_set()) or stopped():
            checkpoint['status'] = 'interrupted'
        else:
            checkpoint['status'] = 'running'
        write_json(checkpoint_path, checkpoint)
        set_state(active_recheck_progress={'cycle': batch_cycle, 'completed': len(completed),
                                           'total': len(batch_contracts),
                                           'remaining': len(set(batch_contracts)-completed),
                                           'updated_at': int(time.time()),
                                           'status': checkpoint.get('status', 'running')})

    stats['remaining'] = len(set(batch_contracts) - completed)
    return stats

def _active_recheck_queue_path():
    return ROOT / 'active_forecast_recheck_queue.json'


def _queue_active_forecast_recheck(cfg, skip_contracts=None, cancel_event=None, cycle=None):
    """Queue every requested recheck cycle; never discard a cycle because a batch is busy.

    Requests are persisted and coalesced by cycle. A single worker drains the queue
    serially, while recheck_active_forecasts checkpoints progress per contract.
    """
    global _ACTIVE_RECHECK_THREAD
    request = {'cycle': cycle, 'cfg': dict(cfg or {}),
               'skip_contracts': sorted(str(x) for x in (skip_contracts or set())),
               'queued_at': int(time.time())}
    queue_path = _active_recheck_queue_path()
    with _ACTIVE_RECHECK_LOCK:
        queue_data = read_json(queue_path, {})
        requests = list(queue_data.get('requests') or []) if isinstance(queue_data, dict) else []
        # This is a rolling refresh queue, not a history of every hourly cycle.
        # Keep only the newest waiting request. The currently running batch has
        # its own durable per-contract checkpoint; once it finishes, the worker
        # processes the latest snapshot instead of replaying every obsolete cycle.
        requests = [request]
        write_json(queue_path, {'version': 2, 'requests': requests, 'updated_at': int(time.time())})
        if _ACTIVE_RECHECK_THREAD is not None and _ACTIVE_RECHECK_THREAD.is_alive():
            runtime_log('ACTIVE_FORECAST_RECHECK_QUEUED_BEHIND_RUNNING cycle={} queue_depth={}'.format(cycle, len(requests)))
            return {'status': 'queued', 'cycle': cycle, 'queue_depth': len(requests)}

        def worker():
            global _ACTIVE_RECHECK_THREAD
            while True:
                with _ACTIVE_RECHECK_LOCK:
                    data = read_json(queue_path, {})
                    pending = list(data.get('requests') or []) if isinstance(data, dict) else []
                    if not pending:
                        _ACTIVE_RECHECK_THREAD = None
                        return
                    current = pending.pop(0)
                    write_json(queue_path, {'version': 1, 'requests': pending, 'updated_at': int(time.time())})
                batch_cycle = current.get('cycle')
                started = time.monotonic()
                try:
                    stats = recheck_active_forecasts(current.get('cfg') or {},
                        skip_contracts=current.get('skip_contracts') or [],
                        cancel_event=cancel_event, cycle=batch_cycle)
                    elapsed = int(time.monotonic() - started)
                    runtime_log('ACTIVE_FORECAST_RECHECK_DONE cycle={} elapsed_seconds={} stats={}'.format(
                        batch_cycle, elapsed, json.dumps(stats, ensure_ascii=False)))
                    state = read_json(STATE, {})
                    diagnostics = dict(state.get('diagnostics') or {})
                    diagnostics['active_forecast_recheck_last'] = dict(stats, cycle=batch_cycle, elapsed_seconds=elapsed)
                    set_state(diagnostics=diagnostics, active_recheck_completed_cycle=batch_cycle,
                              active_recheck_completed_at=int(time.time()))
                    # If service is shutting down, leave pending work on disk for the next start.
                    if (cancel_event is not None and cancel_event.is_set()) or stopped():
                        break
                except Exception as exc:
                    runtime_log('ACTIVE_FORECAST_RECHECK_FAILED cycle={}: {}'.format(batch_cycle, exc), 'ERROR')
                    # Keep failed work persisted for recovery, but avoid a tight retry loop.
                    with _ACTIVE_RECHECK_LOCK:
                        data = read_json(queue_path, {})
                        pending = list(data.get('requests') or []) if isinstance(data, dict) else []
                        if not any(str(r.get('cycle')) == str(batch_cycle) for r in pending):
                            pending.insert(0, current)
                        write_json(queue_path, {'version': 1, 'requests': pending, 'updated_at': int(time.time())})
                    break
            runtime_log('ACTIVE_FORECAST_RECHECK_WORKER_EXIT')

        _ACTIVE_RECHECK_THREAD = threading.Thread(target=worker, daemon=True,
                                                  name=f'active-recheck-{cycle}')
        _ACTIVE_RECHECK_THREAD.start()
    runtime_log('ACTIVE_FORECAST_RECHECK_QUEUED cycle={}'.format(cycle))
    return {'status': 'queued', 'cycle': cycle}



TOP5_RECHECK_DELAY_SECONDS = 40 * 60

def _schedule_top5_candle_recheck(engine, rows, cancel_event, cycle, completion_event):
    """At TOP-5 age 40m, recheck TOP-5 and the existing long-running queue.

    The TOP-5 contracts are checked first. Existing long-running forecasts are
    then advanced in the same background task, without changing their normal
    periodic scheduler or delaying the next full market scan.
    """
    from core.engine import LearningEngine
    from core.exchange import KuCoin

    root = engine.root
    cfg = dict(engine.cfg)
    top_rows = [dict(r) for r in (rows or []) if isinstance(r, dict)]
    top_ids = {str(r.get('id')) for r in top_rows if r.get('id') and str(r.get('prediction', 'WAIT')).upper() in ('LONG', 'SHORT')}
    top_contracts = {}
    long_running_contracts = {}
    long_running_states = {'LONG_RUNNING_WAITING', 'WAITING_TP2', 'WAITING_TP3', 'ACTIVE'}

    # Snapshot all relevant IDs now. A later full scan may append new forecasts
    # while this delayed worker is sleeping; those new IDs must not be touched.
    for row in top_rows:
        contract = str(row.get('contract') or row.get('exchange_symbol') or '').strip()
        if not contract:
            continue
        bucket = top_contracts.setdefault(contract, {'top_ids': set(), 'pending_ids': set()})
        if row.get('id') and str(row.get('prediction', 'WAIT')).upper() in ('LONG', 'SHORT'):
            bucket['top_ids'].add(str(row['id']))

    for pending_path in sorted(engine.logs.glob('*_pending.json')):
        contract = pending_path.name[:-len('_pending.json')]
        try:
            pending_rows = json.loads(pending_path.read_text(encoding='utf-8'))
        except Exception:
            continue
        if not isinstance(pending_rows, list):
            continue
        for pending in pending_rows:
            if not isinstance(pending, dict) or str(pending.get('prediction', 'WAIT')).upper() not in ('LONG', 'SHORT'):
                continue
            if pending.get('resolved') and not pending.get('post_sl_recheck_pending'):
                continue
            pid = str(pending.get('id') or '')
            if not pid:
                continue
            if contract in top_contracts:
                top_contracts[contract]['pending_ids'].add(pid)
            state = str(pending.get('verification_state') or '').upper()
            if state in long_running_states:
                long_running_contracts.setdefault(contract, set()).add(pid)

    for contract, bucket in top_contracts.items():
        bucket['pending_ids'].update(bucket['top_ids'])

    def resolve_contract(contract, ids, promote_top_ids=None):
        if cancel_event.is_set() or stopped() or not ids:
            return False
        ex = KuCoin(contract)
        learner = LearningEngine(root, ex, dict(cfg), initialize_ledgers=False)
        learner.set_symbol(contract)
        try:
            learner.resolve_pending(allowed_ids=set(ids))
        finally:
            # Any TOP-5 forecast still unresolved at +40m enters the existing
            # long-running states; TP1/TP2 milestones keep their established
            # WAITING_TP2 / WAITING_TP3 state instead.
            if promote_top_ids:
                learner.mark_unresolved_long_running(promote_top_ids)
        return True

    def top5_is_resolved():
        for contract, bucket in top_contracts.items():
            if not bucket['top_ids']:
                continue
            path = engine.logs / f'{contract}_predictions.json'
            try:
                ledger = json.loads(path.read_text(encoding='utf-8')) if path.exists() else []
            except Exception:
                ledger = []
            found = {str(x.get('id')): x for x in ledger if isinstance(x, dict)} if isinstance(ledger, list) else {}
            for pid in bucket['top_ids']:
                record = found.get(pid)
                if not (record and record.get('resolved') and not record.get('post_sl_recheck_pending')):
                    return False
        return bool(top_ids)

    def worker():
        issued_at = min((int(r.get('top5_issued_at') or time.time()) for r in top_rows), default=int(time.time()))
        remaining = max(0, issued_at + TOP5_RECHECK_DELAY_SECONDS - int(time.time()))
        if remaining and cancel_event.wait(remaining):
            return
        if cancel_event.is_set() or stopped():
            return
        started = time.monotonic()
        checked_top = 0
        top_errors = []
        for contract, bucket in top_contracts.items():
            try:
                if resolve_contract(contract, bucket['pending_ids'], promote_top_ids=bucket['top_ids']):
                    checked_top += 1
            except Exception as exc:
                top_errors.append({'contract': contract, 'error': str(exc)[:180]})
        all_resolved = top5_is_resolved()
        runtime_log('TOP5_40M_RECHECK_DONE cycle={} contracts={} elapsed_seconds={:.1f} resolved={} errors={}'.format(
            cycle, checked_top, time.monotonic()-started, all_resolved, json.dumps(top_errors, ensure_ascii=False)))
        if all_resolved:
            completion_event.set()
            runtime_log('TOP5_40M_RECHECK_ALL_RESOLVED cycle={} -> START_NEXT_FULL_SCAN'.format(cycle))

        # Existing long-running forecasts are included in this candle refresh,
        # but this is only an additional observation pass: the established
        # periodic long-running scheduler and its interval remain unchanged.
        checked_long = 0
        long_errors = []
        for contract, ids in long_running_contracts.items():
            if contract in top_contracts:
                ids = set(ids) - set(top_contracts[contract]['pending_ids'])
            if not ids:
                continue
            try:
                if resolve_contract(contract, ids):
                    checked_long += 1
            except Exception as exc:
                long_errors.append({'contract': contract, 'error': str(exc)[:180]})
        runtime_log('LONG_RUNNING_40M_REFRESH_DONE cycle={} contracts={} elapsed_seconds={:.1f} errors={}'.format(
            cycle, checked_long, time.monotonic()-started, json.dumps(long_errors, ensure_ascii=False)))

    thread = threading.Thread(target=worker, daemon=True, name=f'top5-40m-recheck-{cycle}')
    thread.start()
    runtime_log('TOP5_40M_RECHECK_SCHEDULED cycle={} delay_seconds={}'.format(cycle, TOP5_RECHECK_DELAY_SECONDS))
    return thread

def main():
    wake_lock = None
    runtime_log('SERVICE ENTRY: scanner.py main() called')
    cancel_event = threading.Event()
    heartbeat_stop = threading.Event()
    instance_id = str(uuid.uuid4())
    lock_acquired = False
    try:
        # Mark the service alive BEFORE importing the heavy trading stack.
        # On a cold Android start numpy/Kivy/Python imports can take several
        # seconds; the UI must not mistake that startup window for a dead service.
        try:
            runtime_log('PHASE: importing PythonService')
            from jnius import autoclass
            PythonService = autoclass('org.kivy.android.PythonService')
            PythonService.mService.setAutoRestartService(True)
            wake_lock = acquire_wakelock()
            runtime_log('WakeLock startup: ' + ('ACQUIRED' if wake_lock is not None else 'UNAVAILABLE'), 'INFO' if wake_lock is not None else 'WARN')
        except Exception as exc:
            runtime_log('PythonService init failed: ' + repr(exc), 'ERROR')
        if not acquire_service_lock(instance_id):
            runtime_log('SERVICE LOCK: another live instance owns the service', 'WARN')
            return
        lock_acquired = True
        runtime_log(f'SERVICE LOCK acquired: {instance_id}')
        ctl=control_data()
        if bool(ctl.get('stop')):
            runtime_log('SERVICE START blocked by user stop flag', 'WARN')
            set_state(status='stopped', running=False, paused=True, done=False,
                      phase='STOPPED', service_alive=False, user_stopped=bool(ctl.get('user_stopped', False)))
            return
        runtime_log('PHASE: publishing STARTING heartbeat')
        set_state(status='starting', running=True, paused=False, done=False, phase='STARTING',
                  service_alive=True, service_instance_id=instance_id,
                  message='Фоновый сервис запущен. Загружаю самообучение.')

        # Keep the heartbeat alive during cold start too. Heavy numpy/engine
        # initialization can take long enough on Android that a one-time
        # startup heartbeat becomes stale and the UI incorrectly declares the
        # service dead. The heartbeat must start before heavy imports.
        def heartbeat_loop():
            while not heartbeat_stop.wait(HEARTBEAT_SECONDS):
                try:
                    current = read_json(STATE, {})
                    set_state(service_alive=True, service_instance_id=instance_id,
                              phase=current.get('phase', 'STARTING'))
                except Exception:
                    pass

        heartbeat_thread=threading.Thread(target=heartbeat_loop, daemon=True, name='service-heartbeat')
        heartbeat_thread.start()
        runtime_log('HEARTBEAT thread started')

        # Import the application stack only after the service has published a
        # continuously refreshed heartbeat. If an import fails, the exception
        # is written to state below instead of leaving the UI with a generic
        # "service did not start".
        runtime_log('PHASE: importing trading stack')
        from core.config import load, migrate_scan_runtime_settings
        runtime_log('IMPORT OK: core.config')
        from core.engine import LearningEngine
        runtime_log('IMPORT OK: core.engine')
        from core.exchange import KuCoin
        runtime_log('IMPORT OK: core.exchange')
        cfg_path = Path(__file__).resolve().parent.parent / 'config.json'
        cfg = load(cfg_path)
        settings = ROOT / 'settings.json'
        if settings.exists():
            try: cfg.update(json.loads(settings.read_text(encoding='utf-8')))
            except Exception: pass
        migrate_scan_runtime_settings(cfg, settings)
        runtime_log('SCAN CONFIG: model_stage_timeout_seconds=' + str(cfg.get('scan_model_stage_timeout_seconds', 1800)))

        set_state(status='starting', running=True, paused=False, done=False, phase='STARTING',
                  service_alive=True, service_instance_id=instance_id,
                  message='Фоновый сервис запущен. Подготавливаю самообучение.')
        runtime_log('PHASE: creating KuCoin client')
        exchange=KuCoin(cfg['symbol'])
        runtime_log('KuCoin client created')
        runtime_log('PHASE: creating LearningEngine')
        engine=LearningEngine(ROOT, exchange, cfg)
        runtime_log('LearningEngine created')
        if wake_lock is None:
            wake_lock=acquire_wakelock()
        runtime_log('WakeLock after engine init: ' + ('ACQUIRED' if wake_lock is not None else 'UNAVAILABLE'), 'INFO' if wake_lock is not None else 'WARN')
        session_id=int(ctl.get('run_id',0) or int(time.time()))
        state=read_json(STATE,{})
        def heartbeat_loop():
            while not heartbeat_stop.wait(HEARTBEAT_SECONDS):
                set_state(service_alive=True, service_instance_id=instance_id, phase=read_json(STATE,{}).get('phase','RUNNING'))
        manual_thread=threading.Thread(target=manual_worker_loop,args=(cfg,),daemon=True,name='manual-predict')
        manual_thread.start()
        monitor_thread=threading.Thread(target=prediction_monitor_loop,args=(cfg,cancel_event),daemon=True,name='prediction-monitor')
        monitor_thread.start()
        cycle=int(state.get('cycle',0) or 0)
        # Do not resume the legacy continuous model-direction recheck queue.
        # Active forecasts now wait for TP/SL; only outcome-triggered contracts
        # are prioritized for the next full analysis pass.
        runtime_log('PHASE: entering RUNNING loop')
        set_state(status='running', running=True, paused=False, done=False, phase='LEARN',
                  session_id=session_id, cycle=cycle, total=0, done_count=0, rows=[], errors=0,
                  learning='continuous', service_alive=True, service_instance_id=instance_id,
                  message='Проверяю старые прогнозы и обновляю модели.')

        while not stopped():
            cycle_started_monotonic=time.monotonic()
            scan_started_at=time.time()
            # Refresh state at each cycle boundary. Keeping the startup snapshot
            # forever caused last_top5/last_top5_cycle to roll back at every
            # PRESCAN transition, making the dashboard look stale.
            state = read_json(STATE, {})
            # Resolve outcomes after the full market pass, so TP/SL checks can
            # reuse the same process-wide 5m candle cache populated for all symbols.
            # Outcome-triggered priority is carried into the next market pass.
            resolved=[]
            retrained=[]
            outcome_priority_contracts=[]
            resolved_contracts=[]
            readiness_started=time.monotonic()
            readiness=engine.readiness()
            readiness_seconds=time.monotonic()-readiness_started
            runtime_log(f'READINESS_DONE cycle={cycle+1} elapsed_seconds={readiness_seconds:.3f} ready={bool(readiness.get("ready"))}')
            ctl=control_data()
            prediction_request=bool(ctl.get('prediction_request'))

            # Automatic scanning is cadence-driven, not signal-count-driven.
            # Once the service is started, a full market scan is performed on a
            # fixed hourly cadence. Readiness no longer switches the service
            # into an idle state; it only describes the current learning state.
            if readiness.get('ready') and prediction_request:
                # Manual request is still accepted, but the regular cadence
                # remains the source of truth for subsequent scans.
                ctl['prediction_request']=False
                write_json(CONTROL,ctl)

            if wake_lock is None:
                wake_lock=acquire_wakelock()
            runtime_log('WakeLock: ' + ('ACQUIRED' if wake_lock is not None else 'UNAVAILABLE'), 'INFO' if wake_lock is not None else 'WARN')
            cycle += 1
            scan_interval = max(300, int(engine.cfg.get('scan_interval_seconds', DEFAULT_SCAN_INTERVAL_SECONDS)))
            # Start a new market cycle, but preserve the latest TOP-5 in service state
            # so the UI never loses the last real predictions while the next scan runs.
            previous_top5 = list(state.get('last_top5') or [])[:5]
            previous_top5_cycle = int(state.get('last_top5_cycle', 0) or 0)
            set_state(status='running', running=True, paused=False, done=False, phase='PRESCAN', cycle=cycle,
                      resolved_count=len(resolved), retrained_count=len(retrained), readiness=readiness,
                      done_count=0, total=0, name='', row=None, rows=[], prediction_ids=[],
                      last_top5=previous_top5, last_top5_cycle=previous_top5_cycle,
                      quick_count=0, errors=0, scan_started_at=int(scan_started_at),
                      scan_interval_seconds=scan_interval, next_scan_at=int(scan_started_at + scan_interval),
                      message=('Получена команда. Начинаю полный проход рынка для нового TOP-5.' if prediction_request
                               else 'Начинаю новый полный проход рынка для следующего TOP-5.'))

            def progress(done,total,name,row,err,phase='PRESCAN'):
                if stopped(): cancel_event.set()
                current=read_json(STATE,{})
                errors=int(current.get('errors',0) or 0)+(1 if err is not None else 0)
                set_state(status='stopping' if cancel_event.is_set() else 'running',
                          running=not cancel_event.is_set(), paused=cancel_event.is_set(), done=False,
                          phase=phase, done_count=int(done), total=int(total), name=str(name), row=row,
                          errors=errors, cycle=cycle, readiness=readiness)

            runtime_log(f'FULL_SCAN_START cycle={cycle} interval_seconds={scan_interval} readiness_seconds={readiness_seconds:.3f}')
            full_scan_started = cycle_started_monotonic
            rows,total,quick_count,errors,diagnostics=engine.scan_all(progress=progress, cancel_event=cancel_event, run_id=cycle, priority_contracts=outcome_priority_contracts)
            diagnostics=dict(diagnostics or {},cycle_readiness_seconds=round(readiness_seconds,3))
            scan_timing=(diagnostics or {}).get('timings_seconds',{}) or {}
            runtime_log(f'FULL_SCAN_DONE cycle={cycle} elapsed_seconds={int(time.monotonic()-full_scan_started)} model_seconds={float(scan_timing.get("model",0.0) or 0.0):.1f} model_per_candidate_seconds={float(scan_timing.get("model_per_candidate",0.0) or 0.0):.1f} model_profile_count={int(scan_timing.get("model_profile_count",0) or 0)} profile_live_row={float(scan_timing.get("model_profile_live_row_seconds",0.0) or 0.0):.1f} profile_predict={float(scan_timing.get("model_profile_predict_seconds",0.0) or 0.0):.1f} profile_diagnostics={float(scan_timing.get("model_profile_diagnostics_seconds",0.0) or 0.0):.1f} profile_lens={float(scan_timing.get("model_profile_lens_seconds",0.0) or 0.0):.1f} math={float(scan_timing.get("math_validation",0.0) or 0.0):.1f} freshness={float(scan_timing.get("freshness",0.0) or 0.0):.1f} scan_persist={float(scan_timing.get("scan_prediction_persistence",0.0) or 0.0):.1f} market={int(total)} quick_ok={int(quick_count)} deep={int((diagnostics or {}).get("deep_candidates",0) or 0)} stage25={int((diagnostics or {}).get("second_stage_candidates_submitted",(diagnostics or {}).get("second_stage_candidates",0)) or 0)} stage25_done={int((diagnostics or {}).get("second_stage_candidates_completed",(diagnostics or {}).get("second_stage_candidates",0)) or 0)} math_profile={json.dumps((diagnostics or {}).get("math_profile",{}).get("formula_seconds",{}),ensure_ascii=False)} top5={len(rows or [])} errors={int(errors)} model_stage_timed_out={bool((diagnostics or {}).get("model_stage_timed_out",False))} math_stage_timed_out={bool((diagnostics or {}).get("math_stage_timed_out",False))} cancelled={bool((diagnostics or {}).get("cancelled",False))}')
            if cancel_event.is_set() or (isinstance(diagnostics,dict) and diagnostics.get('cancelled')) or stopped():
                set_state(status='stopped', running=False, paused=True, done=False, phase='STOPPED',
                          total=int(total), quick_count=int(quick_count), errors=int(errors),
                          diagnostics=diagnostics or {}, rows=[], cycle=cycle, readiness=engine.readiness())
                break

            # The market scan has produced and mathematically validated its
            # candidates. Publishing must not wait for the unrelated historical
            # outcome sweep or retraining. Maintenance is run immediately AFTER
            # TOP-5 persistence/publication, with current-cycle IDs excluded.
            def run_post_scan_maintenance(exclude_prediction_ids=None):
                nonlocal resolved, retrained, readiness, outcome_priority_contracts
                maintenance_started=time.monotonic()
                resolve_started=time.monotonic()
                runtime_log('LEARN_RESOLVE_START: resolving active forecasts from shared hourly-scan candle cache (post-publication)')
                resolved=engine.resolve_all_pending(exclude_ids=exclude_prediction_ids)
                runtime_log(f'LEARN_RESOLVE_DONE elapsed_seconds={time.monotonic()-resolve_started:.2f} resolved={len(resolved or [])} per_contract={json.dumps(getattr(engine,"_last_resolve_profile",[]),ensure_ascii=False)}')
                wait_started=time.monotonic()
                runtime_log('WAIT_RESOLVE_START: advancing WAIT learning horizon from shared hourly-scan candle cache (post-publication)')
                wait_resolved,wait_diagnostics=engine.resolve_wait_learning(exclude_ids=exclude_prediction_ids)
                runtime_log(f'WAIT_RESOLVE_DONE elapsed_seconds={time.monotonic()-wait_started:.2f} '
                            f'resolved={len(wait_resolved or [])} diagnostics={json.dumps(wait_diagnostics or {},ensure_ascii=False)} '
                            f'per_contract={json.dumps(getattr(engine,"_last_wait_resolve_profile",[]),ensure_ascii=False)}')
                # Resolve formula-lens shadow observations in their own ledger.
                # This runs only after the live TOP-5 has already been published;
                # incomplete windows remain pending and never block the Master.
                try:
                    math_shadow_resolution=engine.resolve_math_shadow_observations()
                    runtime_log(f'MATH_SHADOW_RESOLVE status={math_shadow_resolution.get("status")} '
                                f'checked={math_shadow_resolution.get("checked",0)} '
                                f'resolved={math_shadow_resolution.get("resolved",0)} '
                                f'training_rows_added={math_shadow_resolution.get("training_rows_added",0)} '
                                f'fetch_errors={math_shadow_resolution.get("fetch_errors",0)}')
                except Exception as math_shadow_exc:
                    runtime_log(f'MATH_SHADOW_RESOLVE_ERROR: {str(math_shadow_exc)[:200]}','WARN')
                outcome_priority_contracts=_add_outcome_analysis_priority(resolved)
                resolved_contracts=[x.get('contract') or x.get('exchange_symbol') for x in resolved
                                    if x.get('contract') or x.get('exchange_symbol')]
                global_resolved=engine._count_resolved_logs()
                retrained=_retrain_with_real_position_batch(engine,resolved_contracts,global_resolved)
                readiness=engine.readiness()
                elapsed=time.monotonic()-maintenance_started
                runtime_log(f'POST_SCAN_MAINTENANCE_DONE elapsed_seconds={elapsed:.2f} '
                            f'resolved={len(resolved or [])} retrained={len(retrained or [])}')
                return elapsed

            analyzed_priority = (diagnostics or {}).get('priority_analyzed_contracts', []) if isinstance(diagnostics, dict) else []
            _consume_outcome_analysis_priority(analyzed_priority)
            unique={r.get('contract'):r for r in rows if r.get('contract')}
            rows=list(unique.values())[:5]
            # TOP-5 is a maximum, not a requirement to manufacture WAIT rows.
            # If the full market pass finds only 1-4 real LONG/SHORT
            # opportunities, verify those real predictions without padding the
            # list. Verification is asynchronous and does not block new scans.
            if not rows:
                run_post_scan_maintenance(exclude_prediction_ids=[])
                # Continue the one-hour delayed direction rechecks even when this
                # market pass finds no new LONG/SHORT candidates.
                _queue_active_forecast_recheck(engine.cfg, cancel_event=cancel_event, cycle=cycle)
                # A cycle with no validated trade candidate is not a TOP-5
                # issuance. Keep the last issued TOP-5 visible. Active forecasts
                # wait for TP/SL; only outcome-triggered contracts get priority.
                diag=dict(diagnostics or {})
                diag['no_trade_candidates']=True
                diag['valid_predictions']=0
                set_state(status='running', running=True, paused=False, done=False,
                          phase='NO_CANDIDATES', cycle=cycle, total=int(total),
                          quick_count=int(quick_count), errors=int(errors),
                          diagnostics=diag, rows=[], prediction_ids=[],
                          readiness=engine.readiness(),
                          message='Полный проход завершён: валидных кандидатов нет. Последний выданный TOP-5 сохранён; следующий цикл идёт по расписанию.')
                # No trade candidates do not reset the cadence. The next full
                # scan is still scheduled one hour from this scan start.
                next_scan_at = scan_started_at + scan_interval
                while not stopped() and not cancel_event.is_set() and time.time() < next_scan_at:
                    remaining=max(1,int(next_scan_at-time.time()))
                    set_state(status='running', running=True, paused=False, done=False, phase='WAIT_NEXT_SCAN',
                              cycle=cycle, next_scan_in=remaining, next_scan_at=int(next_scan_at),
                              readiness=engine.readiness(),
                              message=f'Следующее полное сканирование через {remaining} сек. (фиксированный интервал 1 час).')
                    if not _sleep_or_stop(min(20,remaining),cancel_event): break
                continue

            # TOP-5 scan rows must be persisted in the canonical prediction/pending logs.
            # Otherwise they can remain visible as "Проверяется" forever while global
            # statistics only count manually stored forecasts.
            persistence_started=time.monotonic()
            runtime_log(f'SCAN_PERSISTENCE_START cycle={cycle} candidates={len(rows)}')
            try:
                persisted_rows = engine.persist_scan_predictions(rows)
            except Exception as exc:
                runtime_log(f'SCAN_PERSISTENCE_ERROR cycle={cycle}: {exc}', 'ERROR')
                persisted_rows = []
                diagnostics = dict(diagnostics or {}, persistence_error=str(exc))
            persistence_seconds=time.monotonic()-persistence_started
            runtime_log(f'SCAN_PERSISTENCE_DONE cycle={cycle} elapsed_seconds={persistence_seconds:.3f} saved={len(persisted_rows)}')
            if len(persisted_rows) == len(rows):
                engine._last_issued_top5 = list(rows)
                math_shadow_status = engine.start_math_shadow_worker()
                runtime_log(f'MATH_SHADOW_QUEUED cycle={cycle} status={math_shadow_status.get("status")} candidates={math_shadow_status.get("count",0)}')
            if len(persisted_rows) != len(rows):
                # Do not display a TOP-5 as successfully persisted when any
                # contract failed lifecycle reconciliation.
                set_state(status='running', running=True, paused=False, done=False,
                          phase='PERSISTENCE_ERROR', cycle=cycle, total=int(total),
                          quick_count=int(quick_count), errors=int(errors) + (len(rows) - len(persisted_rows)),
                          diagnostics=dict(diagnostics or {}, persistence_expected=len(rows), persistence_saved=len(persisted_rows)),
                          rows=persisted_rows, prediction_ids=[r.get('id') for r in persisted_rows if r.get('id')],
                          readiness=engine.readiness(),
                          message=f'Ошибка сохранения жизненного цикла прогнозов: сохранено {len(persisted_rows)} из {len(rows)}. Неподтверждённые строки не выдаются как сохранённые.')
                # Retry on the next fixed scan; don't falsely report these rows
                # as persisted and don't create an alternate ad-hoc lifecycle.
                next_scan_at = scan_started_at + scan_interval
                while not stopped() and not cancel_event.is_set() and time.time() < next_scan_at:
                    remaining=max(1,int(next_scan_at-time.time()))
                    set_state(status='running', running=True, paused=False, done=False, phase='WAIT_NEXT_SCAN',
                              cycle=cycle, next_scan_in=remaining, next_scan_at=int(next_scan_at),
                              readiness=engine.readiness(),
                              message=f'Ошибка сохранения прогнозов. Повторный полный скан через {remaining} сек.')
                    if not _sleep_or_stop(min(20,remaining),cancel_event): break
                continue
            rows = persisted_rows
            # Capture the exact local-device epoch when this TOP-5 was issued.
            # Keep this separate from each prediction lifecycle's original `time`:
            # a contract can reappear in a later TOP-5 while its original forecast
            # remains active. The issuance timestamp belongs to this scan event.
            top5_issued_at = int(time.time())
            for issued_row in rows:
                if isinstance(issued_row, dict):
                    issued_row['top5_issued_at'] = top5_issued_at
                    issued_row['top5_cycle'] = int(cycle)
            prediction_ids=[r.get('id') for r in rows if r.get('id')]
            # Exclude only lifecycles created by this scan. Existing active
            # lifecycles remain eligible for the just-completed TP/SL/WAIT sweep.
            new_lifecycle_ids=[r.get('id') for r in rows
                               if r.get('id') and str(r.get('state_lifecycle_status','')).upper()=='ACTIVE_NEW']
            # Publish the issued TOP-5 immediately. No continuous model-direction
            # recheck is queued for the rest of the active pool: those forecasts
            # wait for TP/SL, and the outcome-triggered priority queue is handled
            # inside the next full market-analysis pass.
            top5_started_at=top5_issued_at
            next_scan_at=scan_started_at + scan_interval
            next_scan_remaining=max(0,int(next_scan_at-time.time()))
            set_state(status='running', running=True, paused=False, done=False, phase='VERIFY',
                      cycle=cycle, total=int(total), quick_count=int(quick_count), errors=int(errors),
                      diagnostics=dict(diagnostics or {}), rows=rows, prediction_ids=prediction_ids,
                      last_top5=rows[:5], last_top5_cycle=cycle, top5_started_at=top5_started_at,
                      top5_issued_at=top5_issued_at,
                      scan_started_at=int(scan_started_at), scan_interval_seconds=scan_interval,
                      next_scan_at=int(next_scan_at), next_scan_in=next_scan_remaining,
                      resolved_count=int(readiness.get('resolved',0) or 0), resolved_total=len(prediction_ids), readiness=readiness,
                      message=f'TOP-5 выдан и сохранён: {len(rows)} из 5. Следующий полный скан по фиксированному расписанию через {next_scan_remaining} сек.')
            runtime_log(f'TOP5_ISSUED cycle={cycle} count={len(rows)} elapsed_since_cycle_start_seconds={time.monotonic()-cycle_started_monotonic:.3f} ids={json.dumps(prediction_ids, ensure_ascii=False)}')
            maintenance_seconds=run_post_scan_maintenance(exclude_prediction_ids=new_lifecycle_ids)
            set_state(status='running', running=True, paused=False, done=False, phase='VERIFY',
                      cycle=cycle, rows=rows, prediction_ids=prediction_ids, last_top5=rows[:5],
                      last_top5_cycle=cycle, readiness=readiness, resolved_count=int(readiness.get('resolved',0) or 0),
                      diagnostics=dict(diagnostics or {},post_publication_maintenance_seconds=round(maintenance_seconds,3),
                                      scan_persistence_seconds=round(persistence_seconds,3),
                                      current_cycle_new_lifecycles=len(new_lifecycle_ids)))
            # Run the delayed LONG/SHORT direction-recheck queue asynchronously.
            # It records observations only; original Entry/SL/TP and lifecycle
            # remain immutable. Queue snapshots coalesce so backlog cannot grow
            # by one full copy of the market on every hourly scan.
            _queue_active_forecast_recheck(engine.cfg, cancel_event=cancel_event, cycle=cycle)
            top5_recheck_event = threading.Event()
            _schedule_top5_candle_recheck(engine, rows, cancel_event, cycle, top5_recheck_event)
            # Fixed cadence: the next full market scan is scheduled one hour
            # after this scan STARTED. Previous TOP-5 predictions are not allowed
            # to delay the next scan; they continue through resolve_all_pending()
            # while the complete TP/SL pool is advanced before each hourly scan.
            next_scan_at = scan_started_at + scan_interval
            while not cancel_event.is_set() and not stopped() and time.time() < next_scan_at:
                if top5_recheck_event.is_set():
                    runtime_log('NEXT_FULL_SCAN_EARLY cycle={} reason=TOP5_ALL_RESOLVED_AT_40M'.format(cycle))
                    break
                # Do not resolve every pending forecast and attempt retraining
                # every 20 seconds. That work used to monopolize the scan thread
                # and could postpone the next full pass by tens of minutes.
                remaining_seconds=max(0,int(next_scan_at-time.time()))
                set_state(status='running', running=True, paused=False, done=False, phase='WAIT_NEXT_SCAN',
                          cycle=cycle, total=int(total), quick_count=int(quick_count), errors=int(errors),
                          rows=rows, prediction_ids=prediction_ids, last_top5=rows[:5], last_top5_cycle=cycle,
                          scan_started_at=int(scan_started_at), scan_interval_seconds=scan_interval,
                          next_scan_at=int(next_scan_at), next_scan_in=remaining_seconds,
                          readiness=engine.readiness(),
                          message=(f'Новый полный скан через {remaining_seconds} сек. Фиксированный интервал: 1 час. '
                                   f'Проверка старых прогнозов выполняется отдельно.'))
                if not _sleep_or_stop(min(20,max(1,remaining_seconds)),cancel_event):
                    break
            if cancel_event.is_set() or stopped():
                break
            # Continue directly into the next fixed-cadence scan.
            continue

        set_state(status='stopped', running=False, paused=True, done=False, phase='STOPPED',
                  service_alive=False, service_instance_id=instance_id)
        if wake_lock is not None:
            try: wake_lock.release()
            except Exception: pass
    except Exception as exc:
        runtime_log('FATAL SERVICE EXCEPTION: ' + repr(exc), 'ERROR')
        runtime_log(traceback.format_exc(), 'ERROR')
        set_state(status='error', running=False, paused=False, done=False, phase='ERROR',
                  service_alive=False, service_instance_id=instance_id, error=str(exc),
                  traceback=traceback.format_exc())
        if wake_lock is not None:
            try: wake_lock.release()
            except Exception: pass
    finally:
        runtime_log('SERVICE EXIT: releasing resources')
        heartbeat_stop.set()
        if lock_acquired:
            release_service_lock(instance_id)


if __name__ == '__main__':
    main()
