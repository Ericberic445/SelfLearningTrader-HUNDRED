import numpy as np
import time

MATH_FORMULA_VERSION = 9
CALIBRATION_FIELDS = {
    'math_prob_move': 'move_hit',
    'math_monte_carlo': 'positive_return',
    'math_bayesian': 'positive_return',
    'math_ptp1': 'tp1_before_sl',
    'math_ptp2': 'tp2_before_sl',
    'math_ptp3': 'tp3_before_sl',
    'math_psl': 'sl_before_tp1',
}

# Causal mathematical features used at the deep-analysis stage. Pairwise
# features are computed only when a benchmark price series is supplied.
MATH_FEATURES = [
    'math_markov','math_prob_move','math_ar','math_arima','math_sarima','math_garch',
    'math_hurst','math_mean_reversion','math_cointegration','math_correlation',
    'math_return_vol_correlation','math_trend_deviation','math_entropy','math_fractal',
    'math_wavelet','math_kalman','math_monte_carlo','math_bayesian','math_change_point',
    'math_ptp1','math_ptp2','math_ptp3','math_psl'
]


def _safe(a):
    return np.nan_to_num(np.asarray(a, dtype=float), nan=0.0, posinf=0.0, neginf=0.0)

def _safe_prices(a):
    """Return only valid positive observations; never forward/back-fill prices.

    Callers that also use OHLC/timestamps must apply the same validity mask to
    every aligned field before calling this helper.
    """
    raw = np.asarray(a, dtype=float).reshape(-1)
    if not len(raw):
        return raw
    return raw[np.isfinite(raw) & (raw > 0)]


def _ols_ar(x, p=3):
    """Fit an AR(p) by least squares and return its one-step forecast signal."""
    x = _safe(x)
    p = max(1, int(p))
    if len(x) <= p + 8:
        return 0.0
    y = x[p:]
    X = np.column_stack([np.ones(len(y))] + [x[p-i-1:len(x)-i-1] for i in range(p)])
    try:
        coef = np.linalg.lstsq(X, y, rcond=None)[0]
        forecast = float(np.asarray([1.0] + [float(x[-i-1]) for i in range(p)]) @ coef)
        residual = y - X @ coef
        scale = max(float(np.std(residual, ddof=min(X.shape[1], max(0, len(residual)-1)))), 1e-12)
        return float(np.tanh(forecast / scale))
    except Exception:
        return 0.0


def _arima_111(rets):
    """Conditional-sum-of-squares ARIMA(1,1,1) forecast on log-price levels.

    Input is a log-return series, i.e. the first difference of log prices. The
    fitted ARMA(1,1) is therefore the differenced ARIMA(1,1,1) representation.
    Parameters are estimated by bounded conditional sum of squares, not fixed
    coefficients. Output is a volatility-normalized next-return forecast.
    """
    y = _safe(rets)
    if len(y) < 35:
        return 0.0
    y = y[-240:]
    mean_return = float(np.mean(y))
    y = y - mean_return
    scale = float(np.std(y))
    if not np.isfinite(scale) or scale < 1e-12:
        return 0.0
    z = y / scale
    best = (float('inf'), 0.0, 0.0, 0.0, np.zeros_like(z))
    # Coarse grid initialization followed by coordinate refinement. Restrict
    # AR and MA roots to the stationary/invertible interval.
    for phi in np.linspace(-0.90, 0.90, 13):
        for theta in np.linspace(-0.90, 0.90, 13):
            resid = np.zeros_like(z)
            for i in range(1, len(z)):
                resid[i] = z[i] - phi*z[i-1] - theta*resid[i-1]
            loss = float(np.mean(resid[5:]**2))
            if loss < best[0]:
                best = (loss, float(phi), float(theta), 0.0, resid)
    _, phi, theta, _, resid = best
    for step in (0.10, 0.04, 0.015):
        candidates = []
        for pp in (phi-step, phi, phi+step):
            for tt in (theta-step, theta, theta+step):
                if abs(pp) >= 0.98 or abs(tt) >= 0.98:
                    continue
                rr = np.zeros_like(z)
                for i in range(1, len(z)):
                    rr[i] = z[i] - pp*z[i-1] - tt*rr[i-1]
                candidates.append((float(np.mean(rr[5:]**2)), pp, tt, rr))
        if candidates:
            loss, phi, theta, resid = min(candidates, key=lambda q:q[0])
    forecast_z = phi*z[-1] + theta*resid[-1] + mean_return/scale
    return float(np.tanh(forecast_z / max(float(np.std(resid[5:])), 1e-12)))


def _sarima_101_101(rets, season=12):
    """Fit multiplicative SARIMA(1,0,0)(1,0,0,s) by conditional SSE.

    For the multiplicative specification, the AR polynomial is
    (1 - phi*B)(1 - Phi*B**s), so the equation contains the constrained
    cross-term -phi*Phi*y[t-s-1]. phi and Phi are estimated under stationary
    bounds rather than fitting the cross-term as an unrelated coefficient.
    """
    y = _safe(rets)
    s = max(2, int(season))
    # Require at least 6 complete seasonal cycles; use a much longer history
    # than the old 3-cycle minimum, while remaining bounded for Android.
    if len(y) < max(48, 6*s):
        return 0.0
    y = y[-720:]
    lag = s+1
    target = y[lag:]
    y1, ys, ycross = y[lag-1:-1], y[lag-s:-s], y[:-s-1]
    if np.std(target) < 1e-12:
        return 0.0
    best = (float('inf'), 0.0, 0.0, 0.0)
    for phi in np.linspace(-0.85, 0.85, 11):
        for seasonal_phi in np.linspace(-0.85, 0.85, 11):
            cross = -phi*seasonal_phi
            intercept = float(np.mean(target-phi*y1-seasonal_phi*ys-cross*ycross))
            resid = target-(intercept+phi*y1+seasonal_phi*ys+cross*ycross)
            loss = float(np.mean(resid**2))
            if loss < best[0]:
                best = (loss, float(phi), float(seasonal_phi), intercept)
    _, phi, seasonal_phi, intercept = best
    for step in (0.08, 0.03, 0.01):
        candidates = []
        for pp in np.linspace(max(-0.97, phi-step), min(0.97, phi+step), 5):
            for ss in np.linspace(max(-0.97, seasonal_phi-step), min(0.97, seasonal_phi+step), 5):
                cross = -pp*ss
                cc = float(np.mean(target-pp*y1-ss*ys-cross*ycross))
                residual = target-(cc+pp*y1+ss*ys+cross*ycross)
                candidates.append((float(np.mean(residual**2)), float(pp), float(ss), cc))
        _, phi, seasonal_phi, intercept = min(candidates, key=lambda item:item[0])
    # Empirical-Bayes style shrinkage is applied after fitting so the optimizer
    # cannot immediately undo it on a short/noisy seasonal sample.
    seasonal_phi *= min(1.0, max(0.25, (len(y) / float(20*s))))
    cross = -phi*seasonal_phi
    intercept = float(np.mean(target-phi*y1-seasonal_phi*ys-cross*ycross))
    forecast = intercept+phi*y[-1]+seasonal_phi*y[-s]+cross*y[-s-1]
    resid = target-(intercept+phi*y1+seasonal_phi*ys+cross*ycross)
    scale = max(float(np.std(resid)), 1e-12)
    return float(np.tanh(forecast/scale))

def _fit_garch11(ret):
    """Fit Gaussian-QMLE GARCH(1,1) by constrained grid search.

    Returns (conditional_variance, omega, alpha, beta). alpha,beta are
    constrained nonnegative with alpha+beta < 1 for covariance stationarity.
    """
    r = _safe(ret)
    if len(r) < 25:
        # Too little history for a defensible GARCH parameter fit: retain only
        # unconditional variance and mark fitted dynamics neutral.
        v = max(float(np.var(r)), 0.0)
        return v, 0.0, 0.0, 0.0
    r = r[-500:] - float(np.mean(r[-500:]))
    unconditional = float(np.var(r))
    if not np.isfinite(unconditional) or unconditional < 1e-24:
        return 0.0, 0.0, 0.0, 0.0
    best = (float('inf'), unconditional*0.05, 0.05, 0.90, np.full(len(r), unconditional))
    # QMLE objective. Coarse grid keeps this practical on Android; coefficients
    # are fitted per series rather than hard-coded.
    alphas = np.linspace(0.02, 0.25, 8)
    betas = np.linspace(0.50, 0.96, 12)
    for alpha in alphas:
        for beta in betas:
            if alpha + beta >= 0.995:
                continue
            omega = max(unconditional*(1.0-alpha-beta), 1e-18)
            var = np.empty(len(r), dtype=float)
            var[0] = unconditional
            for i in range(1, len(r)):
                var[i] = omega + alpha*r[i-1]*r[i-1] + beta*var[i-1]
                if not np.isfinite(var[i]) or var[i] <= 0:
                    var[i] = unconditional
            objective = float(np.mean(np.log(np.maximum(var[1:], 1e-24)) + r[1:]**2/np.maximum(var[1:], 1e-24)))
            if objective < best[0]:
                best = (objective, omega, float(alpha), float(beta), var)
    _, omega, alpha, beta, var = best
    next_var = omega + alpha*r[-1]*r[-1] + beta*var[-1]
    return max(float(next_var), 0.0), float(omega), alpha, beta

def _entropy(x, bins=8):
    x = _safe(x)
    if len(x) < 10 or np.ptp(x) < 1e-12:
        return 0.0
    hist, _ = np.histogram(x, bins=bins)
    p = hist.astype(float) / max(float(np.sum(hist)), 1.0)
    p = p[p > 0]
    return float(-np.sum(p * np.log2(p)) / np.log2(bins))


def _hurst(x):
    """Estimate H from log-log scaling of standard deviation of lagged changes."""
    x = _safe(x)
    n = len(x)
    if n < 32 or np.std(x) < 1e-12:
        return 0.5
    lags = sorted(set(max(2, int(v)) for v in (2, 3, 4, 6, 8, 12, 16, 24) if v < n//2))
    scales = []
    for lag in lags:
        delta = x[lag:] - x[:-lag]
        sd = float(np.std(delta))
        if np.isfinite(sd) and sd > 1e-12:
            scales.append((lag, sd))
    if len(scales) < 3:
        return 0.5
    slope = np.polyfit(np.log([v[0] for v in scales]), np.log([v[1] for v in scales]), 1)[0]
    return float(np.clip(slope, 0.0, 1.0))

def _kalman(x, q=None, r=None):
    """Two-state local-linear-trend Kalman filter (level and slope).

    Process and observation noise are scaled from the input series so the
    filter behaves consistently across assets with different price levels.
    The returned signal is the one-step predicted level residual in standard
    deviation units, clipped to [-1,1].
    """
    z = _safe(x)
    if len(z) < 3:
        return 0.0
    scale = max(float(np.std(np.diff(z))), 1e-9)
    q_level = float(q if q is not None else (0.02*scale)**2)
    q_slope = (0.005*scale)**2
    obs_var = float(r if r is not None else (0.15*scale)**2)
    F = np.asarray([[1.0, 1.0], [0.0, 1.0]])
    H = np.asarray([[1.0, 0.0]])
    Q = np.asarray([[q_level, 0.0], [0.0, q_slope]])
    R = max(obs_var, 1e-18)
    state = np.asarray([z[0], 0.0])
    P = np.eye(2)*max(float(np.var(z[:min(len(z), 20)])), 1e-8)
    for obs in z[1:]:
        state = F @ state
        P = F @ P @ F.T + Q
        innovation = float(obs - (H @ state)[0])
        S = float((H @ P @ H.T)[0,0] + R)
        if not np.isfinite(S) or S <= 1e-18:
            continue
        K = (P @ H.T)[:,0] / S
        state = state + K*innovation
        P = (np.eye(2)-np.outer(K, H[0])) @ P
        P = 0.5*(P+P.T)
    next_level = float((F @ state)[0])
    return float(np.clip((next_level-z[-1])/max(float(np.std(z[-min(len(z), 60):])), 1e-9), -1, 1))

def _wavelet_dwt(x):
    """Multilevel Haar DWT; positive detail means recent values rise across each pair."""
    a = _safe(x)
    if len(a) < 16:
        return 0.0
    a = a[-(len(a)//16*16):]
    if len(a) < 16:
        return 0.0
    details = []
    current = a.copy()
    root2 = np.sqrt(2.0)
    while len(current) >= 2:
        if len(current) % 2:
            current = current[:-1]
        left, right = current[0::2], current[1::2]
        detail = (right-left)/root2
        approximation = (left+right)/root2
        details.append(detail)
        current = approximation
    # Use all decomposition scales; recent signed detail gives direction while
    # RMS detail energy supplies a scale-normalized denominator.
    signed = 0.0
    energy = 0.0
    for level, d in enumerate(details, start=1):
        weight = 1.0/np.sqrt(level)
        signed += weight*float(np.mean(d[-max(1, len(d)//4):]))
        energy += weight*float(np.sqrt(np.mean(d*d)))
    if energy < 1e-12:
        return 0.0
    return float(np.clip(signed/energy, -1, 1))


def _wavelet_proxy(x):
    """Backward-compatible alias for the full multilevel Haar DWT feature."""
    return _wavelet_dwt(x)

def _change_point(x):
    x = _safe(x)
    if len(x) < 20:
        return 0.0
    sd = float(np.std(x))
    if sd < 1e-12:
        return 0.0
    n = len(x); best = 0.0
    for k in range(max(5, n-40), n-5):
        score = abs(float(np.mean(x[:k])) - float(np.mean(x[k:]))) / sd
        best = max(best, score)
    return float(np.clip(best / 3.0, 0, 1))


def _markov(rets):
    """Three-state transition score robust to tied/constant return series."""
    r = _safe(rets)
    if len(r) < 12:
        return 0.0
    scale = float(np.std(r))
    if scale < 1e-12:
        # Constant non-zero returns have direction but no transition evidence;
        # leave the Markov component neutral and let AR/Bayesian capture drift.
        return 0.0
    # Markov states represent actual return direction, not relative quantiles.
    # Quantile states incorrectly labeled the highest tercile of a falling
    # market as an "up" state and could output +1 for steadily falling prices.
    neutral_band = max(scale * 0.10, 1e-12)
    states = np.where(r < -neutral_band, 0, np.where(r > neutral_band, 2, 1)).astype(int)
    cur = int(states[-1])
    prior = states[:-1]
    den = int(np.sum(prior == cur))
    if den == 0:
        # No history for this state: no evidence, not a directional +1.
        return 0.0
    next_states = states[1:]
    p_down = float(np.sum((prior == cur) & (next_states == 0))) / den
    p_up = float(np.sum((prior == cur) & (next_states == 2))) / den
    return float(np.clip(p_up - p_down, -1, 1))


def _trend_deviation(logp):
    """Single-series deviation from a linear trend; not cointegration."""
    x = _safe(logp)
    if len(x) < 20:
        return 0.0
    t = np.arange(len(x), dtype=float)
    slope = np.polyfit(t, x, 1)[0]
    resid = x - (slope*t + np.mean(x-slope*t))
    sd = float(np.std(resid))
    if sd < 1e-12:
        return 0.0
    return float(np.clip(-(resid[-1]-np.mean(resid))/sd, -1, 1))


def _relative_spread(logp, benchmark_logp):
    """Engle-Granger two-step cointegration signal with residual ADF test.

    Step 1 estimates the cointegrating regression with intercept. Step 2 runs an
    augmented Dickey-Fuller regression on residuals with up to five lagged
    differences selected by AIC. Residual-test critical value is conservative
    and cointegration-specific; no signal is emitted unless the residual
    process is sufficiently stationary and the current spread is displaced.
    """
    y = _safe(logp); x = _safe(benchmark_logp)
    n = min(len(y), len(x))
    if n < 60:
        return 0.0
    y, x = y[-n:], x[-n:]
    if np.std(y) < 1e-12 or np.std(x) < 1e-12:
        return 0.0
    try:
        X = np.column_stack([np.ones(n), x])
        beta = np.linalg.lstsq(X, y, rcond=None)[0]
        resid = y-X@beta
        sigma = float(np.std(resid, ddof=2))
        if sigma < 1e-10:
            return 0.0
        dy = np.diff(resid)
        level = resid[:-1]
        max_lag = min(5, max(0, len(dy)//10))
        best = None
        for lag in range(max_lag+1):
            start = lag
            target = dy[start:]
            cols = [np.ones(len(target)), level[start:]]
            for j in range(1, lag+1):
                cols.append(dy[start-j:len(dy)-j])
            design = np.column_stack(cols)
            coef = np.linalg.lstsq(design, target, rcond=None)[0]
            err = target-design@coef
            dof = len(target)-design.shape[1]
            if dof <= 2:
                continue
            s2 = float(np.dot(err,err)/dof)
            cov = s2*np.linalg.pinv(design.T@design)
            se = float(np.sqrt(max(cov[1,1], 0.0)))
            tstat = float(coef[1]/se) if se > 1e-12 else 0.0
            aic = len(target)*np.log(max(float(np.mean(err*err)), 1e-24))+2*design.shape[1]
            if best is None or aic < best[0]:
                best = (aic, tstat, float(coef[1]))
        if best is None:
            return 0.0
        _, tstat, rho = best
        # Approximate 5% Engle-Granger critical value for two I(1) series with
        # an intercept. This is a decision gate, not a claim of exact p-values.
        significance = float(np.clip((-3.34-tstat)/2.0, 0.0, 1.0))
        half_life_strength = float(np.clip(-rho/0.25, 0.0, 1.0)) if rho < 0 else 0.0
        z = float(resid[-1]/sigma)
        return float(np.clip(-z, -1, 1)*significance*half_life_strength)
    except Exception:
        return 0.0

def _correlation(x, benchmark):
    """Correlation of instrument returns with benchmark returns."""
    x = _safe(x); v = _safe(benchmark)
    n = min(len(x), len(v))
    if n < 10:
        return 0.0
    x = x[-n:]; v = v[-n:]
    if np.std(x) < 1e-12 or np.std(v) < 1e-12:
        return 0.0
    return float(np.clip(np.corrcoef(x, v)[0, 1], -1, 1))


def compute_correlation_matrix(series_by_symbol, min_overlap=30):
    """Return a timestamp-aligned Pearson correlation matrix of log returns.

    Each mapping value is a candle mapping with `time` and `close` arrays. The
    matrix is descriptive, not a directional vote; insufficient/constant pairs
    receive neutral off-diagonal correlation 0. Diagonal entries are 1 for a
    series with enough valid returns. The caller decides which universe to pass.
    """
    if not isinstance(series_by_symbol, dict):
        return {'symbols': [], 'matrix': [], 'overlap_counts': []}
    returns_by_symbol = {}
    for symbol, payload in series_by_symbol.items():
        try:
            times = np.asarray(payload.get('time', []), dtype=np.int64).reshape(-1)
            close = np.asarray(payload.get('close', []), dtype=float).reshape(-1)
            n = min(len(times), len(close))
            times, close = times[-n:], close[-n:]
            valid = np.isfinite(close) & (close > 0)
            times, close = times[valid], close[valid]
            if len(times) < int(min_overlap)+1:
                continue
            order = np.argsort(times, kind='mergesort')
            times, close = times[order], close[order]
            # Keep the last valid observation for duplicate candle timestamps.
            keep = np.r_[times[1:] != times[:-1], True]
            times, close = times[keep], close[keep]
            if len(times) < int(min_overlap)+1:
                continue
            dt = np.diff(times)
            positive_dt = dt[dt > 0]
            if not len(positive_dt):
                continue
            typical_dt = float(np.median(positive_dt))
            ret = np.diff(np.log(close))
            ret_times = times[1:]
            contiguous = (dt > 0) & (dt <= typical_dt*1.5)
            aligned = {int(t):float(r) for t,r,ok in zip(ret_times,ret,contiguous) if ok and np.isfinite(r)}
            if len(aligned) >= int(min_overlap):
                returns_by_symbol[str(symbol)] = aligned
        except Exception:
            continue
    symbols = sorted(returns_by_symbol)
    size = len(symbols)
    matrix = np.eye(size, dtype=float).tolist()
    overlaps = [[0 for _ in range(size)] for _ in range(size)]
    for i in range(size):
        overlaps[i][i] = len(returns_by_symbol[symbols[i]])
        for j in range(i+1, size):
            left, right = returns_by_symbol[symbols[i]], returns_by_symbol[symbols[j]]
            shared = sorted(set(left).intersection(right))
            overlaps[i][j] = overlaps[j][i] = len(shared)
            corr = 0.0
            if len(shared) >= int(min_overlap):
                a = np.asarray([left[t] for t in shared], dtype=float)
                b = np.asarray([right[t] for t in shared], dtype=float)
                if np.std(a) > 1e-12 and np.std(b) > 1e-12:
                    corr = float(np.clip(np.corrcoef(a,b)[0,1], -1.0, 1.0))
                    if not np.isfinite(corr): corr = 0.0
            matrix[i][j] = matrix[j][i] = corr
    return {'symbols':symbols, 'matrix':matrix, 'overlap_counts':overlaps}


def _return_vol_correlation(rets):
    r = _safe(rets)
    if len(r) < 10 or np.std(r) < 1e-12 or np.std(np.abs(r)) < 1e-12:
        return 0.0
    return float(np.clip(np.corrcoef(r, np.abs(r))[0, 1], -1, 1))


def _garch(ret):
    """Return the fitted GARCH(1,1) one-step conditional standard deviation."""
    variance, _, _, _ = _fit_garch11(ret)
    return float(np.sqrt(max(variance, 0.0)))


def _monte_carlo_paths(rets, horizon=12, paths=400, seed=7, return_step_returns=False):
    """Simulate returns with fitted AR(1) drift and GARCH(1,1) volatility.

    Standardized historical innovations are resampled empirically instead of
    assuming normally distributed returns. A fixed seed makes a given input
    reproducible; paths are cumulative log returns, not simple returns.
    """
    r = _safe(rets)
    horizon = max(1, int(horizon)); paths = max(1, int(paths))
    if len(r) < 25:
        empty = np.zeros((0, horizon), dtype=float)
        return (empty, empty.copy()) if return_step_returns else empty
    r = r[-500:]
    mu = float(np.mean(r))
    centered = r-mu
    if np.std(centered) < 1e-12:
        steps = np.full((paths, horizon), mu)
        cumulative = np.cumsum(steps, axis=1)
        return (cumulative, steps) if return_step_returns else cumulative
    try:
        phi = float(np.linalg.lstsq(np.column_stack([np.ones(len(centered)-1), centered[:-1]]), centered[1:], rcond=None)[0][1])
    except Exception:
        phi = 0.0
    phi = float(np.clip(phi, -0.95, 0.95))
    _, omega, alpha, beta = _fit_garch11(r)
    variance = max(float(np.var(centered)), 1e-18)
    for i in range(1, len(centered)):
        variance = max(omega+alpha*centered[i-1]**2+beta*variance, 1e-18)
    sigma = np.sqrt(variance)
    innovations = centered[1:] - phi*centered[:-1]
    innovation_sd = max(float(np.std(innovations)), 1e-12)
    standardized = innovations/innovation_sd
    standardized = standardized[np.isfinite(standardized)]
    if len(standardized) < 5:
        standardized = np.asarray([-1.0, 0.0, 1.0])
    rng = np.random.default_rng(int(seed))
    sampled = rng.choice(standardized, size=(paths, horizon), replace=True)
    out = np.empty((paths, horizon), dtype=float)
    prev = np.full(paths, float(centered[-1]))
    var_path = np.full(paths, variance)
    for t in range(horizon):
        var_path = np.maximum(omega+alpha*prev*prev+beta*var_path, 1e-18)
        shock = sampled[:,t]*np.sqrt(var_path)
        nxt = mu+phi*prev+shock
        out[:,t] = nxt
        prev = nxt-mu
    cumulative = np.cumsum(out, axis=1)
    return (cumulative, out) if return_step_returns else cumulative


def _first_passage_probabilities(sims, direction_sign, targets, stop_distance,
                                 close=None, high=None, low=None, seed=7,
                                 step_returns=None):
    """Estimate managed TP1/TP2/TP3 first passage with moving protective stops.

    Before TP1 the initial SL is active. After TP1 the stop moves to entry;
    after TP2 it moves to TP1. A target already reached remains a success even
    if a later protective stop is touched. Same-candle target/active-stop ties
    are unresolved; the Monte Carlo expectation assigns fractional half-credit,
    while realized outcome labels must exclude unresolved ordering.

    Intrabar OHLC excursions are sampled jointly from historical candles in
    return-size/sign buckets, preserving the empirical relation between candle
    return and its upper/lower wick instead of sampling wick sizes independently.
    """
    paths = np.asarray(sims, dtype=float)
    if paths.ndim != 2 or paths.size == 0 or len(targets) < 3:
        return 0.5, 0.5, 0.5, 0.5
    n_paths, horizon = paths.shape
    sign = 1.0 if float(direction_sign) >= 0 else -1.0
    oriented = paths * sign
    if step_returns is None:
        steps = np.diff(np.column_stack([np.zeros(n_paths), paths]), axis=1)
    else:
        steps = np.asarray(step_returns, dtype=float)
        if steps.shape != paths.shape:
            steps = np.diff(np.column_stack([np.zeros(n_paths), paths]), axis=1)
    upper = np.zeros(0, dtype=float); lower = np.zeros(0, dtype=float); hist_ret = np.zeros(0, dtype=float)
    try:
        c = np.asarray(close, dtype=float).reshape(-1)
        h = np.asarray(high, dtype=float).reshape(-1)
        l = np.asarray(low, dtype=float).reshape(-1)
        n = min(len(c), len(h), len(l))
        c, h, l = c[-n:], h[-n:], l[-n:]
        valid = np.isfinite(c) & np.isfinite(h) & np.isfinite(l) & (c > 0) & (h >= c) & (l <= c) & (l > 0)
        c, h, l = c[valid], h[valid], l[valid]
        if len(c) >= 10:
            upper = np.maximum(0.0, np.log(h/c))
            lower = np.maximum(0.0, np.log(c/l))
            hist_ret = np.diff(np.log(c), prepend=np.log(c[0]))
            upper, lower, hist_ret = upper[1:], lower[1:], hist_ret[1:]
    except Exception:
        pass
    upper_path = np.zeros((n_paths, horizon), dtype=float)
    lower_path = np.zeros((n_paths, horizon), dtype=float)
    if len(upper) >= 10:
        # Select wick pairs conditionally on simulated candle return quantile.
        edges = np.unique(np.quantile(hist_ret, np.linspace(0, 1, 6)))
        rng = np.random.default_rng(int(seed)+1)
        for t in range(horizon):
            bucket = np.digitize(steps[:, t], edges[1:-1], right=True)
            for b in range(5):
                rows = np.flatnonzero(bucket == b)
                if not len(rows):
                    continue
                candidates = np.flatnonzero(np.digitize(hist_ret, edges[1:-1], right=True) == b)
                if not len(candidates):
                    candidates = np.arange(len(upper))
                chosen = rng.choice(candidates, size=len(rows), replace=True)
                upper_path[rows, t] = upper[chosen]
                lower_path[rows, t] = lower[chosen]
    favorable_excursion = upper_path if sign > 0 else lower_path
    adverse_excursion = lower_path if sign > 0 else upper_path
    targets = [float(v) for v in targets[:3]]
    initial_stop = float(stop_distance)
    # Per-path state machine: 0=before TP1, 1=after TP1, 2=after TP2, 3=TP3.
    state = np.zeros(n_paths, dtype=np.int8)
    tp_credit = np.zeros((3, n_paths), dtype=float)
    sl_first = np.zeros(n_paths, dtype=float)
    active = np.ones(n_paths, dtype=bool)
    # Vectorized path-state transitions. The previous implementation iterated
    # in Python over every simulated path for every candle; with 2,000 paths,
    # five timeframes and 25 candidates this dominated Android CPU time.
    # This preserves the exact TP/SL/tie ordering while looping only over the
    # three ordered targets, not over individual Monte Carlo paths.
    for j in range(horizon):
        if not np.any(active):
            break
        favorable = oriented[:, j] + favorable_excursion[:, j]
        adverse = oriented[:, j] - adverse_excursion[:, j]
        stop_level = np.where(state == 0, -initial_stop,
                     np.where(state == 1, 0.0, targets[0]))
        stop_hit = active & (adverse <= stop_level)
        next_target = np.choose(np.minimum(state, 2), [targets[0], targets[1], targets[2]])
        target_hit = active & (state < 3) & (favorable >= next_target)
        tie = stop_hit & target_hit
        if np.any(tie):
            idx = np.flatnonzero(tie)
            for k in range(3):
                mask = idx[state[idx] == k]
                if len(mask):
                    tp_credit[k, mask] = 0.5
            first = idx[state[idx] == 0]
            if len(first):
                sl_first[first] = 0.5
            active[idx] = False
        stop_only = stop_hit & ~target_hit
        if np.any(stop_only):
            idx = np.flatnonzero(stop_only)
            first = idx[state[idx] == 0]
            if len(first):
                sl_first[first] = 1.0
            active[idx] = False
        target_only = target_hit & ~stop_hit
        if np.any(target_only):
            for k in range(3):
                eligible = target_only & (state == k) & (favorable >= targets[k])
                if not np.any(eligible):
                    continue
                if k < 2:
                    moved_stop = 0.0 if k == 0 else targets[0]
                    post_target_tie = eligible & (adverse <= moved_stop)
                    if np.any(post_target_tie):
                        tp_credit[k, post_target_tie] = 0.5
                        active[post_target_tie] = False
                    clean = eligible & ~post_target_tie
                else:
                    clean = eligible
                if np.any(clean):
                    tp_credit[k, clean] = 1.0
                    state[clean] = k + 1
                    if k == 2:
                        active[clean] = False
    probs = [float(np.mean(tp_credit[k])) for k in range(3)]
    return probs[0], probs[1], probs[2], float(np.mean(sl_first))

def _monte_carlo(rets, horizon=12, paths=400, seed=7):
    sims = _monte_carlo_paths(rets, horizon, paths, seed)
    if sims.size == 0:
        return 0.5
    terminal = sims[:, -1]
    # A zero terminal return is neutral evidence, not a bearish result.
    return float(np.clip(np.mean((terminal > 0).astype(float) + 0.5*(terminal == 0)), 0, 1))

def _bayesian(rets, horizon=12):
    """Beta-Bernoulli probability of a positive cumulative log return.

    Use disjoint horizon-sized return blocks, anchored at the latest bar. The
    previous rolling-window implementation counted highly overlapping paths
    as independent Bernoulli observations and overstated confidence.
    """
    r = _safe(rets)
    h = max(1, int(horizon))
    n_blocks = len(r) // h
    if n_blocks < 10:
        return 0.5
    blocks = r[-n_blocks*h:].reshape(n_blocks, h)
    cumulative = np.sum(blocks, axis=1)
    positive = float(np.sum(cumulative > 0))
    negative = float(np.sum(cumulative < 0))
    # Jeffreys prior Beta(1/2, 1/2) avoids arbitrary overconfidence.
    return float((positive+0.5)/(positive+negative+1.0))

def _mean_reversion(logp):
    """Estimate OU-like mean reversion from deviations around a rolling mean."""
    x = _safe(logp)
    if len(x) < 30:
        return 0.0
    # Remove the broad linear drift before estimating reversion. Without this
    # step a perfectly monotonic price path is mistaken for a stretched
    # mean-reverting spread solely because a trailing average lags the trend.
    t = np.arange(len(x), dtype=float)
    trend = np.polyfit(t, x, 1)
    x = x - (trend[0]*t + trend[1])
    if float(np.std(x)) < 1e-12:
        return 0.0
    window = min(24, max(8, len(x)//4))
    # Align a trailing moving average to each observation without future data.
    smooth = np.empty_like(x)
    # Expanding means before the first full window avoid using later points
    # to define an earlier observation's baseline.
    for i in range(window-1):
        smooth[i] = np.mean(x[:i+1])
    for i in range(window-1, len(x)):
        smooth[i] = np.mean(x[i-window+1:i+1])
    spread = x-smooth
    lag, delta = spread[:-1], np.diff(spread)
    if np.std(lag) < 1e-12:
        return 0.0
    design = np.column_stack([np.ones(len(lag)), lag])
    coef = np.linalg.lstsq(design, delta, rcond=None)[0]
    kappa = float(coef[1])
    if kappa >= 0:
        return 0.0
    half_life = float(np.log(2.0)/max(-np.log(max(1.0+kappa, 1e-6)), 1e-6)) if kappa > -1 else 0.0
    if half_life <= 0 or half_life > len(x):
        return 0.0
    z = float(spread[-1]/max(float(np.std(spread)), 1e-12))
    strength = float(np.clip(1.0-half_life/len(x), 0.0, 1.0))
    return float(np.clip(-z/3.0, -1, 1)*strength)

def _normalized_epoch_seconds(value):
    stamp = int(value)
    if abs(stamp) >= 100_000_000_000_000_000:
        return stamp // 1_000_000_000
    if abs(stamp) >= 100_000_000_000_000:
        return stamp // 1_000_000
    if abs(stamp) >= 100_000_000_000:
        return stamp // 1_000
    return stamp


def _binary_auc(scores, labels):
    scores = np.asarray(scores, dtype=float)
    labels = np.asarray(labels, dtype=int)
    positives = int(np.sum(labels == 1)); negatives = int(np.sum(labels == 0))
    if positives == 0 or negatives == 0:
        return None
    order = np.argsort(scores, kind='mergesort')
    sorted_scores = scores[order]
    ranks = np.empty(len(scores), dtype=float)
    i = 0
    while i < len(order):
        j = i + 1
        while j < len(order) and sorted_scores[j] == sorted_scores[i]:
            j += 1
        ranks[order[i:j]] = (i + 1 + j) / 2.0
        i = j
    rank_sum = float(np.sum(ranks[labels == 1]))
    return float((rank_sum - positives*(positives+1)/2.0) / (positives*negatives))


def _binary_log_loss(probabilities, labels):
    probabilities=np.clip(np.asarray(probabilities,dtype=float),1e-7,1.0-1e-7)
    labels=np.asarray(labels,dtype=float)
    if len(probabilities)==0 or len(probabilities)!=len(labels):
        return None
    return float(-np.mean(labels*np.log(probabilities)+(1.0-labels)*np.log(1.0-probabilities)))


def _fit_reliability_map(pairs):
    """Fit a compact monotone reliability map from (probability, label) pairs."""
    if not pairs:
        return {'x': [], 'y': []}
    pairs = sorted((float(p), int(y)) for p, y in pairs if np.isfinite(float(p)) and 0.0 <= float(p) <= 1.0)
    if len(pairs) < 2:
        return {'x': [], 'y': []}
    n_bins = min(10, max(2, len(pairs)//10))
    blocks = []
    for chunk in np.array_split(np.asarray(pairs, dtype=float), n_bins):
        if not len(chunk):
            continue
        n = int(len(chunk)); p_sum = float(np.sum(chunk[:,0])); successes = float(np.sum(chunk[:,1]))
        blocks.append({'n':n, 'p_sum':p_sum, 'successes':successes})
        while len(blocks) >= 2:
            a, b = blocks[-2], blocks[-1]
            ra = (a['successes']+1.0)/(a['n']+2.0)
            rb = (b['successes']+1.0)/(b['n']+2.0)
            if ra <= rb:
                break
            blocks[-2:] = [{'n':a['n']+b['n'], 'p_sum':a['p_sum']+b['p_sum'],
                            'successes':a['successes']+b['successes']}]
    xs=[]; ys=[]
    for block in blocks:
        xs.append(float(block['p_sum']/block['n']))
        ys.append(float((block['successes']+1.0)/(block['n']+2.0)))
    compact=[]
    for block, x in zip(blocks, xs):
        n = int(block['n'])
        successes = float(block['successes'])
        if compact and x <= compact[-1][0]:
            old_x, old_successes, old_n = compact[-1]
            compact[-1] = (old_x, old_successes + successes, old_n + n)
        else:
            compact.append((x, successes, n))
    return {'x':[v[0] for v in compact],
            'y':[float((v[1]+1.0)/(v[2]+2.0)) for v in compact]}


def _validate_math_probability_heads(valid, group_key, min_samples=100, min_cycles=80,
                                     min_test_rows=30, min_brier_skill=0.02, min_auc=0.52,
                                     min_log_loss_skill=0.01):
    """Strict chronological holdout validation; no same-cycle rows cross the split."""
    groups = {}
    for index, row in enumerate(valid):
        key = group_key(row)
        try:
            stamp = _normalized_epoch_seconds(row.get('time', index))
        except Exception:
            stamp = index
        groups.setdefault(key, []).append((stamp, index))
    ordered_groups = sorted(groups, key=lambda key: (min(x[0] for x in groups[key]), str(key)))
    cut = int(len(ordered_groups)*0.75)
    candidate_train = set(ordered_groups[:cut]); test_groups = set(ordered_groups[cut:])
    test_start = min((stamp for key in test_groups for stamp, _ in groups[key]), default=None)
    # Purge training observations whose label horizon overlaps validation.
    train_groups = set()
    for key in candidate_train:
        rows = [valid[index] for _, index in groups[key]]
        safe = True
        for row in rows:
            try:
                stamp = _normalized_epoch_seconds(row.get('time', 0))
                horizon_seconds = max(0, int(row.get('horizon_seconds', 0) or 0))
                if test_start is not None and stamp + horizon_seconds >= test_start:
                    safe = False
                    break
            except Exception:
                safe = False
                break
        if safe:
            train_groups.add(key)
    report = {}; validated = []
    for field, label_field in CALIBRATION_FIELDS.items():
        train_p=[]; train_y=[]; test_p=[]; test_y=[]
        for row in valid:
            key = group_key(row)
            try:
                p = float(row['p'][field]); y = int(bool(row['y'][label_field]))
                if not np.isfinite(p) or not 0.0 <= p <= 1.0:
                    continue
                if key in train_groups: train_p.append(p); train_y.append(y)
                elif key in test_groups: test_p.append(p); test_y.append(y)
            except Exception:
                continue
        train_cycles = len({group_key(r) for r in valid if group_key(r) in train_groups and field in (r.get('p') or {}) and label_field in (r.get('y') or {})})
        test_cycles = len({group_key(r) for r in valid if group_key(r) in test_groups and field in (r.get('p') or {}) and label_field in (r.get('y') or {})})
        metrics = {'train_rows':len(train_y), 'test_rows':len(test_y), 'train_cycles':train_cycles,
                   'test_cycles':test_cycles, 'brier_score':None, 'baseline_brier_score':None,
                   'brier_skill':None, 'calibrated_brier_score':None, 'calibrated_brier_skill':None,
                   'auc':None, 'log_loss':None, 'baseline_log_loss':None,
                   'calibrated_log_loss':None, 'calibrated_log_loss_skill':None,
                   'calibration_not_worse_than_raw_log_loss':False, 'validated':False}
        if len(train_y) >= 50 and len(test_y) >= int(min_test_rows) and train_cycles >= 30 and test_cycles >= 20:
            train_y_arr=np.asarray(train_y,dtype=int); test_y_arr=np.asarray(test_y,dtype=int); test_p_arr=np.asarray(test_p,dtype=float)
            prevalence=float(np.mean(train_y_arr))
            brier=float(np.mean((test_p_arr-test_y_arr)**2))
            baseline=float(np.mean((prevalence-test_y_arr)**2))
            skill=float(1.0-brier/baseline) if baseline > 1e-12 else None
            auc=_binary_auc(test_p_arr,test_y_arr)
            reliability=_fit_reliability_map(list(zip(train_p,train_y)))
            if len(reliability['x']) >= 2:
                calibrated_p=np.interp(test_p_arr, np.asarray(reliability['x'],float), np.asarray(reliability['y'],float))
            else:
                calibrated_p=test_p_arr
            calibrated_brier=float(np.mean((calibrated_p-test_y_arr)**2))
            calibrated_skill=float(1.0-calibrated_brier/baseline) if baseline > 1e-12 else None
            raw_log_loss=_binary_log_loss(test_p_arr,test_y_arr)
            baseline_log_loss=_binary_log_loss(np.full(len(test_y_arr),prevalence),test_y_arr)
            calibrated_log_loss=_binary_log_loss(calibrated_p,test_y_arr)
            log_loss_skill=(1.0-calibrated_log_loss/baseline_log_loss
                            if baseline_log_loss is not None and baseline_log_loss > 1e-12 and calibrated_log_loss is not None else None)
            calibration_not_worse=(raw_log_loss is not None and calibrated_log_loss is not None and
                                   calibrated_log_loss <= raw_log_loss + 1e-9)
            metrics.update({'brier_score':brier,'baseline_brier_score':baseline,'brier_skill':skill,
                            'calibrated_brier_score':calibrated_brier,'calibrated_brier_skill':calibrated_skill,'auc':auc,
                            'log_loss':raw_log_loss,'baseline_log_loss':baseline_log_loss,
                            'calibrated_log_loss':calibrated_log_loss,
                            'calibrated_log_loss_skill':log_loss_skill,
                            'calibration_not_worse_than_raw_log_loss':bool(calibration_not_worse)})
            metrics['validated']=bool(skill is not None and skill >= float(min_brier_skill) and
                                      calibrated_skill is not None and calibrated_skill >= float(min_brier_skill) and
                                      log_loss_skill is not None and log_loss_skill >= float(min_log_loss_skill) and
                                      calibration_not_worse and auc is not None and auc >= float(min_auc))
            if metrics['validated']:
                validated.append(field)
        report[field]=metrics
    return {'status':'ok' if len(valid) >= int(min_samples) and len(groups) >= int(min_cycles) else 'accumulating',
            'train_cycles':len(train_groups), 'test_cycles':len(test_groups),
            'purged_train_cycles':len(candidate_train - train_groups), 'heads':report,
            'validated_heads':validated, 'minimum_samples':int(min_samples), 'minimum_cycles':int(min_cycles),
            'minimum_test_rows':int(min_test_rows), 'minimum_brier_skill':float(min_brier_skill),
            'minimum_log_loss_skill':float(min_log_loss_skill), 'minimum_auc':float(min_auc)}


def fit_math_probability_calibration(samples, formula_version=MATH_FORMULA_VERSION, min_samples=100, min_cycles=80):
    """Fit leakage-safe, monotone reliability maps from matured out-of-sample rows.

    Samples must have been recorded at issuance and labeled only after the same
    fixed forecast horizon elapsed. Equal-frequency bins are smoothed with a
    Beta(1,1) prior and pooled-adjacent-violators enforces monotonicity.
    Every individual probability head must meet both the sample and independent
    cycle thresholds; multiple coins from one scan cycle cannot satisfy the
    independent-cycle requirement by themselves. The default 80-cycle floor
    supports a 75/25 chronological split with at least 20 validation cycles.
    """
    valid = [r for r in (samples or []) if int(r.get('formula_version', -1)) == int(formula_version)]
    def group_key(row):
        try:
            cycle = int(row.get('cycle', 0) or 0)
            if cycle > 0:
                return ('cycle', cycle)
            if row.get('time') is not None:
                stamp = _normalized_epoch_seconds(row.get('time'))
                return ('time', stamp // 1800)  # scans are nominally 30-minute cycles
        except Exception:
            pass
        return ('id', str(row.get('id', 'unknown')))
    # Reproduce the chronological, horizon-purged training split used by
    # validation. Deployment maps are fitted ONLY on training cycles; held-out
    # cycles remain untouched and cannot leak into the calibration curve.
    grouped={}
    for index,row in enumerate(valid):
        try: stamp=_normalized_epoch_seconds(row.get('time',index))
        except Exception: stamp=index
        grouped.setdefault(group_key(row),[]).append((stamp,index))
    ordered=sorted(grouped,key=lambda key:(min(x[0] for x in grouped[key]),str(key)))
    cut=int(len(ordered)*0.75)
    candidate_train=set(ordered[:cut]); test_groups=set(ordered[cut:])
    test_start=min((stamp for key in test_groups for stamp,_ in grouped[key]),default=None)
    train_groups=set()
    for key in candidate_train:
        safe=True
        for stamp,index in grouped[key]:
            row=valid[index]
            try: horizon=max(0,int(row.get('horizon_seconds',0) or 0))
            except Exception: safe=False; break
            if test_start is not None and stamp+horizon>=test_start:
                safe=False; break
        if safe: train_groups.add(key)
    maps = {}
    for field, label_field in CALIBRATION_FIELDS.items():
        pairs = []
        field_groups = set()
        for row in valid:
            try:
                key=group_key(row)
                if key not in train_groups: continue
                p = float(row['p'][field]); y = int(bool(row['y'][label_field]))
                if np.isfinite(p) and 0.0 <= p <= 1.0:
                    pairs.append((p, y)); field_groups.add(key)
            except Exception:
                continue
        if len(pairs) < max(50,int(min_samples*0.5)) or len(field_groups) < max(30,int(min_cycles*0.5)):
            continue
        reliability = _fit_reliability_map(pairs)
        maps[field]={'x':reliability['x'], 'y':reliability['y'],
                     'n':len(pairs), 'independent_cycles':len(field_groups),
                     'fit_partition':'chronological_train_only'}
    independent_groups = len({group_key(row) for row in valid})
    validation = _validate_math_probability_heads(valid, group_key, min_samples=min_samples, min_cycles=min_cycles)
    return {'formula_version':int(formula_version), 'maps':maps,
            'sample_count':len(valid), 'independent_cycles':independent_groups,
            'minimum_samples':int(min_samples), 'minimum_cycles':int(min_cycles),
            'validation':validation, 'validated_heads':validation.get('validated_heads', [])}

def apply_math_probability_calibration(snapshot, calibration, formula_version=MATH_FORMULA_VERSION):
    """Apply matured out-of-sample reliability maps and restore probability coherence."""
    out = dict(snapshot)
    if not isinstance(calibration, dict) or int(calibration.get('formula_version', -1)) != int(formula_version):
        return out
    maps = calibration.get('maps', {})
    # A fitted reliability map is not automatically approved for live use.
    # Apply it only when its own chronological holdout passed the promotion gate.
    validated_heads = set(calibration.get('validated_heads', []) or [])
    for field in CALIBRATION_FIELDS:
        if field not in validated_heads:
            continue
        if field in ('math_ptp1','math_ptp2','math_ptp3','math_psl') and float(out.get('math_target_sign', 1.0)) == 0.0:
            continue
        mapping = maps.get(field, {}) if isinstance(maps, dict) else {}
        try:
            if int(mapping.get('n', 0)) < 100 or len(mapping.get('x', [])) < 2:
                continue
            raw = float(np.clip(out.get(field, 0.5), 0.0, 1.0))
            out[field] = float(np.clip(np.interp(raw, np.asarray(mapping['x'], float),
                                                   np.asarray(mapping['y'], float)), 0.0, 1.0))
        except Exception:
            continue
    out['math_ptp1'] = float(np.clip(max(out.get('math_ptp1',0.5), out.get('math_ptp2',0.5), out.get('math_ptp3',0.5)),0,1))
    out['math_ptp2'] = float(np.clip(min(out['math_ptp1'], max(out.get('math_ptp2',0.5), out.get('math_ptp3',0.5))),0,1))
    out['math_ptp3'] = float(np.clip(min(out['math_ptp2'], out.get('math_ptp3',0.5)),0,1))
    out['math_psl'] = float(np.clip(min(out.get('math_psl',0.5), 1.0-out['math_ptp1']),0,1))
    return out


def compute_math_snapshot(close, high=None, low=None, volume=None, horizon=12, seed=7, benchmark_close=None, forecast_direction=None,
                          target_log_distances=None, stop_log_distance=None, probability_calibration=None,
                          candle_time=None, benchmark_time=None, validated_probability_heads=None):
    """Compute causal mathematical signals and path-touch probabilities.

    ARIMA(1,1,1), multiplicative SARIMA(1,0,0)(1,0,0,12) with expanded 720-return input history, constrained
    Gaussian-QMLE GARCH(1,1), and an Engle-Granger residual ADF test are fitted
    with NumPy-only estimators for Android compatibility. The ADF significance
    gate uses an approximate cointegration critical value, not exact finite-
    sample p-values. TP/SL probabilities are model-based estimates, not yet
    calibrated probabilities until evaluated against a large untouched sample.
    """
    raw_close = np.asarray(close, dtype=float).reshape(-1)
    raw_high = np.asarray(high, dtype=float).reshape(-1) if high is not None else raw_close.copy()
    raw_low = np.asarray(low, dtype=float).reshape(-1) if low is not None else raw_close.copy()
    raw_volume = np.asarray(volume, dtype=float).reshape(-1) if volume is not None else None
    n_raw = min(len(raw_close), len(raw_high), len(raw_low))
    # Avoid Python's [-0:] behavior (which returns the full array) when any
    # required OHLC input is empty. All aligned arrays must have the same size.
    if n_raw:
        raw_close, raw_high, raw_low = raw_close[-n_raw:], raw_high[-n_raw:], raw_low[-n_raw:]
        if raw_volume is not None:
            raw_volume = raw_volume[-n_raw:]
    else:
        raw_close = raw_close[:0]
        raw_high = raw_high[:0]
        raw_low = raw_low[:0]
        if raw_volume is not None:
            raw_volume = raw_volume[:0]
    valid_ohlc = (np.isfinite(raw_close) & np.isfinite(raw_high) & np.isfinite(raw_low) &
                  (raw_close > 0) & (raw_high >= raw_close) & (raw_low > 0) & (raw_low <= raw_close))
    bad = np.flatnonzero(~valid_ohlc)
    start = int(bad[-1] + 1) if len(bad) else 0
    c, high, low = raw_close[start:], raw_high[start:], raw_low[start:]
    volume = raw_volume[start:] if raw_volume is not None else None
    quality = {'status':'checking','input_rows':int(n_raw),
               'valid_ohlc_rows':int(np.sum(valid_ohlc)),
               'invalid_ohlc_rows':int(np.sum(~valid_ohlc)),
               'ohlc_contiguous_suffix_rows':int(len(c)),
               'timestamp_breaks':0,'expected_interval_seconds':None,
               'last_interval_seconds':None,'contiguous_rows':int(len(c)),
               'reason':None}
    timestamp_error=None
    if candle_time is not None:
        try:
            supplied_time = np.asarray(candle_time, dtype=np.int64).reshape(-1)
            if len(supplied_time) < n_raw:
                raise ValueError('candle_time length does not cover OHLC rows')
            raw_time = supplied_time[-n_raw:] if n_raw else supplied_time[:0]
            candle_time = np.asarray([_normalized_epoch_seconds(v) for v in raw_time[start:]], dtype=np.int64)
            if len(candle_time) != len(c):
                raise ValueError('candle_time/OHLC alignment mismatch')
            # Do not bridge missing, duplicate, or out-of-order candles. Retain
            # the latest strictly contiguous suffix and report exactly why it
            # was shortened; never replace missing candles with fabricated data.
            if len(candle_time) >= 3:
                dt = np.diff(candle_time)
                positive = dt[dt > 0]
                if not len(positive):
                    raise ValueError('no positive candle intervals')
                typical = float(np.median(positive))
                quality['expected_interval_seconds']=typical
                quality['last_interval_seconds']=float(dt[-1]) if len(dt) else None
                breaks = np.flatnonzero((dt <= 0) | (dt > typical * 1.5))
                quality['timestamp_breaks']=int(len(breaks))
                if len(breaks):
                    keep_from = int(breaks[-1] + 1)
                    c, high, low = c[keep_from:], high[keep_from:], low[keep_from:]
                    if volume is not None:
                        volume = volume[keep_from:]
                    candle_time = candle_time[keep_from:]
        except Exception as exc:
            timestamp_error=str(exc)
            # If timestamps cannot be aligned, refuse to infer continuity by
            # array position. The diagnostic retains the precise failure.
            c = c[:0]; high = high[:0]; low = low[:0]
            if volume is not None:
                volume = volume[:0]
            candle_time = None
    n = len(c)
    quality['contiguous_rows']=int(n)
    if n >= 20:
        quality['status']='ready' if candle_time is not None else 'ready_without_timestamps'
        quality['reason']=None
    else:
        quality['status']='insufficient_contiguous_candles'
        quality['reason']=(f'timestamp_alignment_error:{timestamp_error}' if timestamp_error else
                           'invalid_ohlc_suffix_too_short' if quality['invalid_ohlc_rows'] else
                           'timestamp_gap_suffix_too_short' if quality['timestamp_breaks'] else
                           'fewer_than_20_valid_candles')
    if n < 20:
        result = {k: 0.0 for k in MATH_FEATURES}
        result.update({'math_prob_move': 0.5, 'math_hurst': 0.5, 'math_fractal': 1.5, 'math_monte_carlo': 0.5,
                       'math_bayesian': 0.5, 'math_ptp1': 0.5, 'math_ptp2': 0.5,
                       'math_ptp3': 0.5, 'math_psl': 0.5, 'math_direction': 0.0,
                       'math_target_sign': 0.0, 'math_trend_direction': 0.0,
                       'math_benchmark_direction': 0.0, 'math_consensus': 0.0})
        result['_math_raw_probabilities'] = {k: float(result[k]) for k in CALIBRATION_FIELDS}
        result['_validated_probability_heads'] = sorted(set(validated_probability_heads or []))
        result['_probability_validation_enforced'] = bool(validated_probability_heads is not None)
        result['_math_data_quality']=quality
        return result
    # Econometric models use log returns consistently with the horizon labels.
    r = np.diff(np.log(np.maximum(c, 1e-12)))
    # Expanded history improves seasonal/volatility estimation. Individual
    # estimators retain bounded fitting windows for predictable Android cost.
    w = r[-720:]
    # A window of 720 returns requires 721 closes; keep returns and levels aligned.
    lw = np.log(np.maximum(c[-(len(w)+1):], 1e-12))
    formula_profile = {}
    _t_formula = time.perf_counter(); ar = _ols_ar(w, 3); formula_profile['AR'] = time.perf_counter()-_t_formula
    # Fit actual conditional-sum-of-squares ARIMA and seasonal AR models.
    _t_formula = time.perf_counter(); arima = _arima_111(w); formula_profile['ARIMA'] = time.perf_counter()-_t_formula
    _t_formula = time.perf_counter(); sarima = _sarima_101_101(w, season=12); formula_profile['SARIMA'] = time.perf_counter()-_t_formula
    _t_formula = time.perf_counter(); g = _garch(w); formula_profile['GARCH'] = time.perf_counter()-_t_formula
    sd = float(np.std(w)); sd_safe = max(sd, 1e-12)
    _t_formula = time.perf_counter(); mr = _mean_reversion(lw); formula_profile['MeanReversion'] = time.perf_counter()-_t_formula
    _t_formula = time.perf_counter(); hurst = _hurst(lw); formula_profile['Hurst'] = time.perf_counter()-_t_formula
    _t_formula = time.perf_counter(); entropy = _entropy(w); formula_profile['Entropy'] = time.perf_counter()-_t_formula
    # Graph dimension of a 1-D self-affine series: D = 2 - H, in [1, 2].
    fractal = float(np.clip(2.0-hurst, 1.0, 2.0))
    _t_formula = time.perf_counter(); wave = _wavelet_dwt(w); formula_profile['Wavelet'] = time.perf_counter()-_t_formula
    _t_formula = time.perf_counter(); kal = _kalman(lw); formula_profile['Kalman'] = time.perf_counter()-_t_formula
    _t_formula = time.perf_counter(); cp = _change_point(w); formula_profile['ChangePoint'] = time.perf_counter()-_t_formula
    _t_formula = time.perf_counter(); sims, sim_steps = _monte_carlo_paths(w, horizon, 2000, seed, return_step_returns=True); formula_profile['MonteCarloPaths'] = time.perf_counter()-_t_formula
    if sims.size:
        terminal = sims[:, -1]
        # Ties at exactly zero carry half a vote, keeping a flat/no-drift market neutral.
        mc = float(np.clip(np.mean((terminal > 0).astype(float) + 0.5*(terminal == 0)), 0, 1))
    else:
        mc = 0.5
    _t_formula = time.perf_counter(); bay = _bayesian(w, horizon=horizon); formula_profile['Bayesian'] = time.perf_counter()-_t_formula
    _t_formula = time.perf_counter(); mark = _markov(w); formula_profile['Markov'] = time.perf_counter()-_t_formula
    _t_formula = time.perf_counter(); trend_deviation = _trend_deviation(lw); formula_profile['TrendDeviation'] = time.perf_counter()-_t_formula
    _t_formula = time.perf_counter()
    if benchmark_close is not None:
        bc = _safe_prices(benchmark_close)
        asset_for_pair = c
        benchmark_for_pair = bc
        # If candle timestamps are available, pair returns only at identical
        # timestamps. Truncating both arrays to the same length can pair
        # different market minutes when either feed has missing candles.
        timestamps_requested = candle_time is not None or benchmark_time is not None
        if timestamps_requested:
            try:
                at = np.asarray(candle_time, dtype=np.int64).reshape(-1) if candle_time is not None else np.asarray([], dtype=np.int64)
                bt_raw = np.asarray(benchmark_time, dtype=np.int64).reshape(-1) if benchmark_time is not None else np.asarray([], dtype=np.int64)
                bt = np.asarray([_normalized_epoch_seconds(v) for v in bt_raw], dtype=np.int64)
                if len(at) == len(c) and len(bt) == len(bc):
                    bmap = {int(t): float(v) for t, v in zip(bt, bc) if np.isfinite(v) and v > 0}
                    shared = [(int(t), float(v), bmap[int(t)]) for t, v in zip(at, c)
                              if int(t) in bmap and np.isfinite(v) and v > 0]
                    if len(shared) >= 20:
                        asset_for_pair = np.asarray([x[1] for x in shared], dtype=float)
                        benchmark_for_pair = np.asarray([x[2] for x in shared], dtype=float)
                    else:
                        asset_for_pair = np.asarray([], dtype=float)
                        benchmark_for_pair = np.asarray([], dtype=float)
                else:
                    # Never silently pair different timestamps by array position.
                    asset_for_pair = np.asarray([], dtype=float)
                    benchmark_for_pair = np.asarray([], dtype=float)
            except Exception:
                asset_for_pair = np.asarray([], dtype=float)
                benchmark_for_pair = np.asarray([], dtype=float)
        if len(asset_for_pair) >= 20 and len(benchmark_for_pair) >= 20:
            pair_asset_logp = np.log(np.maximum(asset_for_pair[-121:], 1e-12))
            pair_benchmark_logp = np.log(np.maximum(benchmark_for_pair[-121:], 1e-12))
            # Pair windows have identical timestamp support and therefore identical
            # lengths, even when one of the original feeds contains gaps.
            n_pair = min(len(pair_asset_logp), len(pair_benchmark_logp))
            pair_asset_logp = pair_asset_logp[-n_pair:]
            pair_benchmark_logp = pair_benchmark_logp[-n_pair:]
            benchmark_returns = np.diff(pair_benchmark_logp)
            asset_returns = np.diff(pair_asset_logp)
            _t_formula=time.perf_counter(); coin = _relative_spread(pair_asset_logp, pair_benchmark_logp); formula_profile['Cointegration'] = time.perf_counter()-_t_formula
            _t_formula=time.perf_counter(); corr = _correlation(asset_returns, benchmark_returns); formula_profile['Correlation'] = time.perf_counter()-_t_formula
            bsd = max(float(np.std(benchmark_returns[-30:])), 1e-12)
            benchmark_direction = float(np.tanh(2.0 * float(np.mean(benchmark_returns[-12:])) / bsd)) if len(benchmark_returns) >= 12 else 0.0
        else:
            coin = 0.0; corr = 0.0; benchmark_direction = 0.0
            formula_profile['Cointegration'] = 0.0; formula_profile['Correlation'] = 0.0
    else:
        coin = 0.0; corr = 0.0; benchmark_direction = 0.0
        formula_profile['Cointegration'] = 0.0; formula_profile['Correlation'] = 0.0
    _t_formula = time.perf_counter(); return_vol_corr = _return_vol_correlation(w); formula_profile['ReturnVolCorrelation'] = time.perf_counter()-_t_formula
    trend_direction = float(np.tanh(2.0 * float(np.mean(w[-12:])) / sd_safe))
    # Probability of a meaningful absolute move is non-directional. Use the
    # simulated horizon distribution and a one-horizon historical volatility
    # threshold; do not turn this risk estimate into a LONG/SHORT vote.
    _t_formula = time.perf_counter()
    if sims.size:
        move_threshold = max(sd_safe*np.sqrt(max(1, int(horizon))), 1e-12)
        p_move = float(np.mean(np.abs(sims[:, -1]) >= move_threshold))
    else:
        p_move = 0.5
    formula_profile['ProbabilityMove'] = time.perf_counter()-_t_formula
    probability_validation_enforced = validated_probability_heads is not None
    validated_heads = set(validated_probability_heads or [])
    def vote_probability(field, raw_value):
        # When a probability head is validated, use its fitted reliability map
        # consistently both in its exposed value and in the derived consensus.
        if not isinstance(probability_calibration, dict) or int(probability_calibration.get('formula_version', -1)) != MATH_FORMULA_VERSION:
            return float(raw_value)
        mapping = (probability_calibration.get('maps') or {}).get(field, {})
        try:
            if int(mapping.get('n', 0)) >= 100 and len(mapping.get('x', [])) >= 2:
                return float(np.clip(np.interp(float(raw_value), np.asarray(mapping['x'],float), np.asarray(mapping['y'],float)),0,1))
        except Exception:
            pass
        return float(raw_value)
    bay_for_vote = vote_probability('math_bayesian', bay) if (not probability_validation_enforced or 'math_bayesian' in validated_heads) else 0.5
    mc_for_vote = vote_probability('math_monte_carlo', mc) if (not probability_validation_enforced or 'math_monte_carlo' in validated_heads) else 0.5
    bay_vote = 2*bay_for_vote-1
    mc_vote = 2*mc_for_vote-1
    direction = float(np.clip(.20*mark + .18*ar + .14*arima + .10*sarima + .10*mr +
                              .08*wave + .08*kal + .06*coin + .06*bay_vote, -1, 1))
    requested_direction = str(forecast_direction or '').upper()
    if requested_direction == 'LONG':
        direction_sign = 1.0
    elif requested_direction == 'SHORT':
        direction_sign = -1.0
    elif requested_direction == 'WAIT':
        direction_sign = 0.0
    else:
        direction_sign = 1.0 if direction >= 0 else -1.0
        if abs(direction) < 0.03:
            direction_sign = 1.0 if float(np.mean(w[-12:])) >= 0 else -1.0
    oriented = sims * direction_sign if sims.size else np.zeros((0, max(1, int(horizon))))
    if requested_direction == 'WAIT':
        ptp1 = ptp2 = ptp3 = psl = 0.5
    elif oriented.size:
        if target_log_distances is None:
            targets = (float(np.log1p(0.003)), float(np.log1p(0.006)), float(np.log1p(0.009)))
        else:
            # TP distances must be strictly positive. Clamping a negative TP
            # distance to zero made the barrier trivially true for half of all
            # simulated paths and silently inflated target probabilities.
            try:
                raw_targets = [float(v) for v in target_log_distances]
                targets = tuple(sorted(v for v in raw_targets if np.isfinite(v) and v > 0.0))[:3]
            except Exception:
                targets = ()
        try:
            stop_distance = float(np.log1p(0.003)) if stop_log_distance is None else float(stop_log_distance)
        except (TypeError, ValueError, OverflowError):
            stop_distance = 0.0
        if len(targets) >= 3 and np.isfinite(stop_distance) and stop_distance > 0:
            # First-passage probabilities use historical intrabar high/low
            # excursions as well as simulated closes. Same-candle ambiguity
            # receives fractional expected credit here; realized labels exclude
            # unresolved same-candle ordering rather than fabricating a winner.
            _t_formula = time.perf_counter()
            ptp1, ptp2, ptp3, psl = _first_passage_probabilities(
                sims, direction_sign, targets, stop_distance,
                close=c, high=high, low=low, seed=seed, step_returns=sim_steps)
            formula_profile['FirstPassageTP_SL'] = time.perf_counter()-_t_formula
        else:
            ptp1 = ptp2 = ptp3 = psl = 0.5
    else:
        ptp1 = ptp2 = ptp3 = psl = 0.5
    # Risk/regime metrics must not create a directional bias. Hurst persistence
    # is interacted with the observed trend; correlation is conditioned on BTC trend.
    hurst_direction = (hurst - 0.5) * 2.0 * trend_direction
    benchmark_directional_corr = corr * benchmark_direction
    # This aggregate uses each primitive expert once. `direction` is itself
    # already a weighted composite of several of these methods, so adding it
    # beside its constituents would double-count the same evidence.
    consensus_weights = np.asarray([.18, .12, .10, .08, .06, .07, .09, .07, .06, .08, .07], dtype=float)
    consensus_values = np.asarray([mark, mc_vote, ar, arima, sarima, hurst_direction,
                                   mr, wave, kal, coin, benchmark_directional_corr], dtype=float)
    consensus = float(np.clip(np.dot(consensus_weights, consensus_values) /
                              max(float(np.sum(consensus_weights)), 1e-12), -1, 1))
    garch_ratio = g/sd_safe if sd > 1e-12 else 0.0
    garch_feature = float(np.clip(garch_ratio/(1.0+garch_ratio), 0, 1)) if garch_ratio > 0 else 0.0
    result = {
        '_math_compute_profile': formula_profile,
        'math_markov': mark, 'math_prob_move': p_move, 'math_ar': ar, 'math_arima': arima,
        'math_sarima': sarima, 'math_garch': garch_feature, 'math_hurst': hurst,
        'math_mean_reversion': mr, 'math_cointegration': coin, 'math_correlation': corr,
        'math_return_vol_correlation': return_vol_corr, 'math_trend_deviation': trend_deviation,
        'math_entropy': entropy, 'math_fractal': fractal, 'math_wavelet': wave,
        'math_kalman': kal, 'math_monte_carlo': mc, 'math_bayesian': bay,
        'math_change_point': cp, 'math_ptp1': ptp1, 'math_ptp2': ptp2,
        'math_ptp3': ptp3, 'math_psl': psl, 'math_direction': direction,
        'math_target_sign': direction_sign, 'math_trend_direction': trend_direction,
        'math_benchmark_direction': benchmark_direction, 'math_consensus': consensus
    }
    # Calibration must always be trained on the raw formula outputs captured
    # at issuance, never on outputs that were already transformed by an older
    # calibration map. The public math fields below may be calibrated for use.
    raw_probabilities = {k: float(result[k]) for k in CALIBRATION_FIELDS}
    calibrated = apply_math_probability_calibration(result, probability_calibration)
    calibrated['_math_raw_probabilities'] = raw_probabilities
    calibrated['_validated_probability_heads'] = sorted(validated_heads)
    calibrated['_probability_validation_enforced'] = bool(probability_validation_enforced)
    calibrated['_math_data_quality'] = quality
    return calibrated


MATH_OUTPUTS = MATH_FEATURES + ['math_direction', 'math_trend_direction', 'math_benchmark_direction', 'math_consensus']
