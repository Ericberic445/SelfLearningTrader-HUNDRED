# SelfLearningTrader FIVE 1.0.280 — Master direction history and walk-forward audit

## Scope

This release changes only the Master directional-history persistence and Master directional candidate-validation path. The UI, Challenger, C1, C2, C3, forecast lifecycle, TP/SL rules, and direction-label definitions are unchanged.

## Source backup used

`SelfLearningTrader_backup_20261123_080358_021.slbackup.zip` (2026-11-23 08:03:58).

The backup contained a legacy single-file `master_direction_training.npz` with 120,000 historical candle rows across 233 contracts. The rows covered 760 unique 5-minute timestamps (about 63.25 hours). This archive was read-only during the audit; all candidate training and migration experiments ran in isolated scratch copies.

## 1.0.280 changes

### Per-contract history retention

- Replaced the single globally truncated direction-pool write path with compressed per-contract shards under `data/master_direction_pool/`.
- Each contract retains up to 1,500 completed fixed-horizon rows; the merged Master training view is bounded to 300,000 rows.
- Added resumable migration from the old `master_direction_training.npz` file. The original archive remains as a recovery source. A migration-complete marker is written only after all contract shards have been safely persisted.
- The loader falls back to legacy rows for any contract whose shard is missing, including after migration, so a missing shard does not silently discard that contract's old history.
- The per-contract update path does not reload and concatenate all contract shards on every scan. The full merged view is built only for retraining/validation.

### Directional validation

- Added three expanding chronological forward-validation windows, each with the configured one-hour purge interval.
- Promotion now requires the existing untouched chronological holdout to beat both the majority baseline and incumbent on ordinary and balanced accuracy, all three classes to meet coverage/recall requirements, and at least two of three walk-forward windows to pass. Aggregate walk-forward accuracy and balanced accuracy must also beat both baseline and incumbent.
- Only after validation passes is the deployable Master refit on all eligible rows. The held-out results remain the recorded validation results; the holdout is not used to claim validation accuracy.
- Existing Master-only class weights `[2.0, 0.8, 2.0]` remain unchanged. No probability values are inflated and no signal threshold is lowered.
- Master direction-pool update failures/results are now recorded in the learning audit instead of being silently swallowed.

## Migration test on the supplied backup

The real 120,000-row legacy archive was migrated in an isolated copy:

- 120,000 rows migrated.
- 233 per-contract shard files created.
- Re-loaded pool: 120,000 rows, 233 contracts.
- SHORT/WAIT/LONG counts preserved exactly: 41,404 / 36,721 / 41,875.
- A separate automated regression test deletes one shard and verifies that its rows are recovered from the retained legacy archive.

## Offline Master training on the supplied runtime data

The exact Master direction dataset was reconstructed from the supplied backup using the 1.0.280 training builder:

- 120,535 eligible rows.
- 280 contracts represented after adding eligible one-hour online observations.
- Class counts: SHORT 41,587; WAIT 36,929; LONG 42,019.

The candidate passed the single chronological holdout and all three walk-forward windows in the isolated scratch run.

### Untouched chronological holdout

| Metric | Candidate | Majority baseline | Incumbent Master |
|---|---:|---:|---:|
| Accuracy | 42.54% | 30.18% | 30.96% |
| Balanced accuracy | 42.47% | 33.33% | 31.60% |

Candidate class recall: SHORT 39.77%, WAIT 40.11%, LONG 47.52%.

### Aggregate walk-forward windows

| Metric | Candidate | Fold-specific majority baseline | Incumbent Master |
|---|---:|---:|---:|
| Accuracy | 41.76% | 27.86% | 31.81% |
| Balanced accuracy | 42.04% | 33.33% | 31.74% |

All 3 of 3 forward windows passed. Aggregate class recall: SHORT 44.04%, WAIT 46.63%, LONG 35.45%. The third window was the weakest; its individual accuracy was 38.76%, still above its baseline (32.88%) and incumbent (36.54%).

This is an offline replay of the supplied historical/runtime data, not proof of future live-market accuracy.

## Saved Top-5 shadow replay

The final isolated Master weights were replayed on the five saved Top-5 feature rows from the backup, with unavailable historical market-metric features neutralized exactly as the direction-training pool does. At the existing base Master gate (34% directional probability and 2.5 percentage-point edge), the isolated Master base produced 4 SHORT and 1 WAIT:

- ARCUSDTM: SHORT (35.0% SHORT, 30.6% WAIT, 34.4% LONG)
- PUMPUSDTM: SHORT (34.8%, 31.6%, 33.6%)
- KASUSDTM: WAIT (33.7%, 33.0%, 33.3%)
- PIEVERSEUSDTM: SHORT (38.6%, 25.0%, 36.4%)
- ELSAUSDTM: SHORT (39.0%, 24.2%, 36.8%)

This is a shadow replay of the Master base head on old saved rows. It is not a live scan and does not include every downstream regime/math/lens adjustment in the full prediction pipeline.

## Verification

- Automated suite: **336 passed, 24 subtests passed**.
- `python -m compileall -q app main.py`: passed.
- Root and Android `config.json`: identical.
- Android release identity: **1.0.280 / numeric version 10280**.
- Legacy-to-shard migration on the supplied backup: passed; row and class counts preserved.
- Per-contract retention, legacy fallback, and three-window walk-forward behavior: covered by new regression tests.
- Buildozer is not installed in this environment; **no APK was built**. The deliverable is a verified source ZIP. The existing GitHub Actions workflow is retained for Android APK build.

## Explicitly unchanged

- Challenger weights, state, training, comparison, and promotion logic.
- C1, C2, and C3.
- UI/layout.
- Existing LONG/SHORT/WAIT label definitions and TP/SL forecast lifecycle rules.
