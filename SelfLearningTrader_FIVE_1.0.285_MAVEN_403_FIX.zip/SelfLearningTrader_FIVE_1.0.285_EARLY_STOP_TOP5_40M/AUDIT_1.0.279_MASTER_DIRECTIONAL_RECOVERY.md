# SelfLearningTrader FIVE 1.0.279 — Master directional recovery audit

## Scope

This release addresses the observed collapse of Master predictions toward WAIT after the persistent historical candle pool became available. Only Master directional training and its matching validation path are changed. No UI, Challenger, C1, C2, or C3 code/state is changed.

## Findings from runtime backup 2026-11-23 08:03:58

- `master_direction_training.npz` contains 120,000 `HISTORICAL_CANDLE` rows across 233 contracts.
- The pool spans 760 unique 5-minute timestamps (about 63 hours), not 120,000 independent time points.
- The exact direction-training builder merges the pool with 535 eligible one-hour `ONLINE_DIRECTION_OBSERVATION` rows, for 120,535 rows total.
- The active Master had not been retrained on this newly populated pool. Its last retrain was 2026-11-22 10:26:44 UTC.
- The current Challenger control cohort is active and had 17/25 paired outcomes at backup time; the retraining cycle was waiting for the remaining paired outcomes.
- The saved Top-5 rows were all WAIT. Master LONG probabilities were 36.18–38.30%; directional edges were approximately 3.7–6.0 percentage points.
- The accepted Master validation was below its majority baseline, so the 1.0.278 confidence/edge guard required at least 55% directional probability and 6 percentage points of edge.

## Offline experiment on the exact merged runtime dataset

Using an isolated copy of the runtime weights and the exact 120,535-row direction dataset:

| Metric | Existing class weighting | Master-only weights [2.0, 0.8, 2.0] |
|---|---:|---:|
| Accuracy | 40.51% | 42.54% |
| Balanced accuracy | 40.89% | 42.47% |
| SHORT recall | 26.58% | 39.77% |
| WAIT recall | 90.89% | 40.11% |
| LONG recall | 5.19% | 47.52% |

For the weighted candidate, the same chronological holdout majority baseline was 30.18% accuracy and the incumbent was 30.96%. The candidate passed the existing promotion criteria in the isolated test. No runtime weights were changed.

A separate five-block expanding-window check showed that the later four forward blocks had all three class recalls at or above 20%, while the earliest block failed (WAIT recall 0%, LONG recall 9%). This is promising evidence for the current recent regime, but not proof of stable performance across every historical regime. Promotion still requires the existing chronological holdout gate.

The shadow candidate was also evaluated against the five saved Top-5 feature rows. It produced SHORT for PIEVERSE and ELSA, and WAIT for the other three. These are offline shadow results, not live forecasts.

## 1.0.279 change

- Added `master_direction_class_weights`, default `[2.0, 0.8, 2.0]`.
- Applied these weights only to `ModelManager.train_master_incremental` and the matching Master validation replay.
- The weights change the training loss only. They do not alter displayed probabilities, lower the confidence gate, force LONG/SHORT, or modify stored labels.
- Existing promotion requirements remain in force: accuracy and balanced accuracy must beat baseline and incumbent, and each class must meet minimum recall/coverage.
- The generic bootstrap weighting path remains unchanged.
- Challenger and C1/C2/C3 code and state remain untouched.

## Verification

- Offline candidate on the exact merged runtime dataset: `master_candidate_promoted` in an isolated scratch copy.
- Exact latest chronological holdout: 42.54% accuracy, 42.47% balanced accuracy; class recall SHORT 39.77%, WAIT 40.11%, LONG 47.52%.
- Five expanding-window forward blocks: four later blocks met the 20% recall floor for all three classes; the earliest block failed and is explicitly retained as a limitation above.
- Automated test suite: **334 passed, 24 subtests passed**.
- `python -m compileall -q app tests`: passed.
- Root and app `config.json` are byte-identical.
- Android release identity: **1.0.279 / numeric version 10279**.
- ZIP integrity: passed.
- Buildozer is not installed in this environment; **no APK was built**. This is a verified source ZIP, not an APK.

## Runtime limitation

The supplied phone backup is still on the pre-1.0.279 code. This release has not been installed on the phone. Its Master-only weighting will be used only after installing 1.0.279 and when the existing training scheduler reaches the next eligible Master retraining cycle. No prediction percentages have been artificially increased.
