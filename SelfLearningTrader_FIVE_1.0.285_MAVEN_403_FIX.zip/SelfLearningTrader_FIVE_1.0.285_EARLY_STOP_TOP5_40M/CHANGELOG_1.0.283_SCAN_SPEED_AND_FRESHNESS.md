# SelfLearningTrader FIVE 1.0.283 — scan speed, complete math validation and fresh TOP-5

## Scope

- Core scanner, Master inference, math validation and ledger-read performance.
- No UI/layout changes.
- No Master weights, Challenger weights, Challenger snapshots or C1/C2/C3 state were changed or retrained while preparing this source release.
- Existing 720 → 50 → 25 → TOP-5 funnel and formula set are preserved.
- Existing TP1/TP2/TP3/SL outcome semantics and formula validation thresholds are preserved.

## Eight performance and correctness repairs

1. **TOP-5 publication no longer waits for old-forecast maintenance.** The new scan is persisted and issued first. The full-pool TP/SL sweep, WAIT resolution and retraining run after publication. Only IDs for genuinely new lifecycles (`ACTIVE_NEW`) are excluded from those resolution passes. Existing active lifecycles still receive their TP/SL/WAIT check in the same cycle; a newly issued forecast cannot be resolved against its own pre-issuance candle history.
2. **Prediction-ledger parsing is cached by file signatures.** Statistics populations and resolved-learning rows are reused while the underlying prediction files remain unchanged. A file create/replace/append changes the signature and invalidates the cache.
3. **All five timeframe histories are reused.** `live_row()` retains the exact 5m/15m/1h/4h/1d frames already fetched by `collect()`. Stage-25 uses those frames directly instead of calling `candles()` again for each candidate/timeframe. Missing or insufficient cached frames still use the existing safe fetch path.
4. **Duplicate Master inference is removed.** The initial prediction and diagnostics share one `predict_bundle()` result. Model artifacts are loaded once per file signature and automatically reloaded after atomic replacement/retraining.
5. **Monte Carlo first-passage processing is vectorized.** The TP1/TP2/TP3 and moving-stop state machine preserves its original tie/partial-credit rules while replacing the per-path Python loop with vectorized NumPy masks. No path count or probability threshold was reduced.
6. **Math timeout now fails closed.** If the 25-candidate math stage times out, the partial candidate set is not ranked or issued as TOP-5. The previous TOP-5 remains visible and the cycle reports submitted/completed counts and timeout status.
7. **Final price freshness is mandatory before publication.** It no longer depends on Master readiness or the legacy `freshness_enabled_when_ready` setting. An unavailable ticker invalidates that candidate. Small accepted moves refresh current price and recalculate Entry/SL/TP. Material moves trigger a fresh model pass plus the complete math stage, followed by another ticker check.
8. **Stage-level profiling is expanded.** Diagnostics now record formula execution times, timeframe fetch/compute times, per-candidate math time, benchmark/correlation-matrix time, scan persistence time, per-contract TP/SL resolution time and per-contract WAIT resolution/stale-expiry time.

## Validation

- `python -m compileall -q app tests` — passed.
- `python -m pytest -q --disable-warnings` — **348 passed, 24 subtests passed**.
- The vectorized first-passage routine was compared with the 1.0.282 reference implementation over 25 randomized OHLC/Monte Carlo cases; outcomes matched exactly to floating-point precision.
- Local synthetic benchmark: vectorized first-passage averaged approximately 2.30 ms/call versus 3.17 ms/call for the reference loop in the measured case. This is a local microbenchmark, not a full Android scan benchmark.
- A synthetic 1,200-candle `compute_math_snapshot()` run averaged approximately 0.13 seconds on the development environment. Android/KuCoin live timing has not been measured.
- APK build and on-device installation are not claimed in this source-only release.
