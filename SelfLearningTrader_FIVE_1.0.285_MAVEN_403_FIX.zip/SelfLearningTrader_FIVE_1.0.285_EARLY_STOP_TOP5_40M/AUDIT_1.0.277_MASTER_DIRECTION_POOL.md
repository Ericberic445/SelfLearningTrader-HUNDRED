# SelfLearningTrader FIVE 1.0.277 — Master direction pool audit

## Problem confirmed in the 1.0.275 runtime archive

The 1.0.276 fixed-horizon direction filter found only 503 online observations (SHORT 173, WAIT 195, LONG 135). The runtime archive contained no `HISTORICAL_CANDLE` rows, because bootstrap candles were temporary and were not retained in the global replay archive. Consequently, after the initial bootstrap, Master direction retraining was effectively starved of broad cross-contract candle history. The 1.0.276 candidate trained on this small sample reached 20.79% accuracy on its 101-row holdout versus a 41.58% majority baseline and was correctly rejected.

## 1.0.277 changes

- Persist direction labels from the same closed 5-minute candle history already collected during scans.
- Use the existing fixed-horizon `make_labels` target semantics, not the separate regime target.
- Store 30 causal Master features, with market microstructure fields neutralized where historical alignment is unavailable.
- Persist `time`, `resolved_time`, contract, prediction ID, target, weights, and experience kind.
- Deduplicate by `(contract, candle_time)` and cap at 120,000 rows.
- Merge persistent historical candle rows with only fixed-horizon online observations for Master direction training.
- Require at least 1,500 rows from at least 5 contracts before retraining. Existing chronological promotion checks remain mandatory.

## Safety boundaries

- Challenger is not read, trained, copied, reset, or written by this new path.
- Existing Master weights are not overwritten unless a candidate passes the promotion gate.
- Trade outcome, WAIT-control, and variable-horizon position records are not reclassified as direction labels.
- No UI changes.

## Validation limitation

The supplied runtime backup contains the 60,000-row market-regime pool, but not the raw candle close series needed to reconstruct the independent 3-class direction labels for that historic pool. Therefore this release validates the new persistence and routing logic with tests; it does not claim that a new Master has already beaten the live incumbent. The app must accumulate the persistent direction pool from scans before a new candidate can be evaluated.

## Executed checks

- Full Python test suite: **328 passed, 24 subtests passed**.
- `python -m compileall -q app tests`: passed.
- Android release identity: `1.0.277` / numeric version `10277`; root and app configs are byte-identical.
- ZIP integrity: passed.
- Buildozer is not installed in this execution environment, so an APK was not built here. The project retains its GitHub Actions Android build workflow.
