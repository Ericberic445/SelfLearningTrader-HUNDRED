import numpy as np
from app.core.engine import LearningEngine


class TickerExchange:
    timeout=8
    def __init__(self,rows): self.rows=rows
    def all_tickers(self): return self.rows


def _engine(rows):
    engine=LearningEngine.__new__(LearningEngine)
    engine.exchange=TickerExchange(rows)
    engine.cfg={'freshness_enabled_when_ready':False,'freshness_required_before_top5':True,'freshness_small_move_pct':0.2,
                'freshness_recheck_move_pct':0.5,'freshness_max_rechecks':2,
                'freshness_candidate_pool':10}
    engine.readiness=lambda: (_ for _ in ()).throw(AssertionError('freshness must not depend on readiness'))
    engine._signal_levels=lambda row,pred:(float(row['close'][0]),float(row['close'][0])-1.2,
        float(row['close'][0])+1.8,float(row['close'][0])+2.7,float(row['close'][0])+3.6)
    return engine


def test_freshness_runs_before_ready_and_refreshes_entry_and_levels():
    engine=_engine([{'symbol':'AAAUSDTM','price':100.1}])
    candidate={'contract':'AAAUSDTM','exchange_symbol':'AAAUSDTM','prediction':'LONG',
        'price':100.0,'entry':100.0,'sl':98.8,'tp1':101.8,'tp2':102.7,'tp3':103.6,
        'features':{'atrpct':0.01},'quality':0.9}
    result,diag=engine._apply_ready_freshness([candidate],[candidate])
    assert len(result)==1
    assert result[0]['freshness_status']=='fresh'
    assert result[0]['freshness_price_refreshed'] is True
    assert result[0]['price']==100.1
    assert result[0]['entry']==100.1
    assert result[0]['sl']<result[0]['entry']<result[0]['tp1']
    assert diag['enabled'] is True


def test_freshness_rejects_candidate_when_live_ticker_is_unavailable():
    engine=_engine([])
    candidate={'contract':'AAAUSDTM','exchange_symbol':'AAAUSDTM','prediction':'LONG',
        'price':100.0,'entry':100.0,'features':{'atrpct':0.01}}
    result,diag=engine._apply_ready_freshness([candidate],[candidate])
    assert result==[]
    assert diag['invalidated']==1


def test_material_move_reanalysis_uses_master_without_waiting_for_math(tmp_path):
    from unittest.mock import patch

    class FreshKuCoin:
        timeout=8
        _request_gap=0.1
        def __init__(self,contract,timeout=8):
            self.futures_symbol=contract
            self.timeout=timeout
        def display_symbol(self,contract): return contract.replace('USDTM','-USDT')
        def all_tickers(self): return [{'symbol':self.futures_symbol,'price':101.0}]

    class FreshEngine:
        stage25_calls=0
        def __init__(self,root,exchange,cfg,initialize_ledgers=False):
            self.exchange=exchange
            self.cfg=cfg
        def _scan_train_and_predict(self,item,scan_history=800,run_id=None,update_regime_training=False):
            return {'contract':item['contract'],'exchange_symbol':item['contract'],'symbol':item['display'],
                    'prediction':'LONG','price':101.0,'entry':101.0,'sl':99.8,'tp1':102.8,
                    'tp2':103.7,'tp3':104.6,'features':{'atrpct':0.01},'quick_score':0.0}
        def _stage25_validate(self,rows,cancel_event=None):
            type(self).stage25_calls+=1
            row=dict(rows[0]); row['math_converged']=True
            return [row]

    engine=LearningEngine.__new__(LearningEngine)
    engine.root=tmp_path
    engine.exchange=TickerExchange([{'symbol':'AAAUSDTM','price':101.0}])
    engine.cfg={'freshness_small_move_pct':0.2,'freshness_recheck_move_pct':0.5,
                'freshness_max_rechecks':2,'freshness_candidate_pool':10,'scan_model_request_gap':0.2}
    engine._signal_levels=lambda row,pred:(float(row['close'][0]),float(row['close'][0])-1.2,
        float(row['close'][0])+1.8,float(row['close'][0])+2.7,float(row['close'][0])+3.6)
    candidate={'contract':'AAAUSDTM','exchange_symbol':'AAAUSDTM','symbol':'AAA-USDT','prediction':'LONG',
               'price':100.0,'entry':100.0,'sl':98.8,'tp1':101.8,'tp2':102.7,'tp3':103.6,
               'features':{'atrpct':0.01},'quick_score':0.8,'prescan_quality':0.9}
    with patch('app.core.exchange.KuCoin',FreshKuCoin), patch('app.core.engine.LearningEngine',FreshEngine):
        result,diag=engine._apply_ready_freshness([candidate],[candidate])
    assert len(result)==1
    assert FreshEngine.stage25_calls==0
    assert diag['rechecked']==1
    assert result[0]['prediction']=='LONG'
    assert result[0]['freshness_price_refreshed'] is True
    assert result[0]['entry']==101.0
