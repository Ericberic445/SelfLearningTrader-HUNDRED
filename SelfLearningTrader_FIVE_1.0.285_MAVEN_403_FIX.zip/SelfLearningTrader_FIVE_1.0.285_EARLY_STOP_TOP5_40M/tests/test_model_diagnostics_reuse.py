import numpy as np
from app.core.model import ModelManager


def test_prediction_diagnostics_reuses_bundle_without_second_master_inference():
    manager=ModelManager.__new__(ModelManager)
    def forbidden(*args,**kwargs):
        raise AssertionError('prediction_diagnostics repeated Master inference')
    manager.predict_bundle=forbidden
    manager._individual_math_expert_predictions=lambda snapshot: {}
    manager.math_expert_selector_state=lambda: {'status':'collecting','active_expert':None}
    manager.active_math_expert=lambda: None
    extra={
        'master_probs':np.asarray([0.2,0.3,0.5]),'decision_source':'master_core',
        'lens_active':False,'lenses':{k:{'probs':np.asarray([0.2,0.3,0.5])} for k in ('c1','c2','c3')},
        'market_regime':{},'combination_probs':{'MASTER':np.asarray([0.2,0.3,0.5])},
        'performance_snapshot':[],'selector_probs':None,'outcome_probs':None,
    }
    result=manager.prediction_diagnostics({},'LONG',np.asarray([0.2,0.3,0.5]),bundle_extra=extra)
    assert result['master_p_long']==0.5
    assert result['decision_source']=='master_core'
