import numpy as np

from app.core.engine import LearningEngine
from app.core.model import ModelManager


def test_direction_training_uses_only_fixed_horizon_independent_labels():
    engine = LearningEngine.__new__(LearningEngine)
    engine.cfg = {'horizon_bars': 12, 'direction_horizon_tolerance_seconds': 1800}
    exp = {
        'time': np.asarray([10000, 10000, 10000, 10000, 10000, 10000], dtype=np.int64),
        'resolved_time': np.asarray([13600, 13600, 28000, 13600, 13600, 13600], dtype=np.int64),
        'target': np.asarray([0, 1, 2, 2, 1, 0], dtype=np.int8),
        'contract': np.asarray(['BTC'] * 6),
        'experience_kind': np.asarray([
            'HISTORICAL_CANDLE', 'ONLINE_DIRECTION_OBSERVATION', 'ONLINE_DIRECTION_OBSERVATION',
            'TRADE', 'WAIT_CONTROL', 'DIRECTION_OBSERVATION'
        ]),
        'sample_weight': np.ones(6, dtype=np.float32),
    }
    filtered = engine._experience_for_direction_training(exp)
    assert filtered['experience_kind'].tolist() == [
        'HISTORICAL_CANDLE', 'ONLINE_DIRECTION_OBSERVATION'
    ]
    assert filtered['target'].tolist() == [0, 1]
    assert filtered['resolved_time'].tolist() == [13600, 13600]


def test_direction_class_weights_upweight_rare_direction_classes(tmp_path):
    mm = ModelManager(tmp_path, config={'direction_class_balance_power': 1.5})
    labels = np.asarray([0] * 80 + [1] * 10 + [2] * 10)
    weights = mm._direction_class_weights(labels)
    assert weights.shape == (3,)
    assert np.all(np.isfinite(weights))
    assert np.all(weights > 0)
    assert weights[1] > weights[0]
    assert weights[2] > weights[0]
    assert np.isclose(float(np.mean(weights)), 1.0)


def test_direction_promotion_rejects_candidate_that_collapses_to_one_class(tmp_path):
    mm = ModelManager(tmp_path, config={'horizon_bars': 1, 'model_validation_fraction': 0.2})

    class CollapsedModel:
        n_classes = 3

        def fit(self, X, y, **kwargs):
            return self

        def predict(self, X):
            return np.zeros(len(X), dtype=int)

    mm._new = lambda: CollapsedModel()
    n = 240
    X = np.zeros((n, 30), dtype=float)
    y = np.tile(np.asarray([0, 1, 2], dtype=int), n // 3)
    times = np.arange(n, dtype=np.int64) * 300
    weights = np.ones(n, dtype=float)
    candidate, report = mm._temporal_candidate(X, y, times, weights, 'direction')
    assert candidate is None
    assert report['status'] == 'rejected'
    assert report['class_coverage_passed'] is False
    assert report['class_metrics']['WAIT']['predicted_count'] == 0
    assert report['class_metrics']['LONG']['predicted_count'] == 0
