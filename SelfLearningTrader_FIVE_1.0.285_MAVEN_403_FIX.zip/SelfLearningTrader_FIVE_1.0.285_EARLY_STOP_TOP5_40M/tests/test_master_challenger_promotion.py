from pathlib import Path

from app.core.engine import LearningEngine


class _Exchange:
    futures_symbol = 'BTC-USDTM'


def _paired_rows(master_outcome, challenger_outcome, n=25):
    return [{
        'id': f'p{i}', 'challenger_generation': 4,
        'challenger_control_active': True, 'challenger_prediction': 'LONG',
        'trade_outcome': master_outcome,
        'challenger_outcome': {'trade_outcome': challenger_outcome},
    } for i in range(n)]


def test_candidate_challenger_wins_and_is_marked_for_master_promotion():
    engine = LearningEngine.__new__(LearningEngine)
    engine.cfg = {'retrain_batch_size': 25}
    engine._append_learning_audit = lambda event: None
    state = {'challenger_generation': 4, 'challenger_start_resolved': 100,
             'challenger_control_target': 125}
    result = engine._evaluate_challenger_control(
        _paired_rows('TP1', 'INITIAL_SL'), state)
    assert result['result'] == 'CHALLENGER_IMPROVED'
    assert result['winner'] == 'CHALLENGER_CANDIDATE'
    assert len(result['paired_prediction_ids']) == 25
    assert state['challenger_active'] is False


def test_new_master_candidate_wins_and_is_kept():
    engine = LearningEngine.__new__(LearningEngine)
    engine.cfg = {'retrain_batch_size': 25}
    engine._append_learning_audit = lambda event: None
    state = {'challenger_generation': 4, 'challenger_start_resolved': 100,
             'challenger_control_target': 125}
    result = engine._evaluate_challenger_control(
        _paired_rows('INITIAL_SL', 'TP2'), state)
    assert result['result'] == 'MASTER_IMPROVED'
    assert result['winner'] == 'INCUMBENT_MASTER'


def test_frozen_winner_snapshot_is_restored_to_master_atomically(tmp_path):
    engine = LearningEngine.__new__(LearningEngine)
    engine.root = tmp_path
    engine.data = tmp_path / 'data'
    engine.data.mkdir()
    engine.challenger_root = engine.data / 'challenger_snapshot'
    engine.exchange = _Exchange()
    engine.cfg = {}
    source = engine.challenger_root / 'models_v8_self_learning' / 'GLOBAL'
    target = engine.root / 'models_v8_self_learning' / 'GLOBAL'
    source.mkdir(parents=True)
    target.mkdir(parents=True)
    (source / 'champion.npz').write_bytes(b'incumbent-winner')
    (source / 'champion.json').write_text('{"winner":"incumbent"}')
    (source / 'market_regime.npz').write_bytes(b'incumbent-regime')
    (target / 'champion.npz').write_bytes(b'losing-candidate')
    restored = engine._restore_challenger_snapshot()
    assert (target / 'champion.npz').read_bytes() == b'incumbent-winner'
    assert 'champion.npz' in restored
    assert (target / 'market_regime.npz').read_bytes() == b'incumbent-regime'
    assert engine.mm.root == tmp_path


def test_expired_partial_tp_outcomes_are_comparable():
    engine = LearningEngine.__new__(LearningEngine)
    engine.cfg = {'retrain_batch_size': 25}
    engine._append_learning_audit = lambda event: None
    state = {'challenger_generation': 4, 'challenger_start_resolved': 100,
             'challenger_control_target': 125}
    rows = _paired_rows('EXPIRED_AFTER_TP2', 'EXPIRED_AFTER_TP1')
    result = engine._evaluate_challenger_control(rows, state)
    assert result['result'] == 'CHALLENGER_IMPROVED'


def test_clean_master_reset_never_erases_existing_incumbent():
    engine = LearningEngine.__new__(LearningEngine)
    engine.mm = type('MM', (), {'has_champion': lambda self: True})()
    engine._training_state = lambda: {'clean_master_reset_done': False}
    saved = {}
    audits = []
    engine._save_training_state = lambda state: saved.update(state)
    engine._append_learning_audit = lambda event: audits.append(event)

    result = engine._clean_master_reset_if_needed()

    assert result['status'] == 'incumbent_preserved_temporal_validation_required'
    assert saved['clean_master_reset_done'] is True
    assert saved['clean_master_reset_skipped_existing_master'] is True
    assert audits[0]['event'] == 'CLEAN_RESET_SKIPPED_EXISTING_MASTER'


def test_challenger_paired_win_cannot_bypass_temporal_master_gate():
    class _MM:
        meta = 'master.json'
        def _read_json(self, path, default):
            return {
                'last_retrain': 200,
                'last_accepted_promotion_check': {
                    'status': 'accepted', 'rows': 1500, 'validation_rows': 300,
                    'candidate_saved_without_holdout_rows': True,
                    'class_coverage_passed': True,
                    'candidate_accuracy': .60, 'baseline_accuracy': .50,
                    'incumbent_accuracy': .55,
                    'candidate_balanced_accuracy': .58,
                    'baseline_balanced_accuracy': .45,
                    'incumbent_balanced_accuracy': .52,
                    'walk_forward_validation': {
                        'passed': True, 'fold_passes': 2,
                        'folds': [{'status': 'passed'}, {'status': 'passed'}, {'status': 'rejected'}],
                    },
                },
            }

    engine = LearningEngine.__new__(LearningEngine)
    engine.mm = _MM()
    engine.cfg = {'direction_min_training_rows': 1500,
                  'direction_walk_forward_folds': 3,
                  'direction_walk_forward_min_pass_folds': 2,
                  'model_promotion_min_balanced_lift': .01,
                  'model_promotion_min_accuracy_lift': 0.0}
    gate = engine._master_candidate_temporal_promotion_gate({'challenger_created_at': 100})
    assert gate['passed'] is True

    gate = engine._master_candidate_temporal_promotion_gate({'challenger_created_at': 250})
    assert gate['passed'] is False
    assert gate['reason'] == 'temporal_validation_predates_candidate_generation'


def test_challenger_promotion_gate_rejects_candidate_that_only_beats_paired_outcomes():
    class _MM:
        meta = 'master.json'
        def _read_json(self, path, default):
            return {'last_retrain': 200, 'last_accepted_promotion_check': {
                'status': 'accepted', 'rows': 1500, 'validation_rows': 300,
                'candidate_saved_without_holdout_rows': True, 'class_coverage_passed': True,
                'candidate_accuracy': .51, 'baseline_accuracy': .50,
                'incumbent_accuracy': .50, 'candidate_balanced_accuracy': .46,
                'baseline_balanced_accuracy': .45, 'incumbent_balanced_accuracy': .45,
                'walk_forward_validation': {'passed': True, 'fold_passes': 2,
                    'folds': [{'status': 'passed'}, {'status': 'passed'}, {'status': 'rejected'}]},
            }}

    engine = LearningEngine.__new__(LearningEngine)
    engine.mm = _MM()
    engine.cfg = {'direction_min_training_rows': 1500,
                  'direction_walk_forward_folds': 3,
                  'direction_walk_forward_min_pass_folds': 2,
                  'model_promotion_min_balanced_lift': .02,
                  'model_promotion_min_accuracy_lift': 0.0}
    gate = engine._master_candidate_temporal_promotion_gate({'challenger_created_at': 100})
    assert gate['passed'] is False
    assert gate['reason'] == 'candidate_does_not_beat_incumbent_and_majority_baseline'
