import numpy as np
from app.core.features import FEATURES
from app.core.model import ModelManager
from app.core.engine import LearningEngine


def _market_rows(n=40):
    times=1_800_000_000 + np.arange(n,dtype=np.int64)*300
    close=100.0*np.exp(np.linspace(0.0,0.02,n))
    x={'time':times,'close':close,'high':close*1.002,'low':close*0.998}
    for i,name in enumerate(FEATURES):
        x[name]=np.full(n,(i+1)*0.001,dtype=float)
    x['book_imbalance']=np.full(n,0.8)
    x['oi_change']=np.full(n,0.4)
    x['funding']=np.full(n,0.02)
    x['liquidation_bias']=np.full(n,0.7)
    return x


def test_direction_pool_persists_only_completed_fixed_horizon_rows(tmp_path):
    mm=ModelManager(tmp_path,'XBTUSDTM',{})
    x=_market_rows(40)
    first=mm.update_direction_training(x,'BTCUSDTM',horizon_bars=12,
                                        long_threshold=0.003,short_threshold=-0.003)
    assert first['status']=='direction_pool_updated'
    pool=mm.load_direction_training_pool()
    assert len(pool['time'])==28
    assert np.all(pool['resolved_time']-pool['time']==3600)
    assert set(np.unique(pool['experience_kind']).tolist())=={'HISTORICAL_CANDLE'}
    for name in ('book_imbalance','oi_change','funding','liquidation_bias'):
        assert np.all(pool[name]==0.0)
    second=mm.update_direction_training(x,'BTCUSDTM',horizon_bars=12,
                                        long_threshold=0.003,short_threshold=-0.003)
    assert second['status']=='direction_pool_unchanged'
    assert len(mm.load_direction_training_pool()['time'])==28


def test_direction_training_builder_merges_pool_and_only_fixed_horizon_online(tmp_path):
    mm=ModelManager(tmp_path,'XBTUSDTM',{})
    x=_market_rows(40)
    mm.update_direction_training(x,'BTCUSDTM',horizon_bars=12,
                                  long_threshold=0.003,short_threshold=-0.003)
    engine=object.__new__(LearningEngine)
    engine.mm=mm
    engine.cfg={'horizon_bars':12,'direction_horizon_tolerance_seconds':1800}
    n=3
    exp={
        'time':np.asarray([1_800_000_000,1_800_000_000,1_800_000_000]),
        'resolved_time':np.asarray([1_800_003_600,1_800_003_600,1_800_000_100]),
        'contract':np.asarray(['ETHUSDTM']*3),
        'prediction_id':np.asarray(['a','b','c']),
        'target':np.asarray([2,0,1],dtype=np.int8),
        'sample_weight':np.asarray([0.15,0.15,1.0],dtype=np.float32),
        'experience_kind':np.asarray(['ONLINE_DIRECTION_OBSERVATION','ONLINE_DIRECTION_OBSERVATION','TRADE']),
    }
    for name in FEATURES:
        exp[name]=np.zeros(n,dtype=np.float32)
    result=engine._experience_for_direction_training(exp)
    # 28 completed historical candle labels + two valid one-hour online labels.
    assert len(result['target'])==30
    assert int(np.sum(result['experience_kind']=='HISTORICAL_CANDLE'))==28
    assert int(np.sum(result['experience_kind']=='ONLINE_DIRECTION_OBSERVATION'))==2
    assert not np.any(result['experience_kind']=='TRADE')


def test_master_retraining_waits_for_minimum_cross_contract_coverage(tmp_path):
    mm=ModelManager(tmp_path,'XBTUSDTM',{
        'direction_min_training_rows':10,
        'direction_min_training_contracts':5,
    })
    n=20
    x={'target':np.asarray([0,1,2,0,1]*4,dtype=np.int8),
       'time':np.arange(n,dtype=np.int64)+1_800_000_000,
       'resolved_time':np.arange(n,dtype=np.int64)+1_800_003_600,
       'contract':np.asarray(['BTCUSDTM']*n),
       'sample_weight':np.ones(n,dtype=np.float32)}
    for name in FEATURES:
        x[name]=np.linspace(0,1,n,dtype=np.float32)
    result=mm.train_master_incremental(x,min_rows=10)
    assert result['status']=='not_enough_direction_training_contracts'
    assert result['contracts']==1
    assert result['required_contracts']==5
    assert not mm.champion.exists()


def test_direction_pool_migrates_to_per_contract_shards_and_retains_each_contract(tmp_path):
    mm=ModelManager(tmp_path,'XBTUSDTM',{
        'direction_training_pool_max_rows':1000,
        'direction_training_pool_max_rows_per_contract':300,
    })
    n_btc=100; n_eth=50
    times=np.concatenate((1_800_000_000+np.arange(n_btc)*300,
                          1_800_000_000+np.arange(n_eth)*300)).astype(np.int64)
    contracts=np.asarray(['BTCUSDTM']*n_btc+['ETHUSDTM']*n_eth)
    target=np.tile(np.asarray([0,1,2],dtype=np.int8),50)[:len(times)]
    legacy={
        'time':times,'resolved_time':times+3600,'contract':contracts,
        'prediction_id':np.asarray([f'legacy:{c}:{t}' for c,t in zip(contracts,times)]),
        'target':target,'outcome_target':np.full(len(times),-1,dtype=np.int8),
        'sample_weight':np.ones(len(times),dtype=np.float32),
        'outcome_sample_weight':np.zeros(len(times),dtype=np.float32),
        'math_consensus':np.zeros(len(times),dtype=np.float32),
        'experience_kind':np.asarray(['HISTORICAL_CANDLE']*len(times)),
        'book_imbalance_valid':np.zeros(len(times),dtype=np.int8),
    }
    for name in FEATURES:
        legacy[name]=np.zeros(len(times),dtype=np.float32)
    np.savez_compressed(mm.direction_pool,**legacy)

    x=_market_rows(400)
    result=mm.update_direction_training(x,'BTCUSDTM',horizon_bars=12)
    assert result['status']=='direction_pool_updated'
    assert mm.direction_pool_migration.exists()
    pool=mm.load_direction_training_pool()
    assert len(pool['time'])==350
    assert int(np.sum(pool['contract']=='BTCUSDTM'))==300
    assert int(np.sum(pool['contract']=='ETHUSDTM'))==50
    assert len(list(mm.direction_pool_dir.glob('*.npz')))==2

    # If a shard is lost later, the retained legacy archive restores that contract.
    mm._direction_shard_path('ETHUSDTM').unlink()
    recovered=mm.load_direction_training_pool()
    assert int(np.sum(recovered['contract']=='ETHUSDTM'))==50
    assert int(np.sum(recovered['contract']=='BTCUSDTM'))==300


def test_direction_walk_forward_gate_checks_three_future_windows(tmp_path):
    class EncodedDirectionModel:
        n_classes=3
        def fit(self, X, y, **kwargs):
            return self
        def predict(self, X):
            return np.clip(np.rint(X[:,0]).astype(int),0,2)

    mm=ModelManager(tmp_path,'XBTUSDTM',{
        'horizon_bars':1,'model_validation_fraction':0.2,
        'model_validation_embargo_seconds':300,
        'model_promotion_min_balanced_lift':0.0,
        'model_promotion_min_accuracy_lift':0.0,
        'direction_min_class_recall':0.2,
        'direction_min_predicted_class_fraction':0.01,
        'direction_walk_forward_folds':3,
        'direction_walk_forward_validation_fraction':0.10,
        'direction_walk_forward_min_pass_folds':2,
    })
    mm._new=lambda:EncodedDirectionModel()
    n=600
    y=np.tile(np.asarray([0,1,2],dtype=int),n//3)
    X=np.zeros((n,len(FEATURES)),dtype=float)
    X[:,0]=y
    times=np.arange(n,dtype=np.int64)*300
    candidate,report=mm._temporal_candidate(X,y,times,np.ones(n),'direction')
    assert candidate is not None
    wf=report['walk_forward_validation']
    assert wf['status']=='passed'
    assert len(wf['folds'])==3
    assert wf['fold_passes']>=2
    assert wf['class_coverage_passed'] is True
