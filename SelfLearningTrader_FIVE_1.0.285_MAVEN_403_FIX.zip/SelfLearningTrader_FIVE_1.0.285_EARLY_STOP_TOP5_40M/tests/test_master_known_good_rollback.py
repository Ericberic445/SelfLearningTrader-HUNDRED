import hashlib
import json
import shutil
from pathlib import Path

from app.core.engine import LearningEngine
from app.core.model import ModelManager


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _engine(tmp_path, assets, live_master):
    engine = LearningEngine.__new__(LearningEngine)
    engine.root = tmp_path
    engine.cfg = {}
    engine.data = tmp_path / 'data'
    engine.data.mkdir(parents=True)
    engine.logs = tmp_path / 'logs'
    engine.logs.mkdir()
    engine.learning_audit = engine.data / 'learning_audit.jsonl'
    engine.challenger_root = engine.data / 'challenger_snapshot'
    engine.challenger_root.mkdir()
    (engine.challenger_root / 'champion.npz').write_bytes(b'unchanged challenger')
    engine.mm = ModelManager(tmp_path)
    shutil.copy2(live_master, engine.mm.champion)
    engine.mm._write_json(engine.mm.meta, {
        'status': 'master_direction',
        'last_accepted_promotion_check': {'status': 'accepted', 'candidate_accuracy': 0.39,
                                          'baseline_accuracy': 0.45},
        'directional_transfer_migration': {'status': 'applied'},
    })
    engine.mm._write_json(engine.mm.shared_base, {'base_version': 115, 'master_observations': 1237})
    engine.mm._write_json(engine.mm.learning_state, {
        'schema_version': 2, 'resolved_total': 1237, 'batch_size': 25,
        'lens_activation_resolved': 25, 'base_version': 115
    })
    engine._master_rollback_asset_root = lambda: assets
    engine._append_learning_audit = lambda row: None
    return engine


def _assets(tmp_path, checkpoint_source, checkpoint_meta):
    assets = tmp_path / 'assets' / 'master_rollback_20261118'
    assets.mkdir(parents=True)
    shutil.copy2(checkpoint_source, assets / 'champion.npz')
    shutil.copy2(checkpoint_meta, assets / 'champion.json')
    return assets


def _make_model(path, value):
    mm = ModelManager(path.parent / (path.stem + '_manager'))
    model = mm._new()
    model.weights[0, 0] = value
    mm._save(path, model)
    return mm


def test_rolls_back_only_known_regression_hash_and_preserves_challenger_and_shared_state(tmp_path, monkeypatch):
    import app.core.engine as engine_module

    checkpoint = tmp_path / 'known_good.npz'
    _make_model(checkpoint, 0.11)
    checkpoint_meta = tmp_path / 'known_good.json'
    checkpoint_meta.write_text(json.dumps({
        'schema_version': 2, 'status': 'master_direction',
        'last_promotion_check': {'status': 'rejected'}
    }), encoding='utf-8')
    assets = _assets(tmp_path, checkpoint, checkpoint_meta)

    bad = tmp_path / 'bad_master.npz'
    _make_model(bad, 0.77)
    engine = _engine(tmp_path / 'runtime', assets, bad)
    bad_hash = _sha(engine.mm.champion)
    monkeypatch.setattr(engine_module, '_KNOWN_REGRESSION_MASTER_HASHES', {bad_hash})

    challenger_before = (engine.challenger_root / 'champion.npz').read_bytes()
    shared_before = engine.mm.shared_base.read_bytes()
    learning_before = engine.mm.learning_state.read_bytes()

    result = engine._restore_known_good_master()
    assert result['status'] == 'master_restored_to_20261118_checkpoint'
    assert _sha(engine.mm.champion) == _sha(checkpoint)
    assert (engine.challenger_root / 'champion.npz').read_bytes() == challenger_before
    assert engine.mm.shared_base.read_bytes() == shared_before
    assert engine.mm.learning_state.read_bytes() == learning_before
    assert (engine.data / 'master_rollback_20261118' / 'pre_rollback_champion.npz').exists()
    assert engine.mm._read_json(engine.mm.meta, {}).get('master_rollback', {}).get('challenger_untouched') is True
    # The restored metadata does not activate the emergency 55%/6pp weak-model guard.
    assert engine.mm._master_validation_guard()['active'] is False
    assert engine._restore_known_good_master()['status'] == 'master_already_on_20261118_checkpoint'


def test_unknown_master_hash_is_never_overwritten(tmp_path, monkeypatch):
    import app.core.engine as engine_module

    checkpoint = tmp_path / 'known_good.npz'
    _make_model(checkpoint, 0.11)
    checkpoint_meta = tmp_path / 'known_good.json'
    checkpoint_meta.write_text(json.dumps({'schema_version': 2, 'status': 'master_direction'}), encoding='utf-8')
    assets = _assets(tmp_path, checkpoint, checkpoint_meta)

    unknown = tmp_path / 'unknown_master.npz'
    _make_model(unknown, 0.44)
    engine = _engine(tmp_path / 'runtime', assets, unknown)
    before = _sha(engine.mm.champion)
    monkeypatch.setattr(engine_module, '_KNOWN_REGRESSION_MASTER_HASHES', set())

    result = engine._restore_known_good_master()
    assert result['status'] == 'master_rollback_skipped_unknown_live_weights'
    assert _sha(engine.mm.champion) == before
    assert not (engine.data / 'master_rollback_20261118' / 'pre_rollback_champion.npz').exists()
