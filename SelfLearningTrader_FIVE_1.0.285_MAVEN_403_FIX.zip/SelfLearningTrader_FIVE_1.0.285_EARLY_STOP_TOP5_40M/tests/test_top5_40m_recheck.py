import json
import threading
import time
import sys
import types
from pathlib import Path

from app.services import scanner


def test_top5_40m_recheck_includes_same_contract_pending_and_signals_when_top5_resolves(tmp_path, monkeypatch):
    logs = tmp_path / 'logs'
    logs.mkdir()
    contract = 'COIN0USDTM'
    top_id = 'top5-id'
    old_id = 'existing-long-running-id'
    old_contract = 'OLDUSDTM'
    old_global_id = 'global-long-running-id'
    (logs / f'{contract}_pending.json').write_text(json.dumps([
        {'id': top_id, 'prediction': 'LONG', 'resolved': 0},
        {'id': old_id, 'prediction': 'SHORT', 'resolved': 0, 'verification_state': 'LONG_RUNNING_WAITING'},
    ]), encoding='utf-8')
    (logs / f'{contract}_predictions.json').write_text(json.dumps([
        {'id': top_id, 'prediction': 'LONG', 'resolved': 0},
    ]), encoding='utf-8')
    (logs / f'{old_contract}_pending.json').write_text(json.dumps([
        {'id': old_global_id, 'prediction': 'LONG', 'resolved': 0, 'verification_state': 'LONG_RUNNING_WAITING'},
    ]), encoding='utf-8')
    (logs / f'{old_contract}_predictions.json').write_text(json.dumps([
        {'id': old_global_id, 'prediction': 'LONG', 'resolved': 0},
    ]), encoding='utf-8')

    class FakeBaseEngine:
        def __init__(self):
            self.root = tmp_path
            self.cfg = {}
            self.logs = logs

    calls = []

    class FakeExchange:
        def __init__(self, symbol):
            self.symbol = symbol

    class FakeLearner:
        def __init__(self, root, exchange, cfg, **kwargs):
            self.contract = exchange.symbol
            self.pending = logs / f'{self.contract}_pending.json'
            self.predictions = logs / f'{self.contract}_predictions.json'

        def set_symbol(self, symbol):
            self.contract = symbol

        def resolve_pending(self, allowed_ids=None):
            calls.append((self.contract, set(allowed_ids or [])))
            rows = json.loads(self.predictions.read_text(encoding='utf-8'))
            for row in rows:
                if row['id'] in (allowed_ids or set()):
                    row['resolved'] = 1
            self.predictions.write_text(json.dumps(rows), encoding='utf-8')

        def mark_unresolved_long_running(self, allowed_ids):
            return 0

    monkeypatch.setattr(scanner, 'TOP5_RECHECK_DELAY_SECONDS', 0)
    monkeypatch.setattr(scanner, 'stopped', lambda: False)
    monkeypatch.setattr(scanner, 'runtime_log', lambda *args, **kwargs: None)
    core_pkg = types.ModuleType('core')
    core_pkg.__path__ = []
    exchange_mod = types.ModuleType('core.exchange')
    exchange_mod.KuCoin = FakeExchange
    engine_mod = types.ModuleType('core.engine')
    engine_mod.LearningEngine = FakeLearner
    monkeypatch.setitem(sys.modules, 'core', core_pkg)
    monkeypatch.setitem(sys.modules, 'core.exchange', exchange_mod)
    monkeypatch.setitem(sys.modules, 'core.engine', engine_mod)

    done = threading.Event()
    rows = [{'id': top_id, 'contract': contract, 'prediction': 'LONG', 'top5_issued_at': int(time.time())}]
    thread = scanner._schedule_top5_candle_recheck(FakeBaseEngine(), rows, threading.Event(), 7, done)
    thread.join(timeout=3)

    assert not thread.is_alive()
    assert done.is_set()
    assert calls == [(contract, {top_id, old_id}), (old_contract, {old_global_id})]


def test_mark_unresolved_top5_forecast_enters_existing_long_running_state(tmp_path):
    from app.core.engine import LearningEngine

    engine = LearningEngine.__new__(LearningEngine)
    engine.pending = tmp_path / 'AAAUSDTM_pending.json'
    engine.predictions = tmp_path / 'AAAUSDTM_predictions.json'
    rows = [
        {'id': 'unresolved', 'prediction': 'LONG', 'resolved': 0, 'tp1_hit': False, 'tp2_hit': False, 'verification_state': 'INITIAL_WAIT'},
        {'id': 'tp1', 'prediction': 'LONG', 'resolved': 0, 'tp1_hit': True, 'tp2_hit': False, 'verification_state': 'INITIAL_WAIT'},
        {'id': 'done', 'prediction': 'SHORT', 'resolved': 1, 'tp1_hit': False, 'tp2_hit': False, 'verification_state': 'COMPLETED_TP'},
    ]
    engine.pending.write_text(json.dumps(rows), encoding='utf-8')
    engine.predictions.write_text(json.dumps(rows), encoding='utf-8')

    assert engine.mark_unresolved_long_running({'unresolved', 'tp1', 'done'}) == 2
    pending = json.loads(engine.pending.read_text(encoding='utf-8'))
    states = {row['id']: row['verification_state'] for row in pending}
    assert states['unresolved'] == 'LONG_RUNNING_WAITING'
    assert states['tp1'] == 'WAITING_TP2'
    assert states['done'] == 'COMPLETED_TP'
