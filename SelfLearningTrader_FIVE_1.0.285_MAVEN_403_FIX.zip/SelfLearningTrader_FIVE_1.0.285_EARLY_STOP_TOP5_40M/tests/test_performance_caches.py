import json
import numpy as np
from app.core.engine import LearningEngine
from app.core.model import ModelManager


def test_prediction_population_cache_reuses_snapshot_and_invalidates_on_file_change(tmp_path):
    engine=LearningEngine.__new__(LearningEngine)
    engine.logs=tmp_path
    first=engine._prediction_stats_population()
    second=engine._prediction_stats_population()
    assert first is second
    path=tmp_path/'AAAUSDTM_predictions.json'
    path.write_text('[]',encoding='utf-8')
    third=engine._prediction_stats_population()
    assert third is not first
    assert third['raw_rows']==[]


def test_resolved_learning_rows_cache_invalidates_when_ledger_changes(tmp_path):
    engine=LearningEngine.__new__(LearningEngine)
    engine.logs=tmp_path
    first=engine._resolved_learning_rows()
    second=engine._resolved_learning_rows()
    assert first==second==[]
    path=tmp_path/'AAAUSDTM_predictions.json'
    path.write_text(json.dumps([{'id':'x','resolved':False}]),encoding='utf-8')
    assert engine._resolved_learning_rows()==[]
    assert engine._resolved_learning_rows_cache_signature==engine._prediction_files_signature()


def test_model_artifact_cache_reuses_weights_and_invalidates_after_atomic_save(tmp_path):
    manager=ModelManager(tmp_path,'XBTUSDTM',{})
    model=manager._new()
    manager._save(manager.champion,model)
    first=manager._load_path(manager.champion,'direction')
    second=manager._load_path(manager.champion,'direction')
    assert first is second
    changed=manager._new()
    changed.weights=np.asarray(changed.weights)+0.125
    manager._save(manager.champion,changed)
    third=manager._load_path(manager.champion,'direction')
    assert third is not first
    assert np.allclose(third.weights,changed.weights)


def test_wait_resolver_skips_all_archives_when_cached_population_has_no_wait_queue(tmp_path):
    engine=LearningEngine.__new__(LearningEngine)
    engine.logs=tmp_path
    engine.cfg={'wait_learning_horizon_bars':48}
    for i in range(50):
        (tmp_path/f'COIN{i}USDTM_predictions.json').write_text('[]',encoding='utf-8')
    engine._prediction_stats_population=lambda: {'pending_wait':[]}
    changed,stats=engine.resolve_wait_learning()
    assert changed==[]
    assert stats['checked']==0
    assert engine._last_wait_resolve_profile[0]['operation']=='skip_no_pending_wait'
    assert engine._last_wait_resolve_profile[0]['prediction_archives_opened']==0
