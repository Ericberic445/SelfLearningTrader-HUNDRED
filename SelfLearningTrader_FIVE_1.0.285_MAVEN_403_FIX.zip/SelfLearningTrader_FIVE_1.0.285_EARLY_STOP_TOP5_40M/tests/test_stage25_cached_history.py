import numpy as np
from unittest.mock import patch
from app.core.engine import LearningEngine
from app.core.math_models import MATH_FEATURES


class FakeExchange:
    calls = 0
    def __init__(self, symbol='XBTUSDTM', timeout=25):
        self.timeout = timeout
        self.futures_symbol = symbol
    def set_symbol(self, symbol):
        self.futures_symbol = symbol
    def candles(self, tf, limit=5000):
        type(self).calls += 1
        n = 120
        return {'time': np.arange(n), 'close': np.linspace(100, 110, n),
                'high': np.linspace(101, 111, n), 'low': np.linspace(99, 109, n),
                'volume': np.ones(n)}


class FakeModel:
    def __init__(self):
        self.predict_calls = 0

    def predict_bundle(self, row, consensus, math_snapshot):
        self.predict_calls += 1
        return 'WAIT', np.asarray([0.1, 0.8, 0.1]), {}
    def prediction_diagnostics(self, *args):
        return {}


def _math_snapshot(*args, **kwargs):
    out = {k: 0.5 for k in MATH_FEATURES}
    out.update({'math_direction': 0.2, 'math_consensus': 0.3, 'math_target_sign': 1.0})
    return out


def test_stage25_reuses_cached_candles_and_clears_directional_tp_sl_for_wait():
    FakeExchange.calls = 0
    engine = LearningEngine.__new__(LearningEngine)
    engine.exchange = FakeExchange()
    engine.cfg = {'scan_model_request_gap': 0.0, 'scan_math_workers': 1, 'horizon_bars': 12}
    engine.mm = FakeModel()
    engine._math_method_scores = lambda m, direction: {'fake': 0.5}
    engine._signal_levels = lambda row, pred: (110.0, float('nan'), float('nan'), float('nan'), float('nan'))
    engine._attach_lens_plans = lambda row: row
    cached = {'time': np.arange(120), 'close': np.linspace(100, 110, 120),
              'high': np.linspace(101, 111, 120), 'low': np.linspace(99, 109, 120),
              'volume': np.ones(120)}
    row = {'contract': 'AAAUSDTM', 'symbol': 'AAA-USDT', 'prediction': 'LONG',
           'price': 110.0, 'edge_score': 0.4, 'quality': 0.8,
           'p_short': 0.2, 'p_wait': 0.3, 'p_long': 0.5,
           'features': {'atrpct': 0.01}, '_stage25_base': cached}
    with patch('app.core.exchange.KuCoin', FakeExchange), patch('app.core.engine.compute_math_snapshot', _math_snapshot):
        out = engine._stage25_validate([row])
    assert len(out) == 1
    assert out[0]['prediction'] == 'WAIT'
    assert out[0]['p_tp1'] is None and out[0]['p_tp2'] is None
    assert out[0]['p_tp3'] is None and out[0]['p_sl'] is None
    # WAIT is Master’s live action, but the independent formula shadow still
    # evaluates directional methods against its strongest raw Master direction.
    assert out[0]['math_method_scores'] == {'fake': 0.5}
    assert out[0]['math_decision_architecture'] == 'master_one_pass_with_independent_formula_advisers'
    assert 'prediction_guard' not in out[0]
    assert engine.mm.predict_calls == 1  # no Master/formula direction-convergence loop
    assert '_stage25_base' not in out[0]
    # The cached 5m history is reused; only the four additional closed
    # timeframes are fetched for the adaptive formula layer.
    assert FakeExchange.calls == 5


def test_stage25_does_not_fallback_to_legacy_ensemble_after_master_ignores_conflicting_formulas():
    class ConflictAwareModel(FakeModel):
        def select_master_math_advisors(self, context_key, candidates):
            return {
                'selected_experts': [],
                'considered_experts': ['C1|MARKOV|5m', 'C2|AR|5m'],
                'advice_score': 0.0,
                'advice_strength': 0.0,
                'status': 'validated_advisers_conflict_master_ignored',
                'eligible_count': 2,
            }

        def active_math_ensemble(self, context_key):
            # Must not be resurrected after the current Master selection chose none.
            return ['C1|MARKOV|5m']

        def candidate_math_ensemble(self, context_key):
            return ['C1|MARKOV|5m']

    FakeExchange.calls = 0
    engine = LearningEngine.__new__(LearningEngine)
    engine.exchange = FakeExchange()
    engine.cfg = {'scan_model_request_gap': 0.0, 'scan_math_workers': 1, 'horizon_bars': 12}
    engine.mm = ConflictAwareModel()
    engine._math_method_scores = lambda m, direction: {'fake': 0.5}
    engine._signal_levels = lambda row, pred: (110.0, float('nan'), float('nan'), float('nan'), float('nan'))
    engine._attach_lens_plans = lambda row: row
    cached = {'time': np.arange(120), 'close': np.linspace(100, 110, 120),
              'high': np.linspace(101, 111, 120), 'low': np.linspace(99, 109, 120),
              'volume': np.ones(120)}
    row = {'contract': 'AAAUSDTM', 'symbol': 'AAA-USDT', 'prediction': 'LONG',
           'price': 110.0, 'edge_score': 0.4, 'quality': 0.8,
           'p_short': 0.2, 'p_wait': 0.3, 'p_long': 0.5,
           'features': {'atrpct': 0.01}, '_stage25_base': cached}
    with patch('app.core.exchange.KuCoin', FakeExchange), patch('app.core.engine.compute_math_snapshot', _math_snapshot):
        out = engine._stage25_validate([row])
    assert len(out) == 1
    assert out[0]['math_ensemble_selected_experts'] == []
    assert out[0]['math_advice_selection_status'] == 'validated_advisers_conflict_master_ignored'
    assert out[0]['math_advice_strength'] == 0.0



def test_stage25_passes_each_validated_formula_to_master_individually():
    class IndividualAdviserModel(FakeModel):
        def __init__(self):
            super().__init__()
            self.received_advisers = None

        def select_master_math_advisors(self, context_key, candidates):
            advisers = [
                {'name': 'C1|MARKOV|5m', 'score': 0.7, 'prediction': 'LONG',
                 'validation_lift': 0.10, 'validation_n': 30,
                 'advice_strength': 0.12},
                {'name': 'C2|AR|5m', 'score': -0.6, 'prediction': 'SHORT',
                 'validation_lift': 0.08, 'validation_n': 30,
                 'advice_strength': 0.10},
            ]
            return {'advisors': advisers,
                    'selected_experts': [x['name'] for x in advisers],
                    'considered_experts': [x['name'] for x in advisers],
                    'status': 'individual_advisers_active',
                    'eligible_count': 2, 'selected_count': 2}

        def candidate_math_ensemble(self, context_key):
            return []

        def predict_bundle(self, row, consensus, math_snapshot, math_advisors=None):
            self.predict_calls += 1
            self.received_advisers = list(math_advisors or [])
            return 'WAIT', np.asarray([0.1, 0.8, 0.1]), {}

    FakeExchange.calls = 0
    engine = LearningEngine.__new__(LearningEngine)
    engine.exchange = FakeExchange()
    engine.cfg = {'scan_model_request_gap': 0.0, 'scan_math_workers': 1, 'horizon_bars': 12}
    engine.mm = IndividualAdviserModel()
    engine._math_method_scores = lambda m, direction: {'fake': 0.5}
    engine._signal_levels = lambda row, pred: (110.0, float('nan'), float('nan'), float('nan'), float('nan'))
    engine._attach_lens_plans = lambda row: row
    cached = {'time': np.arange(120), 'close': np.linspace(100, 110, 120),
              'high': np.linspace(101, 111, 120), 'low': np.linspace(99, 109, 120),
              'volume': np.ones(120)}
    row = {'contract': 'AAAUSDTM', 'symbol': 'AAA-USDT', 'prediction': 'LONG',
           'price': 110.0, 'edge_score': 0.4, 'quality': 0.8,
           'p_short': 0.2, 'p_wait': 0.3, 'p_long': 0.5,
           'features': {'atrpct': 0.01}, '_stage25_base': cached}
    with patch('app.core.exchange.KuCoin', FakeExchange), patch('app.core.engine.compute_math_snapshot', _math_snapshot):
        out = engine._stage25_validate([row])
    assert len(out) == 1
    assert [x['name'] for x in engine.mm.received_advisers] == [
        'C1|MARKOV|5m', 'C2|AR|5m']
    assert out[0]['math_advice_selection_status'] == 'individual_advisers_active'
    assert out[0]['math_advice_score'] == 0.0
    assert out[0]['math_advice_strength'] == 0.0


def test_stage25_reuses_all_five_closed_timeframes_from_model_stage_cache():
    FakeExchange.calls = 0
    engine = LearningEngine.__new__(LearningEngine)
    engine.exchange = FakeExchange()
    engine.cfg = {'scan_model_request_gap': 0.0, 'scan_math_workers': 1, 'horizon_bars': 12}
    engine.mm = FakeModel()
    engine._math_method_scores = lambda m, direction: {'fake': 0.5}
    engine._signal_levels = lambda row, pred: (110.0, 98.0, 112.0, 113.0, 114.0)
    engine._attach_lens_plans = lambda row: row
    frames = {}
    for tf in ('5min', '15min', '1hour', '4hour', '1day'):
        frames[tf] = {'time': np.arange(120) * 300000,
                      'close': np.linspace(100, 110, 120),
                      'high': np.linspace(101, 111, 120),
                      'low': np.linspace(99, 109, 120),
                      'volume': np.ones(120)}
    row = {'contract': 'AAAUSDTM', 'symbol': 'AAA-USDT', 'prediction': 'LONG',
           'price': 110.0, 'edge_score': 0.4, 'quality': 0.8,
           'p_short': 0.2, 'p_wait': 0.3, 'p_long': 0.5,
           'features': {'atrpct': 0.01}, '_stage25_base': frames['5min'],
           '_stage25_frames': frames}
    def cached_snapshot(*args, **kwargs):
        result=_math_snapshot(*args, **kwargs)
        result['_math_data_quality']={'status':'ready_without_timestamps'}
        return result
    with patch('app.core.exchange.KuCoin', FakeExchange), patch('app.core.engine.compute_math_snapshot', cached_snapshot):
        out = engine._stage25_validate([row])
    assert len(out) == 1
    # One request is the shared BTC benchmark; all five candidate timeframes
    # are reused from the already-fetched live model-stage frame set.
    assert FakeExchange.calls == 1
    assert set(out[0]['math_profile_by_timeframe_seconds']) == {'5m', '15m', '1h', '4h', '1d'}
    assert out[0]['math_candidate_seconds'] >= 0
    assert '_stage25_frames' not in out[0]
