import json
import numpy as np
from pathlib import Path

from app.core.engine import LearningEngine


class FakeExchange:
    def __init__(self, bars):
        self.bars = bars
        self.futures_symbol = 'AAAUSDTM'
    def candles(self, tf, limit):
        return {k: np.asarray(v)[-limit:] for k, v in self.bars.items()}


def _bars_with_late_tp():
    n = 120
    times = (1_800_000_000 + np.arange(n) * 300) * 1_000_000
    close = np.full(n, 100.0)
    high = np.full(n, 102.0)
    low = np.full(n, 98.0)
    # TP1 is crossed only after the original 96-bar (8-hour) lifecycle window.
    high[105] = 106.0
    return {'time': times, 'open': close.copy(), 'high': high, 'low': low,
            'close': close, 'volume': np.full(n, 100.0)}


def test_tp_hit_after_eight_hour_window_does_not_prevent_sideways_expiry(tmp_path, monkeypatch):
    engine = LearningEngine.__new__(LearningEngine)
    engine.root = Path(tmp_path)
    engine.logs = Path(tmp_path) / 'logs'
    engine.logs.mkdir(parents=True, exist_ok=True)
    engine.pending = engine.logs / 'AAAUSDTM_pending.json'
    engine.predictions = engine.logs / 'AAAUSDTM_predictions.json'
    engine.cfg = {'history_limit': 5000, 'horizon_bars': 12,
                  'max_forecast_lifetime_bars': 96, 'long_threshold': 0.003,
                  'short_threshold': -0.003, 'post_sl_recheck_bars': 3}
    bars = _bars_with_late_tp()
    engine.exchange = FakeExchange(bars)
    row = {'id': 'forecast-a', 'contract': 'AAAUSDTM', 'exchange_symbol': 'AAAUSDTM',
           'prediction': 'LONG', 'time': int(bars['time'][0]), 'price': 100.0,
           'entry': 100.0, 'sl': 90.0, 'tp1': 105.0, 'tp2': 110.0, 'tp3': 115.0,
           'horizon_bars': 12, 'resolved': 0, 'features': {},
           'tp1_hit': False, 'tp2_hit': False, 'tp3_hit': False}
    engine.pending.write_text(json.dumps([row]), encoding='utf-8')
    engine.predictions.write_text(json.dumps([row]), encoding='utf-8')
    engine._record_math_calibration_from_predictions = lambda *args, **kwargs: False

    resolved = engine.resolve_pending(allowed_ids={'forecast-a'})

    assert len(resolved) == 1
    assert resolved[0]['verification_state'] == 'EXPIRED_SIDEWAYS'
    assert resolved[0]['result'] == 'SIDEWAYS'
    assert resolved[0]['expiry_market_classification'] == 'SIDEWAYS'
    assert resolved[0]['statistics_exclude'] is True
    assert resolved[0]['training_exclude'] is True
    assert resolved[0]['tp1_hit'] is False
