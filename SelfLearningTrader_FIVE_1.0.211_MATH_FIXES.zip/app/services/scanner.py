import json
import os
import time
from pathlib import Path
import threading
import uuid
import traceback

STATE_NAME = 'background_scan_state.json'
CONTROL_NAME = 'background_scan_control.json'
LOCK_NAME = 'background_scan.lock'
MANUAL_REQUEST_NAME = 'manual_prediction_request.json'
MONITOR_REQUEST_NAME = 'prediction_monitor_request.json'
POSITION_REQUEST_NAME = 'position_monitor_request.json'
MONITOR_EVENTS_DIR = 'monitor_events'
HEARTBEAT_SECONDS = 2.0
STALE_SECONDS = 12
DEFAULT_SCAN_INTERVAL_SECONDS = 1800  # fixed 30-minute market scan cadence


def app_private_dir():
    # The UI and the Android service MUST use exactly the same persistent
    # runtime directory.  ANDROID_PRIVATE is the app's private root; the UI
    # stores runtime state under stl_generational_v15_3/runtime.  Keeping the
    # same path here is critical: otherwise the service can be alive and
    # writing heartbeats while the UI reads a different directory and shows
    # "В фоне — Ожидание" forever.
    p = os.environ.get('ANDROID_PRIVATE')
    if p:
        return Path(p) / 'stl_generational_v15_3'
    p = os.environ.get('ANDROID_APP_PATH')
    if p:
        return Path(p) / 'stl_generational_v15_3'
    return Path.home() / '.stl_generational_v15_3'

ROOT = app_private_dir() / 'runtime'
ROOT.mkdir(parents=True, exist_ok=True)
STATE = ROOT / STATE_NAME
CONTROL = ROOT / CONTROL_NAME
LOCK = ROOT / LOCK_NAME
MANUAL_REQUEST = ROOT / MANUAL_REQUEST_NAME
MONITOR_REQUEST = ROOT / MONITOR_REQUEST_NAME
POSITION_REQUEST = ROOT / POSITION_REQUEST_NAME
REAL_POSITIONS = ROOT / 'real_positions.json'
MONITOR_EVENTS = ROOT / MONITOR_EVENTS_DIR
MONITOR_EVENTS.mkdir(parents=True, exist_ok=True)
STATE_LOCK = threading.Lock()
RUNTIME_LOG = ROOT / 'runtime_diagnostics.log'
RUNTIME_LOG_LOCK = threading.Lock()

def runtime_log(message, level='INFO'):
    """Append a timestamped runtime diagnostic line without ever crashing the service."""
    try:
        line = f"{time.strftime('%Y-%m-%d %H:%M:%S')} [{level}] {message}"
        with RUNTIME_LOG_LOCK:
            with RUNTIME_LOG.open('a', encoding='utf-8') as fh:
                fh.write(line + '\n')
            try:
                lines = RUNTIME_LOG.read_text(encoding='utf-8').splitlines()[-120:]
                data = read_json(STATE, {})
                data['runtime_log_tail'] = lines
                data['runtime_log_path'] = str(RUNTIME_LOG)
                write_json(STATE, data)
            except Exception:
                pass
    except Exception:
        pass



def write_json(path, data):
    tmp = path.with_suffix(path.suffix + '.tmp')
    try:
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
        tmp.replace(path)
    except Exception:
        try:
            path.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
        except Exception:
            pass


def read_json(path, default=None):
    try:
        return json.loads(path.read_text(encoding='utf-8')) if path.exists() else (default if default is not None else {})
    except Exception:
        return default if default is not None else {}


def control_data():
    return read_json(CONTROL, {})


def stopped():
    return bool(control_data().get('stop'))


def set_state(**kwargs):
    with STATE_LOCK:
        data = read_json(STATE, {})
        data.update(kwargs)
        now=int(time.time())
        data['updated_at'] = now
        data['heartbeat_at'] = now
        write_json(STATE, data)


def acquire_service_lock(instance_id):
    payload={'instance_id':instance_id,'created_at':int(time.time())}
    try:
        fd=os.open(str(LOCK), os.O_CREAT|os.O_EXCL|os.O_WRONLY)
        os.write(fd, json.dumps(payload).encode('utf-8'))
        os.close(fd)
        return True
    except FileExistsError:
        old=read_json(LOCK,{})
        state=read_json(STATE,{})
        # Migrate any TOP-5 created by older versions into the canonical logs so
        # old yellow rows can finally be resolved and counted by the same stats.
        try:
            engine.persist_scan_predictions(list(state.get('last_top5') or [])[:5])
        except Exception:
            pass
        heartbeat=int(state.get('heartbeat_at',0) or 0)
        owner=str(old.get('instance_id',''))
        if heartbeat and int(time.time())-heartbeat <= STALE_SECONDS and owner:
            return False
        try: LOCK.unlink()
        except Exception: pass
        try:
            fd=os.open(str(LOCK), os.O_CREAT|os.O_EXCL|os.O_WRONLY)
            os.write(fd, json.dumps(payload).encode('utf-8')); os.close(fd)
            return True
        except Exception:
            try:
                if 'fd' in locals(): os.close(fd)
            except Exception: pass
            return False
    except Exception:
        return False


def release_service_lock(instance_id):
    try:
        owner=read_json(LOCK,{}).get('instance_id')
        if owner == instance_id:
            LOCK.unlink()
    except Exception:
        pass


def acquire_wakelock():
    try:
        from jnius import autoclass
        PythonActivity = autoclass('org.kivy.android.PythonActivity')
        Context = autoclass('android.content.Context')
        activity = PythonActivity.mActivity
        pm = activity.getSystemService(Context.POWER_SERVICE)
        lock = pm.newWakeLock(1, 'SelfLearningTraderFiveV15_3::ContinuousLearning')
        lock.setReferenceCounted(False)
        lock.acquire()
        return lock
    except Exception:
        return None


def _retrain_with_real_position_batch(engine, contracts, resolved_total):
    """Retrain Master for normal forecast batches or queued auxiliary observations."""
    contracts = list(contracts or [])
    real_path = engine.data / 'real_position_learning_state.json'
    online_path = engine.data / 'online_observation_learning_state.json'
    real_state = read_json(real_path, {})
    online_state = read_json(online_path, {})
    if not isinstance(real_state, dict): real_state = {}
    if not isinstance(online_state, dict): online_state = {}
    real_pending = int(real_state.get('pending_samples', 0) or 0)
    online_pending = int(online_state.get('pending_samples', 0) or 0)
    pending = real_pending + online_pending
    batch = max(5, int(engine.cfg.get('real_position_retrain_batch_size', 25)))
    training_state = engine._training_state()
    auxiliary_due = pending >= batch and engine.mm.has_champion() and bool(training_state.get('clean_master_reset_done', False))
    if not contracts and not auxiliary_due:
        return []
    results = engine.retrain_symbols(contracts, resolved_total=resolved_total, force=auxiliary_due)
    if auxiliary_due and results:
        global_result = next((r[1] for r in results if isinstance(r, tuple) and len(r) > 1 and r[0] == 'GLOBAL' and isinstance(r[1], dict)), {})
        if global_result.get('status') == 'master_updated':
            real_state['pending_samples'] = 0
            real_state['last_retrain_at'] = int(time.time())
            real_state['last_retrain_result'] = 'master_updated'
            online_state['pending_samples'] = 0
            online_state['last_retrain_at'] = int(time.time())
            online_state['last_retrain_result'] = 'master_updated'
            write_json(real_path, real_state)
            write_json(online_path, online_state)
            runtime_log(f'AUXILIARY_EXPERIENCE_RETRAIN real_samples={real_pending} online_observations={online_pending} result=master_updated')
    return results


def _prediction_map(ids):
    wanted=set(ids)
    found={}
    if not wanted:
        return found
    for path in ROOT.joinpath('logs').glob('*_predictions.json'):
        try:
            rows=json.loads(path.read_text(encoding='utf-8'))
        except Exception:
            continue
        for row in rows:
            if row.get('id') in wanted:
                found[row['id']]=row
    return found


def _sleep_or_stop(seconds, cancel_event):
    end=time.monotonic()+seconds
    while time.monotonic()<end:
        if stopped():
            cancel_event.set(); return False
        time.sleep(min(2.0, max(0.1,end-time.monotonic())))
    return True


def process_manual_request(cfg, request):
    """Run one user-requested coin prediction in an isolated engine.

    It deliberately uses a separate exchange/engine instance, so it does not
    change the coin currently being scanned by the automatic market worker.
    Model files are replaced atomically by ModelManager, making a concurrent
    read safe while automatic retraining is happening.
    """
    req_id=str(request.get('request_id',''))
    symbol=str(request.get('symbol','')).strip().upper()
    if not req_id or not symbol:
        raise ValueError('Пустой запрос ручного прогноза')
    ex=KuCoin(symbol)
    ex._request_gap=max(float(getattr(ex,'_request_gap',0.10)),0.20)
    eng=LearningEngine(ROOT,ex,cfg)
    eng.set_symbol(ex.futures_symbol)
    if not eng.mm.has_champion():
        eng.train_from_fresh()
    row=eng.predict_and_store(manual=True,source='manual')
    row['request_id']=req_id
    return row


def manual_worker_loop(cfg, heartbeat_state=None):
    active=False
    while True:
        if stopped(): return
        try:
            if MANUAL_REQUEST.exists() and not active:
                req=read_json(MANUAL_REQUEST,{})
                if req:
                    try: MANUAL_REQUEST.unlink()
                    except Exception: pass
                    active=True
                    set_state(manual_prediction_active=True, manual_prediction_result={'request_id':req.get('request_id'),'symbol':req.get('symbol'),'started_at':int(time.time())})
                    try:
                        result=process_manual_request(cfg,req)
                        set_state(manual_prediction_active=False, manual_prediction_result={'request_id':req.get('request_id'),'symbol':req.get('symbol'),'prediction':result,'completed_at':int(time.time())})
                    except Exception as exc:
                        set_state(manual_prediction_active=False, manual_prediction_result={'request_id':req.get('request_id'),'symbol':req.get('symbol'),'error':str(exc),'completed_at':int(time.time())})
                    active=False
        except Exception as exc:
            set_state(manual_prediction_active=False, manual_prediction_error=str(exc))
            active=False
        time.sleep(1.0)


def _monitor_metrics(ex, symbol):
    """Live snapshot for position tracking, alerts, and risk-model learning."""
    ex.set_symbol(symbol)
    candles = ex.candles('5min', limit=80)
    close = float(candles['close'][-1])
    volume = float(candles['volume'][-1])
    prev_volume = float(candles['volume'][-2]) if len(candles['volume']) >= 2 else 0.0
    prev_close = float(candles['close'][-2]) if len(candles['close']) >= 2 else close
    book = float(ex.orderbook_imbalance())
    rsi = macd = atrpct = trend = volz = ret3 = 0.0
    risk_features = {}
    try:
        from core.features import add_features
        from core.position_learning import RISK_FEATURES
        x = add_features(candles)
        i = len(x['time']) - 1
        rsi = float(x['rsi'][i]); macd = float(x['macd'][i]); atrpct = float(x['atrpct'][i])
        trend = float(x['trend'][i]); volz = float(x['volz'][i]); ret3 = float(x['ret3'][i])
        for name in RISK_FEATURES:
            if name in x:
                value = float(x[name][i])
                risk_features[name] = value if value == value and abs(value) != float('inf') else 0.0
    except Exception:
        pass
    price_delta = ((close / prev_close) - 1.0) * 100.0 if prev_close else 0.0
    risk_features['book_imbalance'] = book
    risk_features['price_change_pct_from_prev_5m'] = price_delta
    return {
        'time': int(time.time()), 'price': close, 'volume_5m': volume,
        'prev_volume_5m': prev_volume, 'price_change_pct_from_prev_5m': price_delta,
        'orderbook_imbalance': book, 'rsi': rsi, 'macd': macd, 'atrpct': atrpct,
        'trend': trend, 'volz': volz, 'ret3': ret3, 'risk_features': risk_features,
    }


def _monitor_alerts(prev, cur, prediction, cfg, position=None, risk_result=None):
    alerts = []
    position = position if isinstance(position, dict) else {}
    direction = str(position.get('direction') or prediction.get('prediction', 'WAIT')).upper()
    if prev:
        p0 = float(prev.get('price', cur['price']) or cur['price']); p1 = float(cur['price'])
        price_delta = (p1 / p0 - 1.0) * 100.0 if p0 else 0.0
        v0 = float(prev.get('volume_5m', 0.0) or 0.0); v1 = float(cur.get('volume_5m', 0.0) or 0.0)
        vol_pct = ((v1 / v0) - 1.0) * 100.0 if v0 > 0 else 0.0
        b0 = float(prev.get('orderbook_imbalance', 0.0) or 0.0); b1 = float(cur.get('orderbook_imbalance', 0.0) or 0.0)
        bdelta = b1 - b0
        vol_thr = float(cfg.get('monitor_volume_change_pct', 50.0)); price_thr = float(cfg.get('monitor_price_change_pct', 0.20)); book_thr = float(cfg.get('monitor_orderbook_change', 0.20))
        if abs(vol_pct) >= vol_thr:
            alerts.append({'type':'volume_change','severity':'high' if abs(vol_pct)>=vol_thr*2 else 'medium','message':f'Изменился объём 5m: {vol_pct:+.0f}%','value':vol_pct})
        if abs(price_delta) >= price_thr:
            aligned=(direction=='LONG' and price_delta>0) or (direction=='SHORT' and price_delta<0)
            alerts.append({'type':'price_acceleration','severity':'high' if aligned else 'medium','message':f'Цена изменилась: {price_delta:+.2f}%','value':price_delta})
        if abs(bdelta) >= book_thr:
            aligned=(direction=='LONG' and bdelta>0) or (direction=='SHORT' and bdelta<0)
            alerts.append({'type':'orderbook_shift','severity':'high' if not aligned else 'medium','message':f'Изменилось давление в стакане: {bdelta:+.2f}','value':bdelta})
        prev_rsi=float(prev.get('rsi',cur.get('rsi',50.0)) or 50.0); rsi=float(cur.get('rsi',50.0) or 50.0)
        prev_macd=float(prev.get('macd',cur.get('macd',0.0)) or 0.0); macd=float(cur.get('macd',0.0) or 0.0)
        weakening=(direction=='LONG' and rsi < prev_rsi and macd < prev_macd) or (direction=='SHORT' and rsi > prev_rsi and macd > prev_macd)
        if weakening:
            alerts.append({'type':'momentum_weakening','severity':'high','message':'⚠️ Импульс ослабевает: RSI и MACD движутся против реальной позиции. Возможен разворот/откат.','value':1})
        if len(alerts)>=2:
            adverse=(direction=='LONG' and price_delta<0 and bdelta<0) or (direction=='SHORT' and price_delta>0 and bdelta>0)
            if adverse:
                alerts.append({'type':'possible_reversal','severity':'high','message':'⚠️ Цена и давление в стакане движутся против позиции одновременно с другими неблагоприятными признаками. Возможен разворот.','value':1})
    if position.get('status') == 'OPEN':
        move = float(position.get('unrealized_move_pct', 0.0) or 0.0)
        adverse_signals = any(a.get('type') in ('possible_reversal', 'momentum_weakening') for a in alerts)
        if adverse_signals:
            advice = ('Рассмотри защиту прибыли или перенос стопа к безубытку по своему плану.' if move > 0
                      else 'Проверь исходный стоп и риск позиции; рассмотри выход по своему торговому плану.')
            alerts.append({'type':'position_action_advice','severity':'high',
                           'message':'🧭 Рекомендация помощника: обнаружены признаки ослабления/разворота. ' + advice})
        if isinstance(risk_result, dict) and risk_result.get('ready'):
            probability = float(risk_result.get('probability', 0.0) or 0.0)
            threshold = float(cfg.get('position_risk_alert_threshold', 0.65))
            if probability >= threshold:
                if move > 0:
                    advice = 'Рассмотри защиту прибыли или перенос стопа к безубытку по своему плану.'
                else:
                    advice = 'Проверь исходный стоп и риск позиции; рассмотри выход по своему торговому плану.'
                alerts.append({'type':'learned_position_risk','severity':'high' if probability >= 0.80 else 'medium',
                               'value':probability, 'training_rows':int(risk_result.get('training_rows', 0) or 0),
                               'message':f'⚠️ Индекс риска по обученной модели: {probability*100:.0f}/100 (по {int(risk_result.get("training_rows",0) or 0)} обучающим примерам). {advice}'})
    return alerts


def _append_real_position(position, prediction, status='CLOSED'):
    """Persist manual real-position results separately from model prediction statistics."""
    try:
        rows=read_json(REAL_POSITIONS,[])
        if not isinstance(rows,list): rows=[]
        item=dict(position or {})
        item['status']=status
        item['prediction_id']=(prediction or {}).get('id')
        item['symbol']=(prediction or {}).get('symbol')
        item['prediction']= (prediction or {}).get('prediction')
        item['recorded_at']=int(time.time())
        rows.append(item)
        write_json(REAL_POSITIONS,rows[-1000:])
    except Exception:
        pass


def _append_monitor_event(prediction_id, event):
    try:
        path=MONITOR_EVENTS / f'{prediction_id}_events.json'; rows=read_json(path,[])
        if not isinstance(rows,list): rows=[]
        rows.append(event)
        try: max_events=int(read_json(ROOT/'settings.json',{}).get('monitor_max_events_per_prediction',500))
        except Exception: max_events=500
        write_json(path,rows[-max_events:])
    except Exception: pass


def prediction_monitor_loop(cfg, cancel_event):
    """Monitor selected signal and, after VOIN, the user's real position."""
    last={}; last_alert_at=0.0
    while not cancel_event.is_set() and not stopped():
        try:
            req=read_json(MONITOR_REQUEST,{})
            if req:
                try: MONITOR_REQUEST.unlink()
                except Exception: pass
                action=str(req.get('action','')).lower()
                if action=='stop':
                    set_state(monitor={'active':False,'prediction':None,'position':None,'alerts':[],'message':'Мониторинг остановлен.'}); last={}; continue
                if action=='start':
                    prediction=dict(req.get('prediction') or {})
                    if prediction.get('id') and prediction.get('contract'):
                        set_state(monitor={'active':True,'prediction':prediction,'position':None,'alerts':[],'started_at':int(time.time()),'last_check_at':0,'message':f'Наблюдение за {prediction.get("symbol",prediction.get("contract"))} запущено.'}); last={}; last_alert_at=0.0
                if action=='start_position':
                    prediction=dict(req.get('prediction') or {}); pos=dict(req.get('position') or {})
                    if prediction.get('id') and prediction.get('contract') and float(pos.get('entry_price',0) or 0)>0:
                        pos['status']='OPEN'; pos['started_at']=int(time.time())
                        pos['position_id'] = str(pos.get('position_id') or uuid.uuid4().hex)
                        pos['contract'] = str(prediction.get('contract') or prediction.get('exchange_symbol') or '')
                        pos['observations'] = list(pos.get('observations') or [])
                        set_state(monitor={'active':True,'prediction':prediction,'position':pos,'alerts':[],'started_at':int(time.time()),'last_check_at':0,'message':f'Позиция {prediction.get("symbol",prediction.get("contract"))} открыта.'}); last={}; last_alert_at=0.0
                if action=='close_position':
                    state=read_json(STATE,{ }); mon=dict(state.get('monitor') or {}); pos=dict(mon.get('position') or {})
                    if pos.get('status')=='OPEN' and float(req.get('exit_price',0) or 0)>0:
                        pos['exit_price']=float(req['exit_price']); pos['closed_at']=int(time.time()); pos['status']='CLOSED'
                        direction=str(pos.get('direction') or (mon.get('prediction') or {}).get('prediction') or 'LONG').upper()
                        entry=float(pos.get('entry_price')); exitp=float(pos.get('exit_price'))
                        pnl_pct=((exitp/entry)-1)*100 if direction=='LONG' else ((entry/exitp)-1)*100
                        pos['realized_move_pct']=pnl_pct
                        lev=max(1.0,float(pos.get('leverage',1) or 1))
                        pos['realized_leveraged_move_pct']=pnl_pct*lev
                        try:
                            from core.exchange import KuCoin
                            from core.engine import LearningEngine, _ENGINE_FILE_LOCK
                            contract = str(pos.get('contract') or (mon.get('prediction') or {}).get('contract') or (mon.get('prediction') or {}).get('exchange_symbol') or '')
                            if contract:
                                with _ENGINE_FILE_LOCK:
                                    learner = LearningEngine(ROOT, KuCoin(contract), dict(cfg))
                                    learner.set_symbol(contract)
                                    pos['main_model_learning'] = learner.append_real_position_experience(pos, mon.get('prediction') or {}, cfg)
                            else:
                                pos['main_model_learning'] = {'status': 'missing_contract', 'new_samples': 0}
                        except Exception as learning_exc:
                            pos['main_model_learning'] = {'status': 'error', 'error': str(learning_exc)[:240]}
                        try:
                            from core.position_learning import finalize_position
                            pos['risk_model_learning'] = finalize_position(ROOT, pos, cfg)
                        except Exception as learning_exc:
                            pos['risk_model_learning'] = {'status': 'error', 'error': str(learning_exc)[:240]}
                        pos['observation_count'] = len(pos.get('observations') or [])
                        pos.pop('observations', None)
                        _append_monitor_event(str((mon.get('prediction') or {}).get('id','position')), {'type':'position_closed','time':int(time.time()),'position':pos,'prediction':mon.get('prediction')})
                        _append_real_position(pos, mon.get('prediction') or {}, status='CLOSED')
                        mon['position']=pos; mon['message']=f'Позиция закрыта по фактической цене {exitp:.10g}. Результат движения: {pnl_pct:+.2f}%'; set_state(monitor=mon)
            state=read_json(STATE,{}); mon=state.get('monitor') or {}
            if not mon.get('active'):
                cancel_event.wait(1); continue
            prediction=dict(mon.get('prediction') or {}); symbol=prediction.get('contract') or prediction.get('exchange_symbol')
            if not symbol: cancel_event.wait(1); continue
            ex=KuCoin(symbol); ex._request_gap=max(float(getattr(ex,'_request_gap',0.10)),0.20)
            cur=_monitor_metrics(ex,symbol)
            position=dict(mon.get('position') or {}); direction=str(position.get('direction') or prediction.get('prediction') or 'WAIT').upper()
            risk_result = None
            if position.get('status')=='OPEN':
                ep=float(position.get('entry_price',0) or 0); px=float(cur['price'])
                move=((px/ep)-1)*100 if ep and direction=='LONG' else ((ep/px)-1)*100 if ep and direction=='SHORT' and px else 0.0
                position['current_price']=px; position['unrealized_move_pct']=move; position['last_metrics']=cur
                # Keep full model context, replacing same-timeframe features with live values.
                snapshot_features = dict(prediction.get('features') or {})
                snapshot_features.update(cur.get('risk_features') or {})
                observations = list(position.get('observations') or [])
                last_observation = observations[-1] if observations else None
                sample_interval = max(20, int(cfg.get('position_learning_snapshot_seconds', 60)))
                price_change_threshold = float(cfg.get('position_learning_snapshot_price_change_pct', 0.10))
                time_due = not last_observation or int(cur['time']) - int(last_observation.get('time', 0) or 0) >= sample_interval
                try:
                    prior_snapshot_price = float(last_observation.get('price', px)) if last_observation else px
                    move_due = prior_snapshot_price > 0 and abs(px / prior_snapshot_price - 1.0) * 100.0 >= price_change_threshold
                except Exception:
                    move_due = False
                if not last_observation or time_due or move_due:
                    observations.append({'time':int(cur['time']), 'price':px, 'features':snapshot_features,
                                         'risk_features':dict(cur.get('risk_features') or {}), 'atrpct':float(cur.get('atrpct',0.0) or 0.0)})
                    position['last_learning_snapshot_at'] = int(cur['time'])
                position['observations'] = observations[-500:]
                try:
                    from core.position_learning import predict_risk
                    risk_result = predict_risk(ROOT, cur.get('risk_features') or {})
                except Exception:
                    risk_result = {'ready':False,'probability':None,'training_rows':0}
                tp3=float(prediction.get('tp3') or 0); reached_tp3=(direction=='LONG' and px>=tp3) or (direction=='SHORT' and px<=tp3) if tp3 else False
                if reached_tp3:
                    position['tp3_reached_at']=position.get('tp3_reached_at') or int(time.time())
                    ext=((px/tp3)-1)*100 if direction=='LONG' else ((tp3/px)-1)*100
                    position['max_extension_beyond_tp3_pct']=max(float(position.get('max_extension_beyond_tp3_pct',0) or 0),ext)
                    position['post_tp3_learning']=True
            alerts = _monitor_alerts(last,cur,prediction,cfg,position,risk_result) if last or (position.get('status')=='OPEN' and risk_result and risk_result.get('ready') and risk_result.get('probability',0)>=float(cfg.get('position_risk_alert_threshold',0.65))) else []
            if position.get('status')=='OPEN' and risk_result:
                position['risk_assessment'] = risk_result
            if position.get('status')=='OPEN' and alerts and (time.time()-last_alert_at)>=float(cfg.get('monitor_alert_cooldown_seconds',60)):
                for a in alerts:
                    _append_monitor_event(str(prediction.get('id')), {'type':'alert','time':int(time.time()),'prediction_id':prediction.get('id'),'position':{k:v for k,v in position.items() if k!='observations'},'before':last,'after':cur,'alert':a})
                last_alert_at=time.time()
            mon=dict(mon); mon.update({'active':True,'prediction':prediction,'position':position or None,'last_check_at':int(time.time()),'metrics':cur,'risk_assessment':risk_result,'alerts':alerts,'alerted_at':int(last_alert_at) if last_alert_at else 0,'message':alerts[-1]['message'] if alerts else ('Позиция контролируется. Существенных изменений не обнаружено.' if position.get('status')=='OPEN' else 'Существенных изменений не обнаружено.')})
            set_state(monitor=mon); last=cur
        except Exception as exc:
            state=read_json(STATE,{}); mon=dict(state.get('monitor') or {}); mon.update({'active':bool(mon.get('prediction')),'alerts':[],'message':'Ошибка мониторинга: '+str(exc)}); set_state(monitor=mon)
        try: delay=max(5,int(cfg.get('monitor_poll_seconds',20)))
        except Exception: delay=20
        cancel_event.wait(delay)


def recheck_active_forecasts(cfg, skip_contracts=None, cancel_event=None, cycle=None):
    """Re-run the model for every active forecast contract, independent of TOP-5.

    This is an observation pass only. It records the current model signal, price,
    probabilities and features against the original active lifecycle; it never
    creates a new lifecycle and never closes the original forecast. TP/SL outcome
    resolution remains handled separately by resolve_all_pending().
    """
    from core.exchange import KuCoin
    from core.engine import LearningEngine

    logs = ROOT / 'logs'
    skipped = {str(x).upper().replace('-', '').strip() for x in (skip_contracts or set())}
    active_contracts = {}
    for path in sorted(logs.glob('*_predictions.json')):
        contract = path.name[:-len('_predictions.json')].upper().replace('-', '').strip()
        if not contract:
            continue
        try:
            rows = json.loads(path.read_text(encoding='utf-8'))
        except Exception:
            continue
        if not isinstance(rows, list):
            continue
        active = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            signal = str(row.get('prediction', 'WAIT')).upper()
            if signal not in ('LONG', 'SHORT', 'WAIT'):
                continue
            if row.get('resolved') or row.get('state_lifecycle_closed') or row.get('merged_into_prediction_id'):
                continue
            if signal == 'WAIT' and row.get('wait_learning_resolved'):
                continue
            row_contract = str(row.get('contract') or row.get('exchange_symbol') or contract).upper().replace('-', '').strip()
            if row_contract.endswith('USDT') and not row_contract.endswith('USDTM'):
                row_contract += 'M'
            if row_contract != contract:
                continue
            active.append(row)
        if active and contract not in skipped:
            active.sort(key=lambda x: (int(x.get('time', 0) or 0), str(x.get('id', ''))))
            active_contracts[contract] = active[0]

    stats = {'active_contracts': len(active_contracts), 'checked': 0, 'observations_saved': 0, 'skipped': 0, 'errors': []}
    if not active_contracts:
        return stats

    # Keep network/model concurrency bounded for Android and KuCoin rate limits.
    from concurrent.futures import ThreadPoolExecutor, as_completed
    workers = max(1, min(2, int(cfg.get('scan_model_workers', 2) or 2)))

    def one(contract, active_row):
        if cancel_event is not None and cancel_event.is_set():
            return contract, 'cancelled', None
        ex = KuCoin(contract)
        ex._request_gap = max(float(getattr(ex, '_request_gap', 0.10)), float(cfg.get('scan_model_request_gap', 0.20)))
        eng = LearningEngine(ROOT, ex, dict(cfg))
        eng.set_symbol(contract)
        # A background observation must never launch a fresh training run merely
        # because a model file is missing; report it and keep the original forecast.
        if not eng.mm.has_champion():
            return contract, 'no_model', None
        row = eng._scan_train_and_predict({'contract': contract, 'display': active_row.get('symbol') or ex.display_symbol(contract),
                                           'turnover': active_row.get('turnover24h', 0.0)},
                                          int(cfg.get('active_recheck_history', 800)), run_id=cycle)
        row['source'] = 'active_forecast_recheck'
        row['observation_kind'] = 'MODEL_DIRECTION_RECHECK'
        saved = eng.persist_scan_predictions([row], allow_new_lifecycle=False)
        return contract, 'saved' if saved else 'no_active_lifecycle', saved[0] if saved else None

    with ThreadPoolExecutor(max_workers=workers, thread_name_prefix='active-recheck') as pool:
        futures = {pool.submit(one, contract, row): contract for contract, row in active_contracts.items()}
        for future in as_completed(futures):
            if cancel_event is not None and cancel_event.is_set():
                break
            contract = futures[future]
            try:
                _, status, _ = future.result()
                if status == 'saved':
                    stats['checked'] += 1
                    stats['observations_saved'] += 1
                elif status == 'cancelled':
                    stats['skipped'] += 1
                elif status == 'no_model':
                    stats['skipped'] += 1
                    stats['errors'].append({'contract': contract, 'error': 'no_champion_model'})
                else:
                    stats['skipped'] += 1
            except Exception as exc:
                stats['errors'].append({'contract': contract, 'error': str(exc)[:240]})
    return stats

def main():
    wake_lock = None
    runtime_log('SERVICE ENTRY: scanner.py main() called')
    cancel_event = threading.Event()
    heartbeat_stop = threading.Event()
    instance_id = str(uuid.uuid4())
    lock_acquired = False
    try:
        # Mark the service alive BEFORE importing the heavy trading stack.
        # On a cold Android start numpy/Kivy/Python imports can take several
        # seconds; the UI must not mistake that startup window for a dead service.
        try:
            runtime_log('PHASE: importing PythonService')
            from jnius import autoclass
            PythonService = autoclass('org.kivy.android.PythonService')
            PythonService.mService.setAutoRestartService(True)
        except Exception as exc:
            runtime_log('PythonService init failed: ' + repr(exc), 'ERROR')
        if not acquire_service_lock(instance_id):
            runtime_log('SERVICE LOCK: another live instance owns the service', 'WARN')
            return
        lock_acquired = True
        runtime_log(f'SERVICE LOCK acquired: {instance_id}')
        ctl=control_data()
        if bool(ctl.get('stop')):
            runtime_log('SERVICE START blocked by user stop flag', 'WARN')
            set_state(status='stopped', running=False, paused=True, done=False,
                      phase='STOPPED', service_alive=False, user_stopped=bool(ctl.get('user_stopped', False)))
            return
        runtime_log('PHASE: publishing STARTING heartbeat')
        set_state(status='starting', running=True, paused=False, done=False, phase='STARTING',
                  service_alive=True, service_instance_id=instance_id,
                  message='Фоновый сервис запущен. Загружаю самообучение.')

        # Keep the heartbeat alive during cold start too. Heavy numpy/engine
        # initialization can take long enough on Android that a one-time
        # startup heartbeat becomes stale and the UI incorrectly declares the
        # service dead. The heartbeat must start before heavy imports.
        def heartbeat_loop():
            while not heartbeat_stop.wait(HEARTBEAT_SECONDS):
                try:
                    current = read_json(STATE, {})
                    set_state(service_alive=True, service_instance_id=instance_id,
                              phase=current.get('phase', 'STARTING'))
                except Exception:
                    pass

        heartbeat_thread=threading.Thread(target=heartbeat_loop, daemon=True, name='service-heartbeat')
        heartbeat_thread.start()
        runtime_log('HEARTBEAT thread started')

        # Import the application stack only after the service has published a
        # continuously refreshed heartbeat. If an import fails, the exception
        # is written to state below instead of leaving the UI with a generic
        # "service did not start".
        runtime_log('PHASE: importing trading stack')
        from core.config import load
        runtime_log('IMPORT OK: core.config')
        from core.engine import LearningEngine
        runtime_log('IMPORT OK: core.engine')
        from core.exchange import KuCoin
        runtime_log('IMPORT OK: core.exchange')
        cfg_path = Path(__file__).resolve().parent.parent / 'config.json'
        cfg = load(cfg_path)
        settings = ROOT / 'settings.json'
        if settings.exists():
            try: cfg.update(json.loads(settings.read_text(encoding='utf-8')))
            except Exception: pass

        set_state(status='starting', running=True, paused=False, done=False, phase='STARTING',
                  service_alive=True, service_instance_id=instance_id,
                  message='Фоновый сервис запущен. Подготавливаю самообучение.')
        runtime_log('PHASE: creating KuCoin client')
        exchange=KuCoin(cfg['symbol'])
        runtime_log('KuCoin client created')
        runtime_log('PHASE: creating LearningEngine')
        engine=LearningEngine(ROOT, exchange, cfg)
        runtime_log('LearningEngine created')
        wake_lock=acquire_wakelock()
        runtime_log('WakeLock: ' + ('ACQUIRED' if wake_lock is not None else 'UNAVAILABLE'), 'INFO' if wake_lock is not None else 'WARN')
        session_id=int(ctl.get('run_id',0) or int(time.time()))
        state=read_json(STATE,{})
        def heartbeat_loop():
            while not heartbeat_stop.wait(HEARTBEAT_SECONDS):
                set_state(service_alive=True, service_instance_id=instance_id, phase=read_json(STATE,{}).get('phase','RUNNING'))
        manual_thread=threading.Thread(target=manual_worker_loop,args=(cfg,),daemon=True,name='manual-predict')
        manual_thread.start()
        monitor_thread=threading.Thread(target=prediction_monitor_loop,args=(cfg,cancel_event),daemon=True,name='prediction-monitor')
        monitor_thread.start()
        cycle=int(state.get('cycle',0) or 0)
        runtime_log('PHASE: entering RUNNING loop')
        set_state(status='running', running=True, paused=False, done=False, phase='LEARN',
                  session_id=session_id, cycle=cycle, total=0, done_count=0, rows=[], errors=0,
                  learning='continuous', service_alive=True, service_instance_id=instance_id,
                  message='Проверяю старые прогнозы и обновляю модели.')

        while not stopped():
            # First resolve everything that has become testable and learn from
            # both successful and failed predictions. This runs even when the
            # model is already ready, so the readiness score stays current.
            resolved=engine.resolve_all_pending()
            resolved_contracts=[x.get('contract') or x.get('exchange_symbol') for x in resolved if x.get('contract') or x.get('exchange_symbol')]
            # Results are recorded immediately, but model retraining is deliberately
            # batched. One anomalous prediction must not immediately rewrite the model.
            global_resolved=engine.global_stats().get('learning_ready',engine.global_stats().get('resolved',0))
            retrained=_retrain_with_real_position_batch(engine, resolved_contracts, global_resolved)
            readiness=engine.readiness()
            ctl=control_data()
            prediction_request=bool(ctl.get('prediction_request'))

            # Automatic scanning is cadence-driven, not signal-count-driven.
            # Once the service is started, a full market scan is performed on a
            # fixed 30-minute cadence. Readiness no longer switches the service
            # into an idle state; it only describes the current learning state.
            if readiness.get('ready') and prediction_request:
                # Manual request is still accepted, but the regular cadence
                # remains the source of truth for subsequent scans.
                ctl['prediction_request']=False
                write_json(CONTROL,ctl)

            if wake_lock is None:
                wake_lock=acquire_wakelock()
            runtime_log('WakeLock: ' + ('ACQUIRED' if wake_lock is not None else 'UNAVAILABLE'), 'INFO' if wake_lock is not None else 'WARN')
            cycle += 1
            scan_started_at = time.time()
            scan_interval = max(300, int(engine.cfg.get('scan_interval_seconds', DEFAULT_SCAN_INTERVAL_SECONDS)))
            # Start a new market cycle, but preserve the latest TOP-5 in service state
            # so the UI never loses the last real predictions while the next scan runs.
            previous_top5 = list(state.get('last_top5') or [])[:5]
            previous_top5_cycle = int(state.get('last_top5_cycle', 0) or 0)
            set_state(status='running', running=True, paused=False, done=False, phase='PRESCAN', cycle=cycle,
                      resolved_count=len(resolved), retrained_count=len(retrained), readiness=readiness,
                      done_count=0, total=0, name='', row=None, rows=[], prediction_ids=[],
                      last_top5=previous_top5, last_top5_cycle=previous_top5_cycle,
                      quick_count=0, errors=0, scan_started_at=int(scan_started_at),
                      scan_interval_seconds=scan_interval, next_scan_at=int(scan_started_at + scan_interval),
                      message=('Получена команда. Начинаю полный проход рынка для нового TOP-5.' if prediction_request
                               else 'Начинаю новый полный проход рынка для следующего TOP-5.'))

            def progress(done,total,name,row,err,phase='PRESCAN'):
                if stopped(): cancel_event.set()
                current=read_json(STATE,{})
                errors=int(current.get('errors',0) or 0)+(1 if err is not None else 0)
                set_state(status='stopping' if cancel_event.is_set() else 'running',
                          running=not cancel_event.is_set(), paused=cancel_event.is_set(), done=False,
                          phase=phase, done_count=int(done), total=int(total), name=str(name), row=row,
                          errors=errors, cycle=cycle, readiness=readiness)

            rows,total,quick_count,errors,diagnostics=engine.scan_all(progress=progress, cancel_event=cancel_event, run_id=cycle)
            if cancel_event.is_set() or (isinstance(diagnostics,dict) and diagnostics.get('cancelled')) or stopped():
                set_state(status='stopped', running=False, paused=True, done=False, phase='STOPPED',
                          total=int(total), quick_count=int(quick_count), errors=int(errors),
                          diagnostics=diagnostics or {}, rows=[], cycle=cycle, readiness=engine.readiness())
                break

            unique={r.get('contract'):r for r in rows if r.get('contract')}
            rows=list(unique.values())[:5]
            # TOP-5 is a maximum, not a requirement to manufacture WAIT rows.
            # If the full market pass finds only 1-4 real LONG/SHORT
            # opportunities, verify those real predictions without padding the
            # list. Verification is asynchronous and does not block new scans.
            if not rows:
                # Even when TOP-5 is empty, re-evaluate every existing active forecast.
                active_recheck = recheck_active_forecasts(cfg, skip_contracts=set(), cancel_event=cancel_event, cycle=cycle)
                runtime_log(f'ACTIVE_FORECAST_RECHECK cycle={cycle} stats={json.dumps(active_recheck, ensure_ascii=False)}')
                diag=dict(diagnostics or {})
                diag['active_forecast_recheck'] = active_recheck
                diag['no_trade_candidates']=True
                diag['valid_predictions']=0
                set_state(status='running', running=True, paused=False, done=False,
                          phase='NO_CANDIDATES', cycle=cycle, total=int(total),
                          quick_count=int(quick_count), errors=int(errors),
                          diagnostics=diag, rows=[], prediction_ids=[],
                          readiness=engine.readiness(),
                          message='Полный проход завершён: торговых LONG/SHORT кандидатов нет. Жду следующий цикл.')
                # No trade candidates do not reset the cadence. The next full
                # scan is still scheduled 30 minutes from this scan start.
                next_scan_at = scan_started_at + scan_interval
                while not stopped() and not cancel_event.is_set() and time.time() < next_scan_at:
                    remaining=max(1,int(next_scan_at-time.time()))
                    set_state(status='running', running=True, paused=False, done=False, phase='WAIT_NEXT_SCAN',
                              cycle=cycle, next_scan_in=remaining, next_scan_at=int(next_scan_at),
                              readiness=engine.readiness(),
                              message=f'Следующее полное сканирование через {remaining} сек. (фиксированный интервал 30 минут).')
                    if not _sleep_or_stop(min(20,remaining),cancel_event): break
                continue

            # TOP-5 scan rows must be persisted in the canonical prediction/pending logs.
            # Otherwise they can remain visible as "Проверяется" forever while global
            # statistics only count manually stored forecasts.
            try:
                persisted_rows = engine.persist_scan_predictions(rows)
            except Exception as exc:
                runtime_log(f'SCAN_PERSISTENCE_ERROR cycle={cycle}: {exc}', 'ERROR')
                persisted_rows = []
                diagnostics = dict(diagnostics or {}, persistence_error=str(exc))
            if len(persisted_rows) != len(rows):
                # Do not display a TOP-5 as successfully persisted when any
                # contract failed lifecycle reconciliation.
                set_state(status='running', running=True, paused=False, done=False,
                          phase='PERSISTENCE_ERROR', cycle=cycle, total=int(total),
                          quick_count=int(quick_count), errors=int(errors) + (len(rows) - len(persisted_rows)),
                          diagnostics=dict(diagnostics or {}, persistence_expected=len(rows), persistence_saved=len(persisted_rows)),
                          rows=persisted_rows, prediction_ids=[r.get('id') for r in persisted_rows if r.get('id')],
                          readiness=engine.readiness(),
                          message=f'Ошибка сохранения жизненного цикла прогнозов: сохранено {len(persisted_rows)} из {len(rows)}. Неподтверждённые строки не выдаются как сохранённые.')
                # Retry on the next fixed scan; don't falsely report these rows
                # as persisted and don't create an alternate ad-hoc lifecycle.
                next_scan_at = scan_started_at + scan_interval
                while not stopped() and not cancel_event.is_set() and time.time() < next_scan_at:
                    remaining=max(1,int(next_scan_at-time.time()))
                    set_state(status='running', running=True, paused=False, done=False, phase='WAIT_NEXT_SCAN',
                              cycle=cycle, next_scan_in=remaining, next_scan_at=int(next_scan_at),
                              readiness=engine.readiness(),
                              message=f'Ошибка сохранения прогнозов. Повторный полный скан через {remaining} сек.')
                    if not _sleep_or_stop(min(20,remaining),cancel_event): break
                continue
            rows = persisted_rows
            prediction_ids=[r.get('id') for r in rows if r.get('id')]
            # Re-run the model for active forecasts outside this cycle's TOP-5 too.
            # TOP-5 contracts already got a fresh model output in scan_all; all other
            # active contracts receive an independent observation pass here.
            active_recheck = recheck_active_forecasts(
                cfg, skip_contracts={r.get('contract') or r.get('exchange_symbol') for r in rows},
                cancel_event=cancel_event, cycle=cycle)
            runtime_log(f'ACTIVE_FORECAST_RECHECK cycle={cycle} stats={json.dumps(active_recheck, ensure_ascii=False)}')
            # TOP-5 is saved immediately. Verification continues globally in the
            # background; it must NOT block the next full 673-symbol scan. Older
            # predictions remain immutable and are advanced by resolve_all_pending
            # on every pass. This allows new forecasts to be created while older
            # ones are waiting for TP2/TP3.
            top5_started_at=time.time()
            next_scan_at=scan_started_at + scan_interval
            next_scan_remaining=max(0,int(next_scan_at-time.time()))
            set_state(status='running', running=True, paused=False, done=False, phase='VERIFY',
                      cycle=cycle, total=int(total), quick_count=int(quick_count), errors=int(errors),
                      diagnostics=dict(diagnostics or {}, active_forecast_recheck=active_recheck), rows=rows, prediction_ids=prediction_ids,
                      last_top5=rows[:5], last_top5_cycle=cycle, top5_started_at=top5_started_at,
                      scan_started_at=int(scan_started_at), scan_interval_seconds=scan_interval,
                      next_scan_at=int(next_scan_at), next_scan_in=next_scan_remaining,
                      resolved_count=int(engine.global_stats().get('resolved',0) or 0), resolved_total=len(prediction_ids), readiness=engine.readiness(),
                      message=f'TOP-5 сохранён. Следующий полный скан по фиксированному расписанию через {next_scan_remaining} сек. Старые прогнозы продолжают проверяться независимо.')

            # Fixed cadence: the next full market scan is scheduled 30 minutes
            # after this scan STARTED. Previous TOP-5 predictions are not allowed
            # to delay the next scan; they continue through resolve_all_pending()
            # and the long-running verification queue in the background.
            next_scan_at = scan_started_at + scan_interval
            while not cancel_event.is_set() and not stopped() and time.time() < next_scan_at:
                try:
                    resolved_wait=engine.resolve_all_pending()
                    contracts_wait=[x.get('contract') or x.get('exchange_symbol') for x in resolved_wait if x.get('contract') or x.get('exchange_symbol')]
                    total_resolved=engine.global_stats().get('learning_ready',engine.global_stats().get('resolved',0))
                    retrained_wait=_retrain_with_real_position_batch(engine, contracts_wait, total_resolved)
                    readiness_wait=engine.readiness()
                except Exception:
                    resolved_wait=[]; retrained_wait=[]; readiness_wait=engine.readiness()
                remaining_seconds=max(0,int(next_scan_at-time.time()))
                set_state(status='running', running=True, paused=False, done=False, phase='WAIT_NEXT_SCAN',
                          cycle=cycle, total=int(total), quick_count=int(quick_count), errors=int(errors),
                          rows=rows, prediction_ids=prediction_ids, last_top5=rows[:5], last_top5_cycle=cycle,
                          scan_started_at=int(scan_started_at), scan_interval_seconds=scan_interval,
                          next_scan_at=int(next_scan_at), next_scan_in=remaining_seconds,
                          resolved_count=len(resolved_wait),
                          resolved_total=int(engine.global_stats().get('resolved',0) or 0),
                          retrained_count=len(retrained_wait), readiness=readiness_wait,
                          message=(f'Новый полный скан через {remaining_seconds} сек. Фиксированный интервал: 30 минут. '
                                   f'Старые прогнозы продолжают проверяться независимо.'))
                if not _sleep_or_stop(min(20,max(1,remaining_seconds)),cancel_event):
                    break
            if cancel_event.is_set() or stopped():
                break
            # Continue directly into the next fixed-cadence scan.
            continue

        set_state(status='stopped', running=False, paused=True, done=False, phase='STOPPED',
                  service_alive=False, service_instance_id=instance_id)
        if wake_lock is not None:
            try: wake_lock.release()
            except Exception: pass
    except Exception as exc:
        runtime_log('FATAL SERVICE EXCEPTION: ' + repr(exc), 'ERROR')
        runtime_log(traceback.format_exc(), 'ERROR')
        set_state(status='error', running=False, paused=False, done=False, phase='ERROR',
                  service_alive=False, service_instance_id=instance_id, error=str(exc),
                  traceback=traceback.format_exc())
        if wake_lock is not None:
            try: wake_lock.release()
            except Exception: pass
    finally:
        runtime_log('SERVICE EXIT: releasing resources')
        heartbeat_stop.set()
        if lock_acquired:
            release_service_lock(instance_id)


if __name__ == '__main__':
    main()
