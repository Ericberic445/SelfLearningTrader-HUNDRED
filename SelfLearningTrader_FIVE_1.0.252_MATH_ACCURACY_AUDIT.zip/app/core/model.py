from pathlib import Path
import json, time, threading
import numpy as np
from .features import FEATURES, REGIME_FEATURES, REGIME_NAMES


def _timestamp_seconds(value):
    """Normalize one Unix timestamp to seconds; mixed-unit arrays are allowed."""
    try: value=int(value)
    except (TypeError,ValueError,OverflowError): return 0
    magnitude=abs(value)
    if magnitude>=100_000_000_000_000_000: return value//1_000_000_000
    if magnitude>=100_000_000_000_000: return value//1_000_000
    if magnitude>=100_000_000_000: return value//1_000
    return value


def _normalize_times(values):
    return np.asarray([_timestamp_seconds(v) for v in np.asarray(values).reshape(-1)],dtype=np.int64)

NAMES = {0: 'SHORT', 1: 'WAIT', 2: 'LONG'}
OUTCOME_NAMES = {
    0: 'INITIAL_SL',
    1: 'TP1',
    2: 'TP2',
    3: 'TP3',
    4: 'TP3_PLUS',
}
ACTOR_NAMES = {0: 'MASTER', 1: 'C1', 2: 'C2', 3: 'C3'}
COMBINATION_NAMES = {
    0: 'MASTER', 1: 'MASTER+C1', 2: 'MASTER+C2', 3: 'MASTER+C3',
    4: 'MASTER+C1+C2', 5: 'MASTER+C1+C3', 6: 'MASTER+C2+C3', 7: 'MASTER+C1+C2+C3',
}
COMBINATION_KEYS = tuple(COMBINATION_NAMES.values())
# Independent mathematical experts. These are raw outputs already computed by
# math_models.py; composite/risk-only outputs are deliberately separated.
MATH_EXPERT_FIELDS = {
    'MARKOV': 'math_markov',
    'AR': 'math_ar',
    'ARIMA_111': 'math_arima',
    'SARIMA_101_101': 'math_sarima',
    'MEAN_REVERSION': 'math_mean_reversion',
    'COINTEGRATION': 'math_cointegration',
    'TREND_DEVIATION': 'math_trend_deviation',
    'WAVELET_HAAR': 'math_wavelet',
    'KALMAN_TREND': 'math_kalman',
    'BAYESIAN_SIGN': 'math_bayesian',
    'MONTE_CARLO_DIRECTION': 'math_monte_carlo',
    'HURST_TREND_PERSISTENCE': 'math_hurst',
    'BENCHMARK_CORRELATION': 'math_correlation',
    # Composite controls are retained for fair comparison against individual experts.
    'MATH_DIRECTION_BASELINE': 'math_direction',
    'MATH_CONSENSUS_BASELINE': 'math_consensus',
}

MATH_EXPERT_MIN_TRAIN = 50
MATH_EXPERT_VALIDATION = 30
MATH_EXPERT_MIN_LIFT = 0.05
MATH_EXPERT_MIN_DISCORDANT = 12
MATH_EXPERT_MIN_NET_WINS = 4
_REGIME_POOL_LOCK = threading.RLock()


class NumpyClassifier:
\
\
    def _outcome_percentages(self, rows):
        """Calculate current Master probabilities from verified historical outcomes."""
        counts = {"TP1": 0, "TP2": 0, "TP3": 0, "SL": 0, "WAIT_CORRECT": 0,
                  "MISSED_LONG": 0, "MISSED_SHORT": 0}
        total = 0
        for row in rows or []:
            outcome = str((row or {}).get("outcome", (row or {}).get("result", ""))).upper()
            if outcome in counts:
                counts[outcome] += 1
                total += 1
        if not total:
            return {k: 0.0 for k in counts}
        return {k: round(v * 100.0 / total, 2) for k, v in counts.items()}

    def _historical_retraining_policy(self):
        """Return the policy for rebuilding Master from validated historical experience.
        Old model weights are never treated as ground truth. Historical rows are
        revalidated against the current outcome rules before reuse.
        """
        return {
            "reset_old_master_weights": True,
            "reuse_validated_historical_experience": True,
            "revalidate_outcomes_before_training": True,
            "exclude_unverifiable_legacy_rows": True,
            "selector_uses_only_verified_lens_outcomes": True,
        }

    def _record_master_retrain_cycle(self, state=None):
        state = state if isinstance(state, dict) else getattr(self, "state", {})
        n = int(state.get("master_retrain_cycles", 0) or 0) + 1
        state["master_retrain_cycles"] = n
        state["last_master_retrain_cycle"] = n
        return n

    def __init__(self, n_features, n_classes=3):
        self.n_features = n_features
        self.n_classes = n_classes
        self.weights = np.zeros((n_features, n_classes))
        self.bias = np.zeros(n_classes)
        self.means = np.zeros(n_features)
        self.stds = np.ones(n_features)

    def _class_weights(self, y, class_weights=None):
        if class_weights is not None:
            return np.asarray(class_weights, float)
        counts = np.bincount(y, minlength=self.n_classes).astype(float)
        w = np.ones(self.n_classes, float)
        for c in range(self.n_classes):
            if counts[c] > 0:
                w[c] = 1.0 / np.sqrt(counts[c])
        return w * self.n_classes / max(np.sum(w), 1e-12)

    def fit(self, X, y, epochs=300, learning_rate=.02, l2=.0005, class_weights=None, sample_weights=None):
        X = np.asarray(X, float)
        y = np.asarray(y, int)
        X = np.nan_to_num(X, nan=0, posinf=0, neginf=0)
        if sample_weights is not None:
            pre_w = np.asarray(sample_weights, float).reshape(-1)
            if len(pre_w) == len(y):
                keep = np.isfinite(pre_w) & (pre_w > 0)
                if np.any(keep):
                    X, y, sample_weights = X[keep], y[keep], pre_w[keep]
                else:
                    return self
        self.means = np.mean(X, axis=0)
        self.stds = np.std(X, axis=0)
        self.stds[self.stds < 1e-8] = 1
        return self._fit_normalized(X, y, epochs, learning_rate, l2, class_weights, sample_weights)

    def fit_incremental(self, X, y, epochs=120, learning_rate=.008, l2=.0005, sample_weights=None):
        X = np.asarray(X, float)
        y = np.asarray(y, int)
        X = np.nan_to_num(X, nan=0, posinf=0, neginf=0)
        if sample_weights is not None:
            pre_w = np.asarray(sample_weights, float).reshape(-1)
            if len(pre_w) == len(y):
                keep = np.isfinite(pre_w) & (pre_w > 0)
                if np.any(keep):
                    X, y, sample_weights = X[keep], y[keep], pre_w[keep]
                else:
                    return self
        if len(X) == 0:
            return self
        if len(self.means) != self.n_features or not np.all(np.isfinite(self.means)):
            self.means = np.mean(X, axis=0)
            self.stds = np.std(X, axis=0)
            self.stds[self.stds < 1e-8] = 1
        return self._fit_normalized(X, y, epochs, learning_rate, l2, None, sample_weights)

    def _fit_normalized(self, X, y, epochs, learning_rate, l2, class_weights=None, sample_weights=None):
        if len(X) == 0:
            return self
        Z = (X - self.means) / np.where(np.abs(self.stds) < 1e-8, 1, self.stds)
        n = max(1, len(Z))
        Y = np.zeros((len(y), self.n_classes))
        Y[np.arange(len(y)), y] = 1
        w = self._class_weights(y, class_weights)
        sw = np.asarray(sample_weights, float) if sample_weights is not None else np.ones(len(y), float)
        if len(sw) != len(y):
            sw = np.ones(len(y), float)
        # A zero weight must truly exclude an observation; negative/non-finite
        # weights are invalid. Cap only the upper tail, never raise small weights.
        sw = np.nan_to_num(sw, nan=0.0, posinf=0.0, neginf=0.0)
        sw = np.clip(sw, 0.0, 5.0)
        keep = sw > 0.0
        if not np.any(keep):
            return self
        if not np.all(keep):
            Z, Y, y, sw = Z[keep], Y[keep], y[keep], sw[keep]
            n = max(1, len(Z))
            w = self._class_weights(y, class_weights)
        for _ in range(max(1, int(epochs))):
            s = Z @ self.weights + self.bias
            s -= np.max(s, axis=1, keepdims=True)
            p = np.exp(np.clip(s, -50, 50))
            p /= np.sum(p, axis=1, keepdims=True)
            e = (p - Y) * w[np.clip(y, 0, self.n_classes - 1), None] * sw[:, None]
            self.weights -= learning_rate * ((Z.T @ e) / n + l2 * self.weights)
            self.bias -= learning_rate * np.mean(e, axis=0)
        return self

    def predict_proba(self, X):
        X = np.nan_to_num(np.asarray(X, float), nan=0, posinf=0, neginf=0)
        Z = (X - self.means) / np.where(np.abs(self.stds) < 1e-8, 1, self.stds)
        s = Z @ self.weights + self.bias
        s -= np.max(s, axis=1, keepdims=True)
        p = np.exp(np.clip(s, -50, 50))
        return p / np.sum(p, axis=1, keepdims=True)

    def predict(self, X):
        return np.argmax(self.predict_proba(X), axis=1)


class ModelManager:
    """FIVE architecture: one learning Master plus three fixed mathematical lenses.

    The Master has three complementary memories/heads:
      * champion.npz      - direction head (SHORT / WAIT / LONG),
      * outcome_model.npz - trade-outcome head (SL -> TP1 -> TP2 -> TP3+),
      * master_decision.npz - Master-owned selector that learns which actor
        (Master/C1/C2/C3) is more trustworthy in a given market context.

    C1/C2/C3 are deterministic mathematical lenses. They never train, never
    change their own weights, and never keep adaptive reliability state.
    """

    META_CONTEXT = [
        'trend', 'volatility', 'atrpct', 'rsi', 'bbpos', 'volz',
        'trend_15', 'trend_1h', 'trend_4h', 'trend_1d',
        'book_imbalance', 'oi_change', 'funding', 'liquidation_bias'
    ]
    META_NAMES = (
        ['master_p_short', 'master_p_wait', 'master_p_long'] +
        [f'c{i}_p_{side}' for i in (1, 2, 3) for side in ('short', 'wait', 'long')] +
        ['conflict_m_c1', 'conflict_m_c2', 'conflict_m_c3', 'lens_agreement', 'math_consensus'] +
        [f'perf_{a}_{k}' for a in ('master', 'c1', 'c2', 'c3') for k in ('success', 'outcome', 'recovery')] +
        [f'combo_{i}_{k}' for i in range(8) for k in ('success', 'outcome', 'recovery')] +
        META_CONTEXT
    )
    SELECTOR_SCHEMA_VERSION = 4
    MODEL_SCHEMA_VERSION = 2
    OUTCOME_NAMES = OUTCOME_NAMES

    def __init__(self, root, symbol='XBTUSDTM', config=None):
        self.root = Path(root)
        self.models = self.root / 'models_v8_self_learning' / 'GLOBAL'
        self.models.mkdir(parents=True, exist_ok=True)
        self.champion = self.models / 'champion.npz'
        self.meta = self.models / 'champion.json'
        self.outcome_model = self.models / 'outcome_model.npz'
        self.outcome_meta = self.models / 'outcome_model.json'
        self.master_decision = self.models / 'master_decision.npz'
        self.master_decision_meta = self.models / 'master_decision.json'
        self.shared_base = self.models / 'shared_master_base.json'
        self.regime_model = self.models / 'market_regime.npz'
        self.regime_meta = self.models / 'market_regime.json'
        self.regime_pool = self.root / 'data' / 'market_regime_training.npz'
        self.regime_pool.parent.mkdir(parents=True, exist_ok=True)
        self.learning_state = self.models / 'master_learning_state.json'
        self.lens_performance = self.models / 'master_lens_performance.json'
        self.meta_experience = Path(root) / 'data' / 'master_decision_experience.npz'
        self.meta_experience.parent.mkdir(parents=True, exist_ok=True)
        self.config = config or {}
        self.symbol = symbol
        self._math_expert_selector_cache = None

    def _new(self):
        return NumpyClassifier(len(FEATURES), 3)

    def _new_outcome(self):
        return NumpyClassifier(len(FEATURES), 5)

    def _new_decision(self):
        return NumpyClassifier(len(self.META_NAMES), 8)

    def _new_regime(self):
        return NumpyClassifier(len(REGIME_FEATURES), 4)

    def _regime_validation_accepted(self, meta):
        """Do not let a trained regime head affect signals unless holdout beats baseline.

        Accuracy alone can hide a model that almost never identifies trends, so
        the gate also checks balanced accuracy and both directional trend recalls.
        """
        if not isinstance(meta,dict) or meta.get('status')!='ready':
            return False
        try:
            acc=float(meta.get('validation_accuracy'))
            base=float(meta.get('baseline_accuracy'))
            bal=float(meta.get('balanced_accuracy'))
            delta=float(self.config.get('regime_min_accuracy_delta',0.005))
            min_bal=float(self.config.get('regime_min_balanced_accuracy',0.32))
            min_recall=float(self.config.get('regime_min_trend_recall',0.10))
            metrics=meta.get('class_metrics') or {}
            down=float((metrics.get('TREND_DOWN') or {}).get('recall'))
            up=float((metrics.get('TREND_UP') or {}).get('recall'))
            return bool(np.isfinite(acc) and np.isfinite(base) and np.isfinite(bal)
                        and acc >= base + delta and bal >= min_bal
                        and down >= min_recall and up >= min_recall)
        except (TypeError,ValueError,OverflowError):
            return False

    def _sanitize_selector_market_columns(self, X):
        """Apply the same market-feature availability policy to selector replay rows."""
        arr = np.asarray(X, float).copy()
        mode = str(self._read_json(self.meta,{}).get('market_features_mode','neutral'))
        # These values are not available as causally aligned historical series.
        # Never train the selector on live-only book snapshots or liquidation bias.
        for name in ('book_imbalance','liquidation_bias'):
            try: arr[:, self.META_NAMES.index(name)] = 0.0
            except (ValueError, IndexError): pass
        if mode != 'historical_aligned':
            for name in ('oi_change','funding'):
                try: arr[:, self.META_NAMES.index(name)] = 0.0
                except (ValueError, IndexError): pass
        return arr

    def _save(self, path, m):
        path = Path(path)
        tmp = path.with_name(path.name + '.tmp.npz')
        np.savez(tmp, weights=m.weights, bias=m.bias, means=m.means, stds=m.stds)
        tmp.replace(path)

    def _load_path(self, path, kind='direction'):
        if not Path(path).exists():
            return None
        try:
            z = np.load(path)
            if kind == 'outcome':
                m = self._new_outcome()
            elif kind == 'regime':
                m = self._new_regime()
            elif kind == 'selector':
                m = self._new_decision()
            else:
                m = self._new()
            shape = tuple(z['weights'].shape)
            expected = (m.n_features, m.n_classes)
            if shape == expected:
                m.weights = z['weights']; m.bias = z['bias']; m.means = z['means']
                m.stds = np.where(np.abs(z['stds']) < 1e-8, 1, z['stds'])
                return m
            return None
        except Exception:
            return None

    def _read_json(self, path, default):
        try:
            return json.loads(Path(path).read_text(encoding='utf-8')) if Path(path).exists() else default
        except Exception:
            return default

    def _write_json(self, path, obj):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + '.tmp')
        tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')
        tmp.replace(path)

    def _learning_state(self):
        default = {
            'schema_version': self.MODEL_SCHEMA_VERSION,
            'resolved_total': 0,
            'batch_size': 25,
            'lens_activation_resolved': 25,
            'base_version': 0,
        }
        state = self._read_json(self.learning_state, default)
        if not isinstance(state, dict):
            state = dict(default)
        for k, v in default.items():
            state.setdefault(k, v)
        return state

    def update_learning_state(self, resolved_total=None, base_version=None):
        state = self._learning_state()
        if resolved_total is not None:
            state['resolved_total'] = int(resolved_total)
        if base_version is not None:
            state['base_version'] = int(base_version)
        state['schema_version'] = self.MODEL_SCHEMA_VERSION
        state['batch_size'] = int(self.config.get('retrain_batch_size', 25))
        state['lens_activation_resolved'] = int(self.config.get('lens_activation_resolved', 25))
        state['updated'] = int(time.time())
        self._write_json(self.learning_state, state)
        return state

    def _load_lens_performance(self):
        default = {
            'schema_version': 1,
            'actors': {
                'master': {'n': 0, 'success': 0, 'outcome_sum': 0.0, 'recovery': 0, 'tp1': 0, 'tp2': 0, 'tp3': 0, 'tp3_plus': 0, 'sl': 0},
                'c1': {'n': 0, 'success': 0, 'outcome_sum': 0.0, 'recovery': 0, 'tp1': 0, 'tp2': 0, 'tp3': 0, 'tp3_plus': 0, 'sl': 0},
                'c2': {'n': 0, 'success': 0, 'outcome_sum': 0.0, 'recovery': 0, 'tp1': 0, 'tp2': 0, 'tp3': 0, 'tp3_plus': 0, 'sl': 0},
                'c3': {'n': 0, 'success': 0, 'outcome_sum': 0.0, 'recovery': 0, 'tp1': 0, 'tp2': 0, 'tp3': 0, 'tp3_plus': 0, 'sl': 0},
            },
            'combinations': {name: {'n': 0, 'success': 0, 'outcome_sum': 0.0, 'recovery': 0, 'tp1': 0, 'tp2': 0, 'tp3': 0, 'tp3_plus': 0, 'sl': 0} for name in COMBINATION_KEYS},
            'updated': 0,
        }
        state = self._read_json(self.lens_performance, default)
        if not isinstance(state, dict):
            state = default
        state.setdefault('actors', {})
        for actor in ('master', 'c1', 'c2', 'c3'):
            q = state['actors'].setdefault(actor, {})
            for k, v in default['actors'][actor].items():
                q.setdefault(k, v)
        state.setdefault('combinations', {})
        for name in COMBINATION_KEYS:
            q = state['combinations'].setdefault(name, {})
            for k, v in default['combinations'][name].items():
                q.setdefault(k, v)
        return state

    def _performance_features(self):
        state = self._load_lens_performance()
        vals = []
        for actor in ('master', 'c1', 'c2', 'c3'):
            q = state['actors'][actor]
            n = float(q.get('n', 0))
            vals.extend([
                float(q.get('success', 0)) / max(1.0, n),
                float(q.get('outcome_sum', 0.0)) / max(1.0, n) / 4.0,
                float(q.get('recovery', 0)) / max(1.0, n),
            ])
        for name in COMBINATION_KEYS:
            q = state['combinations'][name]
            n = float(q.get('n', 0))
            vals.extend([
                float(q.get('success', 0)) / max(1.0, n),
                float(q.get('outcome_sum', 0.0)) / max(1.0, n) / 4.0,
                float(q.get('recovery', 0)) / max(1.0, n),
            ])
        return vals

    def _scores(self, y, p):
        acc = float(np.mean(p == y)) if len(y) else 0.0
        per = []
        for c in range(int(np.max(y) + 1) if len(y) else 0):
            mask = y == c
            per.append(float(np.mean(p[mask] == c)) if np.any(mask) else 0.0)
        bal = float(np.mean(per)) if per else 0.0
        action = (p != 1) if len(p) else np.asarray([], dtype=bool)
        action_count = int(np.sum(action))
        directional_precision = float(np.mean(p[action] == y[action])) if action_count else 0.0
        action_rate = float(np.mean(action)) if len(p) else 0.0
        return acc, bal, per, directional_precision, action_rate

    def generation_info(self):
        state = self._learning_state()
        return {
            'generation': 1,
            'master_resolved_total': int(state.get('resolved_total', 0)),
            'architecture': 'MASTER_FIXED_BASE_PLUS_3_FIXED_LENSES',
            'lenses': ['C1_MARKET_REGIME', 'C2_DIRECTION_ENTRY', 'C3_TP_SL_RISK'],
            'decision_model_ready': self._selector_ready(),
            'outcome_model_ready': self._outcome_ready(),
            'shared_base_present': self.shared_base.exists(),
            'lens_learning_present': False,
            'lens_training_enabled': False,
        }

    def has_champion(self):
        return self.champion.exists() and self._load_path(self.champion, 'direction') is not None

    def _selector_ready(self):
        meta = self._read_json(self.master_decision_meta, {})
        min_validation = max(25, int(self.config.get('master_decision_min_validation_rows', 25)))
        min_delta = float(self.config.get('master_decision_min_accuracy_delta', 0.02))
        try:
            validation_rows = int(meta.get('validation_rows', 0) or 0)
            validation_delta = float(meta.get('validation_accuracy_minus_baseline', -1.0))
        except Exception:
            return False
        return bool(meta.get('schema_version') == self.SELECTOR_SCHEMA_VERSION
                    and self._load_path(self.master_decision, 'selector') is not None
                    and validation_rows >= min_validation
                    and np.isfinite(validation_delta) and validation_delta >= min_delta)

    def _selector_temporal_validation(self, X, y, sample_weights, times):
        """Evaluate selector on later timestamped rows with a horizon-sized purge.

        Legacy selector rows without timestamps may train the model, but they are
        never presented as independent validation evidence.
        """
        X = np.asarray(X, float); y = np.asarray(y, int)
        sw = np.asarray(sample_weights, float); times = _normalize_times(times)
        known = times > 0
        min_test = max(25, int(self.config.get('master_decision_min_validation_rows', 25)))
        if int(np.sum(known)) < min_test * 2:
            return {'status': 'selector_validation_accumulating', 'validation_rows': 0,
                    'timestamped_rows': int(np.sum(known)), 'accuracy': None,
                    'baseline_accuracy': None, 'accuracy_minus_baseline': None}
        unique_times = np.unique(times[known])
        if len(unique_times) < 2:
            return {'status': 'selector_validation_accumulating', 'validation_rows': 0,
                    'timestamped_rows': int(np.sum(known)), 'accuracy': None,
                    'baseline_accuracy': None, 'accuracy_minus_baseline': None}
        cutoff = int(unique_times[min(len(unique_times)-1, max(1, int(len(unique_times) * 0.8)))])
        max_time = int(np.max(unique_times))
        scale = 1_000_000 if max_time >= 100_000_000_000_000 else (1_000 if max_time >= 100_000_000_000 else 1)
        gap = max(0, int(self.config.get('horizon_bars', 12))) * 300 * scale
        train_mask = (times <= 0) | ((times > 0) & (times < cutoff - gap))
        test_mask = times >= cutoff
        if int(np.sum(train_mask)) < 50 or int(np.sum(test_mask)) < min_test:
            return {'status': 'selector_validation_accumulating', 'validation_rows': int(np.sum(test_mask)),
                    'train_rows': int(np.sum(train_mask)), 'timestamped_rows': int(np.sum(known)),
                    'accuracy': None, 'baseline_accuracy': None, 'accuracy_minus_baseline': None,
                    'purge_gap': gap, 'test_start_time': cutoff}
        shadow = self._new_decision()
        shadow.fit(X[train_mask], y[train_mask],
                   epochs=int(self.config.get('master_decision_validation_epochs', 60)),
                   learning_rate=float(self.config.get('master_decision_learning_rate', .01)),
                   l2=float(self.config.get('master_decision_l2', .001)),
                   sample_weights=sw[train_mask])
        pred = shadow.predict(X[test_mask]); truth = y[test_mask]
        accuracy = float(np.mean(pred == truth)) if len(truth) else 0.0
        majority = int(np.bincount(y[train_mask], minlength=self._new_decision().n_classes).argmax())
        baseline = float(np.mean(np.full(len(truth), majority, dtype=int) == truth)) if len(truth) else 0.0
        recalls = [float(np.mean(pred[truth == cls] == cls)) for cls in np.unique(truth)]
        return {'status': 'ok', 'train_rows': int(np.sum(train_mask)),
                'validation_rows': int(np.sum(test_mask)), 'timestamped_rows': int(np.sum(known)),
                'accuracy': accuracy, 'baseline_accuracy': baseline,
                'accuracy_minus_baseline': float(accuracy - baseline),
                'balanced_accuracy': float(np.mean(recalls)) if recalls else 0.0,
                'purge_gap': gap, 'test_start_time': cutoff}

    def _outcome_ready(self):
        meta = self._read_json(self.outcome_meta, {})
        return bool(meta.get('schema_version') == self.MODEL_SCHEMA_VERSION and self._load_path(self.outcome_model, 'outcome') is not None)

    def train(self, x, min_rows=500, test_fraction=.2, horizon_bars=12, gap_bars=None):
        n = len(x['target'])
        if n < min_rows:
            raise ValueError(f'Not enough training rows: {n}. Minimum is {min_rows}.')
        # Do not assume callers have already sorted a merged experience archive.
        # A temporal holdout is only independent when rows are ordered by time.
        order = np.argsort(np.asarray(x.get('time', np.arange(n)), dtype=np.int64), kind='stable')
        X = np.column_stack([np.asarray(x[f], float) for f in FEATURES])[order]
        y = np.asarray(x['target'], int)[order]
        sw_all = np.asarray(x.get('sample_weight', np.ones(n, dtype=float)), float).reshape(-1)
        if len(sw_all) != n:
            sw_all = np.ones(n, dtype=float)
        sw_all = sw_all[order]
        # Chronological holdout with an embargo at least as long as the label
        # horizon, preventing overlapping future-label windows across the split.
        gap = max(int(horizon_bars), int(gap_bars or 0), 0)
        cut = max(1, min(n - 1, int(n * (1 - test_fraction))))
        train_end = cut - gap
        if train_end < max(100, min_rows // 2) or n - cut < 50:
            raise ValueError(f'Insufficient rows after temporal validation gap: total={n}, train={train_end}, gap={gap}, test={n-cut}.')
        trX, teX = X[:train_end], X[cut:]; trY, teY = y[:train_end], y[cut:]
        m = self._new().fit(trX, trY, sample_weights=sw_all[:train_end])
        pred = m.predict(teX)
        acc, bal, per, dp, ar = self._scores(teY, pred)
        # Simple majority-class baseline on the same untouched temporal holdout.
        majority = int(np.bincount(trY, minlength=self._new().n_classes).argmax())
        baseline_pred = np.full(len(teY), majority, dtype=int)
        baseline_accuracy = float(np.mean(baseline_pred == teY)) if len(teY) else 0.0
        _, baseline_balanced_accuracy, _, baseline_directional_precision, baseline_action_rate = self._scores(teY, baseline_pred)
        self._save(self.champion, m)
        stamp = time.strftime('%Y%m%d_%H%M%S')
        meta = {
            'schema_version': self.MODEL_SCHEMA_VERSION,
            'engine': 'numpy_softmax_v10_master_multitask_fixed_lenses',
            'generation': 1,
            'accuracy': acc,
            'balanced_accuracy': bal,
            'class_accuracy': per,
            'directional_precision': dp,
            'action_rate': ar,
            'rows': n,
            'train_rows': train_end,
            'purge_gap_rows': gap,
            'test_start_index': cut,
            'test_rows': len(teY),
            'baseline_accuracy': baseline_accuracy,
            'baseline_balanced_accuracy': baseline_balanced_accuracy,
            'baseline_directional_precision': baseline_directional_precision,
            'baseline_action_rate': baseline_action_rate,
            'accuracy_minus_baseline': float(acc - baseline_accuracy),
            'balanced_accuracy_minus_baseline': float(bal - baseline_balanced_accuracy),
            'created': stamp,
            'feature_count': len(FEATURES),
            'features': FEATURES,
            'accepted': True,
            'status': 'master_direction',
            'learning_type': 'initial_bootstrap',
            'target_note': 'Direction is auxiliary to the trade-outcome head; sample weighting is based on actual TP/SL outcome.',
        }
        self._write_json(self.meta, meta)
        self.update_learning_state(resolved_total=self._learning_state().get('resolved_total', 0), base_version=0)
        return meta

    def reset_learning_models(self):
        """Remove learned model weights while preserving validated experience."""
        for p in (self.champion, self.meta, self.outcome_model, self.outcome_meta,
                  self.master_decision, self.master_decision_meta):
            try:
                if p.exists():
                    p.unlink()
            except Exception:
                pass
        return {"status": "models_reset", "experience_preserved": True}

    def train_outcome_from_scratch(self, experience):
        """Build an outcome candidate only from a temporally purged held-out test."""
        if not experience:
            return {"status": "no_experience"}
        y=np.asarray(experience.get('outcome_target',[]),int).reshape(-1)
        if not len(y): return {"status":"outcome_accumulating","rows":0}
        X=np.column_stack([np.asarray(experience[f],float) for f in FEATURES])
        times=_normalize_times(experience.get('resolved_time',experience.get('time',np.arange(len(y)))))
        sw=np.asarray(experience.get('outcome_sample_weight',np.ones(len(y))),float).reshape(-1)
        valid=(y>=0)&(y<=4)
        if len(times)!=len(y) or len(sw)!=len(y):
            return {"status":"invalid_outcome_archive","rows":int(len(y))}
        X=X[valid]; y=y[valid]; times=times[valid]; sw=sw[valid]
        old=self._load_path(self.outcome_model,'outcome')
        candidate,gate=self._temporal_candidate(X,y,times,sw,'outcome',old_model=old)
        if candidate is None:
            self._write_json(self.outcome_meta,{**self._read_json(self.outcome_meta,{}),
                'status':'validation_accumulating' if gate.get('status','').startswith('validation') else 'promotion_rejected',
                'rows':int(len(y)),'last_promotion_check':gate,'updated':int(time.time()),
                'accuracy':None,'accuracy_note':'No in-sample accuracy is reported as validation quality.'})
            return {"status":"outcome_not_promoted_or_accumulating","rows":int(len(y)),"validation":gate}
        self._save(self.outcome_model,candidate)
        self._write_json(self.outcome_meta,{
            "schema_version":self.MODEL_SCHEMA_VERSION,"status":"ready","rows":int(len(y)),
            "updated":int(time.time()),"learning":"temporal_candidate_promotion","classes":OUTCOME_NAMES,
            "target":"actual_trade_outcome_with_dynamic_protection_and_TP3_plus",
            "last_promotion_check":gate,"accuracy":None,
            "accuracy_note":"Held-out accuracy and balanced accuracy are recorded in last_promotion_check."})
        return {"status":"outcome_candidate_promoted","rows":int(len(y)),"validation":gate}

    def rebuild_selector_from_scratch(self):
        """Rebuild the Master selector from stored actor-outcome evidence."""
        if not self.meta_experience.exists():
            return {"status": "no_selector_experience"}
        try:
            with np.load(self.meta_experience, allow_pickle=False) as z:
                schema = int(np.asarray(z['schema_version']).reshape(-1)[0]) if 'schema_version' in z.files else -1
                if schema != self.SELECTOR_SCHEMA_VERSION:
                    return {"status":"legacy_selector_experience_rejected","rows":0}
                X=np.asarray(z["X"],float); y=np.asarray(z["y"],int)
                X=self._sanitize_selector_market_columns(X)
                sw=np.asarray(z["sample_weight"],float) if "sample_weight" in z.files else np.ones(len(y))
        except Exception:
            return {"status": "no_selector_experience"}
        if len(X) < max(25, int(self.config.get("master_decision_min_rows",50))):
            return {"status":"selector_accumulating","rows":int(len(X))}
        if len(np.unique(y)) < 2:
            return {"status":"selector_accumulating_class_diversity","rows":int(len(X)),
                    "class_count":int(len(np.unique(y)))}
        m=self._new_decision()
        m.fit(X,y,epochs=int(self.config.get("master_decision_epochs",80)),
              learning_rate=float(self.config.get("master_decision_learning_rate",.01)),
              l2=float(self.config.get("master_decision_l2",.001)), sample_weights=sw)
        self._save(self.master_decision,m)
        pred=m.predict(X)
        acc=float(np.mean(pred==y)) if len(y) else 0.0
        counts={ACTOR_NAMES[i]:int(np.sum(y==i)) for i in range(4)}
        self._write_json(self.master_decision_meta,{
            "schema_version":self.SELECTOR_SCHEMA_VERSION,"status":"ready",
            "rows":int(len(X)),"accuracy":acc,"updated":int(time.time()),
            "features":self.META_NAMES,"learning":"clean_reset",
            "target":"best_actor_by_real_trade_outcome","actor_counts":counts})
        return {"status":"selector_rebuilt_from_scratch","rows":int(len(X)),"accuracy":acc,"actor_counts":counts}

    @staticmethod
    def _balanced_accuracy(y_true, y_pred, n_classes):
        y_true=np.asarray(y_true,int); y_pred=np.asarray(y_pred,int)
        recalls=[float(np.mean(y_pred[y_true==c]==c)) for c in range(int(n_classes)) if np.any(y_true==c)]
        return float(np.mean(recalls)) if recalls else 0.0

    def _temporal_candidate(self, X, y, times, weights, kind, old_model=None):
        """Train on older rows and validate on later timestamps with a time embargo.

        Rows from many contracts can share timestamps. Split on unique timestamp
        groups and purge by elapsed seconds, not by a count of rows. `times` must
        represent when the target became observable (resolution time for outcomes).
        """
        X=np.nan_to_num(np.asarray(X,float),nan=0.0,posinf=0.0,neginf=0.0)
        y=np.asarray(y,int).reshape(-1); times=_normalize_times(times)
        weights=np.asarray(weights,float).reshape(-1)
        n=len(y)
        if len(X)!=n or len(times)!=n or len(weights)!=n or n<100:
            return None, {'status':'validation_accumulating','rows':int(n),'required_rows':100}
        order=np.argsort(times,kind='stable'); X=X[order]; y=y[order]; times=times[order]; weights=weights[order]
        unique_times=np.unique(times)
        fraction=float(np.clip(float(self.config.get('model_validation_fraction',0.20)),0.10,0.40))
        cut_unique=max(1,min(len(unique_times)-1,int(len(unique_times)*(1.0-fraction))))
        test_start=int(unique_times[cut_unique])
        horizon_seconds=max(1,int(self.config.get('horizon_bars',12)))*300
        configured_embargo=max(0,int(self.config.get('model_validation_embargo_seconds',0) or 0))
        embargo=max(horizon_seconds,configured_embargo)
        train_mask=(times < test_start-embargo) & np.isfinite(weights) & (weights>0)
        test_mask=(times >= test_start) & np.isfinite(weights) & (weights>0)
        train_y=y[train_mask]; test_y=y[test_mask]
        if len(train_y)<50 or len(test_y)<20 or len(np.unique(train_y))<2:
            return None, {'status':'validation_class_or_row_shortage','rows':int(n),'train_rows':int(len(train_y)),'validation_rows':int(len(test_y)),
                          'test_start_time':test_start,'purge_gap_seconds':int(embargo)}
        factory=self._new_outcome if kind=='outcome' else self._new
        candidate=factory()
        epochs=int(self.config.get('outcome_epochs',80) if kind=='outcome' else self.config.get('master_epochs',40))
        lr=float(self.config.get('outcome_learning_rate',.008) if kind=='outcome' else self.config.get('master_learning_rate',.004))
        l2=float(self.config.get('outcome_l2',.001) if kind=='outcome' else self.config.get('master_l2',.0005))
        candidate.fit(X[train_mask],train_y,epochs=epochs,learning_rate=lr,l2=l2,sample_weights=weights[train_mask])
        candidate_pred=candidate.predict(X[test_mask])
        candidate_acc=float(np.mean(candidate_pred==test_y))
        candidate_bal=self._balanced_accuracy(test_y,candidate_pred,candidate.n_classes)
        majority=int(np.bincount(train_y,minlength=candidate.n_classes).argmax())
        baseline_pred=np.full(len(test_y),majority,dtype=int)
        baseline_acc=float(np.mean(baseline_pred==test_y))
        baseline_bal=self._balanced_accuracy(test_y,baseline_pred,candidate.n_classes)
        old_acc=None; old_bal=None
        if old_model is not None:
            old_pred=old_model.predict(X[test_mask])
            old_acc=float(np.mean(old_pred==test_y))
            old_bal=self._balanced_accuracy(test_y,old_pred,candidate.n_classes)
        min_lift=float(self.config.get('model_promotion_min_balanced_lift',0.01))
        min_acc_lift=float(self.config.get('model_promotion_min_accuracy_lift',0.0))
        accepted=(candidate_bal >= baseline_bal+min_lift and candidate_acc >= baseline_acc+min_acc_lift and
                  (old_bal is None or (candidate_bal >= old_bal+min_lift and old_acc is not None and candidate_acc >= old_acc+min_acc_lift)))
        report={'status':'accepted' if accepted else 'rejected','rows':int(n),'train_rows':int(len(train_y)),'validation_rows':int(len(test_y)),
                'candidate_accuracy':candidate_acc,'baseline_accuracy':baseline_acc,'incumbent_accuracy':old_acc,
                'candidate_balanced_accuracy':float(candidate_bal),'baseline_balanced_accuracy':float(baseline_bal),
                'incumbent_balanced_accuracy':None if old_bal is None else float(old_bal),
                'accuracy_lift_vs_baseline':float(candidate_acc-baseline_acc),
                'balanced_accuracy_lift_vs_baseline':float(candidate_bal-baseline_bal),
                'accuracy_lift_vs_incumbent':None if old_acc is None else float(candidate_acc-old_acc),
                'balanced_accuracy_lift_vs_incumbent':None if old_bal is None else float(candidate_bal-old_bal),
                'test_start_time':test_start,'train_max_time':int(np.max(times[train_mask])),'test_min_time':int(np.min(times[test_mask])),
                'train_test_gap_seconds':int(np.min(times[test_mask])-np.max(times[train_mask])),
                'purge_gap_seconds':int(embargo),'purge_gap_bars':int(embargo//300),
                'candidate_saved_without_holdout_rows':True,'split_by_unique_timestamps':True}
        return (candidate if accepted else None),report

    def train_master_incremental(self, x, min_rows=25):
        n = len(x['target'])
        if n < min_rows:
            return {'status': 'not_enough_rows', 'rows': n}
        X=np.column_stack([np.asarray(x[f],float) for f in FEATURES]); y=np.asarray(x['target'],int)
        times=np.asarray(x.get('time',np.arange(n)),dtype=np.int64)
        sw=np.asarray(x.get('sample_weight',np.ones(n,float)),float).reshape(-1)
        if len(sw)!=n: sw=np.ones(n,float)
        old=self._load_path(self.champion,'direction')
        if old is None:
            # Preserve the established cold-start bootstrap path. The promotion
            # gate applies to replacing an existing Master, not initial creation.
            return self.train(x, max(500, min_rows), .2)
        candidate,gate=self._temporal_candidate(X,y,times,sw,'direction',old_model=old)
        if candidate is None:
            # Keep the last known Master untouched until a candidate beats both
            # the temporal baseline and incumbent on a later held-out block.
            self._write_json(self.meta,{**self._read_json(self.meta,{}),'last_promotion_check':gate,'last_retrain_rejected_at':int(time.time())})
            return {'status':'promotion_rejected_or_accumulating','rows':n,'validation':gate}
        self._save(self.champion,candidate)
        meta=self._read_json(self.meta,{})
        meta.update({'schema_version':self.MODEL_SCHEMA_VERSION,'status':'master_direction',
                     'learning_type':'temporal_candidate_promotion','last_retrain':int(time.time()),
                     'rows':int(n),'accepted':True,'last_promotion_check':gate,
                     'target_note':'Candidate trained only on older rows; promotion requires beating baseline and incumbent on later held-out rows.'})
        self._write_json(self.meta,meta)
        return {'status':'master_candidate_promoted','rows':n,'validation':gate}

    def _load_regime_pool(self):
        if not self.regime_pool.exists():
            return None
        try:
            z=np.load(self.regime_pool,allow_pickle=False)
            return {k:z[k] for k in z.files}
        except Exception:
            return None

    def update_regime_training(self, x, contract, horizon_bars=12,
                               long_threshold=0.003, short_threshold=-0.003):
        with _REGIME_POOL_LOCK:
            return self._update_regime_training_locked(x, contract, horizon_bars, long_threshold, short_threshold)

    def _update_regime_training_locked(self, x, contract, horizon_bars=12,
                                      long_threshold=0.003, short_threshold=-0.003):
        """Accumulate cross-contract, timestamped regime examples and retrain sparsely.

        Only completed forward windows are labeled. Feature rows themselves are
        causal. Duplicate (contract, candle-time) rows are not counted twice.
        """
        from .features import make_regime_labels
        try:
            labeled=make_regime_labels(x,int(horizon_bars),float(long_threshold),float(short_threshold))
            times=np.asarray(labeled.get('time',[]),dtype=np.int64).reshape(-1)
            targets=np.asarray(labeled.get('regime_target',[]),float).reshape(-1)
            n=len(times); contract=str(contract or 'UNKNOWN')
            incoming=[]
            for i in range(n):
                if not np.isfinite(targets[i]) or int(targets[i]) not in REGIME_NAMES:
                    continue
                vals=[]; valid=True
                for name in REGIME_FEATURES:
                    arr=np.asarray(labeled.get(name,[]),float).reshape(-1)
                    if len(arr)!=n or not np.isfinite(arr[i]):
                        valid=False; break
                    vals.append(float(arr[i]))
                if valid:
                    incoming.append((contract,int(times[i]),int(targets[i]),vals))
            if not incoming:
                return {'status':'regime_accumulating','added_rows':0}
            old=self._load_regime_pool(); rows={}
            if old:
                ot=np.asarray(old.get('time',[]),dtype=np.int64); oc=np.asarray(old.get('contract',[])).astype(str)
                oy=np.asarray(old.get('target',[]),dtype=np.int8)
                for i,t in enumerate(ot):
                    try: rows[(oc[i],int(t))]=(int(oy[i]),[float(old[f][i]) for f in REGIME_FEATURES])
                    except Exception: continue
            before=len(rows)
            for sym,t,y,vals in incoming:
                rows[(sym,t)]=(y,vals)
            # Keep a bounded recent pool; stable chronological order is used for validation.
            ordered=sorted(((sym,t,y,vals) for (sym,t),(y,vals) in rows.items()),key=lambda r:(r[1],r[0]))
            pool_cap=max(5000,int(self.config.get('regime_training_pool_max_rows',60000)))
            if len(ordered)>pool_cap: ordered=ordered[-pool_cap:]
            added=max(0,len(rows)-before)
            model_exists=self._load_path(self.regime_model,'regime') is not None
            if added==0 and model_exists:
                return {'status':'regime_pool_unchanged','added_rows':0,'pool_rows':len(ordered),
                        'contracts':len(set(str(r[0]) for r in ordered))}
            pool={'time':np.asarray([r[1] for r in ordered],dtype=np.int64),
                  'contract':np.asarray([r[0] for r in ordered]),
                  'target':np.asarray([r[2] for r in ordered],dtype=np.int8)}
            for j,name in enumerate(REGIME_FEATURES):
                pool[name]=np.asarray([r[3][j] for r in ordered],dtype=np.float32)
            tmp=self.regime_pool.with_suffix('.tmp.npz'); np.savez_compressed(tmp,**pool); tmp.replace(self.regime_pool)
            meta=self._read_json(self.regime_meta,{})
            unique_contracts=len(set(pool['contract'].astype(str).tolist()))
            min_contracts=max(3,int(self.config.get('regime_min_contracts',5)))
            min_rows=max(500,int(self.config.get('regime_min_rows',1500)))
            retrain_step=max(500,int(self.config.get('regime_retrain_new_rows',1500)))
            model_exists=self._load_path(self.regime_model,'regime') is not None
            new_since_train=int(meta.get('new_rows_since_train',0) or 0)+added
            last_attempt_rows=int(meta.get('last_attempt_pool_rows',0) or 0)
            due=(not model_exists and len(ordered)>=min_rows and unique_contracts>=min_contracts
                 and (str(meta.get('status',''))=='ready' or len(ordered)-last_attempt_rows>=500)) or (model_exists and new_since_train>=retrain_step)
            if due:
                result=self.train_regime(pool,horizon_bars=int(horizon_bars))
                trained_meta=self._read_json(self.regime_meta,{})
                trained_meta.update({'new_rows_since_train':0,'last_attempt_pool_rows':len(ordered),
                                     'last_pool_update':int(time.time())})
                self._write_json(self.regime_meta,trained_meta)
                return {'status':result.get('status','regime_trained'),'added_rows':added,
                        'pool_rows':len(ordered),'contracts':unique_contracts,'training':result}
            meta.update({'pool_rows':len(ordered),'pool_contracts':unique_contracts,
                         'new_rows_since_train':new_since_train,'last_pool_update':int(time.time())})
            self._write_json(self.regime_meta,meta)
            return {'status':'regime_accumulating' if not model_exists else 'regime_pool_updated',
                    'added_rows':added,'pool_rows':len(ordered),'contracts':unique_contracts,
                    'new_rows_since_train':new_since_train,
                    'required_contracts':min_contracts,'required_rows':min_rows}
        except Exception as exc:
            return {'status':'regime_update_error','error':str(exc)[:240]}

    def train_regime(self, data, horizon_bars=12):
        """Train the four-state regime head with chronological, purged validation."""
        y=np.asarray(data.get('target',[]),int).reshape(-1); times=_normalize_times(data.get('time',[]))
        if len(y)<max(500,int(self.config.get('regime_min_rows',1500))):
            return {'status':'regime_accumulating','rows':len(y)}
        X=np.column_stack([np.asarray(data[f],float).reshape(-1) for f in REGIME_FEATURES])
        valid=(y>=0)&(y<=3)&(times>0)&np.all(np.isfinite(X),axis=1)
        X,y,times=X[valid],y[valid],times[valid]
        contracts=np.asarray(data.get('contract',np.asarray(['UNKNOWN']*len(valid)))).astype(str)
        if len(contracts)==len(valid): contracts=contracts[valid]
        if len(y)<max(500,int(self.config.get('regime_min_rows',1500))):
            return {'status':'regime_accumulating','rows':len(y)}
        unique_times=np.unique(times)
        if len(unique_times)<100:
            return {'status':'regime_accumulating','rows':len(y),'reason':'insufficient_unique_timestamps'}
        cutoff=int(unique_times[min(len(unique_times)-1,max(1,int(len(unique_times)*0.8)))])
        scale=1_000_000 if int(np.max(times))>=100_000_000_000_000 else (1000 if int(np.max(times))>=100_000_000_000 else 1)
        gap=max(1,int(horizon_bars))*300*scale
        train_mask=times < cutoff-gap; test_mask=times>=cutoff
        if int(np.sum(train_mask))<300 or int(np.sum(test_mask))<100:
            return {'status':'regime_accumulating','rows':len(y),'reason':'insufficient_purged_holdout'}
        params={'epochs':int(self.config.get('regime_epochs',45)),
                'learning_rate':float(self.config.get('regime_learning_rate',0.008)),
                'l2':float(self.config.get('regime_l2',0.001))}
        shadow=self._new_regime().fit(X[train_mask],y[train_mask],**params)
        pred=shadow.predict(X[test_mask]); truth=y[test_mask]
        accuracy=float(np.mean(pred==truth))
        classes={}
        for i,name in REGIME_NAMES.items():
            actual_mask=truth==i; pred_mask=pred==i
            recall=float(np.mean(pred[actual_mask]==i)) if np.any(actual_mask) else None
            precision=float(np.mean(truth[pred_mask]==i)) if np.any(pred_mask) else None
            f1=(2*precision*recall/(precision+recall)) if precision is not None and recall is not None and precision+recall>0 else 0.0
            classes[name]={'count':int(np.sum(actual_mask)),'predicted_count':int(np.sum(pred_mask)),
                           'precision':precision,'recall':recall,'f1':float(f1)}
        balanced_accuracy=float(np.mean([v['recall'] for v in classes.values() if v['recall'] is not None]))
        # Baseline is the most frequent class in the training segment.
        majority=int(np.bincount(y[train_mask],minlength=4).argmax())
        baseline=float(np.mean(np.full(len(truth),majority,dtype=int)==truth))
        baseline_balanced=float(np.mean([float(np.mean(np.full(np.sum(truth==i),majority)==i))
                                         for i in range(4) if np.any(truth==i)]))
        delta=float(accuracy-baseline)
        min_delta=float(self.config.get('regime_min_accuracy_delta',0.005))
        min_bal=float(self.config.get('regime_min_balanced_accuracy',0.32))
        min_recall=float(self.config.get('regime_min_trend_recall',0.10))
        accepted=bool(delta>=min_delta and balanced_accuracy>=min_bal
                      and (classes['TREND_DOWN']['recall'] or 0.0)>=min_recall
                      and (classes['TREND_UP']['recall'] or 0.0)>=min_recall)
        old_meta=self._read_json(self.regime_meta,{})
        old_model=self._load_path(self.regime_model,'regime')
        old_accepted=old_model is not None and self._regime_validation_accepted(old_meta)
        payload={'schema_version':2,'status':'ready' if accepted else 'rejected_validation','rows':int(len(y)),
                 'train_rows':int(np.sum(train_mask)),'validation_rows':int(np.sum(test_mask)),
                 'validation_accuracy':accuracy,'balanced_accuracy':balanced_accuracy,
                 'baseline_accuracy':baseline,'baseline_balanced_accuracy':baseline_balanced,
                 'accuracy_minus_baseline':delta,
                 'balanced_accuracy_minus_baseline':float(balanced_accuracy-baseline_balanced),
                 'class_metrics':classes,'class_counts':{REGIME_NAMES[i]:int(np.sum(y==i)) for i in REGIME_NAMES},
                 'trained_pool_rows':int(len(y)),'contract_count':int(len(set(contracts.tolist()))),
                 'purge_gap_bars':int(horizon_bars),'feature_names':REGIME_FEATURES,
                 'updated':int(time.time()),'training':'historical_forward_path_labels',
                 'validation_protocol':{'type':'chronological_holdout','train_cutoff_seconds':int(cutoff),
                    'purge_gap_seconds':int(gap),'horizon_bars':int(horizon_bars),
                    'future_labels_used_as_inputs':False,'test_used_for_fit':False},
                 'validation_gate':{'accepted':accepted,'min_accuracy_delta':min_delta,
                    'min_balanced_accuracy':min_bal,'min_trend_recall':min_recall}}
        if accepted:
            final=self._new_regime().fit(X,y,**params)
            self._save(self.regime_model,final)
            self._write_json(self.regime_meta,payload)
            status='regime_trained'
        elif old_accepted:
            # Keep the last independently accepted model and its validation
            # record. Save the rejected candidate's metrics separately.
            old_meta['last_candidate_validation']=payload
            old_meta['last_candidate_rejected_at']=int(time.time())
            self._write_json(self.regime_meta,old_meta)
            status='regime_candidate_rejected_existing_model_preserved'
        else:
            self._write_json(self.regime_meta,payload)
            status='regime_rejected_validation'
        return {'status':status,'rows':int(len(y)),'validation_accuracy':accuracy,
                'balanced_accuracy':balanced_accuracy,'baseline_accuracy':baseline,
                'baseline_balanced_accuracy':baseline_balanced,'accuracy_minus_baseline':delta,
                'balanced_accuracy_minus_baseline':float(balanced_accuracy-baseline),
                'accepted':accepted,'class_metrics':classes}

    def _regime_scalar(self, row, name):
        """Read the newest causal regime feature without treating missing as zero."""
        try:
            if isinstance(row,dict):
                # Stage-25 supplies the regime head with an explicit feature
                # namespace so absent regime values never get confused with the
                # direction model's neutral-zero imputation.
                regime_features=row.get('regime_features',{})
                if isinstance(regime_features,dict) and name in regime_features:
                    raw=regime_features.get(name)
                elif name in row:
                    raw=row.get(name)
                else:
                    features=row.get('features',{})
                    raw=features.get(name) if isinstance(features,dict) else None
            else:
                raw=None
            if raw is None:
                return float('nan')
            values=np.asarray(raw,dtype=float).reshape(-1)
            if not len(values):
                return float('nan')
            value=float(values[-1])
            return value if np.isfinite(value) else float('nan')
        except (TypeError,ValueError,OverflowError):
            return float('nan')

    def _trend_strength_diagnostics(self, row):
        """Score trend strength from the existing causal features; do not add a second classifier."""
        def val(name):
            x=self._regime_scalar(row,name)
            return x if np.isfinite(x) else float('nan')
        trend_names=('trend','trend_15','trend_1h','trend_4h','trend_1d')
        trends=[val(name) for name in trend_names]
        trends=[x for x in trends if np.isfinite(x)]
        efficiency=val('regime_efficiency'); persistence=val('regime_persistence')
        reversals=val('regime_reversal_rate'); alignment=val('regime_mtf_alignment')
        if not trends or not np.isfinite(efficiency) or not np.isfinite(persistence):
            return {'trend_strength_long':0.0,'trend_strength_short':0.0,
                    'trend_alignment':0.0,'trend_quality':'INSUFFICIENT_DATA'}
        local=float(trends[0]); higher=trends[1:]
        if higher:
            signs=[np.sign(x) for x in higher if x!=0]
            mtf=float(sum(1 for x in signs if x==np.sign(local))/max(1,len(signs))) if local!=0 else 0.0
        else:
            mtf=0.5
        if np.isfinite(alignment): mtf=0.5*mtf+0.5*float(np.clip(alignment,0.0,1.0))
        reversal_penalty=float(np.clip(reversals,0.0,1.0)) if np.isfinite(reversals) else 0.5
        quality=float(np.clip(efficiency,0,1))*float(np.clip(persistence,0,1))
        quality*=float(np.clip(1.0-reversal_penalty,0.0,1.0))
        quality*=float(np.clip(0.55+0.45*mtf,0.0,1.0))
        magnitude=float(np.clip(abs(local)*80.0,0.0,1.0))
        up=float(np.clip(magnitude*quality if local>0 else 0.0,0.0,1.0))
        down=float(np.clip(magnitude*quality if local<0 else 0.0,0.0,1.0))
        if max(up,down)>=0.60 and mtf>=0.65 and quality>=0.55:
            label='STRONG_UP' if up>down else 'STRONG_DOWN'
        elif max(up,down)>=0.30 and quality>=0.30:
            label='MODERATE_UP' if up>down else 'MODERATE_DOWN'
        elif quality<0.25 or reversal_penalty>=0.55:
            label='RANGE_OR_CHOP'
        else:
            label='WEAK_OR_TRANSITIONAL'
        return {'trend_strength_long':round(up,6),'trend_strength_short':round(down,6),
                'trend_alignment':round(float(mtf),6),'trend_quality':label,
                'trend_efficiency':round(float(np.clip(efficiency,0,1)),6),
                'trend_persistence':round(float(np.clip(persistence,0,1)),6),
                'trend_reversal_rate':round(reversal_penalty,6)}

    def market_regime(self, row):
        """Classify regime only with an accepted model or an explicit causal fallback.

        Missing features are never silently converted to zero: doing so previously
        made unrelated coins receive the same confident RANGE result. Older callers
        may omit only the seven regime-specific descriptors; an accepted model can
        impute those from its training means, while core price/MTF inputs remain
        mandatory.
        """
        strength=self._trend_strength_diagnostics(row)
        meta=self._read_json(self.regime_meta,{})
        loaded=self._load_path(self.regime_model,'regime')
        model_accepted=bool(loaded is not None and self._regime_validation_accepted(meta))
        model=loaded if model_accepted else None
        if model_accepted:
            model_status='accepted'
        elif loaded is None:
            model_status=str(meta.get('status','missing'))
        elif meta.get('status')=='ready':
            has_gate_metrics=all(meta.get(k) is not None for k in ('validation_accuracy','baseline_accuracy','balanced_accuracy'))
            model_status='rejected_validation' if has_gate_metrics else 'legacy_unverified'
        else:
            model_status=str(meta.get('status','unverified'))
        values=[]; missing=[]
        for name in REGIME_FEATURES:
            value=self._regime_scalar(row,name)
            values.append(value)
            if not np.isfinite(value): missing.append(name)

        # The first 18 columns are the base + higher-timeframe trend inputs. If
        # those are present, missing derived regime descriptors can be imputed
        # neutrally using the exact means learned by this accepted model.
        core_features=REGIME_FEATURES[:18]
        missing_core=[name for name in core_features if name in missing]
        imputed=[]
        if model is not None and not missing_core:
            model_values=np.asarray(values,float)
            for idx,name in enumerate(REGIME_FEATURES):
                if not np.isfinite(model_values[idx]):
                    model_values[idx]=float(model.means[idx])
                    imputed.append(name)
            p=np.asarray(model.predict_proba(model_values.reshape(1,-1))[0],float)
            p=np.clip(p,0.0,1.0); p/=max(float(np.sum(p)),1e-12)
            idx=int(np.argmax(p)); confidence=float(p[idx])
            if imputed:
                confidence*=max(0.65,1.0-0.05*len(imputed))
            return {'label':REGIME_NAMES[idx],
                'probabilities':{REGIME_NAMES[i]:float(p[i]) for i in REGIME_NAMES},
                'confidence':confidence,'source':'trained_regime_model','rows':int(meta.get('rows',0) or 0),
                'model_validation_accepted':True,'validation_accuracy':meta.get('validation_accuracy'),
                'validation_baseline_accuracy':meta.get('baseline_accuracy'),
                'imputed_features':imputed,'missing_features':missing,**strength}

        # A failed quality gate must never silently become a "trained" result.
        # Also refuse a confident rule fallback when its required causal inputs are
        # absent; missing data means TRANSITION/WAIT, not an invented RANGE.
        eff=self._regime_scalar(row,'regime_efficiency')
        pers=self._regime_scalar(row,'regime_persistence')
        rev=self._regime_scalar(row,'regime_reversal_rate')
        align=self._regime_scalar(row,'regime_mtf_alignment')
        trend_vals=[self._regime_scalar(row,k) for k in ('trend','trend_15','trend_1h','trend_4h','trend_1d')]
        trend_vals=[v for v in trend_vals if np.isfinite(v)]
        fallback_required_missing=[]
        for name,value in (('regime_efficiency',eff),('regime_persistence',pers),
                           ('regime_reversal_rate',rev)):
            if not np.isfinite(value): fallback_required_missing.append(name)
        if not trend_vals:
            fallback_required_missing.append('trend_context')
        if fallback_required_missing:
            return {'label':'TRANSITION',
                'probabilities':{'TREND_DOWN':0.0,'RANGE':0.0,'TRANSITION':1.0,'TREND_UP':0.0},
                'confidence':0.0,'source':'insufficient_data','rows':0,
                'model_validation_accepted':False,'model_validation_status':model_status,
                'model_validation_accuracy':meta.get('validation_accuracy'),
                'model_validation_baseline_accuracy':meta.get('baseline_accuracy'),
                'missing_features':missing,'required_missing_features':fallback_required_missing,**strength}
        avg=float(np.mean(trend_vals)); align=align if np.isfinite(align) else 0.0
        range_score=float(np.clip((0.55-eff)*1.7 + rev*0.55 + (1.0-align)*0.25,0.0,1.0))
        up=float(np.clip(max(0.0,avg)*80.0,0,1))*float(np.clip((eff+pers)/1.4,0,1))*float(np.clip(0.55+align*0.45,0,1))
        down=float(np.clip(max(0.0,-avg)*80.0,0,1))*float(np.clip((eff+pers)/1.4,0,1))*float(np.clip(0.55+align*0.45,0,1))
        transition=float(np.clip(0.35+abs(0.5-eff)*0.35+(1-align)*0.25,0,1))
        raw=np.asarray([down,range_score,transition,up],float)+1e-4
        probs=np.exp(raw*3.0-np.max(raw*3.0)); probs/=np.sum(probs)
        # The causal heuristic was independently evaluated on the saved 60k-row
        # pool and did not beat the baseline. Keep its scores for diagnostics, but
        # never promote an unvalidated heuristic to a confident market regime.
        # TRANSITION lets the decision layer abstain more often until a learned
        # classifier passes its own purged holdout gate.
        return {'label':'TRANSITION',
            'probabilities':{'TREND_DOWN':0.0,'RANGE':0.0,'TRANSITION':1.0,'TREND_UP':0.0},
            'fallback_estimate':{REGIME_NAMES[i]:float(probs[i]) for i in REGIME_NAMES},
            'confidence':0.0,'source':'unvalidated_fallback_wait_guard','rows':0,
            'model_validation_accepted':False,'model_validation_status':model_status,
            'model_validation_accuracy':meta.get('validation_accuracy'),
            'model_validation_baseline_accuracy':meta.get('baseline_accuracy'),
            'missing_features':missing,**strength}

    def _softmax3(self, logits):
        z = np.asarray(logits, float); z -= np.max(z)
        e = np.exp(np.clip(z, -30, 30))
        return e / max(np.sum(e), 1e-12)

    def _rowv(self, row, name):
        try:
            if name in row:
                return float(np.asarray(row.get(name, [0.0])).reshape(-1)[0])
            feat = row.get('features') or {}
            return float(feat.get(name, 0.0))
        except Exception:
            return 0.0

    @staticmethod
    def outcome_label(item):
        if item.get('tp3_hit'):
            return 4 if float(item.get('max_extension_beyond_tp3_pct', item.get('post_tp3_extension', 0.0)) or 0.0) > 0 else 3
        if item.get('tp2_hit'):
            return 2
        if item.get('tp1_hit'):
            return 1
        if item.get('initial_sl_failure') or (item.get('sl_hit') and not item.get('tp1_hit')):
            return 0
        return -1

    @staticmethod
    def outcome_score(item):
        y = ModelManager.outcome_label(item)
        return max(0, y)

    def _fixed_lens(self, master, row, math_snapshot=None):
        """Three deterministic lenses. No lens state, no adaptive weights."""
        p = np.asarray(master, float); lp = np.log(np.clip(p, 1e-6, 1.0))
        trend = np.tanh(np.mean([self._rowv(row, k) for k in ('trend', 'trend_15', 'trend_1h', 'trend_4h', 'trend_1d')]) * 18.0)
        vol = float(np.clip(self._rowv(row, 'volatility') * 80.0, 0.0, 2.0))
        volz = float(np.tanh(self._rowv(row, 'volz') / 3.0))
        rsi = float(np.clip((self._rowv(row, 'rsi') - 50.0) / 25.0, -2, 2))
        bb = float(np.clip((self._rowv(row, 'bbpos') - 0.5) * 2.0, -2, 2))
        # The fixed directional lenses have candle-history training only;
        # do not let a live-only book snapshot affect their direction.
        imb = 0.0
        market_mode = str(self._read_json(self.meta,{}).get('market_features_mode','neutral'))
        oi = float(np.tanh(self._rowv(row, 'oi_change'))) if market_mode == 'historical_aligned' else 0.0
        funding = float(np.tanh(self._rowv(row, 'funding') * 50.0)) if market_mode == 'historical_aligned' else 0.0
        # No validated historical liquidation-side feature series is available.
        liq = 0.0
        math_snapshot = math_snapshot or row.get('math_snapshot') or {}
        groups = {
            'c1': ['math_markov', 'math_hurst', 'math_wavelet'],
            'c2': ['math_ar', 'math_arima', 'math_sarima', 'math_mean_reversion', 'math_cointegration', 'math_correlation', 'math_trend_deviation', 'math_bayesian', 'math_kalman'],
            # C3's directional evidence is kept separate from risk. In the old
            # implementation, high P(SL) was converted to a positive score and
            # could strengthen LONG instead of increasing WAIT/risk.
            'c3': ['math_direction', 'math_monte_carlo', 'math_ptp1', 'math_ptp2', 'math_ptp3'],
        }
        validation_enforced = bool(math_snapshot.get('_probability_validation_enforced', False))
        validated_heads = set(math_snapshot.get('_validated_probability_heads', []) or [])
        def group_score(key):
            vals = []
            for name in groups[key]:
                if name not in math_snapshot:
                    continue
                v = float(math_snapshot[name])
                if name == 'math_direction':
                    v = float(np.clip(v, -1, 1))
                elif name in ('math_ptp1', 'math_ptp2', 'math_ptp3'):
                    if validation_enforced and name not in validated_heads:
                        v = 0.0
                    else:
                        direction_sign = 1.0 if float(math_snapshot.get('math_target_sign', math_snapshot.get('math_direction', 0.0))) >= 0 else -1.0
                        v = direction_sign * (2 * v - 1)
                elif name in ('math_monte_carlo', 'math_bayesian'):
                    v = 2 * v - 1
                    if validation_enforced and name not in validated_heads:
                        v = 0.0
                elif name == 'math_hurst':
                    # Persistence has directional meaning only in the context
                    # of the observed trend; H alone is not a LONG/SHORT signal.
                    v = (v - 0.5) * 2 * float(math_snapshot.get('math_trend_direction', 0.0))
                elif name == 'math_correlation':
                    # Correlation has direction only after conditioning on the
                    # current benchmark trend. Raw correlation is not a signal.
                    v = v * float(math_snapshot.get('math_benchmark_direction', 0.0))
                # Entropy, fractal dimension, GARCH volatility, change-point
                # strength and return/volatility correlation are regime/risk
                # measures. They are deliberately excluded from directional
                # lens scores and remain available to the risk/WAIT layer.
                vals.append(float(np.clip(v, -1, 1)))
            return float(np.mean(vals)) if vals else 0.0

        s1, s2, s3 = group_score('c1'), group_score('c2'), group_score('c3')
        # Fixed coefficients are part of the lens definition, not learned state.
        c1 = self._softmax3(lp + np.array([-(0.55 * trend + 0.25 * s1), 0.12 * vol + 0.10 * volz, (0.55 * trend + 0.25 * s1)]))
        directional = 0.45 * trend + 0.18 * rsi + 0.15 * bb + 0.12 * imb + 0.10 * oi + 0.25 * s2
        c2 = self._softmax3(lp + np.array([-directional, 0.05 * vol, directional]))
        directional_signal = 0.30 * trend + 0.15 * imb + 0.15 * oi - 0.10 * funding - 0.10 * liq + 0.35 * s3
        garch_risk = float(np.clip(math_snapshot.get('math_garch', 0.5), 0, 1))
        sl_raw = float(math_snapshot.get('math_psl', 0.5))
        sl_risk = 0.5 if validation_enforced and 'math_psl' not in validated_heads else float(np.clip(sl_raw, 0, 1))
        entropy_risk = float(np.clip(math_snapshot.get('math_entropy', 0.5), 0, 1))
        change_risk = float(np.clip(math_snapshot.get('math_change_point', 0.0), 0, 1))
        vol_risk = float(np.clip(vol / 2.0, 0, 1))
        risk_level = float(np.clip(.30*garch_risk + .35*sl_risk + .15*entropy_risk +
                                   .10*change_risk + .10*vol_risk, 0, 1))
        confidence = float(np.clip(1.0 - risk_level, 0, 1))
        # Higher adverse excursion probability/volatility raises WAIT and
        # suppresses both directional logits; it never directly boosts LONG.
        c3 = self._softmax3(lp + np.array([
            -directional_signal * confidence,
            0.10 * vol + 1.10 * risk_level,
            -0.10 * vol + directional_signal * confidence
        ]))
        return {
            'c1': {'probs': c1}, 'c2': {'probs': c2}, 'c3': {'probs': c3},
            'shared_base_version': int(self._learning_state().get('base_version', 0)),
            'specialization_scores': {'c1': s1, 'c2': s2, 'c3': s3},
            'reliability': {'c1': 1.0, 'c2': 1.0, 'c3': 1.0},
        }

    def _selector_vector(self, row, master, lenses, math_consensus=0.0, performance_snapshot=None):
        vals = list(np.asarray(master, float))
        for k in ('c1', 'c2', 'c3'):
            vals.extend(list(np.asarray(lenses[k]['probs'], float)))
        for k in ('c1', 'c2', 'c3'):
            vals.append(abs(float(master[2]) - float(lenses[k]['probs'][2])))
        vals.append(float(np.std([float(lenses[k]['probs'][2]) for k in ('c1', 'c2', 'c3')])))
        vals.append(float(math_consensus or 0.0))
        perf=performance_snapshot if performance_snapshot is not None else self._performance_features()
        vals.extend([float(v) for v in perf])
        market_mode = str(self._read_json(self.meta,{}).get('market_features_mode','neutral'))
        for k in self.META_CONTEXT:
            if k in ('book_imbalance','liquidation_bias'):
                vals.append(0.0)
            elif k in ('oi_change','funding') and market_mode != 'historical_aligned':
                vals.append(0.0)
            else:
                vals.append(self._rowv(row,k))
        return np.asarray(vals, float)

    def _feature_matrix(self, row, for_outcome=False):
        """Build a model matrix with an explicit, tested market-feature policy."""
        X = np.column_stack([np.asarray(row[f], float).reshape(-1) for f in FEATURES])
        if not for_outcome and 'book_imbalance' in FEATURES:
            X[:, FEATURES.index('book_imbalance')] = 0.0
        if 'liquidation_bias' in FEATURES:
            X[:, FEATURES.index('liquidation_bias')] = 0.0
        return X

    def predict_bundle(self, row, math_consensus=0.0, math_snapshot=None):
        base = self._load_path(self.champion, 'direction')
        if base is None:
            raise FileNotFoundError('Нет совместимой обученной модели.')
        X = self._feature_matrix(row, for_outcome=False)
        master = base.predict_proba(X)[0]
        state = self._learning_state()
        active = int(state.get('resolved_total', 0)) >= int(state.get('lens_activation_resolved', 25)) and int(state.get('base_version', 0)) >= 1
        if active:
            lenses = self._fixed_lens(master, row, math_snapshot)
        else:
            neutral = np.asarray(master, float)
            lenses = {k: {'probs': neutral.copy()} for k in ('c1', 'c2', 'c3')}
            lenses.update({'shared_base_version': int(state.get('base_version', 0)), 'specialization_scores': {'c1': 0.0, 'c2': 0.0, 'c3': 0.0}, 'reliability': {'c1': 1.0, 'c2': 1.0, 'c3': 1.0}})

        outcome_probs = None
        outcome_model = self._load_path(self.outcome_model, 'outcome')
        if outcome_model is not None:
            # Outcome training rows preserve real snapshots captured when the
            # forecast was issued; only this head may consume that feature.
            X_outcome = self._feature_matrix(row, for_outcome=True)
            outcome_probs = outcome_model.predict_proba(X_outcome)[0]

        selector = None
        selector_probs = None
        performance_snapshot = self._performance_features()
        combination_probs = {}
        combination_lenses = {
            'MASTER': (), 'MASTER+C1': ('c1',), 'MASTER+C2': ('c2',), 'MASTER+C3': ('c3',),
            'MASTER+C1+C2': ('c1', 'c2'), 'MASTER+C1+C3': ('c1', 'c3'),
            'MASTER+C2+C3': ('c2', 'c3'), 'MASTER+C1+C2+C3': ('c1', 'c2', 'c3'),
        }
        for name, selected in combination_lenses.items():
            parts = [master] + [lenses[k]['probs'] for k in selected]
            combination_probs[name] = np.mean(np.asarray(parts, float), axis=0)
        if active and self._selector_ready():
            vec = self._selector_vector(row, master, lenses, math_consensus, performance_snapshot)
            selector = self._load_path(self.master_decision, 'selector')
            selector_probs = selector.predict_proba(vec.reshape(1, -1))[0]
            final = np.zeros(3, float)
            for idx, prob in enumerate(selector_probs):
                final += float(prob) * combination_probs[COMBINATION_NAMES[idx]]
            final /= max(np.sum(final), 1e-12)
            source = 'master_combination_selector'
            selected_combination = COMBINATION_NAMES[int(np.argmax(selector_probs))]
        else:
            final = master.copy()
            vec = self._selector_vector(row, master, lenses, math_consensus, performance_snapshot) if active else None
            source = 'master_core' if not active else 'master_plus_fixed_lenses_learning'
            selected_combination = 'MASTER'
        regime = self.market_regime(row)
        regime_probs=regime.get('probabilities',{})
        range_p=float(regime_probs.get('RANGE',0.0) or 0.0)
        transition_p=float(regime_probs.get('TRANSITION',0.0) or 0.0)
        # Uncertain/ranging regimes increase abstention rather than voting LONG
        # or SHORT. Keep the original probability ratios between directions.
        regime_wait_boost=0.0
        if regime.get('source') in ('insufficient_data','unvalidated_fallback_wait_guard'):
            regime_wait_boost=float(self.config.get('regime_unvalidated_wait_boost',0.12))
            final=np.asarray(final,float).copy()
            final[1]+=regime_wait_boost
            final/=max(float(np.sum(final)),1e-12)
        elif regime.get('source')!='insufficient_data':
            regime_wait_boost=0.20*range_p+0.12*transition_p
            if regime_wait_boost>0:
                final=np.asarray(final,float).copy()
                final[1]+=regime_wait_boost
                final/=max(float(np.sum(final)),1e-12)
        # Improve the existing regime head with strength diagnostics from the same
        # causal features. A chop estimate strengthens WAIT; a strong aligned trend
        # only modestly reinforces Master and never overrides an opposite prediction.
        trend_confirmation_boost=0.0
        chop_wait_boost=0.0
        quality=str(regime.get('trend_quality',''))
        if quality=='RANGE_OR_CHOP':
            chop_wait_boost=0.04
            final=np.asarray(final,float).copy()
            final[1]+=chop_wait_boost
            final/=max(float(np.sum(final)),1e-12)
        candidate=int(np.argmax(final))
        if candidate in (0,2):
            strength_key='trend_strength_short' if candidate==0 else 'trend_strength_long'
            strength_value=float(regime.get(strength_key,0.0) or 0.0)
            aligned_label='STRONG_DOWN' if candidate==0 else 'STRONG_UP'
            moderate_label='MODERATE_DOWN' if candidate==0 else 'MODERATE_UP'
            if quality in (aligned_label,moderate_label) and strength_value>=0.45:
                if regime.get('source')=='trained_regime_model' and float(regime.get('confidence',0.0) or 0.0)>=0.50:
                    trend_confirmation_boost=min(0.04,0.04*strength_value*float(regime.get('confidence',0.0)))
                elif quality==aligned_label and strength_value>=0.65:
                    # Unvalidated rule features may give only a small nudge, never
                    # the full authority of a model that passed holdout validation.
                    trend_confirmation_boost=min(0.015,0.015*strength_value)
                if trend_confirmation_boost>0:
                    final=np.asarray(final,float).copy()
                    final[candidate]+=trend_confirmation_boost
                    final/=max(float(np.sum(final)),1e-12)
        directional = max(float(final[0]), float(final[2]))
        wait = float(final[1])
        threshold = float(self.config.get('min_direction_confidence', 0.55))
        edge = float(self.config.get('min_direction_edge', 0.06))
        if regime.get('source') in ('insufficient_data','unvalidated_fallback_wait_guard'):
            threshold += float(self.config.get('regime_unvalidated_confidence_penalty',0.05))
            edge += float(self.config.get('regime_unvalidated_edge_penalty',0.02))
        if regime.get('label')=='RANGE' and float(regime.get('confidence',0.0))>=0.45:
            threshold += 0.08; edge += 0.03
        elif regime.get('label')=='TRANSITION' and float(regime.get('confidence',0.0))>=0.45:
            threshold += 0.05; edge += 0.02
        cls = int(np.argmax(final))
        if directional < threshold or directional - wait < edge:
            cls = 1
        return NAMES[cls], {i: float(final[i]) for i in range(3)}, {
            'master_probs': master,
            'lenses': lenses,
            'decision_source': source,
            'meta_vector': vec,
            'selector_probs': selector_probs,
            'selected_combination': selected_combination,
            'combination_probs': combination_probs,
            'performance_snapshot': performance_snapshot,
            'outcome_probs': outcome_probs,
            'outcome_names': OUTCOME_NAMES,
            'lens_active': active,
            'market_regime': regime,
            'regime_wait_boost': float(regime_wait_boost),
            'trend_confirmation_boost': float(trend_confirmation_boost),
            'chop_wait_boost': float(chop_wait_boost),
        }

    def predict(self, row, math_consensus=0.0):
        pred, probs, _ = self.predict_bundle(row, math_consensus)
        return pred, probs

    @staticmethod
    def _individual_math_expert_predictions(math_snapshot):
        """Convert individual math outputs into shadow candidates, not live signals."""
        m = math_snapshot if isinstance(math_snapshot, dict) else {}
        if not m:
            return {}
        out = {}
        for name, field in MATH_EXPERT_FIELDS.items():
            try:
                value = float(m.get(field, 0.0) or 0.0)
                if name in ('BAYESIAN_SIGN', 'MONTE_CARLO_DIRECTION'):
                    value = 2.0 * value - 1.0
                elif name == 'HURST_TREND_PERSISTENCE':
                    value = (value - 0.5) * 2.0 * float(m.get('math_trend_direction', 0.0) or 0.0)
                elif name == 'BENCHMARK_CORRELATION':
                    value *= float(m.get('math_benchmark_direction', 0.0) or 0.0)
                value = float(np.clip(value, -1.0, 1.0))
                # Low-magnitude signals abstain. This is a shadow-evaluation
                # threshold, not a probability or a claim of calibrated confidence.
                direction = 'WAIT' if abs(value) < 0.08 else ('LONG' if value > 0 else 'SHORT')
                out[name] = {'score': value, 'prediction': direction,
                             'score_type': 'raw_directional_score', 'calibrated': False}
            except Exception:
                out[name] = {'score': 0.0, 'prediction': 'WAIT',
                             'score_type': 'raw_directional_score', 'calibrated': False}
        return out

    @staticmethod
    def _evaluate_math_expert_selector(rows):
        """Choose an expert on earlier outcomes and validate it on a later holdout.

        The validation window is the latest 30 eligible Master forecasts, including
        rows where an expert abstained. This prevents a model from looking good by
        predicting only on a tiny, easy subset of situations.
        """
        rows = [r for r in (rows or []) if isinstance(r, dict) and int(r.get('baseline_outcome_score', -1)) >= 0]
        rows.sort(key=lambda r: (int(r.get('time', 0) or 0), str(r.get('prediction_id', ''))))
        experts = sorted({name for row in rows for name in (row.get('experts') or {})})
        candidates = []
        diagnostics = {}
        for name in experts:
            expert_rows = [row for row in rows if name in (row.get('experts') or {})]
            if len(expert_rows) < MATH_EXPERT_MIN_TRAIN + MATH_EXPERT_VALIDATION:
                directional = [r for r in expert_rows if str((r.get('experts') or {}).get(name, {}).get('prediction', 'WAIT')).upper() in ('LONG', 'SHORT') and int((r.get('experts') or {}).get(name, {}).get('outcome_score', -1)) >= 0]
                diagnostics[name] = {'status': 'collecting', 'n': len(directional), 'eligible_rows': len(expert_rows)}
                continue
            train_rows = expert_rows[:-MATH_EXPERT_VALIDATION]
            validation_rows = expert_rows[-MATH_EXPERT_VALIDATION:]

            def directional_samples(source):
                out=[]
                for row in source:
                    item=(row.get('experts') or {}).get(name) or {}
                    try:
                        pred=str(item.get('prediction','WAIT')).upper()
                        score=int(item.get('outcome_score',-1))
                        baseline=int(row.get('baseline_outcome_score',-1))
                    except (TypeError,ValueError):
                        continue
                    if pred in ('LONG','SHORT') and score >= 0 and baseline >= 0:
                        out.append({'score':score,'baseline':baseline})
                return out

            train = directional_samples(train_rows)
            valid = directional_samples(validation_rows)
            coverage = len(valid) / max(1, len(validation_rows))
            if len(train) < MATH_EXPERT_MIN_TRAIN or coverage < 0.70:
                diagnostics[name] = {'status': 'collecting' if len(train) < MATH_EXPERT_MIN_TRAIN else 'rejected_validation',
                                     'train_n': len(train), 'validation_n': len(valid),
                                     'validation_window': len(validation_rows), 'validation_coverage': round(coverage,4)}
                continue
            train_rate = sum(x['score'] >= 1 for x in train) / len(train)
            train_base = sum(x['baseline'] >= 1 for x in train) / len(train)
            valid_rate = sum(x['score'] >= 1 for x in valid) / len(valid)
            valid_base = sum(x['baseline'] >= 1 for x in valid) / len(valid)
            wins = sum(x['score'] >= 1 and x['baseline'] == 0 for x in valid)
            losses = sum(x['score'] == 0 and x['baseline'] >= 1 for x in valid)
            discordant = wins + losses
            net = wins - losses
            passes = (valid_rate >= valid_base + MATH_EXPERT_MIN_LIFT and
                      discordant >= MATH_EXPERT_MIN_DISCORDANT and
                      net >= MATH_EXPERT_MIN_NET_WINS and
                      wins / max(1, discordant) >= 0.60)
            diagnostics[name] = {
                'status': 'validated' if passes else 'rejected_validation',
                'train_n': len(train), 'validation_n': len(valid),
                'validation_window': len(validation_rows), 'validation_coverage': round(coverage,4),
                'train_tp1_rate': round(train_rate, 4),
                'train_baseline_tp1_rate': round(train_base, 4),
                'validation_tp1_rate': round(valid_rate, 4),
                'validation_baseline_tp1_rate': round(valid_base, 4),
                'validation_lift': round(valid_rate - valid_base, 4),
                'paired_wins': wins, 'paired_losses': losses,
                'paired_net': net, 'discordant': discordant,
            }
            if passes:
                candidates.append((train_rate - train_base, valid_rate - valid_base, name))
        if candidates:
            candidates.sort(reverse=True)
            lift_train, lift_valid, chosen = candidates[0]
            return {
                'schema_version': 1, 'status': 'validated', 'active_expert': chosen,
                'train_lift': round(lift_train, 4), 'validation_lift': round(lift_valid, 4),
                'minimum_train_samples': MATH_EXPERT_MIN_TRAIN,
                'minimum_validation_samples': MATH_EXPERT_VALIDATION,
                'experts': diagnostics,
            }
        any_ready = any(v.get('status') == 'rejected_validation' for v in diagnostics.values())
        return {
            'schema_version': 1, 'status': 'collecting' if not any_ready else 'no_expert_passed',
            'active_expert': None, 'minimum_train_samples': MATH_EXPERT_MIN_TRAIN,
            'minimum_validation_samples': MATH_EXPERT_VALIDATION, 'experts': diagnostics,
        }

    def refresh_math_expert_selector(self, performance):
        """Refresh promotion state from matched, chronological, high-confidence outcomes."""
        if not isinstance(performance, dict):
            performance = {}
        rows = performance.get('math_expert_rows', [])
        state = self._evaluate_math_expert_selector(rows)
        state['updated'] = int(time.time())
        performance['math_expert_selector'] = state
        self._math_expert_selector_cache = dict(state)
        return state

    def math_expert_selector_state(self):
        """Read selector state once and cache it during scanning for low overhead."""
        if not isinstance(self._math_expert_selector_cache, dict):
            state = self._load_lens_performance().get('math_expert_selector', {})
            self._math_expert_selector_cache = dict(state) if isinstance(state, dict) else {}
        return dict(self._math_expert_selector_cache)

    def active_math_expert(self):
        """Return the currently validated expert, or None while evidence is insufficient."""
        state = self.math_expert_selector_state()
        if state.get('status') != 'validated':
            return None
        name = state.get('active_expert')
        if not name or name not in MATH_EXPERT_FIELDS:
            return None
        return str(name)

    def prediction_diagnostics(self, row, pred, probs, math_consensus=0.0, math_snapshot=None):
        _, final, extra = self.predict_bundle(row, math_consensus, math_snapshot)
        d = {
            'master_p_short': float(extra['master_probs'][0]),
            'master_p_wait': float(extra['master_probs'][1]),
            'master_p_long': float(extra['master_probs'][2]),
            'decision_source': extra['decision_source'],
            'lens_active': bool(extra.get('lens_active', False)),
            'market_regime': dict(extra.get('market_regime') or {}),
            'regime_wait_boost': float(extra.get('regime_wait_boost',0.0) or 0.0),
            'trend_confirmation_boost': float(extra.get('trend_confirmation_boost',0.0) or 0.0),
            'chop_wait_boost': float(extra.get('chop_wait_boost',0.0) or 0.0),
        }
        for i, k in enumerate(('c1', 'c2', 'c3'), 1):
            q = extra['lenses'][k]['probs']
            d[f'c{i}_p_short'] = float(q[0]); d[f'c{i}_p_wait'] = float(q[1]); d[f'c{i}_p_long'] = float(q[2])
        d['conflict_m_c1'] = abs(d['master_p_long'] - d['c1_p_long'])
        d['conflict_m_c2'] = abs(d['master_p_long'] - d['c2_p_long'])
        d['conflict_m_c3'] = abs(d['master_p_long'] - d['c3_p_long'])
        d['lens_agreement'] = float(np.std([d['c1_p_long'], d['c2_p_long'], d['c3_p_long']]))
        d['math_consensus'] = float(math_consensus or 0.0)
        expert_snapshot = dict(math_snapshot) if isinstance(math_snapshot, dict) else {}
        if math_consensus is not None:
            expert_snapshot['math_consensus'] = float(math_consensus or 0.0)
        d['math_expert_predictions'] = self._individual_math_expert_predictions(expert_snapshot)
        pred_name = str(pred or 'WAIT').upper()
        directional_confidence = (float(probs[2]) if pred_name == 'LONG' else
                                  float(probs[0]) if pred_name == 'SHORT' else 0.0)
        d['math_expert_training_eligible'] = bool(pred_name in ('LONG', 'SHORT') and directional_confidence >= 0.80)
        d['math_expert_training_confidence'] = directional_confidence
        d['math_expert_selector'] = self.math_expert_selector_state() or {'status': 'collecting', 'active_expert': None}
        d['math_expert_active_name'] = self.active_math_expert()
        d['lens_predictions'] = {k: NAMES[int(np.argmax(extra['lenses'][k]['probs']))] for k in ('c1', 'c2', 'c3')}
        d['lens_specialization_scores'] = dict(extra['lenses'].get('specialization_scores', {}))
        d['lens_reliability'] = {'c1': 1.0, 'c2': 1.0, 'c3': 1.0}
        d['lens_training_enabled'] = False
        d['shared_base_version'] = int(extra['lenses'].get('shared_base_version', 0) or 0)
        d['lens_performance_snapshot']=list(extra.get('performance_snapshot') or [])
        d['selected_combination'] = str(extra.get('selected_combination', 'MASTER'))
        d['combination_predictions'] = {name: NAMES[int(np.argmax(probs))] for name, probs in (extra.get('combination_probs') or {}).items()}
        if extra.get('selector_probs') is not None:
            for idx, name in COMBINATION_NAMES.items():
                d[f'selector_p_{idx}'] = float(extra['selector_probs'][idx])
            d['selector_selected_combination'] = COMBINATION_NAMES[int(np.argmax(extra['selector_probs']))]
        else:
            for idx in COMBINATION_NAMES:
                d[f'selector_p_{idx}'] = 1.0 if idx == 0 else 0.0
            d['selector_selected_combination'] = 'MASTER'
        op = extra.get('outcome_probs')
        if op is not None:
            for i, name in OUTCOME_NAMES.items():
                d[f'outcome_p_{name.lower()}'] = float(op[i])
            d['predicted_trade_outcome'] = OUTCOME_NAMES[int(np.argmax(op))]
            d['predicted_trade_outcome_score'] = int(np.argmax(op))
        else:
            d['predicted_trade_outcome'] = 'UNTRAINED'
            d['predicted_trade_outcome_score'] = -1
        return d

    def learn_trade_outcomes(self, experience):
        """Promote an outcome head only when a later holdout beats baseline/incumbent."""
        if not experience:
            return {'status':'no_experience'}
        y=np.asarray(experience.get('outcome_target',[]),int).reshape(-1)
        if not len(y): return {'status':'outcome_accumulating','rows':0}
        X=np.column_stack([np.asarray(experience[f],float) for f in FEATURES])
        valid=(y>=0)&(y<=4)
        times=_normalize_times(experience.get('resolved_time',experience.get('time',np.arange(len(y)))))
        sw=np.asarray(experience.get('outcome_sample_weight',np.ones(len(y))),float).reshape(-1)
        if len(times)!=len(y): times=np.arange(len(y),dtype=np.int64)
        if len(sw)!=len(y): sw=np.ones(len(y),float)
        X=X[valid]; y=y[valid]; times=times[valid]; sw=sw[valid]
        if len(y)<max(100,int(self.config.get('outcome_model_min_rows',25))):
            return {'status':'outcome_accumulating','rows':int(len(y)),'required_rows':max(100,int(self.config.get('outcome_model_min_rows',25)))}
        old=self._load_path(self.outcome_model,'outcome')
        candidate,gate=self._temporal_candidate(X,y,times,sw,'outcome',old_model=old)
        if candidate is None:
            self._write_json(self.outcome_meta,{**self._read_json(self.outcome_meta,{}),'last_promotion_check':gate,'last_retrain_rejected_at':int(time.time())})
            return {'status':'outcome_promotion_rejected_or_accumulating','rows':int(len(y)),'validation':gate}
        self._save(self.outcome_model,candidate)
        self._write_json(self.outcome_meta,{'schema_version':self.MODEL_SCHEMA_VERSION,'status':'ready',
            'rows':int(len(y)),'updated':int(time.time()),'learning':'temporal_candidate_promotion',
            'classes':OUTCOME_NAMES,'target':'actual_trade_outcome_with_dynamic_protection_and_TP3_plus',
            'last_promotion_check':gate,'accuracy':None,
            'accuracy_note':'In-sample accuracy is intentionally not reported as model quality; promotion uses held-out balanced accuracy.'})
        return {'status':'outcome_candidate_promoted','rows':int(len(y)),'validation':gate}

    def learn_from_resolved(self, rows):
        """Teach the Master which of the eight Master+lens combinations was best.

        C1/C2/C3 remain fixed. The only trainable decision head is the Master-owned
        combination selector. Every candidate combination is evaluated on the same
        realized price path; the resulting label is the learning target.
        """
        valid = []
        ambiguous_rows = 0
        for x in rows:
            outcomes = x.get('combination_outcomes') or {}
            if not x.get('lens_performance_snapshot') or not all(k in outcomes for k in COMBINATION_KEYS):
                continue
            try:
                scores = [self.outcome_score(outcomes[name]) for name in COMBINATION_KEYS]
                best_score = max(scores)
                winners = [i for i, score in enumerate(scores) if score == best_score]
                # Do not manufacture a MASTER label from argmax's first-item tie break.
                # Selector learns only from rows where one combination actually did better.
                if len(winners) != 1:
                    ambiguous_rows += 1
                    continue
                best = int(winners[0])
                v = self._selector_vector(
                    x.get('features') and {'features': x.get('features')} or x,
                    np.asarray([float(x.get('master_p_short', 0.0)), float(x.get('master_p_wait', 0.0)), float(x.get('master_p_long', 0.0))]),
                    {k: {'probs': np.asarray([float(x.get(f'{k}_p_short', 0.0)), float(x.get(f'{k}_p_wait', 0.0)), float(x.get(f'{k}_p_long', 0.0))])} for k in ('c1','c2','c3')},
                    float(x.get('math_consensus', 0.0) or 0.0), x.get('lens_performance_snapshot'))
                valid.append((v, best, best_score, int(x.get('time', 0) or 0)))
            except Exception:
                continue
        cap = max(500, int(self.config.get('master_decision_experience_max', 12000)))
        old = None
        if self.meta_experience.exists():
            try:
                with np.load(self.meta_experience, allow_pickle=False) as z:
                    # Selector schema 4 intentionally discards legacy rows whose ties
                    # were silently labeled MASTER by np.argmax.
                    schema = int(np.asarray(z['schema_version']).reshape(-1)[0]) if 'schema_version' in z.files else -1
                    if schema == self.SELECTOR_SCHEMA_VERSION:
                        old = {k: z[k] for k in z.files}
                if old is not None and (old.get('X') is None or np.asarray(old['X']).ndim != 2 or np.asarray(old['X']).shape[1] != len(self.META_NAMES)):
                    old = None
                if old is not None:
                    old['X'] = self._sanitize_selector_market_columns(old['X'])
            except Exception:
                old = None
        if not valid and old is None:
            empty_X = np.empty((0, len(self.META_NAMES)), dtype=np.float32)
            np.savez(self.meta_experience, X=empty_X, y=np.empty(0, dtype=np.int8),
                     sample_weight=np.empty(0, dtype=np.float32), time=np.empty(0, dtype=np.int64),
                     schema_version=np.asarray([self.SELECTOR_SCHEMA_VERSION], dtype=np.int16))
            return {'status': 'no_unique_combination_winners', 'new_unique_rows': 0,
                    'ambiguous_rows_skipped': ambiguous_rows, 'rows': 0}
        X = np.asarray([a for a, _, _, _ in valid], dtype=np.float32).reshape((-1, len(self.META_NAMES)))
        y = np.asarray([b for _, b, _, _ in valid], dtype=np.int8)
        sw = np.asarray([1.0 + 0.20 * c for _, _, c, _ in valid], dtype=np.float32)
        times = np.asarray([t for _, _, _, t in valid], dtype=np.int64)
        if old is not None:
            X = np.concatenate([old['X'], X]); y = np.concatenate([old['y'], y])
            old_sw = np.asarray(old.get('sample_weight', np.ones(len(old['y']))), float)
            if len(old_sw) != len(old['y']): old_sw = np.ones(len(old['y']), float)
            old_times = np.asarray(old.get('time', np.zeros(len(old['y']), dtype=np.int64)), dtype=np.int64)
            if len(old_times) != len(old['y']): old_times = np.zeros(len(old['y']), dtype=np.int64)
            sw = np.concatenate([old_sw, sw]); times = np.concatenate([old_times, times])
        X = self._sanitize_selector_market_columns(X)
        order = np.argsort(times, kind='stable')
        X, y, sw, times = X[order], y[order], sw[order], times[order]
        if len(X) > cap:
            X = X[-cap:]; y = y[-cap:]; sw = sw[-cap:]; times = times[-cap:]
        np.savez(self.meta_experience, X=X, y=y, sample_weight=sw, time=times, schema_version=np.asarray([self.SELECTOR_SCHEMA_VERSION], dtype=np.int16))
        if len(np.unique(y)) < 2:
            return {'status': 'selector_accumulating_class_diversity', 'rows': int(len(X)),
                    'new_unique_rows': int(len(valid)), 'ambiguous_rows_skipped': ambiguous_rows,
                    'class_count': int(len(np.unique(y)))}
        min_rows = max(25, int(self.config.get('master_decision_min_rows', 25)))
        if len(X) < min_rows:
            return {'status': 'combination_learning_accumulating', 'rows': int(len(X))}
        m = self._load_path(self.master_decision, 'selector')
        if m is None:
            m = self._new_decision()
            m.fit(X, y, epochs=int(self.config.get('master_decision_epochs', 80)), learning_rate=float(self.config.get('master_decision_learning_rate', .01)), l2=float(self.config.get('master_decision_l2', .001)), sample_weights=sw)
            learning = 'initial'
        else:
            m.fit_incremental(X, y, epochs=int(self.config.get('master_decision_epochs_incremental', 35)), learning_rate=float(self.config.get('master_decision_learning_rate_incremental', .005)), l2=float(self.config.get('master_decision_l2', .001)), sample_weights=sw)
            learning = 'incremental'
        self._save(self.master_decision, m)
        p = m.predict(X); acc = float(np.mean(p == y)) if len(y) else 0.0
        validation = self._selector_temporal_validation(X, y, sw, times)
        min_delta = float(self.config.get('master_decision_min_accuracy_delta', 0.02))
        selector_validated = bool(validation.get('status') == 'ok' and
                                  float(validation.get('accuracy_minus_baseline', -1.0)) >= min_delta)
        status = 'ready' if selector_validated else ('validation_failed' if validation.get('status') == 'ok' else 'accumulating_validation')
        counts = {COMBINATION_NAMES[i]: int(np.sum(y == i)) for i in range(8)}
        self._write_json(self.master_decision_meta, {
            'schema_version': self.SELECTOR_SCHEMA_VERSION, 'status': status, 'rows': int(len(X)), 'accuracy': acc,
            'updated': int(time.time()), 'features': self.META_NAMES, 'learning': learning,
            'target': 'best_master_lens_combination_by_real_trade_outcome', 'combination_counts': counts,
            'fixed_lenses': ['C1','C2','C3'], 'combination_count': 8,
            'validation_rows': int(validation.get('validation_rows', 0) or 0),
            'validation_accuracy': validation.get('accuracy'),
            'validation_baseline_accuracy': validation.get('baseline_accuracy'),
            'validation_accuracy_minus_baseline': validation.get('accuracy_minus_baseline'),
            'validation_balanced_accuracy': validation.get('balanced_accuracy'),
            'validation_status': validation.get('status'),
            'validation_train_rows': int(validation.get('train_rows', 0) or 0),
            'validation_purge_gap': int(validation.get('purge_gap', 0) or 0),
        })
        return {'status': 'combination_selector_updated' if selector_validated else status,
                'rows': int(len(X)), 'new_unique_rows': int(len(valid)),
                'ambiguous_rows_skipped': ambiguous_rows, 'accuracy': acc, 'validation': validation,
                'combination_counts': counts}
