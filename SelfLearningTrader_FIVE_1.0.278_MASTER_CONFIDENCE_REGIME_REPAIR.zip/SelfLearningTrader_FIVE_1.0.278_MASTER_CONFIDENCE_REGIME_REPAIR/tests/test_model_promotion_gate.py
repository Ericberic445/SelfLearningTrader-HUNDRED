import numpy as np
from app.core.model import ModelManager


def test_temporal_candidate_gate_refuses_small_samples(tmp_path):
    mm = ModelManager(tmp_path, config={"horizon_bars": 12})
    n = 80
    X = np.zeros((n, len(mm._new().weights)))
    y = np.arange(n) % 3
    times = np.arange(n, dtype=np.int64) * 300
    weights = np.ones(n)
    candidate, report = mm._temporal_candidate(X, y, times, weights, "direction")
    assert candidate is None
    assert report["status"] == "validation_accumulating"
    assert report["required_rows"] == 100


def test_temporal_candidate_gate_records_purged_holdout_and_baseline(tmp_path):
    mm = ModelManager(tmp_path, config={"horizon_bars": 12, "master_epochs": 100,
                                         "master_learning_rate": 0.03,
                                         "model_promotion_min_balanced_lift": 0.0})
    rng = np.random.default_rng(7)
    n = 240
    X = rng.normal(0, 0.2, (n, len(mm._new().weights)))
    # A stable, causal signal makes the temporal candidate testable.
    X[:, 0] = np.linspace(-2, 2, n)
    y = np.where(X[:, 0] < -0.45, 0, np.where(X[:, 0] > 0.45, 2, 1))
    times = np.arange(n, dtype=np.int64) * 300
    weights = np.ones(n)
    candidate, report = mm._temporal_candidate(X, y, times, weights, "direction")
    assert report["validation_rows"] > 0
    assert report["train_rows"] + report["validation_rows"] < n
    assert report["candidate_saved_without_holdout_rows"] is True
    assert report["test_start_time"] == int(times[int(n * 0.8)])
    assert report["status"] in ("accepted", "rejected")
    if candidate is not None:
        assert candidate.n_classes == 3


def test_direction_candidate_below_majority_accuracy_baseline_is_rejected(tmp_path):
    mm = ModelManager(tmp_path, config={"horizon_bars": 1, "model_validation_fraction": 0.2,
                                         "model_promotion_min_balanced_lift": 0.0,
                                         "model_promotion_min_accuracy_lift": 0.0,
                                         "direction_min_class_recall": 0.0,
                                         "direction_min_predicted_class_fraction": 0.0})

    class FixedModel:
        n_classes = 3
        def fit(self, X, y, **kwargs): return self
        def predict(self, X):
            # Balanced predictions, but deliberately worse ordinary accuracy
            # than the SHORT-majority validation cohort.
            return np.tile(np.asarray([0, 0, 1, 2, 1, 0]), int(np.ceil(len(X)/6)))[:len(X)]

    mm._new = lambda: FixedModel()
    n = 240
    X = np.zeros((n, len(mm._new().weights) if hasattr(mm._new(), 'weights') else 30))
    y = np.tile(np.asarray([0, 0, 0, 0, 1, 2]), 40)
    times = np.arange(n, dtype=np.int64) * 300
    candidate, report = mm._temporal_candidate(X, y, times, np.ones(n), 'direction')
    assert report['candidate_accuracy'] < report['baseline_accuracy']
    assert candidate is None
    assert report['status'] == 'rejected'


def test_master_validation_guard_requires_wait_while_accepted_master_loses_to_baseline(tmp_path):
    mm = ModelManager(tmp_path, config={'master_validation_guard_confidence': 0.55,
                                         'master_validation_guard_edge': 0.06})
    mm._write_json(mm.meta, {'last_accepted_promotion_check': {
        'candidate_accuracy': 0.3992, 'baseline_accuracy': 0.4535
    }})
    guard = mm._master_validation_guard()
    assert guard['active'] is True
    assert guard['reason'] == 'accepted_master_below_majority_accuracy_baseline'
    mm._write_json(mm.meta, {'last_accepted_promotion_check': {
        'candidate_accuracy': 0.51, 'baseline_accuracy': 0.45
    }})
    assert mm._master_validation_guard()['active'] is False


def test_direction_candidate_normalizes_batch_weight_scale_but_preserves_relative_weights(tmp_path):
    class RecordingCandidate:
        n_classes = 3
        def fit(self, X, y, sample_weights=None, **kwargs):
            self.sample_weights = np.asarray(sample_weights, float).copy()
            return self
        def predict(self, X):
            return np.zeros(len(X), dtype=int)

    mm = ModelManager(tmp_path, config={
        'horizon_bars': 1, 'model_validation_fraction': .2,
        'model_promotion_min_balanced_lift': 0.0,
        'model_promotion_min_accuracy_lift': 0.0,
        'direction_min_class_recall': 0.0,
        'direction_min_predicted_class_fraction': 0.0,
    })
    candidate = RecordingCandidate()
    mm._new = lambda: candidate
    n = 240
    X = np.zeros((n, len(mm._new().sample_weights) if hasattr(mm._new(), 'sample_weights') else 30))
    y = np.tile(np.asarray([0, 1, 2]), 80)
    times = np.arange(n, dtype=np.int64) * 300
    weights = np.tile(np.asarray([0.15, 1.0]), n // 2)
    mm._temporal_candidate(X, y, times, weights, 'direction')
    train_mean = float(np.mean(weights[:int(n * .8) - 1]))
    assert np.isclose(np.mean(candidate.sample_weights), 1.0)
    np.testing.assert_allclose(candidate.sample_weights, weights[:len(candidate.sample_weights)] / train_mean)
