import numpy as np
from app.core.features import FEATURES
from app.core.model import ModelManager
from app.core.engine import LearningEngine


def _market_rows(n=40):
    times=1_800_000_000 + np.arange(n,dtype=np.int64)*300
    close=100.0*np.exp(np.linspace(0.0,0.02,n))
    x={'time':times,'close':close,'high':close*1.002,'low':close*0.998}
    for i,name in enumerate(FEATURES):
        x[name]=np.full(n,(i+1)*0.001,dtype=float)
    x['book_imbalance']=np.full(n,0.8)
    x['oi_change']=np.full(n,0.4)
    x['funding']=np.full(n,0.02)
    x['liquidation_bias']=np.full(n,0.7)
    return x


def test_direction_pool_persists_only_completed_fixed_horizon_rows(tmp_path):
    mm=ModelManager(tmp_path,'XBTUSDTM',{})
    x=_market_rows(40)
    first=mm.update_direction_training(x,'BTCUSDTM',horizon_bars=12,
                                        long_threshold=0.003,short_threshold=-0.003)
    assert first['status']=='direction_pool_updated'
    pool=mm.load_direction_training_pool()
    assert len(pool['time'])==28
    assert np.all(pool['resolved_time']-pool['time']==3600)
    assert set(np.unique(pool['experience_kind']).tolist())=={'HISTORICAL_CANDLE'}
    for name in ('book_imbalance','oi_change','funding','liquidation_bias'):
        assert np.all(pool[name]==0.0)
    second=mm.update_direction_training(x,'BTCUSDTM',horizon_bars=12,
                                        long_threshold=0.003,short_threshold=-0.003)
    assert second['status']=='direction_pool_unchanged'
    assert len(mm.load_direction_training_pool()['time'])==28


def test_direction_training_builder_merges_pool_and_only_fixed_horizon_online(tmp_path):
    mm=ModelManager(tmp_path,'XBTUSDTM',{})
    x=_market_rows(40)
    mm.update_direction_training(x,'BTCUSDTM',horizon_bars=12,
                                  long_threshold=0.003,short_threshold=-0.003)
    engine=object.__new__(LearningEngine)
    engine.mm=mm
    engine.cfg={'horizon_bars':12,'direction_horizon_tolerance_seconds':1800}
    n=3
    exp={
        'time':np.asarray([1_800_000_000,1_800_000_000,1_800_000_000]),
        'resolved_time':np.asarray([1_800_003_600,1_800_003_600,1_800_000_100]),
        'contract':np.asarray(['ETHUSDTM']*3),
        'prediction_id':np.asarray(['a','b','c']),
        'target':np.asarray([2,0,1],dtype=np.int8),
        'sample_weight':np.asarray([0.15,0.15,1.0],dtype=np.float32),
        'experience_kind':np.asarray(['ONLINE_DIRECTION_OBSERVATION','ONLINE_DIRECTION_OBSERVATION','TRADE']),
    }
    for name in FEATURES:
        exp[name]=np.zeros(n,dtype=np.float32)
    result=engine._experience_for_direction_training(exp)
    # 28 completed historical candle labels + two valid one-hour online labels.
    assert len(result['target'])==30
    assert int(np.sum(result['experience_kind']=='HISTORICAL_CANDLE'))==28
    assert int(np.sum(result['experience_kind']=='ONLINE_DIRECTION_OBSERVATION'))==2
    assert not np.any(result['experience_kind']=='TRADE')


def test_master_retraining_waits_for_minimum_cross_contract_coverage(tmp_path):
    mm=ModelManager(tmp_path,'XBTUSDTM',{
        'direction_min_training_rows':10,
        'direction_min_training_contracts':5,
    })
    n=20
    x={'target':np.asarray([0,1,2,0,1]*4,dtype=np.int8),
       'time':np.arange(n,dtype=np.int64)+1_800_000_000,
       'resolved_time':np.arange(n,dtype=np.int64)+1_800_003_600,
       'contract':np.asarray(['BTCUSDTM']*n),
       'sample_weight':np.ones(n,dtype=np.float32)}
    for name in FEATURES:
        x[name]=np.linspace(0,1,n,dtype=np.float32)
    result=mm.train_master_incremental(x,min_rows=10)
    assert result['status']=='not_enough_direction_training_contracts'
    assert result['contracts']==1
    assert result['required_contracts']==5
    assert not mm.champion.exists()
