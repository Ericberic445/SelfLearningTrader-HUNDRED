from app.core.engine import LearningEngine

def test_initial_sl_wins_when_tp1_and_sl_are_inside_same_candle():
    out=LearningEngine._resolve_lens_plan(
        {'prediction':'LONG','entry':100,'sl':95,'tp1':105,'tp2':110,'tp3':115},
        [106],[94])
    assert out['sl_hit'] is True
    assert out['tp1_hit'] is False
    assert out['result']=='SL'

def test_existing_breakeven_stop_wins_ambiguous_tp2_candle():
    out=LearningEngine._resolve_lens_plan(
        {'prediction':'LONG','entry':100,'sl':95,'tp1':105,'tp2':110,'tp3':115},
        [106,112],[100.5,99], recheck_bars=3)
    # TP1 is confirmed on bar one. On bar two both TP2 and breakeven are
    # inside the candle, so the existing protective stop wins conservatively.
    assert out['tp1_hit'] is True
    assert out['tp2_hit'] is False
    assert out['protected_exit'] is True
