import numpy as np
from app.core.features import FEATURES
from app.core.model import ModelManager


class RecordingClassifier:
    n_classes = 3
    def fit(self, X, y, sample_weights=None, **kwargs):
        self.fit_X = np.asarray(X).copy()
        self.fit_y = np.asarray(y).copy()
        self.fit_sw = np.asarray(sample_weights).copy()
        return self
    def predict(self, X):
        return np.zeros(len(X), dtype=int)


def test_initial_training_sorts_time_and_uses_sample_weights(tmp_path):
    mm = ModelManager(tmp_path)
    recorder = RecordingClassifier()
    mm._new = lambda: recorder
    saved = {}
    mm._save = lambda path, model: saved.update(model=model)
    mm._write_json = lambda path, data: saved.update(meta=dict(data))
    mm.update_learning_state = lambda **kwargs: None
    mm._learning_state = lambda: {'resolved_total': 0}

    n = 600
    times = np.arange(1_800_000_000, 1_800_000_000 + n * 300, 300, dtype=np.int64)
    order = np.random.default_rng(42).permutation(n)
    x = {f: np.zeros(n, dtype=float) for f in FEATURES}
    x['ret1'] = times.astype(float)[order]
    x['target'] = (np.arange(n) % 3)[order]
    x['time'] = times[order]
    weights = np.linspace(0.05, 1.0, n)
    x['sample_weight'] = weights[order]

    meta = mm.train(x, min_rows=500, test_fraction=0.2, horizon_bars=12)
    assert meta['test_start_index'] == 480
    assert meta['train_rows'] == 468
    assert meta['purge_gap_rows'] == 12
    assert np.all(np.diff(recorder.fit_X[:, 0]) > 0)
    np.testing.assert_allclose(recorder.fit_sw, weights[:468])
