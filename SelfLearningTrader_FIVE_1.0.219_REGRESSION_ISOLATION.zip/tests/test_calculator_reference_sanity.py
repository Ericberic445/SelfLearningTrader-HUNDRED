import pytest
from app.core.calculator import calculate_position

def test_isolated_liquidation_is_on_loss_side_for_both_directions():
    long=calculate_position(100,100,10,direction='LONG',margin_mode='ISOLATED')
    short=calculate_position(100,100,10,direction='SHORT',margin_mode='ISOLATED')
    assert 0 < long['liquidation'] < 100
    assert short['liquidation'] > 100

def test_cross_requires_account_balance():
    with pytest.raises(ValueError):
        calculate_position(100,100,10,margin_mode='CROSS',balance=0)

def test_kucoin_published_isolated_long_example():
    out=calculate_position(30000,600,50,direction='LONG',margin_mode='ISOLATED',
                          multiplier=1.0,mmr=0.004,liquidation_fee=0.0006)
    assert out['liquidation'] == pytest.approx(29535.9, abs=0.2)

def test_short_liquidation_is_above_entry_in_both_modes():
    isolated=calculate_position(100,100,10,direction='SHORT',margin_mode='ISOLATED')
    cross=calculate_position(100,100,10,direction='SHORT',margin_mode='CROSS',balance=200)
    assert isolated['liquidation'] > 100
    assert cross['liquidation'] > 100


def test_liquidation_moves_further_with_lower_leverage_for_both_directions():
    long_10 = calculate_position(100, 100, 10, direction='LONG', margin_mode='ISOLATED')
    long_5 = calculate_position(100, 100, 5, direction='LONG', margin_mode='ISOLATED')
    short_10 = calculate_position(100, 100, 10, direction='SHORT', margin_mode='ISOLATED')
    short_5 = calculate_position(100, 100, 5, direction='SHORT', margin_mode='ISOLATED')
    assert long_5['liquidation'] < long_10['liquidation'] < 100
    assert short_5['liquidation'] > short_10['liquidation'] > 100


def test_calculator_rejects_invalid_fee_and_wrong_side_targets():
    with pytest.raises(ValueError, match='Taker fee'):
        calculate_position(100, 100, 10, taker_fee=1.0)
    with pytest.raises(ValueError, match='убыточной стороне'):
        calculate_position(100, 100, 10, direction='LONG', margin_mode='ISOLATED', sl=101)
    with pytest.raises(ValueError, match='последовательно расти'):
        calculate_position(100, 100, 10, direction='LONG', margin_mode='ISOLATED', tp1=110, tp2=109)
    with pytest.raises(ValueError, match='последовательно снижаться'):
        calculate_position(100, 100, 10, direction='SHORT', margin_mode='ISOLATED', tp1=90, tp2=91)


def test_higher_maintenance_and_liquidation_fees_move_liquidation_toward_entry():
    long_low = calculate_position(100, 100, 10, direction='LONG', margin_mode='ISOLATED', mmr=0.002, liquidation_fee=0.0002)
    long_high = calculate_position(100, 100, 10, direction='LONG', margin_mode='ISOLATED', mmr=0.01, liquidation_fee=0.001)
    short_low = calculate_position(100, 100, 10, direction='SHORT', margin_mode='ISOLATED', mmr=0.002, liquidation_fee=0.0002)
    short_high = calculate_position(100, 100, 10, direction='SHORT', margin_mode='ISOLATED', mmr=0.01, liquidation_fee=0.001)
    assert long_high['liquidation'] > long_low['liquidation']
    assert short_high['liquidation'] < short_low['liquidation']
    assert long_high['liq_distance_pct'] < long_low['liq_distance_pct']
    assert short_high['liq_distance_pct'] < short_low['liq_distance_pct']
