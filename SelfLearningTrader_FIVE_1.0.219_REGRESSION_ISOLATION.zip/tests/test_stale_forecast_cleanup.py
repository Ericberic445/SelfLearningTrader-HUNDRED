from app.core.engine import LearningEngine


def test_age_bars_supports_exchange_microseconds():
    now = 1_791_500_000.0
    created = int((now - 4 * 3600) * 1_000_000)
    assert LearningEngine._age_bars_from_now(created, now) == 48


def test_age_bars_supports_milliseconds_and_seconds():
    now = 1_791_500_000.0
    assert LearningEngine._age_bars_from_now(int((now - 600) * 1000), now) == 2
    assert LearningEngine._age_bars_from_now(int(now - 900), now) == 3


def test_pending_cleanup_keeps_only_unresolved_actionable_forecasts(tmp_path):
    import json
    from pathlib import Path
    engine = LearningEngine.__new__(LearningEngine)
    engine.logs = Path(tmp_path)
    engine.logs.mkdir(parents=True, exist_ok=True)
    path = engine.logs / 'AAAUSDTM_pending.json'
    path.write_text(json.dumps([
        {'id':'a','prediction':'LONG','resolved':False},
        {'id':'b','prediction':'SHORT','resolved':False},
        {'id':'c','prediction':'WAIT','resolved':False},
        {'id':'d','prediction':'LONG','resolved':True},
    ]), encoding='utf-8')
    removed = engine._cleanup_pending_files()
    kept = json.loads(path.read_text(encoding='utf-8'))
    assert removed == 2
    assert [x['id'] for x in kept] == ['a','b']
