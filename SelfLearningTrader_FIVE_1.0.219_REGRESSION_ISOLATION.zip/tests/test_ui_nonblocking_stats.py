from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = (ROOT / "app" / "main.py").read_text(encoding="utf-8")

def block(name, next_name):
    return SRC.split(f"    def {name}", 1)[1].split(f"    def {next_name}", 1)[0]

def test_model_statistics_are_computed_in_worker_thread():
    method = block("show_readiness(self, *_):", "_finish_readiness_load(self, data):")
    assert "threading.Thread(target=work" in method
    assert "engine.readiness()" in method
    assert "engine.detailed_stats()" in method

def test_dashboard_readiness_and_stats_do_not_run_on_ui_callback():
    method = block("_refresh_dashboard(self):", "_apply_dashboard_snapshot(self, snapshot):")
    assert "threading.Thread(target=work" in method
    assert "engine.readiness()" in method
    assert "engine.global_stats()" not in method

def test_menu_readiness_uses_cached_snapshot():
    method = block("_update_ready_menu_label(self):", "_hide_main_menu(self):")
    assert "self.engine.readiness()" not in method
    assert "_cached_readiness" in method

def test_top5_refresh_reads_only_selected_contract_files():
    method = block("_refresh_top5_status(self, rows):", "_top5_result_badge(self, row):")
    assert "self.engine.logs.glob('*_predictions.json')" not in method
    assert "f'{contract}_predictions.json'" in method

def test_analysis_statistics_are_computed_in_worker_thread():
    method = block("show_analysis(self):", "_finish_analysis_load(self, result):")
    assert "threading.Thread(target=work" in method
    assert "engine.stats()" in method
