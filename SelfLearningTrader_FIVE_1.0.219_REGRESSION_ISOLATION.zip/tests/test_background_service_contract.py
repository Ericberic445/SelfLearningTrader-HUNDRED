from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]

class BackgroundServiceContractTests(unittest.TestCase):
    def test_wakelock_uses_service_context_first(self):
        src = (ROOT / 'app' / 'services' / 'scanner.py').read_text(encoding='utf-8')
        fn = src.split('def acquire_wakelock():', 1)[1].split('\ndef ', 1)[0]
        self.assertIn("autoclass('org.kivy.android.PythonService')", fn)
        self.assertIn("getattr(PythonService, 'mService', None)", fn)
        self.assertIn('newWakeLock(1,', fn)
        self.assertIn('WakeLock acquire failed:', fn)

    def test_wakelock_attempt_happens_before_heavy_stack_imports(self):
        src = (ROOT / 'app' / 'services' / 'scanner.py').read_text(encoding='utf-8')
        main_start = src.index('def main():')
        service_init = src.index('PythonService.mService.setAutoRestartService(True)', main_start)
        startup_lock = src.index('wake_lock = acquire_wakelock()', service_init)
        heavy_import = src.index("from core.engine import LearningEngine", main_start)
        self.assertLess(startup_lock, heavy_import)

    def test_runtime_log_tail_is_bounded_and_compacted(self):
        src = (ROOT / 'app' / 'services' / 'scanner.py').read_text(encoding='utf-8')
        self.assertIn('MAX_RUNTIME_TAIL_LINES = 40', src)
        self.assertIn('MAX_RUNTIME_TAIL_LINE_CHARS = 600', src)
        self.assertIn('with STATE_LOCK:', src[src.index('def runtime_log('):src.index('def write_json(')])

    def test_service_recovery_does_not_stop_after_three_attempts(self):
        src = (ROOT / 'app' / 'main.py').read_text(encoding='utf-8')
        self.assertNotIn('после 3 безопасных попыток', src)
        self.assertIn('Повторное восстановление фонового сервиса', src)
        self.assertIn('heartbeat stale; compact state=', src)
        self.assertIn('service watchdog must run on every in-app screen', src)
        self.assertIn('self._battery_opt_prompt_attempted', src)
        self.assertIn('_start_foreground_scan(preserve_ui=True)', src)

    def test_stage25_does_not_fetch_unused_timeframes(self):
        src = (ROOT / 'app' / 'core' / 'engine.py').read_text(encoding='utf-8')
        block = src.split('    def _stage25_validate(', 1)[1].split('    def scan_all(', 1)[0]
        self.assertIn("base = ex.candles('5min', history)", block)
        self.assertNotIn("for tf in ('5min', '15min', '1hour', '4hour', '1day')", block)
        self.assertIn('scan_math_workers', block)

    def test_android_service_is_foreground_sticky_and_has_wakelock_permission(self):
        spec = (ROOT / 'buildozer.spec').read_text(encoding='utf-8')
        self.assertIn('WAKE_LOCK', spec)
        self.assertIn('services = scanner:services/scanner.py:foreground:sticky:', spec)

if __name__ == '__main__':
    unittest.main()
