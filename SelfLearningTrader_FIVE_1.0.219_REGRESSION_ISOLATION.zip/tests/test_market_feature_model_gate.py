import json
import numpy as np
from app.core.model import ModelManager


def test_unverified_market_metrics_cannot_change_fixed_lens_or_selector(tmp_path):
    mm = ModelManager(tmp_path)
    mm.meta.write_text(json.dumps({'market_features_mode': 'neutral'}), encoding='utf-8')
    mm._learning_state = lambda: {'base_version': 1}
    base = {'trend': 0.01, 'trend_15': 0.01, 'trend_1h': 0.02, 'trend_4h': 0.01,
            'trend_1d': 0.02, 'volatility': 0.01, 'volz': 0.3, 'rsi': 58,
            'bbpos': 0.6, 'book_imbalance': 0.1, 'oi_change': 0.0, 'funding': 0.0,
            'liquidation_bias': 0.0}
    changed = dict(base, oi_change=0.8, funding=-0.02, liquidation_bias=1.0)
    master = np.asarray([0.2, 0.2, 0.6])
    math_snapshot = {'math_markov': 0.2, 'math_hurst': 0.6, 'math_entropy': 0.4,
                     'math_fractal': 0.5, 'math_wavelet': 0.1, 'math_change_point': 0.2,
                     'math_ar': 0.1, 'math_arima': 0.1, 'math_sarima': 0.1,
                     'math_mean_reversion': 0.0, 'math_cointegration': 0.0,
                     'math_correlation': 0.0, 'math_trend_deviation': 0.0,
                     'math_return_vol_correlation': 0.0, 'math_bayesian': 0.5,
                     'math_kalman': 0.1, 'math_direction': 0.2,
                     'math_monte_carlo': 0.6, 'math_ptp1': 0.7, 'math_ptp2': 0.5,
                     'math_ptp3': 0.3, 'math_psl': 0.2, 'math_target_sign': 1.0}
    a = mm._fixed_lens(master, base, math_snapshot)
    b = mm._fixed_lens(master, changed, math_snapshot)
    for lens in ('c1', 'c2', 'c3'):
        np.testing.assert_allclose(a[lens]['probs'], b[lens]['probs'])
    va = mm._selector_vector(base, master, a, 0.0, performance_snapshot=[])
    vb = mm._selector_vector(changed, master, b, 0.0, performance_snapshot=[])
    np.testing.assert_allclose(va, vb)


def test_selector_replay_market_columns_are_neutralized_when_unavailable(tmp_path):
    mm = ModelManager(tmp_path)
    mm.meta.write_text(json.dumps({'market_features_mode': 'neutral'}), encoding='utf-8')
    X = np.ones((3, len(mm.META_NAMES)), dtype=float)
    for name in ('oi_change','funding','liquidation_bias'):
        X[:, mm.META_NAMES.index(name)] = 0.7
    sanitized = mm._sanitize_selector_market_columns(X)
    for name in ('oi_change','funding','liquidation_bias'):
        np.testing.assert_allclose(sanitized[:, mm.META_NAMES.index(name)], 0.0)
    assert np.all(X[:, mm.META_NAMES.index('oi_change')] == 0.7)  # source remains unchanged
