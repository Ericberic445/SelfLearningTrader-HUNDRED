import numpy as np
from unittest.mock import patch
from app.core.engine import LearningEngine
from app.core.math_models import MATH_FEATURES


class FakeExchange:
    calls = 0
    def __init__(self, symbol='XBTUSDTM', timeout=25):
        self.timeout = timeout
        self.futures_symbol = symbol
    def set_symbol(self, symbol):
        self.futures_symbol = symbol
    def candles(self, tf, limit=5000):
        type(self).calls += 1
        n = 120
        return {'time': np.arange(n), 'close': np.linspace(100, 110, n),
                'high': np.linspace(101, 111, n), 'low': np.linspace(99, 109, n),
                'volume': np.ones(n)}


class FakeModel:
    def predict_bundle(self, row, consensus, math_snapshot):
        return 'WAIT', np.asarray([0.1, 0.8, 0.1]), {}
    def prediction_diagnostics(self, *args):
        return {}


def _math_snapshot(*args, **kwargs):
    out = {k: 0.5 for k in MATH_FEATURES}
    out.update({'math_direction': 0.2, 'math_consensus': 0.3, 'math_target_sign': 1.0})
    return out


def test_stage25_reuses_cached_candles_and_clears_directional_tp_sl_for_wait():
    FakeExchange.calls = 0
    engine = LearningEngine.__new__(LearningEngine)
    engine.exchange = FakeExchange()
    engine.cfg = {'scan_model_request_gap': 0.0, 'scan_math_workers': 1, 'horizon_bars': 12}
    engine.mm = FakeModel()
    engine._math_method_scores = lambda m, direction: {'fake': 0.5}
    engine._signal_levels = lambda row, pred: (110.0, float('nan'), float('nan'), float('nan'), float('nan'))
    engine._attach_lens_plans = lambda row: row
    cached = {'time': np.arange(120), 'close': np.linspace(100, 110, 120),
              'high': np.linspace(101, 111, 120), 'low': np.linspace(99, 109, 120),
              'volume': np.ones(120)}
    row = {'contract': 'AAAUSDTM', 'symbol': 'AAA-USDT', 'prediction': 'LONG',
           'price': 110.0, 'edge_score': 0.4, 'quality': 0.8,
           'p_short': 0.2, 'p_wait': 0.3, 'p_long': 0.5,
           'features': {'atrpct': 0.01}, '_stage25_base': cached}
    with patch('app.core.exchange.KuCoin', FakeExchange), patch('app.core.engine.compute_math_snapshot', _math_snapshot):
        out = engine._stage25_validate([row])
    assert len(out) == 1
    assert out[0]['prediction'] == 'WAIT'
    assert out[0]['p_tp1'] is None and out[0]['p_tp2'] is None
    assert out[0]['p_tp3'] is None and out[0]['p_sl'] is None
    assert out[0]['math_method_scores'] == {}
    assert '_stage25_base' not in out[0]
    # One benchmark candle request only; the candidate reused its cached history.
    assert FakeExchange.calls == 1
