import numpy as np
import pytest
from app.core.features import _nearest_values

@pytest.mark.parametrize('scale', [1, 1_000, 1_000_000])
def test_mtf_alignment_handles_seconds_milliseconds_and_microseconds(scale):
    # Same two hourly candle-open timestamps, expressed in each supported unit.
    start = 1_800_000_000 * scale
    src = np.asarray([start, start + 3600 * scale], dtype=np.int64)
    target = np.asarray([
        start + 900 * scale,       # first candle is still forming
        start + 3600 * scale,      # first candle has just closed
        start + 3601 * scale,      # still only first closed candle is available
        start + 7200 * scale,      # second candle has just closed
    ], dtype=np.int64)
    got = _nearest_values(target, src, {'time': src, 'rsi': np.asarray([11., 22.])}, 3600)['rsi']
    assert np.isnan(got[0])
    assert got[1] == 11.
    assert got[2] == 11.
    assert got[3] == 22.


def test_mtf_alignment_does_not_use_future_source_row():
    src = np.asarray([1_800_000_000_000, 1_800_003_600_000], dtype=np.int64)
    target = np.asarray([1_800_003_599_999], dtype=np.int64)
    got = _nearest_values(target, src, {'time': src, 'trend': np.asarray([0.1, 0.9])}, 3600)['trend']
    assert np.isnan(got[0])
