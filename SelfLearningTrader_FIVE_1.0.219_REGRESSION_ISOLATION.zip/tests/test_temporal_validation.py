import numpy as np
from app.core.engine import _purged_temporal_split_indices


def test_validation_embargo_uses_time_not_only_row_count():
    # Multiple contracts can share a candle timestamp. All rows in the embargo
    # interval must stay out of training regardless of how many symbols exist.
    times = np.repeat(np.arange(100, dtype=np.int64) * 300, 3)
    train, test, test_start, embargo = _purged_temporal_split_indices(
        times, test_fraction=0.2, gap_seconds=3600)
    assert len(test) > 0
    assert embargo == 3600
    assert np.all(times[test] >= test_start)
    assert np.all(times[train] < test_start - embargo)
    assert not set(times[train]).intersection(set(times[test]))
    assert len(train) < 240  # the 12-bar temporal embargo removes 12 timestamps


def test_validation_embargo_supports_millisecond_and_microsecond_timestamps():
    for scale in (1_000, 1_000_000):
        times = np.arange(100, dtype=np.int64) * 300 * scale + 1_800_000_000 * scale
        train, test, test_start, embargo = _purged_temporal_split_indices(
            times, test_fraction=0.2, gap_seconds=3600)
        assert embargo == 3600 * scale
        assert np.max(times[train]) < test_start - embargo
        assert np.min(times[test]) >= test_start


def test_readiness_uses_independent_model_quality_not_legacy_wait_flag(tmp_path):
    import json
    from pathlib import Path
    from app.core.engine import LearningEngine

    root = Path(tmp_path)
    logs = root / 'logs'; logs.mkdir()
    rows = [{'id': f'p{i}', 'resolved': True, 'prediction': 'LONG',
             'tp1_hit': True, 'sl_hit': False, 'initial_sl_failure': False}
            for i in range(1000)]
    (logs / 'AAAUSDTM_predictions.json').write_text(json.dumps(rows), encoding='utf-8')
    meta_dir = root / 'models_v8_self_learning' / 'AAAUSDTM'; meta_dir.mkdir(parents=True)
    # Deliberately omit legacy not_wait_machine metadata. It must not be the gate.
    (meta_dir / 'champion.json').write_text(json.dumps({
        'accepted': True, 'test_rows': 1000, 'balanced_accuracy': 0.8,
        'directional_precision': 0.95, 'action_rate': 0.8,
        'balanced_accuracy_minus_baseline': 0.10,
        'outcome_validation_rows': 100, 'outcome_accuracy_minus_baseline': 0.10,
    }), encoding='utf-8')

    engine = LearningEngine.__new__(LearningEngine)
    engine.root = root; engine.logs = logs
    engine.cfg = {'readiness_min_resolved': 1000, 'readiness_min_validation_rows': 1000,
                  'readiness_min_balanced_accuracy': 0.60, 'readiness_min_directional_precision': 0.65,
                  'readiness_min_action_rate': 0.10, 'readiness_min_recent_directional_accuracy': 0.90,
                  'readiness_min_tp1_rate': 0.90, 'readiness_max_sl_rate': 0.10,
                  'readiness_min_accuracy': 0.90, 'readiness_min_recent_accuracy': 0.90,
                  'readiness_min_model_test_rows': 50}
    engine.global_stats = lambda: {'resolved': 1000, 'accuracy': 1.0}
    engine._training_state = lambda: {'retrain_batches': 1}
    result = engine.readiness()
    assert result['ready'] is True
    assert result['accepted_models'] == 1


def test_readiness_rejects_model_with_too_few_directional_actions(tmp_path):
    import json
    from pathlib import Path
    from app.core.engine import LearningEngine

    root = Path(tmp_path)
    logs = root / 'logs'; logs.mkdir()
    rows = [{'id': f'p{i}', 'resolved': True, 'prediction': 'LONG',
             'tp1_hit': True, 'sl_hit': False, 'initial_sl_failure': False}
            for i in range(1000)]
    (logs / 'AAAUSDTM_predictions.json').write_text(json.dumps(rows), encoding='utf-8')
    meta_dir = root / 'models_v8_self_learning' / 'AAAUSDTM'; meta_dir.mkdir(parents=True)
    (meta_dir / 'champion.json').write_text(json.dumps({
        'accepted': True, 'test_rows': 1000, 'balanced_accuracy': 0.8,
        'directional_precision': 0.95, 'action_rate': 0.01,
    }), encoding='utf-8')
    engine = LearningEngine.__new__(LearningEngine)
    engine.root = root; engine.logs = logs
    engine.cfg = {'readiness_min_resolved': 1000, 'readiness_min_validation_rows': 1000,
                  'readiness_min_balanced_accuracy': 0.60, 'readiness_min_directional_precision': 0.65,
                  'readiness_min_action_rate': 0.10, 'readiness_min_recent_directional_accuracy': 0.90,
                  'readiness_min_tp1_rate': 0.90, 'readiness_max_sl_rate': 0.10,
                  'readiness_min_accuracy': 0.90, 'readiness_min_recent_accuracy': 0.90,
                  'readiness_min_model_test_rows': 50}
    engine.global_stats = lambda: {'resolved': 1000, 'accuracy': 1.0}
    engine._training_state = lambda: {'retrain_batches': 1}
    result = engine.readiness()
    assert result['ready'] is False
    assert result['action_rate'] < engine.cfg['readiness_min_action_rate']


def test_readiness_rejects_model_that_does_not_beat_baseline(tmp_path):
    import json
    from pathlib import Path
    from app.core.engine import LearningEngine

    root = Path(tmp_path)
    logs = root / 'logs'; logs.mkdir()
    rows = [{'id': f'p{i}', 'resolved': True, 'prediction': 'LONG',
             'tp1_hit': True, 'sl_hit': False, 'initial_sl_failure': False}
            for i in range(1000)]
    (logs / 'AAAUSDTM_predictions.json').write_text(json.dumps(rows), encoding='utf-8')
    meta_dir = root / 'models_v8_self_learning' / 'AAAUSDTM'; meta_dir.mkdir(parents=True)
    (meta_dir / 'champion.json').write_text(json.dumps({
        'accepted': True, 'test_rows': 1000, 'balanced_accuracy': 0.8,
        'directional_precision': 0.95, 'action_rate': 0.8,
        'balanced_accuracy_minus_baseline': -0.02,
        'outcome_validation_rows': 100, 'outcome_accuracy_minus_baseline': 0.10,
    }), encoding='utf-8')
    engine = LearningEngine.__new__(LearningEngine)
    engine.root = root; engine.logs = logs
    engine.cfg = {'readiness_min_resolved': 1000, 'readiness_min_validation_rows': 1000,
                  'readiness_min_balanced_accuracy': 0.60, 'readiness_min_directional_precision': 0.65,
                  'readiness_min_action_rate': 0.10, 'readiness_min_recent_directional_accuracy': 0.90,
                  'readiness_min_tp1_rate': 0.90, 'readiness_max_sl_rate': 0.10,
                  'readiness_min_accuracy': 0.90, 'readiness_min_recent_accuracy': 0.90,
                  'readiness_min_model_test_rows': 50}
    engine.global_stats = lambda: {'resolved': 1000, 'accuracy': 1.0}
    engine._training_state = lambda: {'retrain_batches': 1}
    result = engine.readiness()
    assert result['ready'] is False
    assert 'модель превосходит базовый прогноз' in result['reasons']


def test_outcome_validation_fits_only_on_purged_training_rows(tmp_path):
    from app.core.features import FEATURES
    from app.core.engine import LearningEngine

    class Recorder:
        def __init__(self, n_classes):
            self.n_classes = n_classes
            self.fit_rows = None
        def fit(self, X, y, **kwargs):
            self.fit_rows = len(y)
            return self
        def predict(self, X):
            return np.zeros(len(X), dtype=int)

    class FakeMM:
        def __init__(self): self.direction = Recorder(3); self.outcome = Recorder(5); self.meta = 'unused'
        def _read_json(self, *args): return {'market_features_mode':'neutral'}
        def _new(self): return self.direction
        def _new_outcome(self): return self.outcome
        def _scores(self, y, p):
            acc = float(np.mean(y == p)) if len(y) else 0.0
            classes = sorted(set(y.tolist()))
            bal = float(np.mean([np.mean(p[y == c] == c) for c in classes])) if classes else 0.0
            act = p != 1
            dp = float(np.mean(p[act] == y[act])) if np.any(act) else 0.0
            return acc, bal, [], dp, float(np.mean(act)) if len(act) else 0.0
        def _load_path(self, *args):
            raise AssertionError('validation must not load a persisted outcome model trained on the holdout')

    n = 600
    times = 1_800_000_000_000 + np.arange(n, dtype=np.int64) * 300_000
    exp = {'time': times, 'contract': np.asarray(['AAAUSDTM'] * n),
           'target': (np.arange(n) % 3).astype(np.int8),
           'outcome_target': (np.arange(n) % 5).astype(np.int8),
           'sample_weight': np.ones(n), 'outcome_sample_weight': np.ones(n)}
    for feature in FEATURES:
        exp[feature] = np.linspace(-0.1, 0.1, n)

    engine = LearningEngine.__new__(LearningEngine)
    engine.mm = FakeMM()
    engine.cfg = {'test_fraction':0.2, 'horizon_bars':12, 'validation_min_rows':100,
                  'validation_min_train_rows':100, 'validation_epochs':1,
                  'validation_min_outcome_train_rows':50}
    engine._load_exp = lambda: exp
    result = engine._recompute_validation()
    assert result['status'] == 'ok'
    assert result['outcome_validation_rows'] >= 25
    assert engine.mm.outcome.fit_rows < result['rows'] * 0.8
    assert result['outcome_accuracy'] is not None
    assert result['outcome_baseline_accuracy'] is not None
