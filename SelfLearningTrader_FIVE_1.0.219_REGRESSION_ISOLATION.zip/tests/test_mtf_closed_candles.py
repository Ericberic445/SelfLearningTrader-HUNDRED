import numpy as np
from app.core.features import _nearest_values

def test_higher_timeframe_candle_not_available_until_close():
    src_t=np.array([1_800_000_000_000_000, 1_800_003_600_000_000],dtype=np.int64)
    source={'time':src_t,'rsi':np.array([10.,20.])}
    target=np.array([1_800_000_900_000_000,1_800_003_600_000_000,1_800_003_600_001_000,1_800_007_200_000_000],dtype=np.int64)
    out=_nearest_values(target,src_t,source,3600)['rsi']
    assert np.isnan(out[0])
    assert out[1] == 10.0
    assert out[2] == 10.0
    assert out[3] == 20.0
