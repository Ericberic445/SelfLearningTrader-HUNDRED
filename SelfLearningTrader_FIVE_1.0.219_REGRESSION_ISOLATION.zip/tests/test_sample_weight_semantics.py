import numpy as np
from app.core.model import NumpyClassifier

def test_zero_weight_is_excluded_and_small_weight_not_raised():
    X=np.array([[0.0],[1.0],[2.0]])
    y=np.array([0,1,1])
    a=NumpyClassifier(1,2); b=NumpyClassifier(1,2)
    a.fit(X,y,epochs=2,sample_weights=[1.0,0.0,0.05])
    b.fit(X[[0,2]],y[[0,2]],epochs=2,sample_weights=[1.0,0.05])
    assert np.allclose(a.weights,b.weights)
    assert np.allclose(a.bias,b.bias)

def test_initial_training_uses_temporal_gap_and_baseline(tmp_path):
    from app.core.model import ModelManager
    from app.core.features import FEATURES
    manager=ModelManager(tmp_path, 'XBTUSDTM', {})
    n=600
    x={f:np.linspace(0,1,n) for f in FEATURES}
    x['target']=np.asarray(([0,1,2]*200),dtype=int)
    meta=manager.train(x,min_rows=500,test_fraction=.2,horizon_bars=12)
    assert meta['purge_gap_rows'] == 12
    assert meta['train_rows'] == 468
    assert meta['test_start_index'] == 480
    assert meta['test_rows'] == 120
    assert 0 <= meta['baseline_accuracy'] <= 1
    assert 0 <= meta['baseline_balanced_accuracy'] <= 1
    assert 0 <= meta['baseline_directional_precision'] <= 1
    assert 0 <= meta['baseline_action_rate'] <= 1
    assert meta['accuracy_minus_baseline'] == meta['accuracy'] - meta['baseline_accuracy']
