# SelfLearningTrader FIVE 1.0.217 — audit fixes and verification

## Scope
- Android UI files were not changed.
- Background-service implementation was deliberately not changed, per user instruction. Its device behavior remains unverified and is already reported by the user as not working.
- Saved runtime backup, training archives, previous source ZIPs, TOP-5 pipeline and established forecast outcome semantics are preserved.

## Code changes

1. **Scan cost and measurement**
   - Stage-25 math validation reuses the closed 5m candle frame already downloaded for a candidate, avoiding a duplicate history request for each finalist.
   - Kept the worker-local exchange/engine reuse and bounded parallel stages.
   - Added per-stage per-symbol/candidate timing and total symbols/second diagnostics.
   - Added a synthetic 700-contract scan regression test; this is a local scalability test, not a live KuCoin speed benchmark.

2. **Candle alignment and timestamps**
   - Retained closed-candle checks and seconds/milliseconds/microseconds support.
   - Added causal alignment for historical OI/funding snapshots: values are joined only when their timestamp is at or before the candle close.

3. **Training weights and temporal split**
   - Initial training now sorts rows by timestamp before splitting; previously merged experience could place old/new rows in a non-chronological order.
   - Initial training now passes sample weights to the classifier instead of silently ignoring them.
   - Existing zero/invalid-weight exclusion remains covered by tests.

4. **Independent model validation**
   - Preserved chronological holdout and purge/embargo.
   - Outcome-head validation now trains a temporary head only on the training period and evaluates it on untouched later outcomes; it no longer evaluates a persisted outcome model that may have already seen the holdout.
   - Stores majority-class baseline comparisons and requires readiness checks to include improvement over baseline for both direction and outcome validation.

5. **Market feature provenance**
   - Added public KuCoin historical OI and funding retrieval and causal alignment.
   - OI/funding are enabled only when historical coverage is sufficient and the model metadata records that mode. If unavailable, those features are neutralized consistently in training, inference, and selector replay rather than injecting live-only values.
   - Liquidation-side bias remains neutral because a validated aligned public history is not available in this implementation. Market-feature source/coverage/status is recorded for diagnosis.
   - Optional market-metric requests are single-attempt with a short timeout so a failed optional endpoint cannot consume the scanner's long retry schedule.

6. **Final direction consistency**
   - When Stage-25 changes the final signal, direction-conditioned math values are recomputed.
   - If the final signal is WAIT, TP/SL probability fields are null and nested direction-conditioned estimates are neutralized, rather than retaining values from the abandoned LONG/SHORT direction.
   - TOP-5 ranking safely handles unavailable TP probabilities.

7. **Liquidation calculator validation**
   - Added input validation for fee/MMR ranges, SL loss-side placement and monotonic TP order.
   - Added regression checks for published isolated LONG reference, LONG/SHORT liquidation side, leverage direction, and MMR/liquidation-fee effects.
   - CROSS remains a reference estimate for a single position; full account-level liquidation cannot be inferred without complete account positions/margin/risk-tier data.

8. **Readiness and diagnostics**
   - Readiness now includes baseline superiority and independently validated outcome-head quality, and uses the newer `validation_rows` count when available.
   - Scan diagnostics expose prescan/model/math time per symbol/candidate and market-feature status.
   - Pending-queue cleanup has a regression test confirming only unresolved LONG/SHORT forecasts remain queued.

## Verification
- `python -m compileall -q app tests` — passed.
- `PYTHONPATH=. pytest -q` — **72 passed, 9 subtests passed**.
- Synthetic 700-contract pipeline test passes and still produces exactly five unique TOP candidates.
- ZIP integrity is checked before delivery.
- Original backup/source archives are retained under `preserved_archives/`.

## Not claimed
- No GitHub Actions APK build or Android device test was run.
- No live full-market KuCoin benchmark was run; runtime logs are needed to measure real elapsed time and API error rates.
- The background service was not modified or fixed in this release.
- No claim is made that forecast probabilities are calibrated or profitable merely because unit tests pass.
