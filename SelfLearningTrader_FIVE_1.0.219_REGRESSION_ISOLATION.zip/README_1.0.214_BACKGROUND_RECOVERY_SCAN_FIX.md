# SelfLearningTrader FIVE 1.0.214 — background recovery and scan duration

This release targets the failures observed in the 2026-10-10 runtime backup.

## Findings addressed

- The UI heartbeat timeout diagnostic embedded the complete service state in the log. That state already contained the previous runtime log tail, so the tail recursively grew: the backup contained a 907,971-character log line and a 1,124,982-byte background state JSON.
- The UI stopped retrying service startup after three attempts, and the watchdog only checked service health while the scanner page was visible.
- Stage-25 fetched 5m, 15m, 1h, 4h and 1d candle histories for every finalist, but the calculations consumed only the 5m history and the shared BTC benchmark. Four timeframe fetches per finalist were unused.
- Stage-25 progress did not update while the expensive network work was running, making the scan appear stuck at 100%.
- The service reused the startup snapshot of TOP-5 state at later scan boundaries, which could roll the displayed cycle metadata back.

## Changes

- Runtime log tail is bounded to 40 lines / 600 characters per line. State updates are serialized with heartbeat updates and only the last 64 KiB of the log is read for the tail.
- Heartbeat-timeout diagnostics are compact and rate-limited. Unexpected stale/error/stopped service states trigger retry with backoff up to 60 seconds, until the user explicitly presses OFF.
- The service watchdog remains active on other in-app screens. Automatic recovery preserves the current screen instead of clearing/rebuilding scanner widgets. The Android battery-optimization prompt is attempted at most once per app process.
- Stage-25 now fetches only the 5m history it actually uses, and runs candidate validation with a bounded pool of three workers. The math formulas, input data used by those formulas, ranking criteria, and TOP-5 size are unchanged. Progress continues during this stage and OFF cancellation is checked.
- Each full scan and active-forecast recheck records elapsed time in the runtime log, so the next backup can confirm real cycle duration.
- Current service state is re-read at each scan boundary so the latest TOP-5 metadata is retained.

## Verification

- Python compile check passed.
- 36 unit tests passed, including a Stage-25 test that verifies only the consumed timeframe is requested and progress advances.
- Android device runtime still needs to be verified on the target phone; automated tests cannot prove that the Android OS/vendor will never kill a foreground service.
