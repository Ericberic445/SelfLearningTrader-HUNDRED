# SelfLearningTrader FIVE 1.0.216 — concrete audit work

## Scope preserved

The UI was not changed. TOP-5 scan stages and ranking, forecast/TP/SL tracking (including the existing same-candle conservative behavior), background service, OFF/resume behavior, and saved archives were not intentionally changed. Point 7 was explicitly left untouched. Point 5 (OI/funding/liquidation-side features) is also unchanged for a separate explanation and data-source decision later.

## Changes made

1. **Scan worker reuse:** pre-scan and deep model stage now reuse one `KuCoin` client and `LearningEngine` per worker thread. Stage-25 and active forecast rechecks reuse their exchange client per worker. No mutable engine is shared between threads. Existing request pacing and candidate ranking remain in place.
2. **Temporal validation:** `_recompute_validation` now splits global experience by chronological timestamp and applies a time-based embargo before the held-out period. It reports a clear insufficient-data status when the purged train/test sets are too small.
3. **Baseline reporting:** initial model training now stores majority-class baseline accuracy, balanced accuracy, directional precision, action rate, and model-minus-baseline deltas on the same temporal holdout. This adds evidence; it does not claim calibration or profitability.
4. **Regression tests:** added checks for timestamp units and closed-candle boundaries, time-based validation embargo across duplicate timestamps, readiness quality gates, and thread-local Stage-25 client reuse.

## Verification

- `python -m compileall -q app tests` — passed.
- `PYTHONPATH=. pytest -q` — **56 passed, 9 subtests passed**.
- Preserved source and runtime backup archives were checked by SHA-256 against the originals; hashes match exactly.
- ZIP integrity check is performed on the final package before delivery.

## Still not proven

- No live full scan across hundreds of KuCoin contracts was run in this workspace. The app already records per-stage scan timings; a real runtime log is needed to quantify the actual speed-up and identify remaining network bottlenecks.
- No Android device or GitHub Actions APK build was run. Host tests cannot prove locked-screen behavior, service recovery, or battery-vendor behavior.
- TP1/TP2/TP3/SL probability calibration (point 7) was not altered, as requested.
- OI/funding/liquidation-side history (point 5) remains deferred and must not be described as live verified data.
- Cross-margin liquidation remains reference-only for one position; exact cross liquidation depends on the account's complete positions, margin, risk tiers, and fees.
