# SelfLearningTrader FIVE 1.0.218 — responsiveness and scan retry bounds

- Moved model readiness and detailed-statistics file reads off the Kivy UI thread.
- Moved dashboard readiness calculations to a background worker and removed the duplicate global-statistics file scan.
- Cached readiness for menu labels and the TOP-5 request action so taps do not synchronously rescan all forecast files.
- Reduced dashboard polling frequency from 5 seconds to 15 seconds; manual refresh still requests an immediate refresh.
- Changed TOP-5 result merging to inspect only the contract-specific prediction files for displayed candidates, rather than every coin's history.
- Added scanner-specific HTTP timeout/retry bounds (default 8 seconds, 2 attempts) for quick scan, deep model scan, math validation, and freshness rechecks. Normal non-scan requests retain their existing retry policy.
- No layout or control placement changes.

The source-level regression suite passes. This does not replace validation on the Android device; the next run should confirm that Statistics opens, Refresh stays responsive, and the full scan reaches `FULL_SCAN_DONE` instead of remaining stuck in `MODEL`.
