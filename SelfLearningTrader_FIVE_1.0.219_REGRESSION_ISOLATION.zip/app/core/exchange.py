import json, os, ssl, time, urllib.parse, urllib.request, http.client, threading
import certifi

# Android often has no usable OpenSSL CA path for Python. Use the bundled Mozilla CA set.
_CA_BUNDLE = certifi.where()
os.environ.setdefault("SSL_CERT_FILE", _CA_BUNDLE)
os.environ.setdefault("REQUESTS_CA_BUNDLE", _CA_BUNDLE)
import numpy as np

BASE='https://api.kucoin.com'
FUTURES_BASE='https://api-futures.kucoin.com'
TF_SECONDS={'5min':300,'15min':900,'1hour':3600,'4hour':14400,'1day':86400}
TF_API={'5min':'5min','15min':'15min','1hour':'1hour','4hour':'4hour','1day':'1day'}


def _metric_rows(data):
    """Normalize KuCoin response containers for public market-metric endpoints."""
    if isinstance(data, dict):
        for key in ('data', 'items', 'list', 'records'):
            value = data.get(key)
            if isinstance(value, (list, tuple)):
                return list(value)
        return [data] if any(k in data for k in ('ts', 'timepoint', 'timestamp', 'openInterest', 'fundingRate', 'value')) else []
    return list(data) if isinstance(data, (list, tuple)) else []


def align_market_metric_history(candle_times, oi_rows, funding_rows, candle_seconds=300):
    """Causally align OI-change and funding snapshots to closed 5m candle times.

    `candle_times` are candle OPEN timestamps. Market data is joined at candle
    close using only snapshots whose timestamps are <= that close, so no future
    market snapshot can leak into a historical row.
    """
    target = np.asarray(candle_times, dtype=np.int64).reshape(-1)
    if not len(target):
        return {'oi_change': np.asarray([], float), 'funding': np.asarray([], float), 'coverage': 0.0}
    scale = 1_000_000 if np.max(np.abs(target)) > 10**14 else (1000 if np.max(np.abs(target)) > 10**11 else 1)
    close_times = target + int(candle_seconds) * scale

    oi = []
    for row in _metric_rows(oi_rows):
        try:
            ts = int(row.get('ts', row.get('time', row.get('timestamp', 0))))
            val = float(row.get('openInterest', row.get('value')))
            if ts > 0 and np.isfinite(val) and val > 0:
                oi.append((ts, val))
        except Exception:
            continue
    oi.sort()
    oi_times = np.asarray([x[0] for x in oi], dtype=np.int64)
    oi_vals = np.asarray([x[1] for x in oi], dtype=float)
    oi_change = np.full(len(target), np.nan, dtype=float)
    if len(oi) >= 2:
        idx = np.searchsorted(oi_times, close_times, side='right') - 1
        valid = idx >= 1
        ii = idx[valid]
        oi_change[valid] = oi_vals[ii] / np.maximum(oi_vals[ii - 1], 1e-12) - 1.0

    funding = []
    for row in _metric_rows(funding_rows):
        try:
            ts = int(row.get('timepoint', row.get('ts', row.get('timestamp', row.get('fundingTime', 0)))))
            val = float(row.get('fundingRate', row.get('value', row.get('nextFundingRate'))))
            if ts > 0 and np.isfinite(val):
                funding.append((ts, val))
        except Exception:
            continue
    funding.sort()
    funding_values = np.full(len(target), np.nan, dtype=float)
    if funding:
        ft = np.asarray([x[0] for x in funding], dtype=np.int64)
        fv = np.asarray([x[1] for x in funding], dtype=float)
        idx = np.searchsorted(ft, close_times, side='right') - 1
        valid = idx >= 0
        funding_values[valid] = fv[idx[valid]]
    valid_both = np.isfinite(oi_change) & np.isfinite(funding_values)
    coverage = float(np.mean(valid_both)) if len(target) else 0.0
    return {'oi_change': oi_change, 'funding': funding_values, 'coverage': coverage}

class KuCoin:
    def __init__(self,symbol='XBTUSDTM',timeout=25):
        self.timeout=timeout
        # Ordinary interactive/learning requests retain the resilient default.
        # The market scanner overrides these per-client so a single bad network
        # endpoint cannot hold a finalist worker for many minutes.
        self._max_attempts = 8
        self._retry_delays = (0.4, 0.8, 1.5, 2.5, 4.0, 6.0, 8.0)
        self.ctx=ssl.create_default_context(cafile=_CA_BUNDLE)
        self.ctx.check_hostname=True
        self.ctx.verify_mode=ssl.CERT_REQUIRED
        self._contract_cache={}
        self._market_metrics_cache={}
        self._last_open_interest={}
        self._market_metrics_status='not_checked'
        self._connections={}
        self._conn_lock=threading.Lock()
        self._last_request=0.0
        self._request_gap=0.10
        self.set_symbol(symbol)

    def set_symbol(self,symbol):
        s=str(symbol).strip().upper()
        if not s:
            s='XBTUSDTM'
        # KuCoin Futures uses XBTUSDTM as the BTC perpetual contract symbol.
        # The UI/config uses the human-readable BTC-USDT name, so normalize
        # both directions here. Without this mapping BTC-USDT became
        # BTCUSDTM, which is not a valid KuCoin Futures contract and caused
        # empty 5m candle responses.
        if s in ('BTC-USDT','BTCUSDT','BTCUSDTM'):
            self.futures_symbol='XBTUSDTM'
        elif s.endswith('USDTM'):
            self.futures_symbol=s
        else:
            self.futures_symbol=s.replace('-USDT','USDTM')
        self.symbol=self.display_symbol(self.futures_symbol)

    @staticmethod
    def display_symbol(contract):
        s=str(contract).upper()
        if s.endswith('USDTM'):
            base=s[:-5]
            if base=='XBT': base='BTC'
            return base+'-USDT'
        return s

    def _request_json(self, base, path, params):
        q=urllib.parse.urlencode(params or {})
        target=path + (('?' + q) if q else '')
        parsed=urllib.parse.urlsplit(base)
        host=parsed.netloc
        headers={'User-Agent':'SelfLearningTrader/2.2','Accept':'application/json','Connection':'keep-alive'}
        last=None
        max_attempts = max(1, min(8, int(getattr(self, '_max_attempts', 8) or 8)))
        retry_delays = tuple(getattr(self, '_retry_delays', (0.4, 0.8, 1.5, 2.5, 4.0, 6.0, 8.0)))
        for attempt in range(max_attempts):
            try:
                with self._conn_lock:
                    wait=self._request_gap-(time.monotonic()-self._last_request)
                    if wait>0: time.sleep(wait)
                    conn=self._connections.get(host)
                    if conn is None:
                        conn=http.client.HTTPSConnection(host,timeout=self.timeout,context=self.ctx)
                        self._connections[host]=conn
                    self._last_request=time.monotonic()
                conn.request('GET',target,headers=headers)
                resp=conn.getresponse()
                raw=resp.read()
                status=resp.status
                if status==429 or status>=500:
                    raise RuntimeError(f'HTTP {status}')
                if status>=400:
                    raise RuntimeError(f'HTTP {status}: {raw[:300].decode("utf-8",errors="replace")}')
                d=json.loads(raw.decode('utf-8'))
                if d.get('code') not in (None,'200000'):
                    raise RuntimeError(str(d))
                return d.get('data',d)
            except Exception as e:
                last=e
                with self._conn_lock:
                    c=self._connections.pop(host,None)
                    try:
                        if c: c.close()
                    except Exception: pass
                if attempt >= max_attempts - 1: break
                # Android DNS/network can recover after a short delay.
                # Recreate the HTTPS connection on every failed attempt.
                delay = retry_delays[min(attempt, len(retry_delays) - 1)] if retry_delays else 0.4
                time.sleep(max(0.0, float(delay)))
        raise last if last else RuntimeError('KuCoin request failed')

    def _request_json_optional(self, base, path, params, timeout=2):
        """One-shot request for optional market features; never stall a scan on retries."""
        q=urllib.parse.urlencode(params or {})
        target=path + (('?' + q) if q else '')
        parsed=urllib.parse.urlsplit(base)
        with self._conn_lock:
            wait=self._request_gap-(time.monotonic()-self._last_request)
            if wait>0: time.sleep(wait)
            self._last_request=time.monotonic()
        conn=http.client.HTTPSConnection(parsed.netloc,timeout=max(1,int(timeout)),context=self.ctx)
        try:
            conn.request('GET',target,headers={'User-Agent':'SelfLearningTrader/2.2','Accept':'application/json','Connection':'close'})
            resp=conn.getresponse(); raw=resp.read()
            if resp.status >= 400:
                raise RuntimeError(f'HTTP {resp.status}: {raw[:240].decode("utf-8",errors="replace")}')
            d=json.loads(raw.decode('utf-8'))
            if d.get('code') not in (None,'200000'):
                raise RuntimeError(str(d)[:240])
            return d.get('data',d)
        finally:
            try: conn.close()
            except Exception: pass

    def _get(self,path,params):
        return self._request_json(BASE,path,params)

    def active_symbols(self):
        # Use the documented public Futures endpoint. The old /api/ua/*
        # instrument endpoint is not the canonical Futures contract list and
        # can return an incomplete/incompatible set on some accounts/regions.
        data=self._get_futures('/api/v1/contracts/active',{})
        rows=data.get('data',data) if isinstance(data,dict) else data
        out=[]
        for x in rows or []:
            s=str(x.get('symbol','')).upper()
            settle=str(x.get('settleCurrency','')).upper()
            expire=x.get('expireDate')
            # Scanner target: live USDT-margined perpetual contracts.
            if not s.endswith('USDTM') or settle not in ('','USDT'):
                continue
            if expire not in (None, '', 0, '0'):
                continue
            out.append({'contract':s,'display':self.display_symbol(s),
                        'base':x.get('baseCurrency',''),
                        'volume':float(x.get('volumeOf24h',x.get('volume',0)) or 0),
                        'turnover':float(x.get('turnoverOf24h',x.get('turnover',0)) or 0)})
        # Stable deterministic order; BTC first, then liquidity.
        out.sort(key=lambda x:(x['contract']!='XBTUSDTM',-x['turnover'],x['display']))
        if not out:
            raise RuntimeError('KuCoin Futures: список активных USDT-перпетуалов пуст')
        return out

    def all_tickers(self):
        data=self._get_futures('/api/v1/allTickers',{})
        rows=data.get('data',data) if isinstance(data,dict) else data
        return rows or []

    def candles(self,tf,limit=5000):
        limit=max(1,int(limit)); sec=TF_SECONDS[tf]; end=int(time.time()); chunks=[]; cursor=end
        # Official Futures kline endpoint accepts granularity + from/to.
        # Paginate backwards so there is no artificial 500-row history cap.
        while len(chunks)<limit:
            start=max(0,cursor-sec*199)
            data=self._get_futures('/api/v1/kline/query',{
                'symbol':self.futures_symbol,'granularity':int(sec/60),
                'from':start*1000,'to':cursor*1000
            })
            rows=data.get('data',data) if isinstance(data,dict) else data
            if not rows: break
            rows=list(rows); chunks.extend(rows)
            times=[int(r[0]) for r in rows]
            oldest=min(times)
            if oldest>=cursor*1000: break
            cursor=max(0,oldest//1000-sec)
            if len(rows)<2: break
        rows={int(r[0]):r for r in chunks}; rows=sorted(rows.values(),key=lambda r:int(r[0]))
        # KuCoin timestamps are milliseconds; discard the still-forming candle
        # so the model never treats a partial bar as completed history.
        now_ms=int(time.time()*1000)
        rows=[r for r in rows if int(r[0]) + sec*1000 <= now_ms]
        rows=rows[-limit:]
        if not rows: raise RuntimeError(f'KuCoin не вернул свечи {tf} для {self.futures_symbol}')
        a=np.asarray(rows,dtype=object)
        # KuCoin Futures REST format is [time, open, high, low, close, volume, turnover].
        # The previous build incorrectly treated the HIGH field as CLOSE, which could
        # distort RSI/MACD/ATR and produce absurd 100% predictions.
        return {'time':a[:,0].astype(np.int64)*1000,'open':a[:,1].astype(float),
                'high':a[:,2].astype(float),'low':a[:,3].astype(float),
                'close':a[:,4].astype(float),'volume':a[:,5].astype(float),
                'turnover':a[:,6].astype(float) if a.shape[1]>6 else np.zeros(len(a))}

    def orderbook_imbalance(self):
        try:
            data=self._get('/api/ua/v1/market/orderbook',{'tradeType':'FUTURES','symbol':self.futures_symbol,'depth':'20'})
            bids=data.get('bids',[]) if isinstance(data,dict) else []
            asks=data.get('asks',[]) if isinstance(data,dict) else []
            b=sum(float(x[1]) for x in bids); a=sum(float(x[1]) for x in asks)
            return (b-a)/(b+a+1e-12)
        except Exception: return 0.0

    def contract_info(self):
        """Return contract-specific risk/fee parameters from KuCoin, cached per symbol."""
        if self.futures_symbol in self._contract_cache:
            return self._contract_cache[self.futures_symbol]
        try:
            data=self._get_futures('/api/v1/contracts/'+urllib.parse.quote(self.futures_symbol,safe=''),{})
            out=data if isinstance(data,dict) else {}
            self._contract_cache[self.futures_symbol]=out
            return out
        except Exception:
            return {}

    def _get_futures(self,path,params):
        return self._request_json(FUTURES_BASE,path,params)

    def historical_market_features(self, candle_times, candle_seconds=300):
        """Fetch public OI/funding history and align it causally to candle closes.

        KuCoin retains interval OI history for seven days. The caller should only
        enable these model features when aligned coverage is sufficient; otherwise
        it must use neutral zeros for both training and live inference.
        """
        ts = np.asarray(candle_times, dtype=np.int64).reshape(-1)
        if not len(ts):
            return {'oi_change': np.asarray([], float), 'funding': np.asarray([], float), 'coverage': 0.0, 'status': 'empty'}
        scale = 1_000_000 if np.max(np.abs(ts)) > 10**14 else (1000 if np.max(np.abs(ts)) > 10**11 else 1)
        start_ms = max(0, int(np.min(ts) / scale * 1000) - 24 * 3600 * 1000)
        end_ms = int((np.max(ts) / scale + candle_seconds) * 1000)
        try:
            oi_data = self._request_json_optional(BASE, '/api/ua/v1/market/open-interest', {
                'symbol': self.futures_symbol, 'interval': '5min',
                'startAt': start_ms, 'endAt': end_ms, 'pageSize': 1000,
            })
            funding_data = self._request_json_optional(FUTURES_BASE, '/api/v1/contract/funding-rates', {
                'symbol': self.futures_symbol, 'from': start_ms, 'to': end_ms,
            })
            aligned = align_market_metric_history(ts, _metric_rows(oi_data), _metric_rows(funding_data), candle_seconds)
            aligned['status'] = 'ok' if aligned['coverage'] >= 0.65 else 'insufficient_coverage'
            return aligned
        except Exception as exc:
            return {'oi_change': np.full(len(ts), np.nan), 'funding': np.full(len(ts), np.nan),
                    'coverage': 0.0, 'status': 'unavailable', 'error': str(exc)[:180]}

    def current_market_metrics(self):
        """Return live metrics only when the historical market features were enabled.

        Order-book imbalance and liquidation-side bias remain neutral because a
        compatible historical series is not yet available. OI change and funding
        use public KuCoin endpoints and are enabled by the engine only for models
        trained with aligned historical OI/funding snapshots.
        """
        now_ms = int(time.time() * 1000)
        cache_key = self.futures_symbol
        cached = self._market_metrics_cache.get(cache_key)
        if cached and now_ms - cached.get('time_ms', 0) < 30_000:
            self._market_metrics_status = cached.get('status', 'cached')
            return dict(cached['values'])
        values = {'book_imbalance': self.orderbook_imbalance(), 'oi_change': 0.0, 'funding': 0.0, 'liquidation_bias': 0.0}
        status = 'unavailable'
        try:
            oi_data = self._request_json_optional(BASE, '/api/ua/v1/market/open-interest', {
                'symbol': self.futures_symbol, 'interval': '5min',
                'startAt': max(0, now_ms - 30 * 60 * 1000), 'endAt': now_ms, 'pageSize': 10,
            })
            oi_rows = []
            for row in _metric_rows(oi_data):
                try:
                    t = int(row.get('ts', row.get('time', row.get('timestamp', 0))))
                    v = float(row.get('openInterest', row.get('value')))
                    if t > 0 and np.isfinite(v) and v > 0: oi_rows.append((t, v))
                except Exception:
                    continue
            oi_rows.sort()
            fund_data = self._request_json_optional(FUTURES_BASE, '/api/v1/funding-rate/' + urllib.parse.quote(self.futures_symbol, safe='') + '/current', {})
            fund = fund_data if isinstance(fund_data, dict) else (_metric_rows(fund_data)[0] if _metric_rows(fund_data) else {})
            funding_value = float(fund.get('value', fund.get('fundingRate', fund.get('predictedValue'))))
            if len(oi_rows) >= 2:
                old, new = oi_rows[-2][1], oi_rows[-1][1]
                values['oi_change'] = float(new / max(old, 1e-12) - 1.0)
                values['funding'] = funding_value
                status = 'ok'
        except Exception as exc:
            status = 'unavailable:' + str(exc)[:120]
        self._market_metrics_status = status
        self._market_metrics_cache[cache_key] = {'time_ms': now_ms, 'values': dict(values), 'status': status}
        return values
