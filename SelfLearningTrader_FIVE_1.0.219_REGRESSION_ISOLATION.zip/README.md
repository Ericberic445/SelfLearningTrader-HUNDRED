# SelfLearningTrader FIVE 1.0.186

Current release: **Master trade-outcome learning + 3 fixed mathematical lenses**.

## Current learning architecture

- One learning **Master**. No Challenger and no generation competition.
- First **25 completed forecasts**: Master only.
- After the first 25 and Master update: the common Master Base is exposed to **C1/C2/C3**.
- C1/C2/C3 are **fixed mathematical lenses**. They never train, never keep adaptive weights, and never replace Master.
- Every next block of **25 completed forecasts** is evaluated by Master and the three lenses. Master learns which lens is more useful in each market context and publishes a new shared base.

## Trade-outcome learning

Master records the complete path of each LONG/SHORT forecast:

- Initial SL before TP1 = real trading loss.
- TP1 = successful forecast.
- After TP1, protection moves to Entry; an exit at Entry remains a successful TP1 result.
- TP2 = successful TP2 result; after TP2 protection moves to TP1.
- An exit at TP1 after TP2 remains a successful TP2 result.
- TP3 = super-successful milestone.
- Price continuing above TP3 is stored as **TP3+**, including the extension beyond TP3.
- TP milestones are never downgraded to an SL because of a later protected exit.

## Post-SL analysis

An initial SL remains an actual losing trade and is never rewritten as a win. The next **3 five-minute candles** are nevertheless checked separately. If price subsequently reaches TP1/TP2/TP3 in the predicted direction, Master records that the **direction was confirmed after the stop** and distinguishes this from a genuinely wrong direction.

The engine also records event context around the stop, recovery and protected exits (volume, volume ratio, candle range/body/wicks and timing) so Master can learn why continuation failed or resumed.

## Global experience

Learning memory is symbol-safe and keyed by **contract + timestamp + prediction_id**. Completed experience from all contracts is used for automatic Master retraining. WAIT is history only and never enters the TP/SL verification queue.

The replay memory stores both:

- auxiliary direction target (SHORT / WAIT / LONG), and
- primary trade-outcome target (INITIAL_SL / TP1 / TP2 / TP3 / TP3_PLUS).

## Validation and audit

After each 25-result retraining batch, the project recomputes held-out validation where enough global data exists and writes detailed learning events to `data/learning_audit.jsonl`.

## Android build

- Package ID: `org.selflearningtrader.selflearningtrader`
- Version: `1.0.186` / Android version code `10186`
- Source: `app/`
- Android API 34, min API 24, arm64-v8a
- Foreground scanner service and existing Stop/Resume/background functionality retained.
- UI layout is not intentionally redesigned in this release.

See `README_1.0.186_WAIT_CONTROL_AND_LENS_OUTCOMES.md` for the release details and the older README/V13/V14/V15 files for historical changes.


## Version 1.0.216 — scan worker reuse and validation audit

- Reuses one KuCoin HTTP client and one engine instance per worker thread during pre-scan and deep model analysis. The Stage-25 and active-forecast recheck workers also reuse their thread-local exchange client. This reduces repeated TLS/client/engine initialization without sharing mutable engines across workers or changing ranking.
- Historical experience validation now uses a chronological timestamp split with an embargo measured in time, not only a fixed number of rows. It reports held-out performance against a majority-class baseline.
- Initial training metadata now records baseline balanced accuracy, directional precision, action rate, and model-minus-baseline deltas.
- Added regression coverage for second/millisecond/microsecond candle timestamps, timestamp-based validation embargo, readiness gates, and Stage-25 client reuse.
- **Not changed:** UI, TP/SL outcome tracking, point-7 same-candle logic, TOP-5 selection policy, background service/OFF-resume behavior, or saved archives.
- Verification: `python -m compileall -q app tests`; `PYTHONPATH=. pytest -q` — 56 passed, 9 subtests passed. Android/GitHub APK build and a live full-market timing benchmark have not been run here; runtime timings are already emitted by the app and should be confirmed from a real scan log.

## Version 1.0.214 — background recovery and scan-cycle fixes

- Bounds runtime log tails to 40 lines / 600 characters and serializes state writes, preventing recursive log-tail growth and heartbeat file contention.
- Heartbeat timeout diagnostics now record only compact state fields and are rate-limited.
- Unexpected service errors/stops and stale heartbeats trigger repeated recovery with bounded backoff until the user explicitly presses OFF.
- Stage-25 math validation runs with a bounded pool of three workers using the same indicators, timeframes, and ranking calculations; progress continues while math validation runs, and OFF cancellation is checked.
- UI layout is unchanged; learning and forecast archives are not modified by this source patch.
