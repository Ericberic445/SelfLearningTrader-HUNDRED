# SelfLearningTrader FIVE 1.0.219 — regression isolation

Changes on top of 1.0.218:
- Preserve asynchronous dashboard/statistics work and bounded scan request retries.
- Reuse the HTTP client in MODEL workers but create a fresh LearningEngine per contract. This removes whole-engine reuse introduced in 1.0.216 while retaining HTTP keep-alive.
- Debounce market refresh requests so repeated taps cannot start overlapping active-symbol requests.
- UI layout and trading rules are unchanged.

Validation: Python test suite and static source checks. Android device validation remains required.
