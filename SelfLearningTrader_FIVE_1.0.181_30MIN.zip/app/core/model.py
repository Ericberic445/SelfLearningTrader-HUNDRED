from pathlib import Path
import json, time
import numpy as np
from .features import FEATURES

NAMES={0:'SHORT',1:'WAIT',2:'LONG'}

class NumpyClassifier:
    def __init__(self,n_features,n_classes=3):
        self.n_features=n_features; self.n_classes=n_classes
        self.weights=np.zeros((n_features,n_classes)); self.bias=np.zeros(n_classes)
        self.means=np.zeros(n_features); self.stds=np.ones(n_features)

    def _class_weights(self,y,class_weights=None):
        if class_weights is not None: return np.asarray(class_weights,float)
        counts=np.bincount(y,minlength=self.n_classes).astype(float)
        w=np.ones(self.n_classes,float)
        for c in range(self.n_classes):
            if counts[c] > 0: w[c]=1.0/np.sqrt(counts[c])
        return w*self.n_classes/max(np.sum(w),1e-12)

    def fit(self,X,y,epochs=300,learning_rate=.02,l2=.0005,class_weights=None,sample_weights=None):
        X=np.asarray(X,float); y=np.asarray(y,int)
        X=np.nan_to_num(X,nan=0,posinf=0,neginf=0)
        self.means=np.mean(X,axis=0); self.stds=np.std(X,axis=0); self.stds[self.stds<1e-8]=1
        return self._fit_normalized(X,y,epochs,learning_rate,l2,class_weights,sample_weights)

    def fit_incremental(self,X,y,epochs=120,learning_rate=.008,l2=.0005,sample_weights=None):
        X=np.asarray(X,float); y=np.asarray(y,int)
        X=np.nan_to_num(X,nan=0,posinf=0,neginf=0)
        if len(X)==0: return self
        if not np.any(np.isfinite(self.means)) or np.allclose(self.stds,0):
            self.means=np.mean(X,axis=0); self.stds=np.std(X,axis=0); self.stds[self.stds<1e-8]=1
        return self._fit_normalized(X,y,epochs,learning_rate,l2,None,sample_weights)

    def _fit_normalized(self,X,y,epochs,learning_rate,l2,class_weights=None,sample_weights=None):
        Z=(X-self.means)/np.where(np.abs(self.stds)<1e-8,1,self.stds); n=max(1,len(Z))
        Y=np.zeros((len(y),self.n_classes)); Y[np.arange(len(y)),y]=1
        w=self._class_weights(y,class_weights)
        sw=np.asarray(sample_weights,float) if sample_weights is not None else np.ones(len(y),float)
        if len(sw)!=len(y): sw=np.ones(len(y),float)
        sw=np.clip(sw,0.25,4.0)
        for _ in range(max(1,int(epochs))):
            s=Z@self.weights+self.bias; s-=np.max(s,axis=1,keepdims=True)
            p=np.exp(np.clip(s,-50,50)); p/=np.sum(p,axis=1,keepdims=True)
            e=(p-Y)*w[np.clip(y,0,self.n_classes-1),None]*sw[:,None]
            self.weights-=learning_rate*((Z.T@e)/n+l2*self.weights)
            self.bias-=learning_rate*np.mean(e,axis=0)
        return self

    def predict_proba(self,X):
        X=np.nan_to_num(np.asarray(X,float),nan=0,posinf=0,neginf=0); Z=(X-self.means)/np.where(np.abs(self.stds)<1e-8,1,self.stds)
        s=Z@self.weights+self.bias; s-=np.max(s,axis=1,keepdims=True)
        p=np.exp(np.clip(s,-50,50)); return p/np.sum(p,axis=1,keepdims=True)
    def predict(self,X): return np.argmax(self.predict_proba(X),axis=1)


class ModelManager:
    """FIVE learning architecture: one continuously learning Master plus three fixed lenses.

    C1/C2/C3 are not competing trainable brains. They are deterministic specialized
    views built from the current Master foundation and the common mathematical layer.
    The Master makes its own base forecast, sees all three lens forecasts, and a small
    Master decision layer learns how to resolve their disagreements from real outcomes.
    """
    META_CONTEXT=['trend','volatility','atrpct','rsi','bbpos','volz','trend_15','trend_1h','trend_4h','trend_1d','book_imbalance','oi_change','funding','liquidation_bias']
    META_NAMES=(['master_p_short','master_p_wait','master_p_long']+
                [f'c{i}_p_short' for i in (1,2,3)]+[f'c{i}_p_wait' for i in (1,2,3)]+[f'c{i}_p_long' for i in (1,2,3)]+
                ['conflict_m_c1','conflict_m_c2','conflict_m_c3','lens_agreement','math_consensus']+META_CONTEXT)

    def __init__(self,root,symbol='XBTUSDTM',config=None):
        self.root=Path(root); self.models=self.root/'models_v8_self_learning'/'GLOBAL'; self.models.mkdir(parents=True,exist_ok=True)
        self.champion=self.models/'champion.npz'; self.meta=self.models/'champion.json'
        self.generation_state=self.models/'generation_state.json'; self.generation_history=self.models/'generation_history.json'
        self.master_decision=self.models/'master_decision.npz'; self.master_decision_meta=self.models/'master_decision.json'
        self.meta_experience=Path(root)/'data'/'master_decision_experience.npz'; self.meta_experience.parent.mkdir(parents=True,exist_ok=True)
        self.config=config or {}

    def _new(self): return NumpyClassifier(len(FEATURES),3)
    def _new_decision(self): return NumpyClassifier(len(self.META_NAMES),3)
    def _save(self,path,m):
        path=Path(path); tmp=path.with_name(path.name+'.tmp.npz')
        np.savez(tmp,weights=m.weights,bias=m.bias,means=m.means,stds=m.stds); tmp.replace(path)
    def _load_path(self,path,decision=False):
        if not Path(path).exists(): return None
        try:
            z=np.load(path); m=self._new_decision() if decision else self._new()
            if z['weights'].shape!=(m.n_features,3): return None
            m.weights=z['weights']; m.bias=z['bias']; m.means=z['means']; m.stds=np.where(np.abs(z['stds'])<1e-8,1,z['stds']); return m
        except Exception:return None
    def _read_json(self,path,default):
        try:return json.loads(Path(path).read_text(encoding='utf-8')) if Path(path).exists() else default
        except Exception:return default
    def _write_json(self,path,obj):
        path=Path(path); tmp=path.with_suffix(path.suffix+'.tmp'); tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8'); tmp.replace(path)
    def _scores(self,y,p):
        acc=float(np.mean(p==y)) if len(y) else 0.0; per=[]
        for c in range(3):
            mask=y==c; per.append(float(np.mean(p[mask]==c)) if np.any(mask) else 0.0)
        bal=float(np.mean(per)) if per else 0.0; action=p!=1; action_count=int(np.sum(action))
        directional_precision=float(np.mean(p[action]==y[action])) if action_count else 0.0; action_rate=float(np.mean(action)) if len(p) else 0.0
        return acc,bal,per,directional_precision,action_rate

    def _generation(self):
        return self._read_json(self.generation_state,{'generation':1,'master_resolved_total':0})
    def _save_generation(self,s): self._write_json(self.generation_state,s)
    def generation_info(self):
        s=self._generation(); s.update({'architecture':'MASTER_PLUS_3_LENSES','lenses':['C1_MARKET_REGIME','C2_DIRECTION_ENTRY','C3_TP_SL_RISK'],
                                        'decision_model_ready':self._load_path(self.master_decision,True) is not None})
        return s

    def has_champion(self): return self.champion.exists() and self._load_path(self.champion) is not None

    def train(self,x,min_rows=500,test_fraction=.2):
        n=len(x['target'])
        if n<min_rows: raise ValueError(f'Not enough training rows: {n}. Minimum is {min_rows}.')
        X=np.column_stack([x[f] for f in FEATURES]); y=np.asarray(x['target'],int); cut=max(1,min(n-1,int(n*(1-test_fraction))))
        trX,teX=X[:cut],X[cut:]; trY,teY=y[:cut],y[cut:]; m=self._new().fit(trX,trY)
        pred=m.predict(teX); acc,bal,per,dp,ar=self._scores(teY,pred); self._save(self.champion,m)
        stamp=time.strftime('%Y%m%d_%H%M%S'); meta={'engine':'numpy_softmax_v9_master_lenses','generation':1,'accuracy':acc,'balanced_accuracy':bal,'class_accuracy':per,'directional_precision':dp,'action_rate':ar,'rows':n,'train_rows':cut,'test_rows':len(teY),'created':stamp,'feature_count':len(FEATURES),'features':FEATURES,'accepted':True,'status':'master','learning_type':'initial'}
        self._write_json(self.meta,meta); self._save_generation({'generation':1,'master_resolved_total':0})
        return meta

    def train_master_incremental(self,x,min_rows=500):
        n=len(x['target'])
        if n<min_rows: return {'status':'not_enough_rows','rows':n}
        m=self._load_path(self.champion)
        if m is None: return self.train(x,min_rows,.2)
        X=np.column_stack([x[f] for f in FEATURES]); y=np.asarray(x['target'],int)
        sw=np.asarray(x.get('sample_weight',np.ones(n,float)),float)
        mc=np.asarray(x.get('math_consensus',np.zeros(n)),float)
        actual=np.where(y==2,1.0,np.where(y==0,-1.0,0.0)); agree=actual*mc
        sw*=np.where(agree>0.20,1.20,np.where(agree<-0.20,0.85,1.0))
        m.fit_incremental(X,y,epochs=int(self.config.get('master_epochs',40)),learning_rate=float(self.config.get('master_learning_rate',0.004)),l2=float(self.config.get('master_l2',0.0005)),sample_weights=sw)
        self._save(self.champion,m)
        meta=self._read_json(self.meta,{}); meta.update({'status':'master','learning_type':'continuous_incremental','last_retrain':int(time.time()),'rows':n}); self._write_json(self.meta,meta)
        return {'status':'master_updated','rows':n}

    @staticmethod
    def _softmax3(logits):
        z=np.asarray(logits,float); z-=np.max(z); e=np.exp(np.clip(z,-30,30)); return e/max(np.sum(e),1e-12)

    def _rowv(self,row,name):
        try:
            if name in row: return float(np.asarray(row.get(name,[0.0])).reshape(-1)[0])
            feat=row.get('features') or {}
            return float(feat.get(name,0.0))
        except Exception:return 0.0

    def _lens(self,master,row):
        """Three fixed specialized lenses. They never become separate trainable brains."""
        p=np.asarray(master,float); lp=np.log(np.clip(p,1e-6,1.0))
        trend=np.tanh(np.mean([self._rowv(row,k) for k in ('trend','trend_15','trend_1h','trend_4h','trend_1d')])*18.0)
        vol=float(np.clip(self._rowv(row,'volatility')*80.0,0.0,2.0)); volz=float(np.tanh(self._rowv(row,'volz')/3.0))
        rsi=float(np.clip((self._rowv(row,'rsi')-50.0)/25.0,-2,2)); bb=float(np.clip((self._rowv(row,'bbpos')-0.5)*2.0,-2,2))
        imb=float(np.tanh(self._rowv(row,'book_imbalance'))); oi=float(np.tanh(self._rowv(row,'oi_change'))); funding=float(np.tanh(self._rowv(row,'funding')*50.0)); liq=float(np.tanh(self._rowv(row,'liquidation_bias')))
        # C1: market-regime lens
        c1=self._softmax3(lp+np.array([-0.65*trend,0.15*vol,0.65*trend]))
        # C2: direction/entry lens
        directional=0.55*trend+0.25*rsi+0.20*bb+0.20*imb+0.10*oi
        c2=self._softmax3(lp+np.array([-directional,0.05*vol,directional]))
        # C3: TP/SL/risk lens. It does not choose a side blindly; it adjusts confidence
        # according to risk, funding/liquidation and whether volatility supports follow-through.
        risk_signal=0.35*trend+0.20*imb+0.20*oi-0.25*abs(funding)-0.20*abs(liq)
        confidence=max(0.0,min(1.0,1.0-vol*0.25))
        c3=self._softmax3(lp+np.array([-risk_signal*confidence,0.10*vol,-0.10*vol+risk_signal*confidence]))
        return {'c1':c1,'c2':c2,'c3':c3}

    def _meta_vector(self,row,master,lenses,math_consensus=0.0):
        vals=list(np.asarray(master,float))
        for k in ('c1','c2','c3'): vals.extend(list(np.asarray(lenses[k],float)))
        for k in ('c1','c2','c3'):
            vals.append(abs(float(master[2])-float(lenses[k][2])))
        lens_long=[float(lenses[k][2]) for k in ('c1','c2','c3')]
        vals.append(float(np.std(lens_long)))
        vals.append(float(math_consensus or 0.0))
        vals.extend([self._rowv(row,k) for k in self.META_CONTEXT])
        return np.asarray(vals,float)

    def predict_bundle(self,row,math_consensus=0.0):
        base=self._load_path(self.champion)
        if base is None: raise FileNotFoundError('Нет совместимой обученной модели.')
        X=np.column_stack([np.asarray(row[f],float).reshape(-1) for f in FEATURES]); master=base.predict_proba(X)[0]
        lenses=self._lens(master,row)
        vec=self._meta_vector(row,master,lenses,math_consensus)
        decision=self._load_path(self.master_decision,True)
        if decision is not None:
            final=decision.predict_proba(vec.reshape(1,-1))[0]
            source='master_decision'
        else:
            # Before enough resolved examples exist, Master remains the authoritative
            # forecast. Lenses are still recorded and tested from the very first cycle.
            final=master.copy(); source='master_core'
        directional=max(float(final[0]),float(final[2])); wait=float(final[1]); threshold=float(self.config.get('min_direction_confidence',0.55)); edge=float(self.config.get('min_direction_edge',0.06)); cls=int(np.argmax(final))
        if directional < threshold or directional-wait < edge: cls=1
        return NAMES[cls],{i:float(final[i]) for i in range(3)}, {'master_probs':master,'lenses':lenses,'decision_source':source,'meta_vector':vec}

    def predict(self,row,math_consensus=0.0):
        pred,probs,_=self.predict_bundle(row,math_consensus); return pred,probs

    def prediction_diagnostics(self,row,pred,probs,math_consensus=0.0):
        p,final,extra=self.predict_bundle(row,math_consensus)
        d={'master_p_short':float(extra['master_probs'][0]),'master_p_wait':float(extra['master_probs'][1]),'master_p_long':float(extra['master_probs'][2]),'decision_source':extra['decision_source']}
        for i,k in enumerate(('c1','c2','c3'),1):
            q=extra['lenses'][k]; d[f'c{i}_p_short']=float(q[0]); d[f'c{i}_p_wait']=float(q[1]); d[f'c{i}_p_long']=float(q[2])
        d['conflict_m_c1']=abs(d['master_p_long']-d['c1_p_long']); d['conflict_m_c2']=abs(d['master_p_long']-d['c2_p_long']); d['conflict_m_c3']=abs(d['master_p_long']-d['c3_p_long'])
        d['lens_agreement']=float(np.std([d['c1_p_long'],d['c2_p_long'],d['c3_p_long']]))
        d['math_consensus']=float(math_consensus or 0.0)
        return d

    def learn_from_resolved(self,rows):
        """Train the Master decision layer from real outcomes, not from lens opinions."""
        valid=[]
        for x in rows:
            if x.get('actual') not in ('SHORT','WAIT','LONG'): continue
            if not all(k in x for k in ('master_p_long','c1_p_long','c2_p_long','c3_p_long')): continue
            try:
                v=[]
                v.extend([float(x.get(k,0.0)) for k in ('master_p_short','master_p_wait','master_p_long')])
                for i in (1,2,3): v.extend([float(x.get(f'c{i}_p_short',0.0)),float(x.get(f'c{i}_p_wait',0.0)),float(x.get(f'c{i}_p_long',0.0))])
                v.extend([float(x.get('conflict_m_c1',0.0)),float(x.get('conflict_m_c2',0.0)),float(x.get('conflict_m_c3',0.0)),float(x.get('lens_agreement',0.0)),float(x.get('math_consensus',0.0))])
                feat=x.get('features') or {}; v.extend([float(feat.get(k,0.0)) for k in self.META_CONTEXT])
                valid.append((v,{'SHORT':0,'WAIT':1,'LONG':2}[x['actual']]))
            except Exception: continue
        if not valid:return {'status':'no_meta_rows'}
        cap=max(500,int(self.config.get('master_decision_experience_max',12000)))
        old=None
        if self.meta_experience.exists():
            try:
                z=np.load(self.meta_experience); old={k:z[k] for k in z.files}
            except Exception: old=None
        X=np.asarray([a for a,_ in valid],dtype=np.float32); y=np.asarray([b for _,b in valid],dtype=np.int8)
        if old:
            X=np.concatenate([old['X'],X]); y=np.concatenate([old['y'],y])
        if len(X)>cap: X=X[-cap:]; y=y[-cap:]
        np.savez(self.meta_experience,X=X,y=y)
        # Require a small seed before trusting the meta layer. Afterwards it learns
        # incrementally from the same real outcomes that teach the main Master.
        if len(X)<max(25,int(self.config.get('master_decision_min_rows',50))): return {'status':'meta_learning_accumulating','rows':len(X)}
        m=self._load_path(self.master_decision,True) or self._new_decision()
        if self._load_path(self.master_decision,True) is None:
            m.fit(X,y,epochs=int(self.config.get('master_decision_epochs',80)),learning_rate=float(self.config.get('master_decision_learning_rate',0.01)),l2=float(self.config.get('master_decision_l2',0.001)))
        else:
            m.fit_incremental(X,y,epochs=int(self.config.get('master_decision_epochs',40)),learning_rate=float(self.config.get('master_decision_learning_rate',0.006)),l2=float(self.config.get('master_decision_l2',0.001)))
        self._save(self.master_decision,m)
        self._write_json(self.master_decision_meta,{'status':'ready','rows':len(X),'updated':int(time.time()),'features':self.META_NAMES,'learning':'master_error_and_lens_outcome_learning'})
        return {'status':'meta_updated','rows':len(X)}

