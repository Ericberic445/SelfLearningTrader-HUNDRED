import json
from pathlib import Path

DEFAULT = {
    "symbol":"BTC-USDT","timeframes":["5min","15min","1hour","4hour","1day"],
    "history_limit":1500,"horizon_bars":4,"long_threshold":0.003,
    "short_threshold":-0.003,"retrain_every":25,"retrain_batch_size":25,"min_training_rows":500,
    "test_fraction":0.2,"champion_min_accuracy":0.0,"refresh_seconds":60,"monitor_poll_seconds":20,"monitor_volume_change_pct":50,
    "monitor_price_change_pct":0.20,"monitor_orderbook_change":0.20,
    "monitor_alert_cooldown_seconds":60,"monitor_max_events_per_prediction":500,
    "readiness_min_resolved":1000,"readiness_min_validation_rows":1000,
    "readiness_min_accuracy":0.90,"readiness_min_recent_accuracy":0.90,
    "readiness_min_balanced_accuracy":0.60,"readiness_min_directional_precision":0.65,
    "readiness_min_action_rate":0.10,"readiness_min_recent_directional_accuracy":0.90,
    "readiness_min_tp1_rate":0.90,"readiness_max_sl_rate":0.10,
}

def load(path: Path):
    if not path.exists():
        path.write_text(json.dumps(DEFAULT,ensure_ascii=False,indent=2),encoding="utf-8")
    data=json.loads(path.read_text(encoding="utf-8"))
    out=DEFAULT.copy(); out.update(data); return out
