# V13.25 — startup crash + native touch cleanup

Fixed two concrete V13.24 issues:
- startup crash caused by `header.add_widget(menu_hit)` where `menu_hit` was undefined; now the actual `menu_left` button is added.
- removed unsupported `touch_pad_x/touch_pad_y` constructor arguments from TOP-5 buttons.

Foreground Service configuration from V13.22/V13.23 is preserved.
