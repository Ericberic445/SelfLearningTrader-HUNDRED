# V13.20 touch final check

- Visible MENU/MORE/FULL/REFRESH/LOG buttons keep their original visual size.
- A tap directly on the visible child button is handled by the child itself and calls the same callback.
- The invisible wrapper handles only the extra area outside the visible button.
- No `touch.grab()` is used by `TouchArea`.
- The wrapper never intercepts touches inside the visible child.
- TextInput search remains a normal Kivy TextInput and is not covered by a global touch handler.
- STOP/RESUME logic from V13.18 is preserved.
