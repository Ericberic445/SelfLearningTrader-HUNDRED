# V14.3 — Reference UI

- Main screen uses a compact dark dashboard inspired by the approved reference mockup.
- Persistent readiness card: `МОДЕЛЬ ОБУЧАЕТСЯ — N/10` or `МОДЕЛЬ ГОТОВА — 10/10`.
- Three compact metrics: checked predictions, overall accuracy, recent 100 directional accuracy.
- Current-cycle card and background-service status stay visible while the app is minimized/locked.
- Only one persistent action is visible: bottom-right `⋮`.
- The `⋮` menu is an overlay Popup and contains only: `ПОЛУЧИТЬ 5 ПРОГНОЗОВ`, `КАЛЬКУЛЯТОР`, `СТАТИСТИКА МОДЕЛИ`, `НАСТРОЙКИ`.
- Requesting five forecasts reuses the existing foreground learning service when it is already alive; it never starts a second service for the same request.
- TOP-5 cards show direction, confidence, Entry, SL, TP1, TP2 and TP3.
