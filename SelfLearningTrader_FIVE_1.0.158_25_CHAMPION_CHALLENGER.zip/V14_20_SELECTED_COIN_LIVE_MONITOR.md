# V14.20 — selected-coin live monitor

- TOP-5 remains the market selection.
- Opening one TOP-5 card allows the user to start monitoring only that prediction.
- Monitoring runs in the foreground service and continues while the Activity is minimized/locked.
- Configurable polling interval and alert thresholds.
- Tracks 5m volume, price movement and order-book imbalance.
- Emits warnings on material changes and combined possible reversal conditions.
- Stores before/after market snapshots and alert events per prediction.
- Original Entry/SL/TP levels are never changed by monitoring.
- The background service continues its normal learning/verification independently.
