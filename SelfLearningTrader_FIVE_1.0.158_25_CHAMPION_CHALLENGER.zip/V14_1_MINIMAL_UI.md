# V14.1 — Minimal UI

The continuous self-learning scanner remains the core workflow. The main scanner screen intentionally exposes only one visible control: a compact control/menu button.

Removed from the main screen:
- MENU / MORE / FULL / REFRESH buttons as separate controls
- coin search field and refresh control
- fixed bottom navigation bar
- permanent action buttons
- permanent log button

The hidden control panel provides navigation to Scanner, Analysis, AI Model, Settings and Journal, plus the contextual STOP/RESUME/START action. The scanner itself starts automatically and the foreground service continues the scan/verify/learn cycle.

The previous global touch router was removed. Controls use normal Kivy hitboxes so the visible control and its touch area share the same coordinates.
