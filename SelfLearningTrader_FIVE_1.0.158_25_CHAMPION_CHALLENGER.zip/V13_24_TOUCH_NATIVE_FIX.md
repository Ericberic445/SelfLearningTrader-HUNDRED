# V13.24

- Removed TouchArea touch interception entirely.
- MENU, MORE, FULL and REFRESH are now real Kivy Buttons with larger invisible hit targets and smaller visual rectangles drawn inside the same Button.
- No touch.grab, no Window-level touch interception, and no parent overlay.
- Search remains a normal TextInput with no overlay around it.
- LOG uses the same native-button hit model.
- STOP remains visible after stop and switches to RESUME; background-scan error also leaves RESUME available instead of hiding STOP.
