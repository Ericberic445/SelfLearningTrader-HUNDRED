# V14.21 — TP protection and result logic

- Entry -> original SL before TP1: result `SL`, failed prediction.
- Entry -> TP1 -> return to Entry: result `TP1`, protected/breakeven exit.
- Entry -> TP1 -> TP2 -> return to TP1: result `TP2`, protected exit.
- Entry -> TP3: result `TP3`, completed.
- TP milestones are cumulative.
- `sl_hit` and SL statistics count only initial SL before TP1.
- `protected_exit` records exits after a milestone without classifying them as SL.
- `initial_sl_failure` is the learning/statistics flag for true SL-only failures.
- MFE/MAE and achieved TP remain stored for learning.
