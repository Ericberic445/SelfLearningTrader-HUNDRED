# V13.14 — TOUCH AREA ONLY

- MENU/FULL/MORE visual buttons returned to compact size.
- Their invisible Android touch targets are enlarged to approximately 68x60 dp.
- No visual enlargement of the buttons.
- MENU remains navigation; MORE remains contextual actions.
- V13.12 scan diagnostics are preserved.
