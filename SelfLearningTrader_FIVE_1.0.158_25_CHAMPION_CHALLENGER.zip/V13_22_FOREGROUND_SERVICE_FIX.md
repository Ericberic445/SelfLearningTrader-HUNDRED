# V13.22 — Foreground Service + touch crash fix

- Declares the scanner as a python-for-android foreground service:
  `scanner:services/scanner.py:foreground:sticky:foregroundServiceType=dataSync`
- Adds required Android foreground-service permissions.
- Includes `app/services/scanner.py` inside the actual Buildozer source tree.
- Android scanning starts through `ServiceScanner` and UI polls the persisted service state.
- STOP writes a shared stop control; RESUME starts a fresh foreground service.
- MENU/MORE/FULL callbacks now accept the button argument used by the touch wrapper, preventing the `TypeError` that could close the app.
- Refresh remains a normal wrapped Kivy button and its callback signature is compatible.
