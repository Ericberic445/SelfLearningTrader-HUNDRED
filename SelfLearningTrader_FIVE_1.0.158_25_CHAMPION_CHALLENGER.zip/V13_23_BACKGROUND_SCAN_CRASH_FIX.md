# V13.23 — background scanner crash fix

Fixed the foreground scanner crash:
`cannot access local variable 'results' where it is not associated with a value`.

Cause: `scan_all()` could return `results` from the early cancellation branch before `results` had been initialized. `results` is now initialized before the prescan loop, and the later model stage reuses it.

No UI/touch behavior was changed in this patch.
