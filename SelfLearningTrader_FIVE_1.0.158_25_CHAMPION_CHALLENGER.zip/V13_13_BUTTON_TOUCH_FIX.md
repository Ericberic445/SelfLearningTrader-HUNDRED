# V13.13 — MENU / MORE touch fix

- Increased header MENU touch target from 52dp to 72dp.
- Increased MORE touch target from 48dp to 68dp.
- Increased FULL touch target from 54dp to 68dp.
- Increased header height and spacing for easier finger taps.
- Increased navigation-menu item height from 42dp to 50dp.
- Increased MORE action item height from 46dp to 54dp.
- Kept MENU and MORE functions separate.
- Kept immediate pressed-state visual feedback.
