from pathlib import Path
p=Path('/mnt/data/rtwork/app/services/scanner.py')
s=p.read_text()
s=s.replace("STATE_LOCK = threading.Lock()\n", "STATE_LOCK = threading.Lock()\nRUNTIME_LOG = ROOT / 'runtime_diagnostics.log'\nRUNTIME_LOG_LOCK = threading.Lock()\n\ndef runtime_log(message, level='INFO'):\n    \"\"\"Append a timestamped runtime diagnostic line without ever crashing the service.\"\"\"\n    try:\n        line = f\"{time.strftime('%Y-%m-%d %H:%M:%S')} [{level}] {message}\"\n        with RUNTIME_LOG_LOCK:\n            with RUNTIME_LOG.open('a', encoding='utf-8') as fh:\n                fh.write(line + '\\n')\n            try:\n                lines = RUNTIME_LOG.read_text(encoding='utf-8').splitlines()[-120:]\n                data = read_json(STATE, {})\n                data['runtime_log_tail'] = lines\n                data['runtime_log_path'] = str(RUNTIME_LOG)\n                write_json(STATE, data)\n            except Exception:\n                pass\n    except Exception:\n        pass\n\n")
s=s.replace("def main():\n    wake_lock = None", "def main():\n    wake_lock = None\n    runtime_log('SERVICE ENTRY: scanner.py main() called')")
s=s.replace("        try:\n            from jnius import autoclass\n            PythonService = autoclass('org.kivy.android.PythonService')", "        try:\n            runtime_log('PHASE: importing PythonService')\n            from jnius import autoclass\n            PythonService = autoclass('org.kivy.android.PythonService')")
s=s.replace("        except Exception:\n            pass\n        if not acquire_service_lock(instance_id):", "        except Exception as exc:\n            runtime_log('PythonService init failed: ' + repr(exc), 'ERROR')\n        if not acquire_service_lock(instance_id):")
s=s.replace("        if not acquire_service_lock(instance_id):\n            return", "        if not acquire_service_lock(instance_id):\n            runtime_log('SERVICE LOCK: another live instance owns the service', 'WARN')\n            return")
s=s.replace("        lock_acquired = True\n        ctl=control_data()", "        lock_acquired = True\n        runtime_log(f'SERVICE LOCK acquired: {instance_id}')\n        ctl=control_data()")
s=s.replace("        if bool(ctl.get('stop')):\n            set_state", "        if bool(ctl.get('stop')):\n            runtime_log('SERVICE START blocked by user stop flag', 'WARN')\n            set_state")
s=s.replace("        set_state(status='starting'", "        runtime_log('PHASE: publishing STARTING heartbeat')\n        set_state(status='starting'", 1)
s=s.replace("        heartbeat_thread.start()\n\n        # Import the application stack", "        heartbeat_thread.start()\n        runtime_log('HEARTBEAT thread started')\n\n        # Import the application stack")
s=s.replace("        from core.config import load\n        from core.engine import LearningEngine\n        from core.exchange import KuCoin", "        runtime_log('PHASE: importing trading stack')\n        from core.config import load\n        runtime_log('IMPORT OK: core.config')\n        from core.engine import LearningEngine\n        runtime_log('IMPORT OK: core.engine')\n        from core.exchange import KuCoin\n        runtime_log('IMPORT OK: core.exchange')")
s=s.replace("        exchange=KuCoin(cfg['symbol'])\n        engine=LearningEngine(ROOT, exchange, cfg)", "        runtime_log('PHASE: creating KuCoin client')\n        exchange=KuCoin(cfg['symbol'])\n        runtime_log('KuCoin client created')\n        runtime_log('PHASE: creating LearningEngine')\n        engine=LearningEngine(ROOT, exchange, cfg)\n        runtime_log('LearningEngine created')")
s=s.replace("        wake_lock=acquire_wakelock()", "        wake_lock=acquire_wakelock()\n        runtime_log('WakeLock: ' + ('ACQUIRED' if wake_lock is not None else 'UNAVAILABLE'), 'INFO' if wake_lock is not None else 'WARN')")
s=s.replace("        set_state(status='running'", "        runtime_log('PHASE: entering RUNNING loop')\n        set_state(status='running'", 1)
s=s.replace("    except Exception as exc:\n        set_state(status='error'", "    except Exception as exc:\n        runtime_log('FATAL SERVICE EXCEPTION: ' + repr(exc), 'ERROR')\n        runtime_log(traceback.format_exc(), 'ERROR')\n        set_state(status='error'", 1)
s=s.replace("    finally:\n        heartbeat_stop.set()", "    finally:\n        runtime_log('SERVICE EXIT: releasing resources')\n        heartbeat_stop.set()")
p.write_text(s)

p=Path('/mnt/data/rtwork/app/main.py')
s=p.read_text()
# Add runtime log path initialization
s=s.replace("self._bg_lock_path = self._bg_root / 'background_scan.lock'", "self._bg_lock_path = self._bg_root / 'background_scan.lock'\n        self._runtime_log_path = self._bg_root / 'runtime_diagnostics.log'")
# Menu item, both hidden source and popup handlers by adding at end
s=s.replace("            ('РЕЗЕРВНАЯ КОПИЯ', lambda *_: self.show_backup()),\n", "            ('РЕЗЕРВНАЯ КОПИЯ', lambda *_: self.show_backup()),\n            ('ЭКСПОРТ RUNTIME-ЛОГА', lambda *_: self.export_runtime_log()),\n")
s=s.replace("            self.show_backup,\n        ]", "            self.show_backup,\n            self.export_runtime_log,\n        ]")
# Add method before show_log_screen
needle="    def show_log_screen(self, *_):\n"
method="""    def export_runtime_log(self, *_):\n        \"\"\"Export the service/app runtime diagnostic log to Downloads on Android.\"\"\"\n        try:\n            parts = []\n            if self._runtime_log_path.exists():\n                parts.append(self._runtime_log_path.read_text(encoding='utf-8', errors='replace'))\n            st = self._read_bg_state()\n            tail = st.get('runtime_log_tail') or []\n            if tail:\n                parts.append('\\n'.join(tail))\n            text = '\\n'.join(x for x in parts if x).strip()\n            if not text:\n                text = 'No runtime diagnostics recorded yet.'\n            if platform == 'android':\n                from jnius import autoclass\n                Environment = autoclass('android.os.Environment')\n                MediaStore = autoclass('android.provider.MediaStore')\n                ContentValues = autoclass('android.content.ContentValues')\n                activity = autoclass('org.kivy.android.PythonActivity').mActivity\n                resolver = activity.getContentResolver()\n                values = ContentValues()\n                values.put('display_name', 'SelfLearningTrader_HUNDRED_runtime.log')\n                values.put('mime_type', 'text/plain')\n                values.put('relative_path', Environment.DIRECTORY_DOWNLOADS)\n                uri = resolver.insert(MediaStore.Files.getContentUri('external'), values)\n                if uri is None:\n                    raise RuntimeError('Android не создал файл в Downloads')\n                stream = resolver.openOutputStream(uri)\n                stream.write(text.encode('utf-8'))\n                stream.close()\n                self.append_log('Runtime-лог сохранён в Downloads/SelfLearningTrader_HUNDRED_runtime.log')\n                self.status_card.text = 'RUNTIME-ЛОГ ЭКСПОРТИРОВАН\\nОткрой Downloads → SelfLearningTrader_HUNDRED_runtime.log'\n            else:\n                out = Path.home() / 'SelfLearningTrader_HUNDRED_runtime.log'\n                out.write_text(text, encoding='utf-8')\n                self.append_log('Runtime-лог сохранён: ' + str(out))\n        except Exception as exc:\n            self.append_log('Ошибка экспорта runtime-лога: ' + str(exc))\n            self.status_card.text = 'Ошибка экспорта runtime-лога: ' + str(exc)\n\n"""
s=s.replace(needle, method+needle)
# append_log also write app-side runtime log
old="""    def append_log(self, text):\n        self._log_lines.append(str(text))\n"""
new="""    def append_log(self, text):\n        line = f\"{time.strftime('%Y-%m-%d %H:%M:%S')} [APP] {text}\"\n        try:\n            self._runtime_log_path.parent.mkdir(parents=True, exist_ok=True)\n            with self._runtime_log_path.open('a', encoding='utf-8') as fh:\n                fh.write(line + '\\n')\n        except Exception:\n            pass\n        self._log_lines.append(str(text))\n"""
s=s.replace(old,new)
# Log service state transitions in poll, without changing UI
s=s.replace("        state = self._read_bg_state()\n        self._update_monitor_ui(state)", "        state = self._read_bg_state()\n        self._update_monitor_ui(state)")
# log start request details
s=s.replace("            self.append_log('Foreground Service: generated p4a service.start() requested')", "            self.append_log('Foreground Service: generated p4a service.start() requested; waiting for heartbeat')")
s=s.replace("        except Exception as exc:\n            self._scan_running = False", "        except Exception as exc:\n            self.append_log('RUNTIME SERVICE START EXCEPTION: ' + traceback.format_exc())\n            self._scan_running = False", 1)
# version in UI title optional no need
p.write_text(s)

p=Path('/mnt/data/rtwork/buildozer.spec')
s=p.read_text().replace('version = 1.0.180','version = 1.0.181').replace('android.numeric_version = 10180','android.numeric_version = 10181')
p.write_text(s)

p=Path('/mnt/data/rtwork/.github/workflows/build-apk.yml')
s=p.read_text().replace('version = 1.0.180','version = 1.0.181').replace('android.numeric_version = 10180','android.numeric_version = 10181')
p.write_text(s)
