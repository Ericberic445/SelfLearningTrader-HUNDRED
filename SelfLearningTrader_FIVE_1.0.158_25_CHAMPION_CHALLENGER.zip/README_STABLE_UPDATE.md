# SelfLearningTrader FIVE — stable update build 1.0.198

This package is based on the existing FIVE 1.0.195 source. Application logic and UI are not intentionally changed. Only the Android build version and signing pipeline are changed.

## Permanent update identity
- Package: `org.selflearningtrader.selflearningtrader`
- Version: `1.0.198`
- Version code: `10198`
- Keystore: `signing/debug.keystore`
- Alias: `androiddebugkey`
- Store password: `android`

The GitHub workflow copies this exact keystore, builds the APK, then runs `zipalign` and `apksigner` so the final APK uses modern Android APK Signature Scheme signing. The workflow verifies the final certificate before publishing the APK artifact.

**Important:** future versions must reuse the same `signing/debug.keystore`. Changing or regenerating it breaks in-place updates.

## Installation
If the old 1.0.193 cannot be updated because its certificate is different, uninstall 1.0.193 once, install this 1.0.198 APK, and keep it installed. All later versions built from this project with the same keystore and a higher versionCode can update it without uninstalling.
