# V13.17 — reliable top-button touch

- MENU, FULL, MORE and REFRESH keep their existing visible dimensions.
- Added a larger invisible touch target handled at the Android/Kivy Window level.
- The target is limited to the top controls so it does not interfere with the coin search field.
- A tap is consumed once to prevent duplicate actions.
- Added brief press feedback without changing button size.
