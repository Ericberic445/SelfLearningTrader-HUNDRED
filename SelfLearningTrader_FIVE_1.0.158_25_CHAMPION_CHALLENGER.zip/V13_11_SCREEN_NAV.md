# V13.11 Screen Navigation

- Each bottom tab is a real screen and clears the previous screen widgets.
- Scanner keeps the latest TOP-5 and persists up to 20 TOP-5 results in `top5_history.json`.
- Returning to Scanner restores the latest TOP-5.
- TOP-5 history can be opened from Scanner or MORE.
- Background scanning can continue while viewing another tab; it does not overwrite that tab's UI.
- MENU is navigation only.
- MORE is contextual: actions depend on the current screen and it never duplicates MENU navigation.
- Search suggestions remain hidden until the user types.
- Stop-scan control is visible only while scanning on the Scanner screen.
