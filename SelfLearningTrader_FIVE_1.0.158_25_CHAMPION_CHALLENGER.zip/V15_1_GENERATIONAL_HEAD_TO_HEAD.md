# V15.1 — Generational head-to-head self-learning

- One shared market model is used across all scanned USDT perpetuals.
- The first 100 resolved live observations are accumulated before retraining.
- Retraining creates a challenger; the current champion keeps producing the live signals.
- The next 100 fresh observations are scored for both champion and challenger on the same market path.
- Only after that common 100-observation head-to-head test can the challenger replace the champion.
- Challenger training uses the accumulated resolved experience, including failures and successful TP stages, so later generations inherit the history of earlier generations.
- Failed generations are retained as compact generation history/metrics, not as active models.
- A challenger is never promoted merely because it scores better on its training set.
- Readiness remains gated by 1000 resolved live observations, >90% TP1 criterion and the existing anti-WAIT / validation checks.
