# V14.2 — Minimal ready menu

Main screen keeps maximum workspace. The only visible control is the bottom/compact three-dots control. Its menu contains only:
- Model Ready / Get 5 Predictions
- Calculator
- Model Statistics
- Settings

The continuous background learner runs until the configured 10/10 readiness gates are met. Once ready, it stays in foreground-service idle mode, continues resolving pending predictions and waits for an explicit Get 5 Predictions request. A requested TOP-5 scan is verified (Entry/SL/TP1/TP2/TP3) and its results feed further learning.
