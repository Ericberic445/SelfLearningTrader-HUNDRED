# V15.2 — Foreground service autostart fix

- Keeps the existing python-for-android foreground service.
- Adds an authoritative `TraderApp.on_start()` service startup/recovery path after the Android Activity is started.
- `on_resume()` now restarts the foreground service when it has disappeared, unless the user explicitly stopped it.
- Existing service heartbeat, STOP/RESUME and scanner logic are unchanged.
- No UI layout changes.
