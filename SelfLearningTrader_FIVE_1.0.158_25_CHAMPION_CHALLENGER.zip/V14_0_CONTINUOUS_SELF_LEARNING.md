# SelfLearningTrader V14.0 — continuous self-learning loop

The scanner now follows one continuous cycle on Android:

`SCAN 673+ contracts -> TOP-5 -> VERIFY -> LEARN -> SCAN AGAIN`

For every TOP-5 prediction the app stores the frozen prediction and later evaluates:
- Entry reference
- SL
- TP1
- TP2
- TP3
- first hit / timeout
- return, MFE and MAE

Resolved predictions are stored as experience for the corresponding contract model. The service resolves pending files for **all contracts**, retrains only affected models, then starts the next market scan.

## Anti-WAIT safeguard

The classifier uses balanced class weighting and the live decision has configurable direction confidence and direction-vs-WAIT edge thresholds. Champion selection uses unseen future validation and includes balanced accuracy, directional precision and action rate. A candidate that predicts WAIT on almost everything is rejected when the validation segment contains meaningful directional labels.

## Validation

Training always uses an earlier segment and evaluates the candidate on a later unseen segment. A new candidate replaces the champion only when its validation selection score improves.

## Android background operation

The scanner is a real foreground service with `dataSync` foreground-service type and a partial wake lock. The service is intentionally **not sticky**: normal service recreation must not create an unsolicited second scan. The loop itself controls when the next cycle begins.

The Kivy UI attaches to an already-running background service after Android process recreation instead of starting another one.
