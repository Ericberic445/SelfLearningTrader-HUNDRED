from pathlib import Path
import json, time, threading
import numpy as np
from .features import add_features, align_mtf, make_labels, FEATURES
from .model import ModelManager

_ENGINE_FILE_LOCK=threading.RLock()

class LearningEngine:
    def __init__(self,root,exchange,config):
        self.root=Path(root); self.exchange=exchange; self.cfg=config
        self.data=self.root/'data'; self.data.mkdir(exist_ok=True); self.logs=self.root/'logs'; self.logs.mkdir(exist_ok=True)
        self.mm=ModelManager(self.root, self.exchange.futures_symbol, self.cfg); self.pending=self.logs/f'{self.exchange.futures_symbol}_pending.json'; self.predictions=self.logs/f'{self.exchange.futures_symbol}_predictions.json'; self.experience=self.data/'global_experience.npz'
    def set_symbol(self, symbol):
        self.exchange.set_symbol(symbol)
        self.mm=ModelManager(self.root, self.exchange.futures_symbol, self.cfg)
        self.pending=self.logs/f'{self.exchange.futures_symbol}_pending.json'
        self.predictions=self.logs/f'{self.exchange.futures_symbol}_predictions.json'
        self.experience=self.data/'global_experience.npz'

    def collect(self):
        return {tf:self.exchange.candles(tf,int(self.cfg.get('history_limit',5000))) for tf in self.cfg['timeframes']}
    def build_training(self,frames):
        base=add_features(frames['5min']); x=align_mtf(base,{k:v for k,v in frames.items() if k!='5min'})
        x=make_labels(x,int(self.cfg['horizon_bars']),float(self.cfg['long_threshold']),float(self.cfg['short_threshold']))
        n=len(x['time'])
        for f in FEATURES:
            if f not in x: x[f]=np.zeros(n)
            a=np.asarray(x[f],float).reshape(-1)
            if len(a)!=n: raise ValueError(f'Несовпадение длины признака {f}: {len(a)} вместо {n}')
            x[f]=a
        y=np.asarray(x['target'],float); good=np.isfinite(y)
        for f in FEATURES: good &= np.isfinite(x[f])
        return {f:np.asarray(x[f])[good] for f in FEATURES}|{'target':y[good],'time':np.asarray(x['time'])[good]}
    def _load_exp(self):
        if not self.experience.exists(): return None
        try:
            z=np.load(self.experience); return {k:z[k] for k in z.files}
        except Exception:return None
    def _save_exp(self,x): np.savez(self.experience,**x)
    def _merge_experience(self,hist):
        old=self._load_exp()
        if not old:return hist
        # Experience is already resolved against future market data; append only unique timestamps.
        all_t=np.concatenate([np.asarray(hist['time']),np.asarray(old['time'])]); order=np.argsort(all_t); _,idx=np.unique(all_t[order],return_index=True); keep=order[idx]
        out={'time':all_t[keep]}
        for f in FEATURES+['target']:
            out[f]=np.concatenate([hist[f],old[f]])[keep]
        return out
    def train_from_fresh(self):
        frames=self.collect(); hist=self.build_training(frames); data=self._merge_experience(hist)
        min_rows=int(self.cfg.get('min_training_rows',500)); test_fraction=float(self.cfg.get('test_fraction',.2))
        # First ever training creates the working champion. Every later batch
        # creates a challenger; it never silently replaces the champion.
        if not self.mm.has_champion():
            return self.mm.train(data,min_rows,test_fraction)
        return self.mm.train_challenger(data,min_rows,test_fraction)
    def live_row(self):
        frames=self.collect(); base=add_features(frames['5min']); x=align_mtf(base,{k:v for k,v in frames.items() if k!='5min'}); n=len(x['time'])
        metrics=self.exchange.current_market_metrics()
        for k,v in metrics.items(): x[k]=np.full(n,float(v))
        for f in FEATURES:
            a=np.asarray(x.get(f,[])).reshape(-1)
            if len(a)!=n: raise ValueError(f'Некорректная длина признака {f}: {len(a)}, ожидалось {n}')
        if n==0: raise ValueError('KuCoin не вернул 5min свечи')
        i=n-1; return {k:np.asarray([v[i]]) for k,v in x.items()}
    def _signal_levels(self,row,pred):
        price=float(row['close'][0]); atr=float(row['atrpct'][0])*price; atr=max(atr,price*0.001)
        if pred=='LONG': return price,price-1.2*atr,price+1.8*atr,price+2.7*atr,price+3.6*atr
        if pred=='SHORT': return price,price+1.2*atr,price-1.8*atr,price-2.7*atr,price-3.6*atr
        # WAIT deliberately has no trading plan. Keep only the reference market price;
        # UI/calculator must not turn WAIT into an accidental LONG/SHORT order.
        return price,float('nan'),float('nan'),float('nan'),float('nan')
    def predict_and_store(self, manual=False, source='auto'):
        row=self.live_row(); pred,probs=self.mm.predict(row); entry,sl,tp1,tp2,tp3=self._signal_levels(row,pred); ts=int(row['time'][0]); item={'id':f"{time.time_ns()}-{self.exchange.futures_symbol}",'symbol':self.exchange.symbol,'exchange_symbol':self.exchange.futures_symbol,'contract':self.exchange.futures_symbol,'time':ts,'price':float(row['close'][0]),'prediction':pred,'p_short':probs[0],'p_wait':probs[1],'p_long':probs[2],'entry':entry,'sl':sl,'tp1':tp1,'tp2':tp2,'tp3':tp3,'horizon_bars':int(self.cfg['horizon_bars']),'resolved':0,'manual':bool(manual),'source':str(source)}
        item['features']={f:float(row[f][0]) for f in FEATURES}
        item.update(self.mm.prediction_diagnostics(row,pred,probs))
        if self.mm.has_challenger():
            try:
                sp,sprobs=self.mm.predict_challenger(row); se,ssl,st1,st2,st3=self._signal_levels(row,sp)
                item.update({'shadow_prediction':sp,'shadow_p_short':sprobs[0],'shadow_p_wait':sprobs[1],'shadow_p_long':sprobs[2],
                             'shadow_entry':se,'shadow_sl':ssl,'shadow_tp1':st1,'shadow_tp2':st2,'shadow_tp3':st3,
                             'comparison_generation':self.mm.generation_info().get('generation')})
            except Exception: pass
        self._append_json(self.predictions,item); self._append_json(self.pending,item); return item
    def _read_json(self,path):
        try:return json.loads(path.read_text()) if path.exists() else []
        except Exception:return []
    def _write_json(self,path,data): path.write_text(json.dumps(data,ensure_ascii=False))
    def _append_json(self,path,item): data=self._read_json(path); data.append(item); self._write_json(path,data[-1000:])
    def _verification_slots(self, items):
        """Return IDs allowed to occupy the ten long-running slots."""
        try:
            now_bars=np.asarray(self.exchange.candles('5min',min(int(self.cfg.get('history_limit',5000)),5000))['time'])
        except Exception:
            return {x.get('id') for x in items}
        if len(now_bars)==0:return {x.get('id') for x in items}
        candidates=[]
        for item in items:
            if str(item.get('prediction','WAIT')).upper() not in ('LONG','SHORT'):
                continue
            horizon=int(item.get('horizon_bars',self.cfg.get('horizon_bars',12)))
            idx=int(np.searchsorted(now_bars,int(item.get('time',0)),side='right')); age=max(0,len(now_bars)-idx)
            if age>=horizon:
                candidates.append((int(item.get('time',0)),str(item.get('id',''))))
        candidates.sort()
        return {pid for _,pid in candidates[:10]}

    def _evaluate_shadow(self,item,t,h,l,c):
        """Evaluate challenger on exactly the same future candles as champion."""
        direction=str(item.get('shadow_prediction','WAIT')).upper()
        if direction not in ('LONG','SHORT'):
            return {'prediction':direction,'resolved':True,'tp1_hit':False,'tp2_hit':False,'tp3_hit':False,'initial_sl_failure':False,'sl_hit':False,'protected_exit':False,'result':'WAIT','mfe':0.0,'mae':0.0,'hit':None,'exit_reason':'WAIT'}
        idx=int(np.searchsorted(t,int(item.get('time',0)),side='right'))
        if idx>=len(c): return None
        entry=float(item.get('shadow_entry',item.get('price',c[idx]))); sl=float(item.get('shadow_sl',float('nan')))
        tp1=float(item.get('shadow_tp1',float('nan'))); tp2=float(item.get('shadow_tp2',float('nan'))); tp3=float(item.get('shadow_tp3',float('nan')))
        tp1_hit=tp2_hit=tp3_hit=False; protected=False; first=None; exit_reason=None
        highs=h[idx:]; lows=l[idx:]; closes=c[idx:]
        for off,(hi,lo) in enumerate(zip(highs,lows)):
            if direction=='LONG':
                original=np.isfinite(sl) and lo<=sl; n3=np.isfinite(tp3) and hi>=tp3 and not tp3_hit; n2=np.isfinite(tp2) and hi>=tp2 and not tp2_hit; n1=np.isfinite(tp1) and hi>=tp1 and not tp1_hit
            else:
                original=np.isfinite(sl) and hi>=sl; n3=np.isfinite(tp3) and lo<=tp3 and not tp3_hit; n2=np.isfinite(tp2) and lo<=tp2 and not tp2_hit; n1=np.isfinite(tp1) and lo<=tp1 and not tp1_hit
            if not tp1_hit and original:
                return {'prediction':direction,'resolved':True,'tp1_hit':False,'tp2_hit':False,'tp3_hit':False,'initial_sl_failure':True,'sl_hit':True,'protected_exit':False,'result':'SL','mfe':((np.max(highs)-entry)/entry if direction=='LONG' else (entry-np.min(lows))/entry),'mae':((np.min(lows)-entry)/entry if direction=='LONG' else (entry-np.max(highs))/entry),'hit':'SL','exit_reason':'INITIAL_SL'}
            if n3:
                tp1_hit=tp2_hit=tp3_hit=True; first=first or 'TP3'; exit_reason='TP3'; break
            if n2: tp1_hit=tp2_hit=True; first=first or 'TP2'
            elif n1: tp1_hit=True; first=first or 'TP1'
            protective=entry if tp1_hit and not tp2_hit else (tp1 if tp2_hit and not tp3_hit else None)
            protected_hit=(protective is not None and (lo<=protective if direction=='LONG' else hi>=protective))
            if protected_hit and not tp3_hit:
                protected=True; exit_reason='PROTECTED_AT_TP1' if tp2_hit else 'BREAKEVEN_AT_ENTRY'; break
        return {'prediction':direction,'resolved':True,'tp1_hit':tp1_hit,'tp2_hit':tp2_hit,'tp3_hit':tp3_hit,
                'initial_sl_failure':False,'sl_hit':False,'protected_exit':protected,'result':('TP3' if tp3_hit else 'TP2' if tp2_hit else 'TP1' if tp1_hit else None),
                'mfe':((np.max(highs)-entry)/entry if direction=='LONG' else (entry-np.min(lows))/entry) if len(highs) else 0.0,
                'mae':((np.min(lows)-entry)/entry if direction=='LONG' else (entry-np.max(highs))/entry) if len(lows) else 0.0,
                'hit':first,'exit_reason':exit_reason}

    def resolve_pending(self, allowed_ids=None):
        """Advance every eligible prediction until a real event occurs.

        Initial horizon is only the first observation window.  If neither TP1
        nor SL is reached there, the prediction remains WAITING and is checked
        again on later candles.  TP1/TP2/TP3 are cumulative milestones: hitting
        TP1 never closes the prediction; it stays alive until TP3 or an SL after
        the achieved milestone.  Entry/SL/TP levels are never recalculated.
        """
        data=self._read_json(self.pending)
        unresolved=[x for x in data if not x.get('resolved')]
        if not unresolved:return []
        bars=self.exchange.candles('5min',min(int(self.cfg.get('history_limit',5000)),5000))
        t=np.asarray(bars['time']); h=np.asarray(bars['high']); l=np.asarray(bars['low']); c=np.asarray(bars['close'])
        if len(t)==0:return []
        active_map=self._verification_slots(unresolved) if allowed_ids is None else set(allowed_ids)
        long_running=[]
        for x in unresolved:
            if str(x.get('prediction','WAIT')).upper() in ('LONG','SHORT'):
                age=max(0,int(np.searchsorted(t,int(x.get('time',0)),side='right'))-1)
                if age>=int(x.get('horizon_bars',self.cfg.get('horizon_bars',12))): long_running.append(x)
        long_running.sort(key=lambda x:(int(x.get('time',0)),str(x.get('id',''))))
        queue_pos={x.get('id'):i+1 for i,x in enumerate(long_running) if x.get('id') not in active_map}
        changed=[]
        for item in unresolved:
            pid=item.get('id')
            # WAIT predictions have no trading plan and should not consume the
            # long-running verification slots.
            direction=str(item.get('prediction','WAIT')).upper()
            if direction not in ('LONG','SHORT'):
                continue
            idx=int(np.searchsorted(t,int(item['time']),side='right'))
            if idx>=len(c):
                continue
            horizon=int(item.get('horizon_bars', self.cfg.get('horizon_bars',12)))
            available_end=len(c)
            elapsed_bars=max(0,available_end-idx)
            if elapsed_bars>=horizon and pid not in active_map:
                item['verification_state']='QUEUED'
                item['queue_position']=queue_pos.get(pid)
                continue
            entry=float(item.get('entry',item.get('price',c[idx])))
            sl=float(item.get('sl',float('nan'))); tp1=float(item.get('tp1',float('nan')))
            tp2=float(item.get('tp2',float('nan'))); tp3=float(item.get('tp3',float('nan')))
            tp1_hit=bool(item.get('tp1_hit')); tp2_hit=bool(item.get('tp2_hit')); tp3_hit=bool(item.get('tp3_hit'))
            # Only a stop hit BEFORE TP1 is a failed prediction.  Once TP1 is
            # reached, the protection moves to Entry; after TP2 it moves to TP1.
            # A later protected exit is therefore recorded as the highest TP
            # reached, not as SL.
            sl_hit=bool(item.get('sl_hit')) and not tp1_hit
            protected_exit=bool(item.get('protected_exit',False))
            exit_reason=item.get('exit_reason')
            first_hit=item.get('hit') or None; first_hit_index=item.get('hit_index')
            state='ACTIVE'
            resolved=False
            highs=h[idx:available_end]; lows=l[idx:available_end]; closes=c[idx:available_end]
            for off,(hi,lo) in enumerate(zip(highs,lows)):
                if direction=='LONG':
                    original_stop_hit=np.isfinite(sl) and lo<=sl
                    next_tp3=np.isfinite(tp3) and hi>=tp3 and not tp3_hit
                    next_tp2=np.isfinite(tp2) and hi>=tp2 and not tp2_hit
                    next_tp1=np.isfinite(tp1) and hi>=tp1 and not tp1_hit
                    protective_level = entry if tp1_hit and not tp2_hit else (tp1 if tp2_hit and not tp3_hit else None)
                    protected_stop_hit = protective_level is not None and lo<=protective_level
                else:
                    original_stop_hit=np.isfinite(sl) and hi>=sl
                    next_tp3=np.isfinite(tp3) and lo<=tp3 and not tp3_hit
                    next_tp2=np.isfinite(tp2) and lo<=tp2 and not tp2_hit
                    next_tp1=np.isfinite(tp1) and lo<=tp1 and not tp1_hit
                    protective_level = entry if tp1_hit and not tp2_hit else (tp1 if tp2_hit and not tp3_hit else None)
                    protected_stop_hit = protective_level is not None and hi>=protective_level

                # Before TP1 the original SL is the only failure condition.
                # If TP1 was already achieved, the original SL is no longer
                # relevant: the effective protection is Entry/TP1.
                if not tp1_hit and original_stop_hit:
                    sl_hit=True
                    first_hit=first_hit or 'SL'; first_hit_index=first_hit_index if first_hit_index is not None else off
                    resolved=True; state='COMPLETED_SL'; exit_reason='INITIAL_SL'
                    break

                if next_tp3:
                    tp1_hit=True; tp2_hit=True; tp3_hit=True
                    first_hit=first_hit or 'TP3'; first_hit_index=first_hit_index if first_hit_index is not None else off
                    resolved=True; state='COMPLETED_TP3'; exit_reason='TP3'; protected_exit=False
                    break
                if next_tp2:
                    tp1_hit=True; tp2_hit=True
                    first_hit=first_hit or 'TP2'; first_hit_index=first_hit_index if first_hit_index is not None else off
                    state='WAITING_TP3'
                elif next_tp1:
                    tp1_hit=True
                    first_hit=first_hit or 'TP1'; first_hit_index=first_hit_index if first_hit_index is not None else off
                    state='WAITING_TP2'

                # Recalculate the effective protection after any milestone
                # reached in this candle. TP1 moves protection to Entry; TP2
                # moves it to TP1. A later hit is a protected exit, not SL.
                if direction=='LONG':
                    protective_level = entry if tp1_hit and not tp2_hit else (tp1 if tp2_hit and not tp3_hit else None)
                    protected_stop_hit = protective_level is not None and lo<=protective_level
                else:
                    protective_level = entry if tp1_hit and not tp2_hit else (tp1 if tp2_hit and not tp3_hit else None)
                    protected_stop_hit = protective_level is not None and hi>=protective_level
                if protected_stop_hit and not tp3_hit:
                    protected_exit=True
                    resolved=True
                    if tp2_hit:
                        state='COMPLETED_TP2_PROTECTED'; exit_reason='PROTECTED_AT_TP1'
                    elif tp1_hit:
                        state='COMPLETED_TP1_PROTECTED'; exit_reason='BREAKEVEN_AT_ENTRY'
                    break

            # No terminal event yet: keep the same prediction alive indefinitely.
            if not resolved:
                if elapsed_bars < horizon:
                    state='INITIAL_WAIT'
                elif tp2_hit:
                    state='WAITING_TP3'
                elif tp1_hit:
                    state='WAITING_TP2'
                else:
                    state='LONG_RUNNING_WAITING'
                item.update({'verification_state':state,'verification_elapsed_bars':elapsed_bars,
                             'waiting_hours':round((elapsed_bars*5)/60.0,2),
                             'resolved':0,'tp1_hit':tp1_hit,'tp2_hit':tp2_hit,'tp3_hit':tp3_hit,'sl_hit':sl_hit,
                             'hit':first_hit,'hit_index':first_hit_index})
                continue

            # Terminal result: keep cumulative milestone history.
            ret=float((closes[-1]/entry)-1.0) if entry else 0.0
            if direction=='LONG':
                mfe=float((np.max(highs)-entry)/entry) if len(highs) else 0.0
                mae=float((np.min(lows)-entry)/entry) if len(lows) else 0.0
                actual='LONG' if ret>=float(self.cfg['long_threshold']) else ('SHORT' if ret<=float(self.cfg['short_threshold']) else 'WAIT')
            else:
                mfe=float((entry-np.min(lows))/entry) if len(lows) else 0.0
                mae=float((entry-np.max(highs))/entry) if len(highs) else 0.0
                actual='SHORT' if ret<=float(self.cfg['short_threshold']) else ('LONG' if ret>=float(self.cfg['long_threshold']) else 'WAIT')
            item.update({'resolved':1,'actual':actual,'return':ret,'hit':first_hit or ('TP3' if tp3_hit else 'SL' if sl_hit else None),
                         'result':('TP3' if tp3_hit else 'TP2' if tp2_hit else 'TP1' if tp1_hit else 'SL' if sl_hit else None),
                         'exit_reason':exit_reason,'protected_exit':bool(protected_exit),
                         'hit_index':first_hit_index,'tp1_hit':bool(tp1_hit),'tp2_hit':bool(tp2_hit),'tp3_hit':bool(tp3_hit),
                         'sl_hit':bool(sl_hit),'initial_sl_failure':bool(sl_hit and not tp1_hit),'mfe':mfe,'mae':mae,'resolved_at':int(t[-1]),
                         'verification_state':state,'verification_elapsed_bars':elapsed_bars,
                         'waiting_hours':round((elapsed_bars*5)/60.0,2)})
            # Preserve the original probability and classify the resolved
            # outcome by calibration. All outcomes remain learning samples;
            # the 80% boundary changes the interpretation, not whether the
            # result is counted.
            self._annotate_confidence_outcome(item)
            if item.get('shadow_prediction') and self.mm.has_challenger():
                try:
                    shadow=self._evaluate_shadow(item,t,h,l,c)
                    if shadow:
                        item['shadow_result']=shadow.get('result'); item['shadow_tp1_hit']=bool(shadow.get('tp1_hit')); item['shadow_tp2_hit']=bool(shadow.get('tp2_hit')); item['shadow_tp3_hit']=bool(shadow.get('tp3_hit'))
                        item['shadow_initial_sl_failure']=bool(shadow.get('initial_sl_failure')); item['shadow_mfe']=float(shadow.get('mfe',0.0)); item['shadow_mae']=float(shadow.get('mae',0.0)); item['shadow_protected_exit']=bool(shadow.get('protected_exit'))
                        item['shadow_resolved']=True
                        self.mm.record_head_to_head(item,shadow)
                except Exception:
                    pass
            changed.append(item)

        if changed:
            changed_ids={x.get('id') for x in changed}
            unresolved_left=[x for x in data if not x.get('resolved') and x.get('id') not in changed_ids]
            self._write_json(self.pending,unresolved_left)
            self._append_experience(changed)
            preds=self._read_json(self.predictions); byid={x['id']:x for x in changed}
            for p in preds:
                if p.get('id') in byid:p.update(byid[p['id']])
            self._write_json(self.predictions,preds[-2000:])
        else:
            # Persist WAITING/QUEUED state even when no prediction finished.
            self._write_json(self.pending,unresolved)
            preds=self._read_json(self.predictions); byid={x.get('id'):x for x in unresolved}
            for p in preds:
                if p.get('id') in byid:
                    for k in ('verification_state','verification_elapsed_bars','waiting_hours','queue_position','tp1_hit','tp2_hit','tp3_hit','sl_hit','initial_sl_failure','protected_exit','exit_reason','result','hit','hit_index'):
                        if k in byid[p.get('id')]: p[k]=byid[p.get('id')][k]
            self._write_json(self.predictions,preds[-2000:])
        return changed

    def resolve_all_pending(self):
        """Advance all contracts while enforcing ten global long-running slots."""
        pending_items=[]
        for path in sorted(self.logs.glob('*_pending.json')):
            try:
                data=json.loads(path.read_text(encoding='utf-8')) if path.exists() else []
            except Exception:
                data=[]
            contract=path.name[:-len('_pending.json')]
            for item in data:
                if not item.get('resolved') and str(item.get('prediction','WAIT')).upper() in ('LONG','SHORT'):
                    pending_items.append((contract,item))
        now_ms=int(time.time()*1000)
        horizon_default=int(self.cfg.get('horizon_bars',12))
        long_running=[]
        for contract,item in pending_items:
            age=max(0,(now_ms-int(item.get('time',now_ms)))//300000)
            horizon=int(item.get('horizon_bars',horizon_default))
            if age>=horizon:
                long_running.append((int(item.get('time',0)),str(item.get('id','')),contract))
        long_running.sort()
        allowed_long={pid for _,pid,_ in long_running[:int(self.cfg.get('max_long_running_predictions',10))]}
        allowed_ids={pid for _,pid,_ in long_running if pid in allowed_long}
        queued={pid:i+1 for i,(_,pid,_) in enumerate(long_running) if pid not in allowed_long}
        for path in sorted(self.logs.glob('*_pending.json')):
            try:
                pdata=json.loads(path.read_text(encoding='utf-8')) if path.exists() else []
                changed_q=False
                for item in pdata:
                    pid=item.get('id')
                    if pid in queued and not item.get('resolved'):
                        item['verification_state']='QUEUED'; item['queue_position']=queued[pid]; changed_q=True
                if changed_q:
                    path.write_text(json.dumps(pdata,ensure_ascii=False))
                    pred_path=path.with_name(path.name.replace('_pending.json','_predictions.json'))
                    if pred_path.exists():
                        preds=json.loads(pred_path.read_text(encoding='utf-8'))
                        for pr in preds:
                            if pr.get('id') in queued:
                                pr['verification_state']='QUEUED'; pr['queue_position']=queued[pr.get('id')]
                        pred_path.write_text(json.dumps(preds[-2000:],ensure_ascii=False))
            except Exception:
                pass
        # Fresh predictions (< initial horizon) are always checked; only the
        # long-running pool is capped at ten globally across all symbols.
        resolved=[]
        for path in sorted(self.logs.glob('*_pending.json')):
            contract=path.name[:-len('_pending.json')]
            if not contract: continue
            try:
                self.set_symbol(contract)
                local_ids=[]
                try:
                    pdata=json.loads(path.read_text(encoding='utf-8')) if path.exists() else []
                except Exception:
                    pdata=[]
                for item in pdata:
                    if item.get('resolved'): continue
                    age=max(0,(now_ms-int(item.get('time',now_ms)))//300000)
                    horizon=int(item.get('horizon_bars',horizon_default))
                    if age<horizon or item.get('id') in allowed_ids:
                        local_ids.append(item.get('id'))
                resolved.extend(self.resolve_pending(allowed_ids=set(local_ids)))
            except Exception:
                continue
        return resolved

    def _training_state_path(self):
        return self.data/'training_batch_state.json'

    def _training_state(self):
        p=self._training_state_path()
        try:
            return json.loads(p.read_text(encoding='utf-8')) if p.exists() else {'last_retrain_resolved':0,'retrain_batches':0}
        except Exception:
            return {'last_retrain_resolved':0,'retrain_batches':0}

    def _save_training_state(self,state):
        p=self._training_state_path(); tmp=p.with_suffix('.tmp')
        tmp.write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf-8'); tmp.replace(p)

    def retrain_symbols(self, contracts, resolved_total=None, force=False):
        """Retrain in batches, not after every single resolved prediction.

        A completed prediction is recorded immediately, but model replacement is
        gated until a batch of new resolved observations has accumulated.
        """
        state=self._training_state()
        total=int(resolved_total if resolved_total is not None else self.global_stats().get('resolved',0))
        batch=int(self.cfg.get('retrain_batch_size',self.cfg.get('retrain_every',25)))
        batch=max(1,batch)
        due=force or (total-int(state.get('last_retrain_resolved',0))>=batch)
        if not due:
            return []
        results=[]
        # The model is global across the market, so one batch creates exactly
        # one challenger. Never retrain once per coin from the same 100-result
        # batch, otherwise the challenger would be overwritten repeatedly.
        contract=next(iter(sorted(set(c for c in contracts if c))), None)
        try:
            if contract: self.set_symbol(contract)
            results.append(('GLOBAL',self.train_from_fresh()))
        except Exception as exc:
            results.append(('GLOBAL',{'error':str(exc)}))
        state['last_retrain_resolved']=total
        state['retrain_batches']=int(state.get('retrain_batches',0))+1
        state['last_retrain_at']=int(time.time())
        state['last_batch_size']=batch
        self._save_training_state(state)
        return results

    def _annotate_confidence_outcome(self,item):
        """Classify a resolved prediction by its ORIGINAL confidence.
        All outcomes remain in statistics; confidence only changes interpretation.
        """
        pred=str(item.get('prediction','WAIT')).upper()
        actual=str(item.get('actual','WAIT')).upper()
        if pred not in ('LONG','SHORT'):
            return
        p=float(item.get('prediction_probability', item.get('p_long' if pred=='LONG' else 'p_short', 0.0)) or 0.0)
        p=max(0.0,min(1.0,p))
        confirmed=actual==pred
        opposite=actual in ('LONG','SHORT') and actual!=pred
        outcome=1.0 if confirmed else 0.0
        signed=outcome-p
        if p>=0.80: band='HIGH_80_PLUS'
        elif p>=0.60: band='MEDIUM_60_79'
        else: band='LOW_BELOW_60'
        item.update({'confidence_checked':True,'confidence_at_prediction':p,
                     'confidence_band':band,'confidence_confirmed':bool(confirmed),
                     'confidence_opposite':bool(opposite),'confidence_outcome':('CONFIRMED' if confirmed else 'OPPOSITE' if opposite else 'NEUTRAL'),
                     'calibration_error':float(signed),'brier_error':float((p-outcome)**2),
                     'learning_interpretation':('HIGH_CONFIDENCE_ERROR' if (p>=0.80 and not confirmed) else
                                                'HIGH_CONFIDENCE_CONFIRMATION' if p>=0.80 else
                                                'PROBABILITY_CONFIRMED' if confirmed else
                                                'PROBABILITY_UNDERESTIMATED' if opposite else 'PROBABILITY_UNCERTAIN')})

    def confidence_stats(self, items=None):
        if items is None:
            rows=[]
            for path in self.logs.glob('*_predictions.json'):
                try: rows.extend(json.loads(path.read_text(encoding='utf-8')))
                except Exception: pass
            items=rows
        resolved=[x for x in items if x.get('resolved') and x.get('prediction') in ('LONG','SHORT')]
        out={}
        for key,title in (('HIGH_80_PLUS','80%+'),('MEDIUM_60_79','60–79%'),('LOW_BELOW_60','<60%')):
            q=[x for x in resolved if x.get('confidence_band')==key]
            out[key]={'label':title,'total':len(q),
                      'confirmed':sum(bool(x.get('confidence_confirmed')) for x in q),
                      'opposite':sum(bool(x.get('confidence_opposite')) for x in q),
                      'neutral':sum(x.get('confidence_outcome')=='NEUTRAL' for x in q),
                      'confirmation_rate':(sum(bool(x.get('confidence_confirmed')) for x in q)/len(q) if q else None),
                      'mean_confidence':(sum(float(x.get('confidence_at_prediction',0)) for x in q)/len(q) if q else None),
                      'mean_calibration_error':(sum(float(x.get('calibration_error',0)) for x in q)/len(q) if q else None),
                      'mean_brier_error':(sum(float(x.get('brier_error',0)) for x in q)/len(q) if q else None)}
        return out

    def _append_experience(self,items):
        old=self._load_exp(); rows=[x for x in items if x.get('actual') in ('LONG','SHORT','WAIT')]
        if not rows:return
        new={'time':np.asarray([x['time'] for x in rows]),'target':np.asarray([{'SHORT':0,'WAIT':1,'LONG':2}[x['actual']] for x in rows],int)}
        for f in FEATURES:new[f]=np.asarray([x['features'][f] for x in rows],float)
        if old:
            ts=np.concatenate([old['time'],new['time']]); order=np.argsort(ts); keep=order[np.unique(ts[order],return_index=True)[1]]
            merged={'time':ts[keep]}
            for f in FEATURES+['target']: merged[f]=np.concatenate([old[f],new[f]])[keep]
            self._save_exp(merged)
        else:self._save_exp(new)
    def stats(self):
        p=self._read_json(self.predictions); resolved=[x for x in p if x.get('resolved')]; correct=[x for x in resolved if x.get('actual')==x.get('prediction')]
        return {'predictions':len(p),'pending':len([x for x in p if not x.get('resolved')]),'resolved':len(resolved),'correct':len(correct),'live_accuracy':(len(correct)/len(resolved) if resolved else None)}

    def global_stats(self):
        rows=[]
        for path in self.logs.glob('*_predictions.json'):
            try: rows.extend(json.loads(path.read_text(encoding='utf-8')))
            except Exception: pass
        resolved=[x for x in rows if x.get('resolved')]
        actionable=[x for x in resolved if x.get('prediction') in ('LONG','SHORT')]
        # Live prediction success is defined by reaching TP1 before SL.
        # Endpoint direction is kept separately as `actual` for model diagnostics;
        # it must never turn an SL-only result into a 100% live success.
        correct=[x for x in actionable if x.get('tp1_hit') and not (x.get('sl_hit') and not x.get('tp1_hit'))]
        batch_state=self._training_state()
        return {
            'predictions':len(rows), 'pending':len(rows)-len(resolved), 'resolved':len(resolved),
            'retrain_batches':int(batch_state.get('retrain_batches',0)),
            'resolved_since_retrain':max(0,len(resolved)-int(batch_state.get('last_retrain_resolved',0))),
            'retrain_batch_size':int(self.cfg.get('retrain_batch_size',25)),
            'correct':len(correct), 'accuracy':(len(correct)/len(resolved) if resolved else None),
            'actionable':len(actionable), 'action_rate':(len(actionable)/len(resolved) if resolved else None),
            'directional_accuracy':(sum(bool(x.get('tp1_hit')) for x in actionable)/len(actionable) if actionable else None),
            'tp1':sum(bool(x.get('tp1_hit')) for x in resolved),
            'tp2':sum(bool(x.get('tp2_hit')) for x in resolved),
            'tp3':sum(bool(x.get('tp3_hit')) for x in resolved),
            'sl':sum(bool(x.get('initial_sl_failure', x.get('sl_hit')) and not x.get('tp1_hit')) for x in resolved),
            'protected_exits':sum(bool(x.get('protected_exit')) for x in resolved),
        }

    def detailed_stats(self):
        """Return transparent live-verification statistics with explicit denominators."""
        rows=[]
        for path in self.logs.glob('*_predictions.json'):
            try:
                rows.extend(json.loads(path.read_text(encoding='utf-8')))
            except Exception:
                pass
        resolved=[x for x in rows if x.get('resolved')]
        actionable=[x for x in resolved if x.get('prediction') in ('LONG','SHORT')]

        def counts(items):
            long_items=[x for x in items if x.get('prediction')=='LONG']
            short_items=[x for x in items if x.get('prediction')=='SHORT']
            def hit(key, subset): return sum(bool(x.get(key)) for x in subset)
            def acc(subset):
                return (sum(x.get('actual')==x.get('prediction') for x in subset)/len(subset)) if subset else None
            return {
                'total':len(items),
                'long':len(long_items), 'short':len(short_items),
                'correct':sum(bool(x.get('tp1_hit')) for x in items),
                'accuracy':(sum(bool(x.get('tp1_hit')) for x in items)/len(items)) if items else None,
                'directional_accuracy':(sum(bool(x.get('tp1_hit')) for x in items if x.get('prediction') in ('LONG','SHORT'))/len([x for x in items if x.get('prediction') in ('LONG','SHORT')])) if [x for x in items if x.get('prediction') in ('LONG','SHORT')] else None,
                'tp1':hit('tp1_hit',items), 'tp2':hit('tp2_hit',items),
                'tp3':hit('tp3_hit',items), 'sl':sum(bool(x.get('initial_sl_failure', x.get('sl_hit')) and not x.get('tp1_hit')) for x in items),
                'protected_exits':sum(bool(x.get('protected_exit')) for x in items),
                'long_correct':sum(bool(x.get('tp1_hit')) for x in long_items),
                'short_correct':sum(bool(x.get('tp1_hit')) for x in short_items),
                'long_tp1':hit('tp1_hit',long_items), 'short_tp1':hit('tp1_hit',short_items),
                'long_tp2':hit('tp2_hit',long_items), 'short_tp2':hit('tp2_hit',short_items),
                'long_tp3':hit('tp3_hit',long_items), 'short_tp3':hit('tp3_hit',short_items),
                'long_sl':sum(bool(x.get('initial_sl_failure', x.get('sl_hit')) and not x.get('tp1_hit')) for x in long_items),
                'short_sl':sum(bool(x.get('initial_sl_failure', x.get('sl_hit')) and not x.get('tp1_hit')) for x in short_items),
            }

        def rate(n,d): return (n/d) if d else None
        allc=counts(resolved); act=counts(actionable)
        recent100=actionable[-100:] if len(actionable)>=100 else []
        recent500=actionable[-500:] if len(actionable)>=500 else []
        r100=counts(recent100); r500=counts(recent500)
        metas=[]
        for meta_path in (self.root/'models_v8_self_learning').glob('*/champion.json'):
            try:
                m=json.loads(meta_path.read_text(encoding='utf-8'))
                if m.get('accepted'): metas.append(m)
            except Exception:
                pass
        validation_rows=sum(int(m.get('test_rows',0) or 0) for m in metas)
        balanced=float(np.mean([float(m.get('balanced_accuracy',0)) for m in metas])) if metas else 0.0
        directional_precision=float(np.mean([float(m.get('directional_precision',0)) for m in metas])) if metas else 0.0
        action_rate=float(np.mean([float(m.get('action_rate',0)) for m in metas])) if metas else 0.0
        pending_rows=[x for x in rows if not x.get('resolved') and x.get('prediction') in ('LONG','SHORT')]
        active_long=[x for x in pending_rows if x.get('verification_state') in ('LONG_RUNNING_WAITING','WAITING_TP2','WAITING_TP3','ACTIVE')]
        queued_long=[x for x in pending_rows if x.get('verification_state')=='QUEUED']
        waiting_tp1=sum(1 for x in pending_rows if not x.get('tp1_hit'))
        waiting_tp2=sum(1 for x in pending_rows if x.get('tp1_hit') and not x.get('tp2_hit'))
        waiting_tp3=sum(1 for x in pending_rows if x.get('tp2_hit') and not x.get('tp3_hit'))
        return {
            'all':allc, 'actionable':act, 'recent100':r100, 'recent500':r500,
            'validation_rows':validation_rows, 'accepted_models':len(metas),
            'balanced_accuracy':balanced, 'directional_precision':directional_precision,
            'validation_action_rate':action_rate,
            'pending':len([x for x in rows if not x.get('resolved')]),
            'active_long_running':len(active_long), 'queued_long_running':len(queued_long),
            'waiting_tp1':waiting_tp1, 'waiting_tp2':waiting_tp2, 'waiting_tp3':waiting_tp3,
            'total_saved':len(rows),
            'confidence':self.confidence_stats(rows),
        }

    def readiness(self):
        """Return a conservative 0-10 readiness score for the whole self-learning system.

        Readiness is a gate, not a promise of future profit. It combines large-sample
        live verification with unseen-test metrics from accepted per-symbol champions.
        WAIT cannot satisfy the directional checks by itself.
        """
        gs=self.global_stats()
        resolved=[]
        for path in self.logs.glob('*_predictions.json'):
            try: resolved.extend(json.loads(path.read_text(encoding='utf-8')))
            except Exception: pass
        resolved=[x for x in resolved if x.get('resolved')]
        actionable=[x for x in resolved if x.get('prediction') in ('LONG','SHORT')]
        recent100=actionable[-100:] if len(actionable)>=100 else []
        recent500=actionable[-500:] if len(actionable)>=500 else []
        recent100_acc=(sum(bool(x.get('tp1_hit')) for x in recent100)/len(recent100)) if recent100 else None
        recent500_acc=(sum(bool(x.get('tp1_hit')) for x in recent500)/len(recent500)) if recent500 else None
        tp1=sum(bool(x.get('tp1_hit')) for x in actionable)/len(actionable) if actionable else None
        sl=sum(bool(x.get('initial_sl_failure', x.get('sl_hit')) and not x.get('tp1_hit')) for x in actionable)/len(actionable) if actionable else None
        metas=[]
        for meta_path in (self.root/'models_v8_self_learning').glob('*/champion.json'):
            try:
                m=json.loads(meta_path.read_text(encoding='utf-8'))
                if m.get('accepted'): metas.append(m)
            except Exception: pass
        val_rows=sum(int(m.get('test_rows',0) or 0) for m in metas)
        bal=float(np.mean([float(m.get('balanced_accuracy',0)) for m in metas])) if metas else 0.0
        dp=float(np.mean([float(m.get('directional_precision',0)) for m in metas])) if metas else 0.0
        ar=float(np.mean([float(m.get('action_rate',0)) for m in metas])) if metas else 0.0
        min_res=int(self.cfg.get('readiness_min_resolved',1000))
        min_val=int(self.cfg.get('readiness_min_validation_rows',1000))
        min_bal=float(self.cfg.get('readiness_min_balanced_accuracy',0.60))
        min_dp=float(self.cfg.get('readiness_min_directional_precision',0.65))
        min_ar=float(self.cfg.get('readiness_min_action_rate',0.10))
        min_recent=float(self.cfg.get('readiness_min_recent_directional_accuracy',0.90))
        min_tp1=float(self.cfg.get('readiness_min_tp1_rate',0.90))
        max_sl=float(self.cfg.get('readiness_max_sl_rate',0.10))
        min_acc=float(self.cfg.get('readiness_min_accuracy',0.90))
        min_recent_acc=float(self.cfg.get('readiness_min_recent_accuracy',0.90))
        batch_state=self._training_state()
        retrained_batches=int(batch_state.get('retrain_batches',0))
        checks=[
            retrained_batches>=1,
            gs['resolved']>=min_res,
            gs.get('accuracy') is not None and gs['accuracy']>=min_acc,
            recent100_acc is not None and recent100_acc>=min_recent_acc,
            val_rows>=min_val,
            bal>=min_bal,
            dp>=min_dp,
            ar>=min_ar,
            recent500_acc is not None and recent500_acc>=min_recent,
            tp1 is not None and tp1>=min_tp1,
            sl is not None and sl<=max_sl,
            bool(metas) and all(bool(m.get('not_wait_machine',False)) for m in metas),
        ]
        reasons=[]
        labels=['было пакетное переобучение','проверено достаточно прогнозов','общая точность TP1','точность последних 100','есть независимая валидация','balanced accuracy','точность LONG/SHORT','доля активных прогнозов','стабильность последних 500','достижение TP1','контроль SL','модель не является WAIT-машиной']
        for ok,label in zip(checks,labels):
            if not ok: reasons.append(label)
        return {
            'score':int(sum(bool(x) for x in checks)), 'ready':bool(all(checks)), 'checks':checks, 'labels':labels, 'reasons':reasons,
            'resolved':gs['resolved'],'validation_rows':val_rows,'balanced_accuracy':bal,'directional_precision':dp,'action_rate':ar,
            'recent100_directional_accuracy':recent100_acc,'recent500_directional_accuracy':recent500_acc,
            'tp1_rate':tp1,'sl_rate':sl,'accepted_models':len(metas),
            'accuracy':gs.get('accuracy'),'recent100_accuracy':recent100_acc,
            'retrain_batches':retrained_batches,'retrain_batch_size':int(self.cfg.get('retrain_batch_size',25)),
        }
    def learning_cycle(self):
        resolved=self.resolve_pending(); trained=self.train_from_fresh(); return resolved,trained,self.stats()

    def _quick_candidate(self, item):
        # Lightweight market-wide pre-scan: one recent 5m window per contract.
        # This avoids training hundreds of separate models before ranking the market.
        self.set_symbol(item['contract'])
        bars=self.exchange.candles('5min',240)
        x=add_features(bars); i=len(x['time'])-1
        if i<40: raise ValueError('слишком мало 5m свечей')
        close=float(x['close'][i]); rsi=float(x['rsi'][i]); trend=float(x['trend'][i]);
        macd=float(x['macd'][i]); volz=float(x['volz'][i]); atr=float(x['atrpct'][i]);
        # Directional technical score, deliberately bounded to [-1,1].
        score=(0.30*np.tanh(trend*120.0)+0.25*np.tanh(macd*120.0)+
               0.20*np.clip((rsi-50.0)/25.0,-1,1)+0.15*np.tanh(volz/2.0)+
               0.10*np.tanh((float(x['ret3'][i]) if np.isfinite(x['ret3'][i]) else 0.0)*80.0))
        score=float(np.clip(score,-1,1))
        # Liquidity is a ranking factor, not a directional signal.
        liq=float(item.get('turnover',0.0) or 0.0)
        quality=float(np.clip(abs(score)*0.75 + min(1.0,np.log10(max(liq,1.0))/10.0)*0.25,0,1))
        return {'contract':item['contract'],'symbol':item['display'],'price':close,'quick_score':score,
                'quality':quality,'turnover24h':liq,'atrpct':atr,'rsi':rsi}

    def _persist_scan_prediction(self, r):
        """Persist only a selected TOP candidate, never every deep finalist."""
        contract=str(r.get('contract') or r.get('exchange_symbol') or '')
        if not contract:return
        pred_path=self.logs/f'{contract}_predictions.json'
        pending_path=self.logs/f'{contract}_pending.json'
        self._append_json(pred_path,r)
        self._append_json(pending_path,r)

    def _scan_train_and_predict(self,item,scan_history=800,run_id=None):
        # Full model validation only for the best pre-scan candidates.
        old_limit=self.cfg.get('history_limit',5000)
        try:
            self.cfg['history_limit']=max(500,int(scan_history))
            self.set_symbol(item['contract'])
            if not self.mm.has_champion():
                self.train_from_fresh()
            row=self.live_row(); pred,probs=self.mm.predict(row)
            entry,sl,tp1,tp2,tp3=self._signal_levels(row,pred)
            r={'id':f"{time.time_ns()}-{self.exchange.futures_symbol}",'symbol':self.exchange.symbol,'exchange_symbol':self.exchange.futures_symbol,
               'contract':self.exchange.futures_symbol,'time':int(row['time'][0]),'price':float(row['close'][0]),
               'prediction':pred,'p_short':probs[0],'p_wait':probs[1],'p_long':probs[2],
               'entry':entry,'sl':sl,'tp1':tp1,'tp2':tp2,'tp3':tp3,'horizon_bars':int(self.cfg['horizon_bars']),'resolved':0,
               'turnover24h':float(item.get('turnover',0.0) or 0.0), 'run_id':run_id}
            r['quality']=float(max(probs.values()))
            r['edge_score']=float(max(probs[0],probs[2])-probs[1])
            r['features']={f:float(row[f][0]) for f in FEATURES}
            if self.mm.has_challenger():
                try:
                    sp,sprobs=self.mm.predict_challenger(row); se,ssl,st1,st2,st3=self._signal_levels(row,sp)
                    r.update({'shadow_prediction':sp,'shadow_p_short':sprobs[0],'shadow_p_wait':sprobs[1],'shadow_p_long':sprobs[2],
                              'shadow_entry':se,'shadow_sl':ssl,'shadow_tp1':st1,'shadow_tp2':st2,'shadow_tp3':st3,
                              'comparison_generation':self.mm.generation_info().get('generation')})
                except Exception: pass
            return r
        finally:
            self.cfg['history_limit']=old_limit

    @staticmethod
    def _classify_scan_error(exc):
        """Classify a scanner failure so the UI can explain the error instead of
        showing only one aggregate counter."""
        msg=str(exc or '').lower()
        if any(x in msg for x in ('no address associated with hostname','temporary failure in name resolution','name or service not known','nodename nor servname','getaddrinfo','dns')):
            return 'DNS/сеть'
        if any(x in msg for x in ('http 429','http 408','http 500','http 502','http 503','http 504','timeout','timed out','connection reset','connection aborted','connection refused')):
            return 'HTTP/сеть'
        if 'http ' in msg or 'api' in msg or 'kucoin' in msg and 'не вернул' not in msg:
            return 'API/ответ'
        if any(x in msg for x in ('не вернул свечи','пуст','слишком мало')):
            return 'Свечи/данные'
        return 'Обработка данных'

    def _apply_ready_freshness(self, results, candidate_pool, run_id=None, cancel_event=None):
        """Final freshness gate used only after the model is READY.

        Small price movement is accepted. A material move triggers a fast
        re-analysis of that coin only. If it is still moving materially, the
        candidate is retried a bounded number of times. Invalidated candidates
        are replaced from the already scanned deep candidate pool; the full
        market scan is never restarted.
        """
        if not bool(self.cfg.get('freshness_enabled_when_ready', True)):
            return results, {'enabled': False}
        try:
            if not bool(self.readiness().get('ready')):
                return results, {'enabled': False, 'reason': 'model_not_ready'}
        except Exception:
            return results, {'enabled': False, 'reason': 'readiness_check_failed'}

        small=float(self.cfg.get('freshness_small_move_pct',0.20))
        trigger=float(self.cfg.get('freshness_recheck_move_pct',0.50))
        retries=max(1,int(self.cfg.get('freshness_max_rechecks',2)))
        pool_limit=max(5,int(self.cfg.get('freshness_candidate_pool',50)))
        try:
            tickers=self.exchange.all_tickers()
            price_map={}
            for t in tickers or []:
                sym=str(t.get('symbol','')).upper()
                try:
                    px=float(t.get('price',t.get('markPrice',0)) or 0)
                except Exception:
                    px=0.0
                if sym and px>0: price_map[sym]=px
        except Exception:
            price_map={}

        used=set()
        final=[]
        stats={'enabled':True,'checked':0,'small_move':0,'rechecked':0,'invalidated':0,'retries':0}

        # Keep the original ranking, then fill vacancies from the already
        # scanned deep pool in ranking order.
        pool=[]
        for r in list(results)+list(candidate_pool):
            c=str(r.get('contract') or r.get('exchange_symbol') or '')
            if c and c not in used:
                used.add(c); pool.append(dict(r))
        pool=pool[:max(pool_limit,len(results))]

        for candidate in pool:
            if len(final)>=5: break
            if cancel_event is not None and cancel_event.is_set(): break
            current=dict(candidate)
            for attempt in range(retries+1):
                contract=str(current.get('contract') or current.get('exchange_symbol') or '')
                entry=float(current.get('entry',current.get('price',0)) or 0)
                market_px=float(price_map.get(contract,0) or 0)
                if market_px<=0:
                    # A ticker miss is not a reason to discard a valid signal.
                    current['freshness_status']='ticker_unavailable'
                    current['freshness_checked_at']=int(time.time())
                    break
                delta=abs(market_px/entry-1.0)*100.0 if entry>0 else 0.0
                stats['checked']+=1
                current['freshness_checked_at']=int(time.time())
                current['freshness_market_price']=market_px
                current['freshness_move_pct']=delta
                current['freshness_attempt']=attempt
                # Small movement is acceptable; preserve the original Entry/SL/TP
                # calculated from the prediction snapshot.
                if delta < trigger:
                    current['freshness_status']='fresh' if delta <= small else 'acceptable_move'
                    if delta <= small: stats['small_move']+=1
                    break
                if attempt>=retries:
                    current['freshness_status']='unstable'
                    stats['invalidated']+=1
                    current=None
                    break
                # Re-analyse only this coin using the newest candles.
                stats['rechecked']+=1; stats['retries']+=1
                try:
                    ex=KuCoin(contract,timeout=self.exchange.timeout)
                    ex._request_gap=max(float(getattr(ex,'_request_gap',0.10)), float(self.cfg.get('scan_model_request_gap',0.20)))
                    eng=LearningEngine(self.root,ex,dict(self.cfg))
                    fresh=eng._scan_train_and_predict({'contract':contract,'display':current.get('symbol',ex.display_symbol(contract)),'turnover':current.get('turnover24h',0.0)},800,run_id=run_id)
                    fresh['quick_score']=current.get('quick_score',0.0)
                    fresh['prescan_quality']=current.get('prescan_quality',0.0)
                    current=fresh
                    # Re-read the ticker for this coin immediately after re-analysis.
                    try:
                        latest=ex.all_tickers()
                        for t in latest or []:
                            if str(t.get('symbol','')).upper()==contract:
                                px=float(t.get('price',t.get('markPrice',0)) or 0)
                                if px>0: price_map[contract]=px
                                break
                    except Exception:
                        pass
                    if str(current.get('prediction','WAIT')).upper() not in ('LONG','SHORT'):
                        current=None
                        stats['invalidated']+=1
                        break
                except Exception:
                    current=None
                    stats['invalidated']+=1
                    break
            if current is not None and str(current.get('prediction','WAIT')).upper() in ('LONG','SHORT'):
                final.append(current)

        # If the market was moving too quickly, return the stable subset rather
        # than looping the complete 670+ symbol scan.
        final.sort(key=lambda r:(r.get('edge_score',-9),r.get('quality',0),r.get('turnover24h',0)),reverse=True)
        return final[:5], stats

    def scan_all(self, progress=None, cancel_event=None, run_id=None):
        """Full market scan with a fast parallel pre-scan and a bounded deep stage.

        Every active USDT perpetual is still considered.  The expensive model
        stage is only run for the best pre-scan candidates, while the pre-scan
        itself uses a small worker pool and conservative per-connection pacing.
        """
        from .exchange import KuCoin
        from concurrent.futures import ThreadPoolExecutor, as_completed
        scan_cfg=dict(self.cfg)
        base_exchange=KuCoin(self.exchange.futures_symbol, timeout=self.exchange.timeout)
        symbols=base_exchange.active_symbols()
        total=len(symbols)
        quick=[]; errors=0; results=[]; prescan_errors=0; model_errors=0
        error_breakdown={'DNS/сеть':0,'HTTP/сеть':0,'API/ответ':0,'Свечи/данные':0,'Обработка данных':0,'Модель':0}
        error_samples=[]
        seen_contracts=[]; seen=set()
        for item in symbols:
            c=item['contract']
            if c not in seen:
                seen.add(c); seen_contracts.append(item)
        symbols=seen_contracts; total=len(symbols)
        progress_lock=threading.Lock(); completed=0; error_count=0; ok_count=0

        workers=max(1,min(4,int(scan_cfg.get('scan_workers',4))))
        def quick_one(item):
            ex=KuCoin(item['contract'],timeout=base_exchange.timeout)
            ex._request_gap=max(float(getattr(ex,'_request_gap',0.10)), float(scan_cfg.get('scan_request_gap',0.20)))
            eng=LearningEngine(self.root,ex,scan_cfg)
            return eng._quick_candidate(item)
        with ThreadPoolExecutor(max_workers=workers,thread_name_prefix='quickscan') as pool:
            futs={pool.submit(quick_one,item):item for item in symbols}
            for fut in as_completed(futs):
                item=futs[fut]
                if cancel_event is not None and cancel_event.is_set():
                    break
                try:
                    q=fut.result(); quick.append(q); ok_count+=1
                    err=None
                except Exception as e:
                    errors+=1; prescan_errors+=1; error_count+=1; err=e
                    category=self._classify_scan_error(e); error_breakdown[category]=error_breakdown.get(category,0)+1
                    if len(error_samples)<50: error_samples.append({'symbol':item['display'],'stage':'PRESCAN','category':category,'error':str(e)})
                with progress_lock:
                    completed+=1; d=completed
                if progress: progress(d,total,item['display'],q if err is None else None, None if err is None else {'error':str(err),'category':self._classify_scan_error(err)},phase='PRESCAN')
        if cancel_event is not None and cancel_event.is_set():
            diagnostics={'total_errors':errors,'prescan_errors':errors,'model_errors':0,'breakdown':error_breakdown,'samples':error_samples,'ok':ok_count,'cancelled':True}
            return results,total,ok_count,errors,diagnostics

        quick_by_contract={r['contract']:r for r in quick}; quick=list(quick_by_contract.values())
        quick.sort(key=lambda r:(r.get('quality',0),abs(r.get('quick_score',0)),r.get('turnover24h',0)),reverse=True)
        max_finalists=max(10,int(scan_cfg.get('scan_deep_candidates',40)))
        deep=quick[:max_finalists]
        model_workers=max(1,min(3,int(scan_cfg.get('scan_model_workers',2))))
        model_done=0; next_deep=0
        from concurrent.futures import wait, FIRST_COMPLETED
        def model_one(item):
            ex=KuCoin(item['contract'],timeout=base_exchange.timeout)
            ex._request_gap=max(float(getattr(ex,'_request_gap',0.10)), float(scan_cfg.get('scan_model_request_gap',0.20)))
            eng=LearningEngine(self.root,ex,scan_cfg)
            return eng._scan_train_and_predict({'contract':item['contract'],'display':item['symbol'],'turnover':item['turnover24h']},800,run_id=run_id)
        with ThreadPoolExecutor(max_workers=model_workers,thread_name_prefix='modelscan') as pool:
            pending_futures={}
            while next_deep < len(deep) and len(pending_futures) < model_workers:
                item=deep[next_deep]; next_deep+=1
                pending_futures[pool.submit(model_one,item)]=item
            while pending_futures:
                done_set,_=wait(list(pending_futures),return_when=FIRST_COMPLETED)
                for fut in done_set:
                    item=pending_futures.pop(fut); model_done+=1
                    try:
                        r=fut.result(); r['quick_score']=item['quick_score']; r['prescan_quality']=item['quality']; r['scan_index']=model_done
                        if str(r.get('prediction','WAIT')).upper() in ('LONG','SHORT'): results.append(r)
                        err=None
                    except Exception as e:
                        model_errors+=1; errors+=1; category=self._classify_scan_error(e); error_breakdown[category]=error_breakdown.get(category,0)+1
                        if len(error_samples)<50: error_samples.append({'symbol':item['symbol'],'stage':'MODEL','category':category,'error':str(e)})
                        err={'error':str(e),'category':category}
                    if progress:
                        progress(model_done,len(deep),item['symbol'],None if err else r,err,phase='MODEL')
                    if (cancel_event is not None and cancel_event.is_set()):
                        break
                    if next_deep < len(deep):
                        ni=deep[next_deep]; next_deep+=1
                        pending_futures[pool.submit(model_one,ni)]=ni
                if cancel_event is not None and cancel_event.is_set():
                    for fut in pending_futures:
                        fut.cancel()
                    break
        unique={}
        for r in results:
            c=r.get('contract') or r.get('exchange_symbol')
            if c and c not in unique: unique[c]=r
        unique_pool={}
        for r in results:
            c=r.get('contract') or r.get('exchange_symbol')
            if c and c not in unique_pool: unique_pool[c]=r
        candidate_pool=list(unique_pool.values())
        candidate_pool.sort(key=lambda r:(r.get('edge_score',-9),r.get('quality',0),r.get('turnover24h',0)),reverse=True)
        results=candidate_pool[:5]
        results.sort(key=lambda r:(r.get('edge_score',-9),r.get('quality',0),r.get('turnover24h',0)),reverse=True)
        freshness_diag={'enabled':False}
        try:
            # Freshness is deliberately applied only to a READY model. Before
            # readiness, the learning scan remains unchanged.
            if bool(self.readiness().get('ready')):
                results,freshness_diag=self._apply_ready_freshness(results,candidate_pool[:max(5,int(scan_cfg.get('freshness_candidate_pool',50)))],run_id,cancel_event)
        except Exception as exc:
            freshness_diag={'enabled':True,'error':str(exc)}
        for r in results:
            try:
                self._persist_scan_prediction(r)
            except Exception as exc:
                errors+=1; model_errors+=1
                if len(error_samples)<50:
                    error_samples.append({'symbol':r.get('symbol',r.get('contract')),'stage':'PERSIST','category':'Обработка данных','error':str(exc)})
        diagnostics={'total_errors':errors,'prescan_errors':prescan_errors,
                      'model_errors':model_errors,'breakdown':error_breakdown,
                      'samples':error_samples,'ok':ok_count,'deep_candidates':len(deep),'scan_workers':workers,'model_workers':model_workers,'freshness':freshness_diag}
        return results,total,ok_count,errors,diagnostics

