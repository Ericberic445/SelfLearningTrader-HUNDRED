# SelfLearningTrader FIVE 1.0.157

Functional baseline aligned to the HUNDRED 1.0.198 logic.

Only intended statistical-cycle difference:
- FIVE: 25 resolved TOP-5 results to create a challenger, then 25 fresh results for head-to-head comparison.
- HUNDRED: 100 + 100.

Retained strictness:
- readiness accuracy >= 90%
- recent accuracy >= 90%
- recent directional accuracy >= 90%
- TP1 rate >= 90%
- SL-before-TP1 rate <= 10%
- challenger must exceed champion by the configured 0.01 head-to-head score margin
- confidence >= 80% is the high-confidence learning-error band; lower-confidence predictions are not classified as high-confidence errors
- TP/SL protection and TP3 completion rules remain those of the HUNDRED baseline.

Persistent functionality retained:
- champion/challenger generations
- runtime/background service and STOP control
- freshness/recheck
- backup/restore
- last-100 TOP-5 history
- runtime diagnostics
- persistent model/history state
- Android versioned update baseline
