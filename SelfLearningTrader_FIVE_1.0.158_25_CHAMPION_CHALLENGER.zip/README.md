# SelfLearningTrader FIVE — stable-update baseline 1.0.191

This build is restored directly from the last mature FIVE archive `1.0.187_FINAL_CHAIN_FIXED`.
The application logic is preserved; the Android update/build version is 1.0.191. This version establishes a permanent FIVE signing key stored in signing/debug.keystore. Future builds must reuse that exact keystore so Android updates remain installable over this baseline.

Core FIVE behavior preserved:
- full-market scan → TOP-50 deep candidates → TOP-5
- final freshness re-check of TOP-5 after scanning
- 80% confidence interpretation
- learning batches of 100
- TP/SL result logic
- Stop / Resume
- background foreground-service scanning
- learning-state backup/restore
SelfLearningTrader V15.3 — full legacy-app isolation.

This build is intentionally isolated from the the separate SelfLearningTrader FIVE package so both applications can be installed and run side-by-side. The Android package/service namespace, runtime state, locks, model storage and generation history are kept in the new app private namespace.

# SelfLearningTrader V14.21

V14.21 changes prediction-result accounting: only an original SL hit before TP1 is a failed result. After TP1 protection moves to Entry; after TP2 protection moves to TP1. Protected exits preserve the highest TP reached and are not counted as SL failures.

The selected-coin live monitor from V14.20 remains included.

# SelfLearningTrader V14.18 — continuous verification / TOP-50 / TOP-5

Новая логика проверки прогнозов:
- первый час — только начальное окно; отсутствие TP1/SL не считается ошибкой;
- TP1 не закрывает прогноз — после TP1 ждём TP2, после TP2 ждём TP3;
- TP3 завершает прогноз; исходный SL сохраняется; если SL сработал после TP1/TP2, достигнутые TP не стираются;
- одновременно активно не более 10 долгоиграющих прогнозов; остальные ставятся в очередь;
- Entry/SL/TP старого прогноза никогда не пересчитываются;
- проверка старых прогнозов идёт параллельно с новыми полными сканами;
- полный рынок → быстрый отбор → глубокий анализ TOP-50 → выбор TOP-5; все глубокие кандидаты анализируются до окончательного выбора, но сохраняются/проверяются только выбранные TOP-5;
- WAIT не используется для заполнения TOP-5.

Сборка: python-for-android `v2026.05.09`, Android NDK `28c`, arm64-v8a.
# SelfLearningTrader Ultimate V12

Android-only paper-trading market scanner for KuCoin USDT perpetuals.

## V12 fixes
- Correct KuCoin Futures candle parsing: `[time, open, high, low, close, volume, turnover]`.
- TOP-5 contains unique contracts only; one contract cannot occupy multiple slots.
- Scanner uses an isolated exchange/engine and never changes the user's selected coin.
- Scanner progress distinguishes real-candle candidates from request errors.
- Selected coin is explicitly shown in the UI; opening a TOP-5 candidate synchronizes the search/selection header.
- Manual coin search remains available for the full active-contract list.
- WAIT does not create a trading plan.
- Calculator and Cross/Isolated paper calculations retained.
- Portrait and landscape build configuration retained.

KuCoin's documented Futures Kline format is `[time, open, high, low, close, volume, turnover]`; the previous build incorrectly treated the high field as close, which could distort indicators and model outputs.

## V13 UI/UX redesign
- Main screen no longer shows the full market list; it shows scanner progress and an automatically generated TOP-5.
- Coin search suggestions appear only after the user starts typing.
- Analysis, AI Model and Settings tabs are functional rather than informational placeholders.
- Settings persist in the app user-data directory and affect subsequent scans/training.
- The scanner starts automatically after the active Futures list is loaded.
- TOP-5 candidates remain clickable for detailed prediction and position calculator.

## V13.11 UI navigation
The UI now uses real screen transitions: switching Scanner/Analysis/AI Model/Settings clears the previous screen without deleting stored data. The latest TOP-5 is persisted and can be restored from TOP-5 History. MENU is navigation-only; MORE contains contextual actions for the current screen.


V14.6: background status indicator now requires a fresh service heartbeat; stale running/ready_idle state is shown as service not responding. No UI redesign.

V14.7: candidate cards are hidden during PRESCAN/MODEL and stale rows are cleared at the start of every market cycle; TOP-5 is rendered only after the full market pass reaches VERIFY. Activity resume now forces a safe Kivy redraw/re-layout of the current logical screen without restarting the background service.


## V14.10 — startup fix + manual coin forecast + fast market scan
- Added `ПРОГНОЗ ПО МОНЕТЕ`: request a forecast for one selected/typed USDT perpetual without stopping automatic self-learning.
- Manual requests run in an isolated worker and use the same model, features and Entry/SL/TP logic.
- Full market scan keeps all active USDT perpetuals in the fast stage, using bounded parallel requests.
- Deep model analysis is limited to the best pre-scan candidates and uses a bounded worker pool, stopping after five real LONG/SHORT candidates are available.
- Model champion writes are atomic so manual prediction can safely read the model while automatic retraining is active.
- Status/cycle information blocks now grow with their text instead of overlapping.
- Added conservative scan settings: `scan_workers=4`, `scan_request_gap=0.20`, `scan_deep_candidates=40`, `scan_model_workers=2`, `scan_model_request_gap=0.20`.


## V14.11 build stability
- Pins python-for-android to stable v2026.05.09 instead of the moving develop branch.
- Keeps Android NDK r28c and NumPy support aligned with that release.


## V14.12 build fix
- Removed `libthorvg` from the custom Kivy recipe dependency list.
- The previous GitHub build log showed p4a incorrectly sending `libthorvg` to pip, where no Android wheel exists; this was the direct build-stopping error.
- Kept python-for-android pinned to stable `v2026.05.09`.


V14.13: fixed Android startup crash caused by passing `None` to Kivy `BoxLayout.height` in the dynamic panel helper.


### V14.15
- Added a persistent bottom STOP/RESUME action button on the scanner screen.
- STOP immediately changes to RESUME after a stop request.
- Button uses the same visible pressed-state feedback as other controls.
- The old hidden scroll-area stop control remains disabled/hidden for compatibility.


## V14.16 calculator margin mode
- Calculator defaults to CROSS margin.
- ISOLATED remains available as a manual user selection.
- Prediction verification does not use calculator margin mode.


## V15.1 generation cycle
The app keeps one shared market champion and at most one challenger. Every 100 newly resolved observations create one challenger. The next 100 fresh market situations are evaluated by both models on the same data path; only the head-to-head winner may become the new champion. Challenger training uses the accumulated experience of prior generations.


V15.3 isolation: stable Android package/service namespace and explicit private runtime namespace `stl_generational_v15_3`. This build is intended to coexist with the legacy SelfLearningTrader package.


## V1.0.157 — TOP-5 verification cycle
- The next full market scan starts only after all predictions from the current TOP-5 finish TP/SL verification.
- There is no fixed one-hour delay between TOP-5 scans.
- The current TOP-5 remains visible while its verification is running.


## V15.4 background startup watchdog
- The foreground-service heartbeat starts before heavy numpy/engine initialization and continues during cold start.
- This prevents the UI from falsely declaring a live Android service dead while the service is still initializing.
