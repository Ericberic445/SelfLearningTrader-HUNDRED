# V13.19 — Android touch rework

- Removed the previous `collide_point` expansion and Window-level touch interception.
- MENU, MORE, FULL and REFRESH now use dedicated invisible TouchArea wrappers.
- The visible button dimensions remain compact; only the wrapper is larger.
- Search field is no longer affected by expanded refresh hit-testing and remains a native TextInput.
- Log panel also has an enlarged invisible hit area.
- STOP/RESUME logic from V13.18 is retained.
