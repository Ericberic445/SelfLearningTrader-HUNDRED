# V13.16

- Search placeholder shortened to `Поиск монеты`, so it no longer collides with REFRESH.
- REFRESH keeps the same compact visual size, with a smaller label and expanded invisible touch area.
- All regular buttons now use an invisible expanded touch target while keeping their visible dimensions unchanged.
- TOP-5/content remains vertically scrollable; no attempt was made to disable scrolling.
- Added persistent session state in `session_state.json` under the Android app data directory.
- Added Android lifecycle save hooks (`on_pause`, `on_stop`) and restore on `on_resume`.
- Last TOP-5, visible scan rows, status text and recent log lines are saved so Android process recreation does not erase the user's latest results.
- Existing TOP-5 history persistence remains enabled.
