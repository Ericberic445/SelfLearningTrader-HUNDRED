# SelfLearningTrader FIVE 1.0.269 — Backup discovery

- Kept the Android Storage Access Framework manual file picker (`ACTION_OPEN_DOCUMENT`) for selecting a backup from Downloads, device storage, or supported document providers.
- Expanded automatic discovery from a Downloads-only path to Android `MediaStore.Files` across indexed shared external storage.
- Automatic discovery now accepts `.slbackup`, `.slbackup.zip`, and ZIP-wrapped backup files with the SelfLearningTrader backup filename prefix.
- Added a primary external-volume fallback for OEM MediaStore implementations that return no results from the aggregate external volume.
- Updated import-screen wording to describe the broader search.
- Kept restore verification (ZIP integrity, manifest, per-file SHA-256 checksums, required Master state) before writing restored data.
- No trading, scanning, model-training, or forecast logic changed.

Android scoped-storage limitation: an ordinary app cannot silently crawl every private app folder or every arbitrary file on modern Android. MediaStore discovery covers files indexed and exposed to this app; the SAF manual picker is the fallback for files outside that view.
