# SelfLearningTrader FIVE 1.0.210 — position assistant and auxiliary learning

## Changes in this version

- Kept the existing manual real-position entry/exit flow and existing UI.
- The real-position monitor keeps a bounded history of feature snapshots, sampling at least once per configured interval (60 seconds by default) or after a meaningful price move.
- On manual close, actual entry/exit and realized price move remain in `real_positions.json` separately from forecast outcome statistics.
- The same closed real position feeds two learning paths:
  - `REAL_POSITION_RESULT` and `REAL_POSITION_OBSERVATION` direction-only examples into the shared Master replay buffer (`data/global_experience.npz`). They never invent TP/SL labels and never train the TP/SL outcome head.
  - `data/position_risk_experience.json` learns whether the next short monitoring window contained adverse movement for the open position's direction. The trained model is saved in `data/position_risk_model.json`.
- During a real open position, the assistant continues the existing RSI/MACD/volume/order-book checks. It can now advise the user to consider protecting profit / moving the stop toward breakeven, or to review the stop and consider exit according to the user's own plan. It never sends or closes KuCoin orders.
- Once enough closed-position samples exist, the risk learner adds a model-derived risk index to alerts. Before sufficient examples exist, the assistant relies on explicit heuristic alerts; it does not pretend an untrained risk model is ready.
- Intermediate forecast observations are now sampled up to 48 times per lifecycle by default (previous default 12). A later scan price labels the previous observation immediately as LONG/SHORT/WAIT using the configured movement thresholds. These examples are direction-only, deduplicated, and excluded from TP/SL outcomes. They enter the shared replay buffer before the original forecast resolves.
- Auxiliary real-position and intermediate-observation examples can trigger a Master retrain after 25 pending samples, once the existing clean-reset migration is complete. Successful retraining clears the pending counters; unsuccessful retraining does not.
- Active forecasts outside TOP-5 remain observation-only and continue to preserve the original lifecycle.

## New/updated data files

- `data/position_risk_experience.json`
- `data/position_risk_model.json`
- `data/real_position_learning_state.json`
- `data/online_observation_learning_state.json`

All are created under the app's existing private runtime directory, not in the source ZIP.

## Validation performed

- Python compilation for all application `.py` files.
- Unit tests for the risk learner, risk advice, real-position replay rows, online intermediate observation learning, active rechecks outside TOP-5, and forecast lifecycle preservation.
- No live KuCoin trades are placed by these changes. Real Android background execution and live API behavior still require testing on the phone.
