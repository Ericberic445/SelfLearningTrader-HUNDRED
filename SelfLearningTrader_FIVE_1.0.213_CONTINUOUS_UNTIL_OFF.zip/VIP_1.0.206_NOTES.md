# SelfLearningTrader FIVE 1.0.206 VIP

Final working source archive based on 1.0.205 startup/scan UI fixes.

WAIT learning:
- 5m candles.
- 12 bars is an intermediate checkpoint only.
- Final WAIT learning horizon: 48 bars = 4 hours.
- WAIT is finalized after the full horizon and marked resolved=1.
- WAIT does not receive a trading TP/SL plan.
- Direction labels use the first significant +/- threshold crossing.
- Captures time/speed to first direction, TP1-level holding time, return-to-entry timing, continuation and max excursion.
- Brief threshold touch followed by rapid return is classified as FALSE_SPIKE and retained as a correct/neutral direction lesson rather than a hard missed-direction label.
- Final outcomes: WAIT_CORRECT, MISSED_LONG, MISSED_SHORT, FALSE_SPIKE.
- WAIT_CONTROL records are kept distinct from normal trade records for training.

Validation performed:
- Python compilation of all project .py files: PASS.
- engine.py AST/compile: PASS.
- ZIP integrity checked with zipfile.testzip().
