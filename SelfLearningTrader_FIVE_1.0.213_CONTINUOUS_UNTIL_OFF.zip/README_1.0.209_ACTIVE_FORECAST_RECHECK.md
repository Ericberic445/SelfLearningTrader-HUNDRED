# SelfLearningTrader FIVE 1.0.209 — independent active-forecast rechecks

## Required behavior

- Every active forecast is tracked for actual price movement and TP/SL independently of TOP-5 ranking.
- Every full-market scan cycle re-runs the current model for active contracts not already re-evaluated in the current TOP-5 scan. If TOP-5 is empty, active contracts are still re-evaluated.
- The recheck is observation-only: it records current LONG/SHORT/WAIT, price, probabilities, features, signal transitions, elapsed time, price movement, probability deltas, and feature deltas against the original lifecycle.
- A repeated signal confirms the existing forecast. An opposite signal is recorded as a direction change. Neither signal change closes or replaces the original forecast.
- Original direction, entry, TP/SL levels and creation timestamp remain unchanged. Normal candle-based outcome resolution continues to decide TP/SL results; WAIT retains its original learning horizon.
- Once the original LONG/SHORT forecast resolves, up to 48 evenly sampled prior feature snapshots are added as low-weight direction-only learning examples (weight multiplier 0.10 by default) using the resolved path label. WAIT lifecycles also add low-weight direction-only snapshot samples after their full four-hour evaluation. These snapshots do not count as extra trades and do not train the TP/SL outcome head.
- The background observation pass cannot create a new lifecycle. Only the regular TOP-5 scan can start a new forecast after the prior lifecycle has genuinely resolved.
- Model recheck concurrency is limited to two workers. If a contract has no champion model, the recheck is logged as skipped rather than launching unbounded background training.

## Validation

- Python compilation for all `.py` files.
- Automated tests for exact-contract lifecycle identity, repeated signals, all LONG/SHORT/WAIT transitions, non-closure on signal change, original WAIT horizon, feature/probability/price deltas, observer-only no-new-lifecycle behavior, and active contracts outside TOP-5 including empty TOP-5.
- ZIP integrity verification.

Live Android execution and live KuCoin network behavior still require device testing and are not claimed by source-level tests.
