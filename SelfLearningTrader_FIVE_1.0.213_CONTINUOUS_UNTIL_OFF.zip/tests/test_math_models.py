import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np

APP_DIR = Path(__file__).resolve().parents[1] / 'app'
if str(APP_DIR) not in sys.path:
    sys.path.insert(0, str(APP_DIR))

from core.math_models import _wavelet_proxy, _markov, _garch, compute_math_snapshot
from core.model import ModelManager


class MathModelRegressionTests(unittest.TestCase):
    def test_wavelet_detail_is_not_zero_by_construction(self):
        alternating = np.tile([-0.002, 0.002], 60)
        step = np.r_[np.full(112, -0.001), np.full(8, 0.002)]
        self.assertNotEqual(_wavelet_proxy(alternating), 0.0)
        self.assertNotEqual(_wavelet_proxy(step), 0.0)
        self.assertEqual(_wavelet_proxy(np.zeros(120)), 0.0)

    def test_markov_states_follow_return_sign_not_relative_quantile(self):
        up = np.linspace(0.0001, 0.002, 120)
        down = -np.linspace(0.0001, 0.002, 120)
        alternating = np.tile([-0.002, 0.002], 60)
        self.assertGreater(_markov(up), 0)
        self.assertLess(_markov(down), 0)
        self.assertEqual(_markov(np.zeros(120)), 0.0)
        # The last alternating move is positive, so the next transition is
        # predominantly to the negative state.
        self.assertLess(_markov(alternating), 0)

    def test_garch_zero_volatility_is_not_max_risk(self):
        self.assertEqual(_garch(np.zeros(120)), 0.0)
        close = np.full(130, 100.0)
        snapshot = compute_math_snapshot(close, seed=3)
        self.assertEqual(snapshot['math_garch'], 0.0)

    def test_tp_and_sl_are_independent_directional_path_probabilities(self):
        up_returns = np.full(120, 0.001)
        up_close = 100.0 * np.cumprod(np.r_[1.0, 1.0 + up_returns])
        long = compute_math_snapshot(up_close, forecast_direction='LONG', seed=5)
        short = compute_math_snapshot(up_close, forecast_direction='SHORT', seed=5)
        self.assertGreater(long['math_ptp1'], short['math_ptp1'])
        self.assertLess(long['math_psl'], short['math_psl'])
        self.assertGreaterEqual(long['math_ptp1'], long['math_ptp2'])
        self.assertGreaterEqual(long['math_ptp2'], long['math_ptp3'])
        noisy_returns = np.random.default_rng(17).normal(0.0001, 0.002, 120)
        noisy_close = 100.0 * np.cumprod(np.r_[1.0, 1.0 + noisy_returns])
        noisy = compute_math_snapshot(noisy_close, forecast_direction='LONG', seed=5)
        self.assertNotAlmostEqual(noisy['math_psl'], 1.0 - noisy['math_ptp1'])

    def test_pairwise_correlation_uses_benchmark_returns(self):
        rng = np.random.default_rng(17)
        benchmark_returns = rng.normal(0.0002, 0.002, 140)
        asset_returns = benchmark_returns * 1.7 + rng.normal(0, 0.0001, 140)
        benchmark_close = 100 * np.cumprod(np.r_[1.0, 1.0 + benchmark_returns])
        asset_close = 30 * np.cumprod(np.r_[1.0, 1.0 + asset_returns])
        without_benchmark = compute_math_snapshot(asset_close, seed=1)
        with_benchmark = compute_math_snapshot(asset_close, benchmark_close=benchmark_close, seed=1)
        self.assertEqual(without_benchmark['math_correlation'], 0.0)
        self.assertGreater(with_benchmark['math_correlation'], 0.95)

    def test_c3_increases_wait_when_sl_risk_increases(self):
        with tempfile.TemporaryDirectory() as td:
            manager = ModelManager(td, config={})
            master = np.asarray([0.10, 0.15, 0.75])
            row = {'features': {'trend': 0.01, 'trend_15': 0.01, 'trend_1h': 0.01,
                                'trend_4h': 0.01, 'trend_1d': 0.01}}
            base = {'math_direction': 0.7, 'math_target_sign': 1.0,
                    'math_monte_carlo': 0.8, 'math_ptp1': 0.8, 'math_ptp2': 0.7,
                    'math_ptp3': 0.5, 'math_garch': 0.3, 'math_psl': 0.1,
                    'math_entropy': 0.3, 'math_change_point': 0.1}
            risky = dict(base, math_psl=0.95)
            c3_base = manager._fixed_lens(master, row, base)['c3']['probs']
            c3_risky = manager._fixed_lens(master, row, risky)['c3']['probs']
            self.assertGreater(c3_risky[1], c3_base[1])
            self.assertLess(c3_risky[2], c3_base[2])


if __name__ == '__main__':
    unittest.main(verbosity=2)
