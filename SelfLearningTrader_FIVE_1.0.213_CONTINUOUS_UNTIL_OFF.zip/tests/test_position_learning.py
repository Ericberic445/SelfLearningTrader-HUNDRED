import json
import math
import sys
import tempfile
import unittest
from pathlib import Path

APP_DIR = Path(__file__).resolve().parents[1] / 'app'
if str(APP_DIR) not in sys.path:
    sys.path.insert(0, str(APP_DIR))

from core.position_learning import RISK_FEATURES, finalize_position, predict_risk
from services.scanner import _monitor_alerts


class PositionLearningTests(unittest.TestCase):
    def test_closed_position_trains_risk_model_from_intermediate_snapshots(self):
        with tempfile.TemporaryDirectory() as td:
            observations = []
            # Deterministic triangular price path creates both adverse and favorable
            # forward windows, so both classes can be learned without network access.
            for i in range(180):
                phase = i % 24
                if phase < 12:
                    price = 100.0 + phase * 0.10
                else:
                    price = 101.2 - (phase - 12) * 0.10
                features = {name: 0.0 for name in RISK_FEATURES}
                features.update({'rsi': 35.0 + (i % 50), 'atrpct': 0.002,
                                 'trend': 0.002 if phase < 12 else -0.002,
                                 'ret3': 0.001 if phase < 12 else -0.001,
                                 'price_change_pct_from_prev_5m': 0.1 if phase < 12 else -0.1})
                observations.append({'time': 100000 + i * 20, 'price': price, 'features': features})
            result = finalize_position(td, {'position_id': 'pos-test', 'contract': 'AAAUSDTM',
                'direction': 'LONG', 'realized_move_pct': 0.2, 'observations': observations},
                {'position_risk_lookahead_snapshots': 5, 'position_risk_adverse_threshold_pct': 0.15})
            self.assertGreater(result['new_samples'], 30)
            self.assertEqual(result['status'], 'ready')
            risk = predict_risk(td, observations[-10]['features'])
            self.assertTrue(risk['ready'])
            self.assertTrue(0.0 <= risk['probability'] <= 1.0)

    def test_risk_advice_is_added_for_open_position_when_model_risk_is_high(self):
        prev = {'price': 100.0, 'volume_5m': 100.0, 'orderbook_imbalance': 0.0, 'rsi': 55.0, 'macd': 0.2}
        cur = {'price': 100.1, 'volume_5m': 110.0, 'orderbook_imbalance': 0.1, 'rsi': 54.0, 'macd': 0.1}
        position = {'status': 'OPEN', 'direction': 'LONG', 'unrealized_move_pct': 0.4}
        risk = {'ready': True, 'probability': 0.82, 'training_rows': 250}
        alerts = _monitor_alerts(prev, cur, {'prediction': 'LONG'}, {'position_risk_alert_threshold': 0.65}, position, risk)
        found = [a for a in alerts if a.get('type') == 'learned_position_risk']
        self.assertEqual(len(found), 1)
        self.assertIn('безубытку', found[0]['message'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
