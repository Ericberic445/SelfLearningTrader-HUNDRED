from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]

class BackgroundServiceContractTests(unittest.TestCase):
    def test_wakelock_uses_service_context_first(self):
        src = (ROOT / 'app' / 'services' / 'scanner.py').read_text(encoding='utf-8')
        fn = src.split('def acquire_wakelock():', 1)[1].split('\ndef ', 1)[0]
        self.assertIn("autoclass('org.kivy.android.PythonService')", fn)
        self.assertIn("getattr(PythonService, 'mService', None)", fn)
        self.assertIn('newWakeLock(1,', fn)
        self.assertIn('WakeLock acquire failed:', fn)

    def test_wakelock_attempt_happens_before_heavy_stack_imports(self):
        src = (ROOT / 'app' / 'services' / 'scanner.py').read_text(encoding='utf-8')
        main_start = src.index('def main():')
        service_init = src.index('PythonService.mService.setAutoRestartService(True)', main_start)
        startup_lock = src.index('wake_lock = acquire_wakelock()', service_init)
        heavy_import = src.index("from core.engine import LearningEngine", main_start)
        self.assertLess(startup_lock, heavy_import)

    def test_android_service_is_foreground_sticky_and_has_wakelock_permission(self):
        spec = (ROOT / 'buildozer.spec').read_text(encoding='utf-8')
        self.assertIn('WAKE_LOCK', spec)
        self.assertIn('services = scanner:services/scanner.py:foreground:sticky:', spec)

if __name__ == '__main__':
    unittest.main()
