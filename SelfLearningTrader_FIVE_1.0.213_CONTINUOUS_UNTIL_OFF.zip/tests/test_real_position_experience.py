import json
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

APP_DIR = Path(__file__).resolve().parents[1] / 'app'
if str(APP_DIR) not in sys.path:
    sys.path.insert(0, str(APP_DIR))

from core.engine import LearningEngine
from core.features import FEATURES
from services.scanner import _retrain_with_real_position_batch


class RealPositionExperienceTests(unittest.TestCase):
    def test_auxiliary_learning_batch_retrains_and_clears_counters_only_on_success(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); data = root / 'data'; data.mkdir()
            (data / 'real_position_learning_state.json').write_text(json.dumps({'pending_samples': 15, 'total_samples': 15}))
            (data / 'online_observation_learning_state.json').write_text(json.dumps({'pending_samples': 10, 'total_samples': 10}))
            class FakeMM:
                def has_champion(self): return True
            class FakeEngine:
                def __init__(self):
                    self.data = data; self.cfg = {'real_position_retrain_batch_size': 25}; self.mm = FakeMM(); self.calls = []
                def _training_state(self): return {'clean_master_reset_done': True}
                def retrain_symbols(self, contracts, resolved_total=None, force=False):
                    self.calls.append((contracts, resolved_total, force))
                    return [('GLOBAL', {'status': 'master_updated'})]
            engine = FakeEngine()
            with patch('services.scanner.runtime_log'):
                result = _retrain_with_real_position_batch(engine, [], 100)
            self.assertEqual(engine.calls, [([], 100, True)])
            self.assertEqual(result[0][1]['status'], 'master_updated')
            self.assertEqual(json.loads((data / 'real_position_learning_state.json').read_text())['pending_samples'], 0)
            self.assertEqual(json.loads((data / 'online_observation_learning_state.json').read_text())['pending_samples'], 0)

    def test_intermediate_forecast_observation_is_learned_before_forecast_resolves(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / 'data').mkdir()
            (root / 'logs').mkdir()
            eng = LearningEngine.__new__(LearningEngine)
            eng.root = root; eng.data = root / 'data'; eng.logs = root / 'logs'
            eng.experience = eng.data / 'global_experience.npz'
            eng.cfg = {'long_threshold': 0.003, 'short_threshold': -0.003,
                       'online_observation_sample_weight': 0.15, 'experience_max_rows': 12000}
            eng.learning_audit = eng.data / 'learning_audit.jsonl'
            eng.mm = SimpleNamespace()
            features = {f: 0.0 for f in FEATURES}; features['trend'] = 0.01
            result = eng.append_online_observation_experience('AAAUSDTM', 'forecast-1', 1000,
                                                               100.0, features, 100.5, 0.2, eng.cfg)
            self.assertEqual(result['status'], 'added')
            self.assertEqual(result['target'], 'LONG')
            exp = eng._load_exp()
            self.assertEqual(len(exp['time']), 1)
            self.assertEqual(str(exp['experience_kind'][0]), 'ONLINE_DIRECTION_OBSERVATION')
            self.assertEqual(int(exp['outcome_target'][0]), -1)
            again = eng.append_online_observation_experience('AAAUSDTM', 'forecast-1', 1000,
                                                              100.0, features, 100.5, 0.2, eng.cfg)
            self.assertEqual(again['status'], 'already_recorded')

    def test_real_trade_and_path_snapshots_enter_global_direction_replay(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / 'data').mkdir()
            (root / 'logs').mkdir()
            eng = LearningEngine.__new__(LearningEngine)
            eng.root = root
            eng.data = root / 'data'
            eng.logs = root / 'logs'
            eng.experience = eng.data / 'global_experience.npz'
            eng.cfg = {'long_threshold': 0.003, 'short_threshold': -0.003,
                       'real_position_learning_lookahead_snapshots': 3,
                       'real_position_result_sample_weight': 0.6,
                       'real_position_observation_sample_weight': 0.3,
                       'experience_max_rows': 12000}
            eng.exchange = SimpleNamespace(futures_symbol='AAAUSDTM')
            eng.learning_audit = eng.data / 'learning_audit.jsonl'
            eng.mm = SimpleNamespace()
            prediction = {'id': 'pred-1', 'contract': 'AAAUSDTM', 'prediction': 'LONG', 'math_consensus': 0.2}
            observations = []
            prices = [100.0, 100.2, 100.4, 100.6, 100.8, 101.0, 101.2]
            for i, price in enumerate(prices):
                features = {f: 0.0 for f in FEATURES}
                features['ret3'] = 0.001 * i
                features['rsi'] = 40 + i
                observations.append({'time': 1000 + i * 20, 'price': price, 'features': features})
            position = {'position_id': 'pos-1', 'contract': 'AAAUSDTM', 'direction': 'LONG',
                        'realized_move_pct': 1.2, 'observations': observations}
            result = eng.append_real_position_experience(position, prediction, eng.cfg)
            self.assertEqual(result['status'], 'added')
            self.assertGreaterEqual(result['new_samples'], 2)
            exp = eng._load_exp()
            kinds = set(exp['experience_kind'].astype(str))
            self.assertIn('REAL_POSITION_RESULT', kinds)
            self.assertIn('REAL_POSITION_OBSERVATION', kinds)
            self.assertTrue((exp['outcome_target'] == -1).all())
            state = json.loads((root / 'data' / 'real_position_learning_state.json').read_text())
            self.assertEqual(state['pending_samples'], result['new_samples'])
            again = eng.append_real_position_experience(position, prediction, eng.cfg)
            self.assertEqual(again['new_samples'], 0)


if __name__ == '__main__':
    unittest.main(verbosity=2)
