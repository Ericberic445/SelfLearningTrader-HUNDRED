import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

APP_DIR = Path(__file__).resolve().parents[1] / 'app'
if str(APP_DIR) not in sys.path:
    sys.path.insert(0, str(APP_DIR))

from services import scanner


class FakeKuCoin:
    def __init__(self, contract):
        self.contract = contract
        self._request_gap = 0.1
    def display_symbol(self, contract):
        return contract


class FakeMM:
    def has_champion(self):
        return True


class FakeEngine:
    calls = []
    def __init__(self, root, exchange, cfg):
        self.root = Path(root)
        self.exchange = exchange
        self.mm = FakeMM()
    def set_symbol(self, contract):
        self.contract = contract
    def _scan_train_and_predict(self, item, scan_history=800, run_id=None):
        self.calls.append((item['contract'], run_id))
        return {'id': 'fresh-' + item['contract'], 'contract': item['contract'],
                'exchange_symbol': item['contract'], 'prediction': 'SHORT',
                'price': 98.0, 'p_long': 0.2, 'p_short': 0.7, 'p_wait': 0.1,
                'features': {'rsi': 42.0}}
    def persist_scan_predictions(self, rows, allow_new_lifecycle=True):
        if allow_new_lifecycle:
            raise AssertionError('active recheck must never create a new lifecycle')
        self.persist_calls.append((rows[0]['contract'], allow_new_lifecycle))
        return [{'id': 'original-' + rows[0]['contract'], 'scan_observed_signal': rows[0]['prediction']}]
    persist_calls = []


class ActiveForecastRecheckTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        (self.root / 'logs').mkdir()
        scanner.ROOT = self.root
        FakeEngine.calls = []
        FakeEngine.persist_calls = []

    def tearDown(self):
        self.tmp.cleanup()

    def write(self, contract, rows):
        (self.root / 'logs' / f'{contract}_predictions.json').write_text(json.dumps(rows), encoding='utf-8')

    def test_rechecks_active_contracts_outside_top5_even_when_signal_is_wait(self):
        self.write('AAAUSDTM', [{'id': 'a', 'contract': 'AAAUSDTM', 'prediction': 'LONG', 'time': 1000, 'resolved': 0}])
        self.write('BBBUSDTM', [{'id': 'b', 'contract': 'BBBUSDTM', 'prediction': 'WAIT', 'time': 1000, 'resolved': 0}])
        self.write('CCCUSDTM', [{'id': 'c', 'contract': 'CCCUSDTM', 'prediction': 'SHORT', 'time': 1000, 'resolved': 1}])
        with patch('core.exchange.KuCoin', FakeKuCoin), patch('core.engine.LearningEngine', FakeEngine):
            stats = scanner.recheck_active_forecasts({}, skip_contracts={'AAAUSDTM'}, cycle=9)
        self.assertEqual(stats['active_contracts'], 1)
        self.assertEqual(stats['checked'], 1)
        self.assertEqual(stats['observations_saved'], 1)
        self.assertEqual(FakeEngine.calls, [('BBBUSDTM', 9)])
        self.assertEqual(FakeEngine.persist_calls, [('BBBUSDTM', False)])

    def test_empty_top5_still_rechecks_active_contracts(self):
        self.write('AAAUSDTM', [{'id': 'a', 'contract': 'AAAUSDTM', 'prediction': 'LONG', 'time': 1000, 'resolved': 0}])
        with patch('core.exchange.KuCoin', FakeKuCoin), patch('core.engine.LearningEngine', FakeEngine):
            stats = scanner.recheck_active_forecasts({}, skip_contracts=set(), cycle=10)
        self.assertEqual(stats['checked'], 1)
        self.assertEqual(FakeEngine.persist_calls, [('AAAUSDTM', False)])


if __name__ == '__main__':
    unittest.main(verbosity=2)
