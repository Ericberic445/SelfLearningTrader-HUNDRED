import json
import tempfile
import time
import unittest
from pathlib import Path

from app.core.engine import LearningEngine
from app.core.features import FEATURES


class FakeExchange:
    def __init__(self):
        self.futures_symbol = 'AAAUSDTM'
    def set_symbol(self, symbol):
        s = str(symbol).upper().replace('-', '')
        if s.endswith('USDT'):
            s += 'M'
        self.futures_symbol = s


class ScanLifecycleTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        self.engine = LearningEngine.__new__(LearningEngine)
        self.engine.root = root
        self.engine.logs = root / 'logs'
        self.engine.logs.mkdir()
        self.engine.exchange = FakeExchange()
        self.engine.cfg = {'max_direction_observation_samples_per_forecast': 4, 'direction_observation_sample_weight': 0.05}
        self.engine.pending = self.engine.logs / 'AAAUSDTM_pending.json'
        self.engine.predictions = self.engine.logs / 'AAAUSDTM_predictions.json'
        self.engine.set_symbol = lambda symbol: self._set_symbol_engine(symbol)
        self.engine._read_json = lambda path: json.loads(path.read_text()) if path.exists() else []
        self.engine._write_json = lambda path, data: path.write_text(json.dumps(data))

    def tearDown(self):
        self.tmp.cleanup()

    def _set_symbol_engine(self, symbol):
        self.engine.exchange.set_symbol(symbol)
        self.engine.pending = self.engine.logs / f'{self.engine.exchange.futures_symbol}_pending.json'
        self.engine.predictions = self.engine.logs / f'{self.engine.exchange.futures_symbol}_predictions.json'

    def row(self, pid, signal, ts=None, price=100.0):
        return {'id': pid, 'contract': 'AAAUSDTM', 'exchange_symbol': 'AAAUSDTM',
                'prediction': signal, 'time': ts or int(time.time()), 'price': price,
                'features': {'rsi': 50.0, 'trend': 0.1},
                'entry': price, 'sl': price * .99 if signal == 'LONG' else price * 1.01,
                'tp1': price * 1.01 if signal == 'LONG' else price * .99,
                'tp2': price * 1.02 if signal == 'LONG' else price * .98,
                'tp3': price * 1.03 if signal == 'LONG' else price * .97,
                'horizon_bars': 4, 'resolved': 0}

    def read_preds(self):
        return self.engine._read_json(self.engine.predictions)

    def read_pending(self):
        return self.engine._read_json(self.engine.pending)

    def test_same_long_is_confirmation_not_duplicate(self):
        first = self.engine.persist_scan_predictions([self.row('scan-1', 'LONG', 1000)])[0]
        second = self.engine.persist_scan_predictions([self.row('scan-2', 'LONG', 2800, 102)])[0]
        preds = self.read_preds()
        self.assertEqual(len(preds), 1)
        self.assertEqual(first['id'], second['id'])
        self.assertEqual(preds[0]['time'], 1000)
        self.assertEqual(preds[0]['entry'], 100.0)
        self.assertEqual(preds[0]['confirmation_count'], 1)
        self.assertEqual(len(self.read_pending()), 1)

    def test_same_wait_does_not_reset_original_horizon(self):
        self.engine.persist_scan_predictions([self.row('wait-1', 'WAIT', 1000)])
        self.engine.persist_scan_predictions([self.row('wait-2', 'WAIT', 2800)])
        preds = self.read_preds()
        self.assertEqual(len(preds), 1)
        self.assertEqual(preds[0]['id'], 'wait-1')
        self.assertEqual(preds[0]['time'], 1000)
        self.assertEqual(preds[0]['wait_learning_resolved'] if 'wait_learning_resolved' in preds[0] else False, False)
        self.assertEqual(len(self.read_pending()), 0)

    def test_long_to_short_is_observation_not_closure_or_new_forecast(self):
        self.engine.persist_scan_predictions([self.row('long-1', 'LONG', 1000)])
        out = self.engine.persist_scan_predictions([self.row('short-2', 'SHORT', 2800, 98)])
        preds = self.read_preds()
        self.assertEqual(len(preds), 1)
        old = preds[0]
        self.assertEqual(old['id'], 'long-1')
        self.assertEqual(old['prediction'], 'LONG')
        self.assertEqual(old['time'], 1000)
        self.assertEqual(old['resolved'], 0)
        self.assertEqual(old['last_scan_signal'], 'SHORT')
        self.assertEqual(old['signal_change_count'], 1)
        self.assertEqual(old['signal_change_observations'][-1]['signal'], 'SHORT')
        self.assertEqual(old['signal_change_observations'][-1]['features']['rsi'], 50.0)
        self.assertEqual([x['id'] for x in self.read_pending()], ['long-1'])
        self.assertEqual(out[0]['id'], 'long-1')
        self.assertEqual(out[0]['scan_observed_signal'], 'SHORT')

    def test_resolved_forecast_turns_temporal_snapshots_into_low_weight_direction_samples(self):
        features = {name: 0.0 for name in FEATURES}
        observations = []
        for i in range(20):
            observations.append({'time': 1000 + i * 1800, 'scan_prediction_id': f'scan-{i}',
                                 'signal': 'SHORT' if i % 2 else 'LONG', 'features': dict(features)})
        item = {'id': 'resolved-long', 'actual': 'LONG', 'prediction': 'LONG',
                'features': dict(features), 'scan_observations': observations}
        rows = self.engine._observation_experience_rows(item, 'AAAUSDTM', 'resolved-long', 3)
        self.assertEqual(len(rows), 4)
        self.assertTrue(all(row['target'] == 2 for row in rows))
        self.assertTrue(all(row['outcome_target'] == -1 for row in rows))
        self.assertTrue(all(row['outcome_sample_weight'] == 0.0 for row in rows))
        self.assertTrue(all(row['experience_kind'] == 'DIRECTION_OBSERVATION' for row in rows))
        self.assertTrue(all(abs(row['sample_weight']) <= 0.075 for row in rows))
        self.assertEqual(len({row['prediction_id'] for row in rows}), 4)

    def test_wait_lifecycle_temporal_snapshots_become_low_weight_direction_samples(self):
        features = {name: 0.0 for name in FEATURES}
        item = {'id': 'wait-control', 'contract': 'AAAUSDTM', 'time': 1000,
                'scan_observations': [
                    {'time': 2000 + i * 1800, 'scan_prediction_id': f'wait-scan-{i}',
                     'math_consensus': 0.1, 'features': dict(features)} for i in range(20)]}
        rows = self.engine._wait_observation_experience_rows(item, 2, 'MISSED_LONG')
        self.assertEqual(len(rows), 4)
        self.assertTrue(all(row['target'] == 2 for row in rows))
        self.assertTrue(all(row['outcome_target'] == -1 for row in rows))
        self.assertTrue(all(row['experience_kind'] == 'WAIT_CONTROL_OBSERVATION' for row in rows))
        self.assertTrue(all(row['sample_weight'] < 0.1 for row in rows))
        self.assertEqual(len({row['prediction_id'] for row in rows}), 4)

    def test_observation_records_price_probability_and_feature_deltas(self):
        first = self.row('first', 'LONG', 1000, 100.0)
        first.update({'p_long': 0.7, 'p_short': 0.2, 'p_wait': 0.1})
        first['features'] = {'rsi': 40.0, 'trend': 0.2}
        self.engine.persist_scan_predictions([first])
        second = self.row('second', 'SHORT', 2800, 98.0)
        second.update({'p_long': 0.2, 'p_short': 0.7, 'p_wait': 0.1})
        second['features'] = {'rsi': 55.0, 'trend': -0.1}
        self.engine.persist_scan_predictions([second])
        obs = self.read_preds()[0]['signal_change_observations'][-1]
        self.assertAlmostEqual(obs['price_change_pct_since_previous_observation'], -2.0)
        self.assertAlmostEqual(obs['probability_delta']['p_long'], -0.5)
        self.assertAlmostEqual(obs['probability_delta']['p_short'], 0.5)
        self.assertAlmostEqual(obs['feature_delta']['rsi'], 15.0)
        self.assertAlmostEqual(obs['feature_delta']['trend'], -0.3)

    def test_wait_to_long_records_change_but_preserves_wait_horizon(self):
        self.engine.persist_scan_predictions([self.row('wait-1', 'WAIT', 1000)])
        self.engine.persist_scan_predictions([self.row('long-2', 'LONG', 2800)])
        preds = self.read_preds()
        self.assertEqual(len(preds), 1)
        wait = preds[0]
        self.assertEqual(wait['id'], 'wait-1')
        self.assertEqual(wait['prediction'], 'WAIT')
        self.assertEqual(wait['time'], 1000)
        self.assertFalse(wait.get('resolved'))
        self.assertFalse(wait.get('wait_learning_resolved', False))
        self.assertEqual(wait['last_scan_signal'], 'LONG')
        self.assertEqual(wait['signal_change_count'], 1)
        self.assertEqual(len(self.read_pending()), 0)

    def test_existing_duplicate_active_rows_merge_into_oldest_without_replacing_it(self):
        a = self.row('old-1', 'LONG', 1000)
        b = self.row('old-2', 'SHORT', 2000)
        self.engine._write_json(self.engine.predictions, [a, b])
        self.engine._write_json(self.engine.pending, [a, b])
        out = self.engine.persist_scan_predictions([self.row('scan-3', 'SHORT', 3000)])
        preds = self.read_preds()
        self.assertEqual(len(preds), 2)  # later legacy row retained for audit
        self.assertEqual(preds[0]['id'], 'old-1')
        self.assertFalse(preds[0].get('resolved'))  # original forecast remains live
        self.assertEqual(preds[0]['last_scan_signal'], 'SHORT')
        self.assertEqual(preds[1]['resolved'], 1)
        self.assertEqual(preds[1]['state_change_only'], True)
        self.assertEqual(preds[1]['merged_into_prediction_id'], 'old-1')
        self.assertEqual([x['id'] for x in self.read_pending()], ['old-1'])
        self.assertEqual(out[0]['id'], 'old-1')


    def test_all_state_transitions_are_observations_until_original_outcome(self):
        states = ('LONG', 'SHORT', 'WAIT')
        for old_state in states:
            for new_state in states:
                with self.subTest(old=old_state, new=new_state):
                    self.engine._write_json(self.engine.predictions, [])
                    self.engine._write_json(self.engine.pending, [])
                    self.engine.persist_scan_predictions([self.row('old', old_state, 1000)])
                    out = self.engine.persist_scan_predictions([self.row('new', new_state, 2800)])
                    preds = self.read_preds()
                    self.assertEqual(len(preds), 1)
                    original = preds[0]
                    self.assertEqual(original['id'], 'old')
                    self.assertEqual(original['prediction'], old_state)
                    self.assertEqual(original['time'], 1000)
                    self.assertFalse(original.get('resolved'))
                    self.assertEqual(original['last_scan_signal'], new_state)
                    self.assertEqual(original['signal_change_count'], 0 if old_state == new_state else 1)
                    self.assertEqual(out[0]['id'], 'old')
                    pending_ids = [x['id'] for x in self.read_pending()]
                    self.assertEqual(pending_ids, ['old'] if old_state in ('LONG', 'SHORT') else [])

    def test_opposite_then_original_signal_does_not_replace_original_forecast(self):
        self.engine.persist_scan_predictions([self.row('long-1', 'LONG', 1000, 100)])
        self.engine.persist_scan_predictions([self.row('short-2', 'SHORT', 2800, 98)])
        out = self.engine.persist_scan_predictions([self.row('long-3', 'LONG', 4600, 101)])
        preds = self.read_preds()
        self.assertEqual(len(preds), 1)
        original = preds[0]
        self.assertEqual(original['id'], 'long-1')
        self.assertEqual(original['prediction'], 'LONG')
        self.assertEqual(original['entry'], 100)
        self.assertEqual(original['time'], 1000)
        self.assertFalse(original.get('resolved'))
        self.assertEqual([x['signal'] for x in original['scan_observations']], ['SHORT', 'LONG'])
        self.assertEqual(original['signal_change_count'], 2)
        self.assertEqual(out[0]['id'], 'long-1')

    def test_new_lifecycle_starts_only_after_original_is_resolved(self):
        self.engine.persist_scan_predictions([self.row('long-1', 'LONG', 1000)])
        preds = self.read_preds()
        preds[0]['resolved'] = 1
        preds[0]['resolved_at'] = 2500
        preds[0]['trade_outcome'] = 'TP1'
        preds[0]['tp1_hit'] = True
        self.engine._write_json(self.engine.predictions, preds)
        out = self.engine.persist_scan_predictions([self.row('short-2', 'SHORT', 2800, 98)])
        preds = self.read_preds()
        self.assertEqual(len(preds), 2)
        self.assertEqual(preds[0]['id'], 'long-1')
        self.assertEqual(preds[0]['resolved'], 1)
        self.assertEqual(preds[1]['id'], 'short-2')
        self.assertEqual(preds[1]['prediction'], 'SHORT')
        self.assertFalse(preds[1].get('resolved'))
        self.assertEqual(out[0]['id'], 'short-2')

    def test_observation_only_pass_never_starts_a_new_lifecycle_after_resolution(self):
        self.engine.persist_scan_predictions([self.row('first-long', 'LONG', 1000)])
        preds = self.read_preds()
        preds[0]['resolved'] = 1
        preds[0]['resolved_at'] = 2000
        preds[0]['trade_outcome'] = 'TP1'
        self.engine._write_json(self.engine.predictions, preds)
        out = self.engine.persist_scan_predictions([self.row('recheck-short', 'SHORT', 2800)], allow_new_lifecycle=False)
        self.assertEqual(out, [])
        self.assertEqual(len(self.read_preds()), 1)
        self.assertEqual(self.read_preds()[0]['id'], 'first-long')

    def test_reprocessing_same_scan_id_is_idempotent(self):
        row = self.row('same-id', 'LONG', 1000)
        self.engine.persist_scan_predictions([row])
        self.engine.persist_scan_predictions([row])
        preds = self.read_preds()
        self.assertEqual(len(preds), 1)
        self.assertEqual(preds[0].get('confirmation_count', 0), 0)
        self.assertEqual(len(preds[0].get('scan_confirmations', [])), 0)

    def test_same_timestamp_different_contracts_remain_separate(self):
        self.engine.persist_scan_predictions([self.row('aaa-id', 'LONG', 12345)])
        other = self.row('bbb-id', 'SHORT', 12345)
        other['contract'] = 'BBB-USDT'
        other['exchange_symbol'] = 'BBB-USDT'
        self.engine.persist_scan_predictions([other])
        aaa_path = self.engine.logs / 'AAAUSDTM_predictions.json'
        bbb_path = self.engine.logs / 'BBBUSDTM_predictions.json'
        self.assertEqual(len(json.loads(aaa_path.read_text())), 1)
        self.assertEqual(len(json.loads(bbb_path.read_text())), 1)
        self.assertEqual(json.loads(aaa_path.read_text())[0]['id'], 'aaa-id')
        self.assertEqual(json.loads(bbb_path.read_text())[0]['id'], 'bbb-id')


    def test_wrong_contract_row_inside_file_is_not_merged_or_confirmed(self):
        original = self.row('aaa-original', 'LONG', 1000)
        wrong = self.row('bbb-wrong', 'SHORT', 1100)
        wrong['contract'] = 'BBBUSDTM'
        wrong['exchange_symbol'] = 'BBBUSDTM'
        self.engine._write_json(self.engine.predictions, [original, wrong])
        self.engine._write_json(self.engine.pending, [original, wrong])
        out = self.engine.persist_scan_predictions([self.row('aaa-scan', 'SHORT', 2800)])
        preds = self.read_preds()
        self.assertEqual(len(preds), 2)
        self.assertEqual(preds[0]['id'], 'aaa-original')
        self.assertEqual(preds[0]['last_scan_signal'], 'SHORT')
        self.assertFalse(preds[0].get('resolved'))
        self.assertEqual(preds[1]['id'], 'bbb-wrong')
        self.assertFalse(preds[1].get('resolved'))
        self.assertEqual(out[0]['id'], 'aaa-original')
        self.assertEqual([x['id'] for x in self.read_pending()], ['aaa-original'])

    def test_current_scan_state_is_keyed_by_exact_contract(self):
        self.engine.persist_scan_predictions([self.row('aaa-state', 'LONG', 1000)])
        other = self.row('bbb-state', 'SHORT', 1000)
        other['contract'] = 'BBB-USDT'
        other['exchange_symbol'] = 'BBB-USDT'
        self.engine.persist_scan_predictions([other])
        state = json.loads((self.engine.logs / 'current_scan_state.json').read_text())
        self.assertEqual(set(state.keys()), {'AAAUSDTM', 'BBBUSDTM'})
        self.assertEqual(state['AAAUSDTM']['prediction_id'], 'aaa-state')
        self.assertEqual(state['BBBUSDTM']['prediction_id'], 'bbb-state')


if __name__ == '__main__':
    unittest.main(verbosity=2)
