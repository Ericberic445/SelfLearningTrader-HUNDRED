from app.core.engine import LearningEngine


def test_age_bars_supports_exchange_microseconds():
    now = 1_791_500_000.0
    created = int((now - 4 * 3600) * 1_000_000)
    assert LearningEngine._age_bars_from_now(created, now) == 48


def test_age_bars_supports_milliseconds_and_seconds():
    now = 1_791_500_000.0
    assert LearningEngine._age_bars_from_now(int((now - 600) * 1000), now) == 2
    assert LearningEngine._age_bars_from_now(int(now - 900), now) == 3
