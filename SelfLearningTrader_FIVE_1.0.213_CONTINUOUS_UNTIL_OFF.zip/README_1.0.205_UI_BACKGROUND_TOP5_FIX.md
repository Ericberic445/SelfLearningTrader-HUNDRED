# SelfLearningTrader 1.0.205 — background TOP-5 UI fix

- Scanner/forecast/training logic is unchanged.
- MODEL intermediate rows are no longer pushed to or rendered by the Kivy UI.
- Completed TOP-5 is rendered once per completed cycle.
- VERIFY cards are rebuilt only when their outcome signature changes.
- WAIT_NEXT_SCAN no longer rebuilds TOP-5 every poll.
- Readiness is checked sparsely: after 500-contract scan buckets and phase changes, not every 0.5 seconds.
- `_scan_seen` and related UI counters are initialized at UI construction, fixing reconnect errors.
- Android foreground scanner continues independently of the Activity UI.
