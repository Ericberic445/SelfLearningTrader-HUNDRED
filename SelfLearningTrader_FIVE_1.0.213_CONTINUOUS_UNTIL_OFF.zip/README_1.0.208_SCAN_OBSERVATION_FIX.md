# SelfLearningTrader FIVE 1.0.208 — scan observation lifecycle correction

## Rules

- Lifecycle identity is the exact normalized KuCoin Futures contract.
- Every 30-minute scan is an observation of the active lifecycle while that lifecycle remains unresolved.
- Repeated or changed LONG/SHORT/WAIT signals are stored with timestamp, scan ID, price, probabilities, feature snapshot, and diagnostic data.
- A signal change (for example LONG → SHORT → LONG) never closes or replaces the original forecast and never resets its entry, TP/SL, original timestamp, or horizon. The original directional forecast remains pending until its actual TP/SL outcome is determined.
- WAIT remains under its full 48-bar (4-hour) learning horizon; intermediate signal changes are observations, not premature closure.
- A new lifecycle may start only after the prior lifecycle has resolved through its normal outcome path.
- Existing repeated scan records are merged into the oldest active lifecycle as observations; legacy rows are retained for audit and excluded from outcome/training statistics.
- Pending records are rebuilt from active directional lifecycle records. The state index stores both the original forecast state and the latest observed scan signal.

## Validation scope

`tests/test_scan_lifecycle.py` checks same-signal confirmations, changed-signal observations, preservation of the original forecast until TP/SL or WAIT horizon, post-resolution new lifecycle creation, legacy duplicate reconciliation, exact-contract isolation, and idempotent scan reprocessing.

Python compilation and ZIP integrity are source-level checks only. Android-device and live KuCoin behavior require device/network testing and are not claimed here.
