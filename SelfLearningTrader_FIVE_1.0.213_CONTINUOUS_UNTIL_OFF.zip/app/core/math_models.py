import numpy as np

# Causal mathematical features used at the deep-analysis stage. Pairwise
# features are computed only when a benchmark price series is supplied.
MATH_FEATURES = [
    'math_markov','math_prob_move','math_ar','math_arima','math_sarima','math_garch',
    'math_hurst','math_mean_reversion','math_cointegration','math_correlation',
    'math_return_vol_correlation','math_trend_deviation','math_entropy','math_fractal',
    'math_wavelet','math_kalman','math_monte_carlo','math_bayesian','math_change_point',
    'math_ptp1','math_ptp2','math_ptp3','math_psl'
]


def _safe(a):
    return np.nan_to_num(np.asarray(a, dtype=float), nan=0.0, posinf=0.0, neginf=0.0)


def _ols_ar(x, p=3):
    x = _safe(x)
    if len(x) <= p + 3:
        return 0.0
    y = x[p:]
    X = np.column_stack([x[p-i-1:len(x)-i-1] for i in range(p)])
    try:
        coef = np.linalg.lstsq(X, y, rcond=None)[0]
        return float(np.clip(coef[0], -2, 2))
    except Exception:
        return 0.0


def _entropy(x, bins=8):
    x = _safe(x)
    if len(x) < 10 or np.ptp(x) < 1e-12:
        return 0.0
    hist, _ = np.histogram(x, bins=bins)
    p = hist.astype(float) / max(float(np.sum(hist)), 1.0)
    p = p[p > 0]
    return float(-np.sum(p * np.log2(p)) / np.log2(bins))


def _hurst(x):
    x = _safe(x)
    n = len(x)
    if n < 32 or np.std(x) < 1e-12:
        return 0.5
    vals = []
    for lag in (2, 4, 8, 16):
        if lag >= n // 2:
            continue
        sd = float(np.std(x[lag:] - x[:-lag]))
        if sd > 1e-12:
            vals.append((lag, sd))
    if len(vals) < 2:
        return 0.5
    slope = np.polyfit(np.log([v[0] for v in vals]), np.log([v[1] for v in vals]), 1)[0]
    return float(np.clip(slope, 0, 1))


def _kalman(x, q=1e-5, r=1e-3):
    x = _safe(x)
    if not len(x):
        return 0.0
    est = float(x[0]); p = 1.0
    for z in x[1:]:
        p += q
        k = p / (p + r)
        est += k * (float(z) - est)
        p = (1-k) * p
    scale = max(abs(est), float(np.std(x)), 1e-9)
    return float(np.clip((x[-1] - est) / scale, -1, 1))


def _wavelet_proxy(x):
    """Signed multiscale Haar detail proxy; zero only when no detail exists."""
    x = _safe(x)
    if len(x) < 16:
        return 0.0
    denom = float(np.std(x[-16:]))
    if not np.isfinite(denom) or denom < 1e-12:
        return 0.0
    details = []
    weights = ((2, 1.0), (4, 0.7), (8, 0.45), (16, 0.25))
    for width, weight in weights:
        segment = x[-width:]
        half = width // 2
        # Haar detail coefficient: difference between adjacent half-window means.
        details.append(weight * (float(np.mean(segment[half:])) - float(np.mean(segment[:half]))))
    return float(np.clip(sum(details) / (sum(w for _, w in weights) * denom), -1, 1))


def _change_point(x):
    x = _safe(x)
    if len(x) < 20:
        return 0.0
    sd = float(np.std(x))
    if sd < 1e-12:
        return 0.0
    n = len(x); best = 0.0
    for k in range(max(5, n-40), n-5):
        score = abs(float(np.mean(x[:k])) - float(np.mean(x[k:]))) / sd
        best = max(best, score)
    return float(np.clip(best / 3.0, 0, 1))


def _markov(rets):
    """Three-state transition score robust to tied/constant return series."""
    r = _safe(rets)
    if len(r) < 12:
        return 0.0
    scale = float(np.std(r))
    if scale < 1e-12:
        # Constant non-zero returns have direction but no transition evidence;
        # leave the Markov component neutral and let AR/Bayesian capture drift.
        return 0.0
    # Markov states represent actual return direction, not relative quantiles.
    # Quantile states incorrectly labeled the highest tercile of a falling
    # market as an "up" state and could output +1 for steadily falling prices.
    neutral_band = max(scale * 0.10, 1e-12)
    states = np.where(r < -neutral_band, 0, np.where(r > neutral_band, 2, 1)).astype(int)
    cur = int(states[-1])
    prior = states[:-1]
    den = int(np.sum(prior == cur))
    if den == 0:
        # No history for this state: no evidence, not a directional +1.
        return 0.0
    next_states = states[1:]
    p_down = float(np.sum((prior == cur) & (next_states == 0))) / den
    p_up = float(np.sum((prior == cur) & (next_states == 2))) / den
    return float(np.clip(p_up - p_down, -1, 1))


def _trend_deviation(logp):
    """Single-series deviation from a linear trend; not cointegration."""
    x = _safe(logp)
    if len(x) < 20:
        return 0.0
    t = np.arange(len(x), dtype=float)
    slope = np.polyfit(t, x, 1)[0]
    resid = x - (slope*t + np.mean(x-slope*t))
    sd = float(np.std(resid))
    if sd < 1e-12:
        return 0.0
    return float(np.clip(-(resid[-1]-np.mean(resid))/sd, -1, 1))


def _relative_spread(logp, benchmark_logp):
    """Pairwise residual deviation, attenuated unless residuals mean-revert.

    This is a lightweight cointegration proxy, not a formal Engle-Granger ADF
    test. It returns neutral when a paired benchmark or sufficient history is
    unavailable, rather than mislabeling single-series trend deviation.
    """
    y = _safe(logp); x = _safe(benchmark_logp)
    n = min(len(y), len(x))
    if n < 40:
        return 0.0
    y = y[-n:]; x = x[-n:]
    if np.std(y) < 1e-12 or np.std(x) < 1e-12:
        return 0.0
    try:
        X = np.column_stack([np.ones(n), x])
        beta = np.linalg.lstsq(X, y, rcond=None)[0]
        resid = y - X @ beta
        sd = float(np.std(resid))
        if sd < 1e-10:
            return 0.0
        lag = resid[:-1]; delta = np.diff(resid)
        denom = float(np.dot(lag-lag.mean(), lag-lag.mean()))
        if denom < 1e-12:
            return 0.0
        phi = float(np.dot(lag-lag.mean(), delta-delta.mean()) / denom)
        stationarity = float(np.clip((-phi-.01)/.20, 0, 1))
        z = float((resid[-1] - np.mean(resid)) / sd)
        return float(np.clip(-z, -1, 1) * stationarity)
    except Exception:
        return 0.0


def _correlation(x, benchmark):
    """Correlation of instrument returns with benchmark returns."""
    x = _safe(x); v = _safe(benchmark)
    n = min(len(x), len(v))
    if n < 10:
        return 0.0
    x = x[-n:]; v = v[-n:]
    if np.std(x) < 1e-12 or np.std(v) < 1e-12:
        return 0.0
    return float(np.clip(np.corrcoef(x, v)[0, 1], -1, 1))


def _return_vol_correlation(rets):
    r = _safe(rets)
    if len(r) < 10 or np.std(r) < 1e-12 or np.std(np.abs(r)) < 1e-12:
        return 0.0
    return float(np.clip(np.corrcoef(r, np.abs(r))[0, 1], -1, 1))


def _garch(ret):
    """Stationary GARCH(1,1) variance recursion with safe zero-vol handling."""
    r = _safe(ret)
    if len(r) < 2:
        return 0.0
    centered = r - float(np.mean(r))
    unconditional = float(np.var(centered))
    if not np.isfinite(unconditional) or unconditional < 1e-24:
        return 0.0
    if len(r) < 20:
        return float(np.sqrt(unconditional))
    alpha = 0.08; beta = 0.90
    omega = max(unconditional * (1-alpha-beta), 1e-24)
    var = max(float(np.var(centered[:10])), unconditional*1e-6, 1e-24)
    for z in centered[10:]:
        var = omega + alpha*float(z)*float(z) + beta*var
        if not np.isfinite(var):
            return float(np.sqrt(unconditional))
    return float(np.sqrt(max(var, 0.0)))


def _monte_carlo_paths(rets, horizon=12, paths=400, seed=7):
    r = _safe(rets)
    horizon = max(1, int(horizon)); paths = max(1, int(paths))
    if len(r) < 20:
        return np.zeros((0, horizon), dtype=float)
    mu = float(np.mean(r[-100:])); sig = float(np.std(r[-100:]))
    if not np.isfinite(sig) or sig < 1e-12:
        return np.full((paths, horizon), mu, dtype=float).cumsum(axis=1)
    rng = np.random.default_rng(seed)
    return np.cumsum(rng.normal(mu, sig, (paths, horizon)), axis=1)


def _monte_carlo(rets, horizon=12, paths=400, seed=7):
    sims = _monte_carlo_paths(rets, horizon, paths, seed)
    if sims.size == 0:
        return 0.5
    return float(np.clip(np.mean(sims[:, -1] > 0), 0, 1))


def _bayesian(rets):
    r = _safe(rets)
    if len(r) < 10:
        return 0.5
    pos = float(np.sum(r > 0)); neg = float(np.sum(r < 0))
    return float((pos+1.0)/(pos+neg+2.0))


def compute_math_snapshot(close, high=None, low=None, volume=None, horizon=12, seed=7, benchmark_close=None, forecast_direction=None):
    c = _safe(close); n = len(c)
    if n < 20:
        result = {k: 0.0 for k in MATH_FEATURES}
        result.update({'math_prob_move': 0.5, 'math_hurst': 0.5, 'math_monte_carlo': 0.5,
                       'math_bayesian': 0.5, 'math_ptp1': 0.5, 'math_ptp2': 0.5,
                       'math_ptp3': 0.5, 'math_psl': 0.5, 'math_direction': 0.0,
                       'math_consensus': 0.0})
        return result
    r = c[1:] / np.maximum(c[:-1], 1e-12) - 1.0
    w = r[-120:]
    lw = np.log(np.maximum(c[-120:], 1e-12))
    ar = _ols_ar(w, 3)
    arima = float(np.clip(ar + np.mean(np.diff(w[-30:]))*20, -1, 1))
    sarima = float(np.clip(arima + np.mean(w[-12:])*10, -1, 1))
    g = _garch(w); sd = float(np.std(w)); sd_safe = max(sd, 1e-12)
    mean = float(np.mean(w))
    mr = float(np.clip(-((w[-1]-mean)/sd_safe)/3.0, -1, 1)) if sd > 1e-12 else 0.0
    hurst = _hurst(lw)
    entropy = _entropy(w)
    fractal = float(np.clip(2.0-hurst, 0, 2)/2.0)
    wave = _wavelet_proxy(w)
    kal = _kalman(lw)
    cp = _change_point(w)
    sims = _monte_carlo_paths(w, horizon, 400, seed)
    mc = float(np.clip(np.mean(sims[:, -1] > 0), 0, 1)) if sims.size else 0.5
    bay = _bayesian(w)
    mark = _markov(w)
    trend_deviation = _trend_deviation(lw)
    if benchmark_close is not None:
        bc = _safe(benchmark_close)
        benchmark_logp = np.log(np.maximum(bc, 1e-12))
        benchmark_returns = np.diff(benchmark_logp)
        coin = _relative_spread(lw, benchmark_logp)
        corr = _correlation(np.diff(lw), benchmark_returns)
    else:
        coin = 0.0
        corr = 0.0
    return_vol_corr = _return_vol_correlation(w)
    p_move = float(np.clip(0.45*bay + 0.30*(mark+1)/2 + 0.25*(ar+1)/2, 0, 1))
    direction = float(np.clip(.22*mark + .16*ar + .12*arima + .08*sarima + .10*mr +
                              .08*wave + .08*kal + .08*coin + .08*(2*bay-1), -1, 1))
    # Probabilities are path-touch estimates in the selected mathematical
    # direction. The reference SL is 0.3% adverse excursion until a concrete
    # forecast SL distance is supplied by the caller.
    requested_direction = str(forecast_direction or '').upper()
    if requested_direction == 'LONG':
        direction_sign = 1.0
    elif requested_direction == 'SHORT':
        direction_sign = -1.0
    else:
        direction_sign = 1.0 if direction >= 0 else -1.0
        if abs(direction) < 0.03:
            direction_sign = 1.0 if float(np.mean(w[-12:])) >= 0 else -1.0
    oriented = sims * direction_sign if sims.size else np.zeros((0, max(1, int(horizon))))
    if oriented.size:
        excursion = np.max(oriented, axis=1)
        adverse = np.min(oriented, axis=1)
        targets = (0.003, 0.006, 0.009)
        ptp1, ptp2, ptp3 = [float(np.mean(excursion >= np.log1p(t))) for t in targets]
        psl = float(np.mean(adverse <= -np.log1p(0.003)))
    else:
        ptp1 = ptp2 = ptp3 = psl = 0.5
    consensus = float(np.clip(.16*mark + .10*(2*mc-1) + .10*direction + .08*ar + .08*arima +
                              .06*sarima + .08*(hurst-.5)*2 + .08*mr + .06*wave + .06*kal +
                              .06*coin + .05*(.5-entropy)*2 + .05*corr + .06*(.5-cp), -1, 1))
    # GARCH is a bounded volatility ratio: 0 for no volatility, 0.5 around
    # sample-level volatility, approaching 1 only when forecast volatility is
    # materially larger than realized volatility.
    garch_ratio = g/sd_safe if sd > 1e-12 else 0.0
    garch_feature = float(np.clip(garch_ratio/(1.0+garch_ratio), 0, 1)) if garch_ratio > 0 else 0.0
    return {
        'math_markov': mark, 'math_prob_move': p_move, 'math_ar': ar, 'math_arima': arima,
        'math_sarima': sarima, 'math_garch': garch_feature, 'math_hurst': hurst,
        'math_mean_reversion': mr, 'math_cointegration': coin, 'math_correlation': corr,
        'math_return_vol_correlation': return_vol_corr, 'math_trend_deviation': trend_deviation,
        'math_entropy': entropy, 'math_fractal': fractal, 'math_wavelet': wave,
        'math_kalman': kal, 'math_monte_carlo': mc, 'math_bayesian': bay,
        'math_change_point': cp, 'math_ptp1': ptp1, 'math_ptp2': ptp2,
        'math_ptp3': ptp3, 'math_psl': psl, 'math_direction': direction,
        'math_target_sign': direction_sign,
        'math_consensus': consensus
    }


MATH_OUTPUTS = MATH_FEATURES + ['math_direction', 'math_consensus']
