"""Learning and inference for the manual real-position risk assistant.

This learner is deliberately separate from forecast TP/SL statistics.  It learns
from intermediate snapshots of manually tracked positions whether the next short
window contained meaningful adverse movement for the position direction.
"""
from pathlib import Path
import json
import math
import time
import numpy as np

RISK_FEATURES = (
    'ret1', 'ret3', 'ret8', 'rsi', 'ema12d', 'ema26d', 'macd', 'macds',
    'atrpct', 'bbpos', 'volz', 'rangepct', 'trend', 'volatility',
    'book_imbalance', 'price_change_pct_from_prev_5m',
)


def _paths(root):
    data = Path(root) / 'data'
    data.mkdir(parents=True, exist_ok=True)
    return data / 'position_risk_experience.json', data / 'position_risk_model.json'


def _vector(features):
    features = features if isinstance(features, dict) else {}
    out = []
    for key in RISK_FEATURES:
        try:
            value = float(features.get(key, 0.0) or 0.0)
            out.append(value if math.isfinite(value) else 0.0)
        except Exception:
            out.append(0.0)
    return out


def _read(path, default):
    try:
        value = json.loads(path.read_text(encoding='utf-8'))
        return value if value is not None else default
    except Exception:
        return default


def _write(path, value):
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
    tmp.replace(path)


def _sigmoid(z):
    z = np.clip(np.asarray(z, dtype=float), -30.0, 30.0)
    return 1.0 / (1.0 + np.exp(-z))


def _train(rows, model_path):
    if len(rows) < 30:
        return {'status': 'accumulating', 'rows': len(rows), 'required_rows': 30}
    y = np.asarray([int(r['adverse']) for r in rows], dtype=float)
    if int(np.sum(y == 1)) < 5 or int(np.sum(y == 0)) < 5:
        return {'status': 'accumulating_classes', 'rows': len(rows), 'adverse_rows': int(np.sum(y == 1)), 'safe_rows': int(np.sum(y == 0))}
    X = np.asarray([_vector(r.get('features')) for r in rows], dtype=float)
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    mean = X.mean(axis=0)
    std = X.std(axis=0)
    std[std < 1e-8] = 1.0
    Z = np.clip((X - mean) / std, -8.0, 8.0)
    Z = np.column_stack([np.ones(len(Z)), Z])
    w = np.zeros(Z.shape[1], dtype=float)
    # Deterministic batch logistic regression; no optional ML dependency required on Android.
    lr = 0.04
    for _ in range(350):
        p = _sigmoid(Z @ w)
        grad = (Z.T @ (p - y)) / len(y)
        grad[1:] += 0.002 * w[1:]
        w -= lr * grad
    probs = _sigmoid(Z @ w)
    model = {
        'schema_version': 1, 'status': 'ready', 'updated_at': int(time.time()),
        'rows': len(rows), 'adverse_rows': int(np.sum(y == 1)), 'safe_rows': int(np.sum(y == 0)),
        'training_accuracy_in_sample': round(float(np.mean((probs >= 0.5) == (y >= 0.5))), 4),
        'features': list(RISK_FEATURES), 'mean': mean.tolist(), 'std': std.tolist(), 'weights': w.tolist(),
        'target': 'adverse_move_within_next_monitor_window',
    }
    _write(model_path, model)
    return {'status': 'ready', 'rows': len(rows), 'adverse_rows': model['adverse_rows'], 'safe_rows': model['safe_rows']}


def finalize_position(root, position, cfg=None):
    """Turn a closed real position's snapshots into forward-labelled risk samples."""
    cfg = cfg or {}
    experience_path, model_path = _paths(root)
    observations = position.get('observations') if isinstance(position, dict) else None
    if not isinstance(observations, list) or len(observations) < 6:
        return {'status': 'insufficient_snapshots', 'snapshots': len(observations or [])}
    direction = str(position.get('direction', 'WAIT')).upper()
    if direction not in ('LONG', 'SHORT'):
        return {'status': 'invalid_direction', 'snapshots': len(observations)}
    valid = []
    for item in observations:
        if not isinstance(item, dict):
            continue
        try:
            price = float(item.get('price', 0.0))
            stamp = int(item.get('time', 0))
            features = item.get('features') or {}
            if price > 0 and stamp > 0 and isinstance(features, dict):
                valid.append({'price': price, 'time': stamp, 'features': features})
        except Exception:
            continue
    valid.sort(key=lambda r: r['time'])
    # Five monitor snapshots are approximately 1–2 minutes at the default poll rate.
    lookahead = max(3, int(cfg.get('position_risk_lookahead_snapshots', 5)))
    base_threshold = float(cfg.get('position_risk_adverse_threshold_pct', 0.15)) / 100.0
    rows = _read(experience_path, [])
    if not isinstance(rows, list):
        rows = []
    existing = {str(r.get('sample_id')) for r in rows if isinstance(r, dict)}
    new_rows = []
    pid = str(position.get('position_id') or position.get('opened_from_prediction_id') or position.get('started_at') or 'position')
    contract = str(position.get('contract') or position.get('symbol') or 'UNKNOWN')
    for i in range(0, max(0, len(valid) - lookahead)):
        current = valid[i]
        future = valid[i + 1:i + lookahead + 1]
        if not future:
            continue
        p0 = current['price']
        if direction == 'LONG':
            adverse = max(0.0, (p0 - min(r['price'] for r in future)) / p0)
            favorable = max(0.0, (max(r['price'] for r in future) - p0) / p0)
        else:
            adverse = max(0.0, (max(r['price'] for r in future) - p0) / p0)
            favorable = max(0.0, (p0 - min(r['price'] for r in future)) / p0)
        atr = abs(float(current['features'].get('atrpct', 0.0) or 0.0))
        threshold = max(base_threshold, atr * float(cfg.get('position_risk_atr_threshold_multiplier', 0.5)))
        if adverse >= threshold and adverse >= favorable * 0.8:
            label = 1
        elif favorable >= threshold and favorable > adverse * 1.25:
            label = 0
        else:
            continue
        sample_id = f'{pid}:{current["time"]}:{i}'
        if sample_id in existing:
            continue
        new_rows.append({'sample_id': sample_id, 'time': current['time'], 'contract': contract,
                         'prediction_id': str(position.get('opened_from_prediction_id') or ''),
                         'features': {k: float(current['features'].get(k, 0.0) or 0.0) for k in RISK_FEATURES},
                         'adverse': int(label), 'future_adverse_pct': adverse * 100.0,
                         'future_favorable_pct': favorable * 100.0,
                         'realized_move_pct': float(position.get('realized_move_pct', 0.0) or 0.0)})
    rows.extend(new_rows)
    rows = rows[-max(1000, int(cfg.get('position_risk_max_rows', 20000))):]
    _write(experience_path, rows)
    train_result = _train(rows, model_path)
    return {'status': train_result.get('status'), 'snapshots': len(valid), 'new_samples': len(new_rows),
            'training_rows': len(rows), 'model': train_result}


def predict_risk(root, features):
    """Return learned risk index for near-term adverse movement, if trained."""
    experience_path, model_path = _paths(root)
    model = _read(model_path, {})
    if model.get('status') != 'ready' or not model.get('weights'):
        rows = _read(experience_path, [])
        return {'ready': False, 'probability': None, 'training_rows': len(rows) if isinstance(rows, list) else 0}
    try:
        x = np.asarray(_vector(features), dtype=float)
        mean = np.asarray(model['mean'], dtype=float)
        std = np.asarray(model['std'], dtype=float)
        weights = np.asarray(model['weights'], dtype=float)
        z = np.clip((x - mean) / np.where(std < 1e-8, 1.0, std), -8.0, 8.0)
        p = float(_sigmoid(np.r_[1.0, z] @ weights))
        return {'ready': True, 'probability': p, 'training_rows': int(model.get('rows', 0) or 0)}
    except Exception:
        return {'ready': False, 'probability': None, 'training_rows': int(model.get('rows', 0) or 0)}
