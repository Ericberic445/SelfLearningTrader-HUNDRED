# SelfLearningTrader FIVE 1.0.211 — Mathematical Model Fixes

This update fixes verified mathematical-layer defects without changing the UI or scan pipeline (700 → 50 → 25 → TOP-5).

## Changes

- Fixed the Haar-like wavelet detail calculation. The previous code centered every window before averaging it, forcing the calculated mean detail to zero. The replacement compares adjacent half-window means at several scales.
- Fixed Markov state assignment. States now represent negative / neutral / positive returns rather than relative quantiles, so a falling market's upper quantile is not incorrectly treated as a positive-return state. Constant returns and unseen transition states return neutral evidence.
- Fixed GARCH volatility normalization. Zero-volatility input now returns zero risk instead of being amplified to the maximum by division by near-zero standard deviation. The recursion uses a stationary GARCH(1,1) parameterization.
- Made TP1/TP2/TP3 probabilities directional path-touch estimates from Monte Carlo paths. The stop-loss reference probability is estimated independently as an adverse excursion, not calculated as `1 - P(TP1)`. The default reference SL distance is 0.3% until the caller supplies a concrete stop distance.
- Fixed C3 risk handling. High estimated adverse-excursion risk now increases WAIT and suppresses directional confidence; it does not directly strengthen LONG.
- Corrected misleading single-series labels: trend deviation is exposed as `math_trend_deviation`; pairwise correlation and relative-spread features use a BTC benchmark when available. Without a benchmark, pairwise correlation and cointegration proxy are neutral rather than pretending to be cross-asset calculations.
- Added one BTC 5-minute benchmark fetch per deep-scan pass, reused across the 25-candidate mathematical pass. The 700 → 50 → 25 → TOP-5 scan scheme is unchanged.

## Validation

- Added six focused regression tests for wavelet, Markov, GARCH, directional TP/SL probabilities, benchmark correlation and C3 risk response.
- Full Python unit suite: 29 tests passed.
- Python bytecode compilation passed.
- This validates source logic only; Android/device and live KuCoin API behavior still require on-device verification.
