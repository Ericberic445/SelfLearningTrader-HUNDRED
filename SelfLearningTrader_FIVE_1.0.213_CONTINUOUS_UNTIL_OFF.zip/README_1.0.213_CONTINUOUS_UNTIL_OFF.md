# SelfLearningTrader FIVE 1.0.213 — continuous background service

This release changes background-service power management only; the UI layout is unchanged.

- The partial CPU wake lock is requested from `PythonService.mService` (the foreground service's Android Context), rather than relying on the UI Activity being present.
- The wake lock request is made at service startup, before importing the heavier trading/model stack, then retried after engine initialization if startup acquisition failed.
- Wake-lock failures are logged with the exception/context instead of being silently swallowed.
- The existing foreground `sticky` service, user STOP/OFF control, scan cadence, prediction logic, and learning logic are preserved.

Android limitation: no app can guarantee survival after Android force-stop, an OEM's aggressive process kill, revoked permissions, or device shutdown. This improves the service's CPU continuity when Android allows the foreground service to run; it still requires real-device testing with screen locked and while other apps/games are active.
