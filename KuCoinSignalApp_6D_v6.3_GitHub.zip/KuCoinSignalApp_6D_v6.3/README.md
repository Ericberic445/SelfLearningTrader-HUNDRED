# KuCoin Signal App 6D / v6.3

Recreated from the September 16, 2026 v6.3 discussion.

This is the **ordinary non-AI scanner**, separate from SelfLearningTrader.

Core v6.3 rules recovered:
- KuCoin Futures.
- Timeframes: 1D, 4H, 1H, 15M, 5M.
- 4H + 1H are the primary direction confirmation.
- If 4H and 1H disagree: WAIT.
- 1D is a senior filter, not a dictator.
- Near-equal LONG/SHORT is neutral.
- Separate LONG and SHORT scores.
- WAIT when confirmations are insufficient.
- Indicators/data: EMA20/50/200, RSI, MACD, ADX/DI gate, VWAP/volume context, Bollinger, market structure, order book imbalance, OI/market contract data, funding, Mark/Index, ATR.
- Incomplete candles are excluded.
- Historical check is limited statistics influencing the score; this is not an AI model or full backtest.
- Entry is blocked without key confirmations.
- LONG and SHORT are both supported.
- TP/SL are calculated from ATR.
- No automatic trading.

Current KuCoin endpoints were wired to the public Futures REST API. KuCoin's current documentation confirms the Futures contracts, all-tickers, kline, order-book, mark-price and funding endpoints used by the app.


Implementation note:
The original source archive was not present in the available Library, so this build is a faithful reconstruction of the recovered v6.3 specification, not a byte-for-byte copy of the lost original.


### Поиск монет
В верхней строке добавлен выпадающий список всех активных USDT Futures-контрактов KuCoin. Достаточно нажать строку и ввести первые буквы (например `BTC`, `ETH`, `SOL`) — список автоматически фильтруется и предлагает подходящие монеты. Название можно выбрать одним нажатием.
