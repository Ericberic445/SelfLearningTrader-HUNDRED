RECOVERY NOTES

The exact original v6.3 APK/ZIP was not found in the available archive.
The project was reconstructed from the remembered September 16 conversation and preserved project/build artifacts.

Important historical fixes:
- v6.1: candle retrieval was fixed.
- v6.2: indicators/data and a basic historical check were added.
- v6.3: limited historical statistics were incorporated into scoring.
- v6.3: 1D was changed to a secondary/senior filter rather than a dictator.
- 4H + 1H must confirm the direction; disagreement produces WAIT.
- Funding N/A should not block a signal.
- OI and Mark/Index are treated as important market-data checks.
- Order-book imbalance is displayed as a percentage.
- Entry is blocked when key data/confirmations are missing.
