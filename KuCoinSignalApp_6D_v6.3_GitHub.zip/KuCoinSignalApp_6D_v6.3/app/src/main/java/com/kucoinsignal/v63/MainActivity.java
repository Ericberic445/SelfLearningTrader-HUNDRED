package com.kucoinsignal.v63;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.text.Editable;
import android.text.TextWatcher;
import org.json.*;
import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

/**
 * KuCoin Signal PRO v6.3 reconstruction.
 * UI and single-symbol analysis follow the installed PRO v6.3 reference screen.
 */
public class MainActivity extends Activity {
    static final String BASE = "https://api-futures.kucoin.com";
    static final String UTA = "https://api.kucoin.com";
    ExecutorService pool = Executors.newFixedThreadPool(4);
    Handler ui = new Handler();
    AutoCompleteTextView coinSearch;
    ArrayAdapter<String> coinAdapter;
    ArrayList<String> coinSymbols = new ArrayList<>();
    TextView resultView, statusView;
    Button analyzeBtn;

    int BG = Color.rgb(15,15,17);
    int PANEL = Color.rgb(15,15,17);
    int MUTED = Color.rgb(205,205,210);
    int BUTTON = Color.rgb(92,92,95);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        loadCoinList();
    }

    TextView tv(String s, float sp) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(Color.WHITE);
        t.setPadding(7,2,7,2);
        return t;
    }

    GradientDrawable rounded(int strokeColor, int fillColor, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fillColor); g.setCornerRadius(radiusDp * getResources().getDisplayMetrics().density);
        g.setStroke((int)(1*getResources().getDisplayMetrics().density), strokeColor);
        return g;
    }

    void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(15,8,15,18);
        root.setBackgroundColor(BG);
        scroll.addView(root, new ScrollView.LayoutParams(-1,-1));

        TextView title = tv("Сигнал фьючерсов PRO v6.3", 27);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        title.setPadding(0,0,0,2);
        root.addView(title, new LinearLayout.LayoutParams(-1,48));

        TextView sub = tv("Многоуровневая проверка • 1D + 4H + 1H + 15M + 5M\n• цена + объём + OI + стакан", 17);
        sub.setTextColor(Color.WHITE);
        sub.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(sub, new LinearLayout.LayoutParams(-1,64));

        coinSearch = new AutoCompleteTextView(this);
        coinSearch.setText("XBTUSDTM");
        coinSearch.setTextColor(Color.WHITE);
        coinSearch.setHintTextColor(Color.GRAY);
        coinSearch.setSingleLine(true);
        coinSearch.setTextSize(20);
        coinSearch.setPadding(5,0,5,0);
        coinSearch.setThreshold(1);
        coinSearch.setDropDownHeight(520);
        coinSearch.setBackgroundColor(Color.TRANSPARENT);
        coinAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, coinSymbols);
        coinSearch.setAdapter(coinAdapter);
        coinSearch.setOnClickListener(v -> { if (!coinSymbols.isEmpty()) coinSearch.showDropDown(); });
        coinSearch.setOnFocusChangeListener((v, hasFocus) -> { if(hasFocus && !coinSymbols.isEmpty()) coinSearch.showDropDown(); });
        coinSearch.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){ if(s.length()>=1 && !coinSymbols.isEmpty()) coinSearch.showDropDown(); }
            public void afterTextChanged(Editable e){}
        });
        root.addView(coinSearch, new LinearLayout.LayoutParams(-1,55));

        View line = new View(this); line.setBackgroundColor(Color.rgb(135,135,140));
        root.addView(line, new LinearLayout.LayoutParams(-1,2));

        analyzeBtn = new Button(this);
        analyzeBtn.setText("АНАЛИЗ");
        analyzeBtn.setTextSize(18);
        analyzeBtn.setTextColor(Color.WHITE);
        analyzeBtn.setAllCaps(false);
        analyzeBtn.setBackgroundColor(BUTTON);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1,62);
        bp.topMargin = 22; bp.bottomMargin = 18;
        root.addView(analyzeBtn, bp);

        resultView = tv("ОЖИДАНИЕ\n\nВход —\nСтоп-лосс —\nТейк-профит 1 —\nТейк-профит 2 —\nТейк-профит 3 —", 20);
        resultView.setGravity(Gravity.LEFT);
        resultView.setPadding(13,11,13,15);
        resultView.setBackground(rounded(Color.rgb(45,45,48), PANEL, 26));
        root.addView(resultView, new LinearLayout.LayoutParams(-1,210));

        statusView = tv("Готово", 17);
        statusView.setPadding(13,9,13,9);
        root.addView(statusView, new LinearLayout.LayoutParams(-1,45));

        TextView spacer = tv("",1);
        root.addView(spacer, new LinearLayout.LayoutParams(-1,150));

        analyzeBtn.setOnClickListener(v -> analyzeSelected());
        setContentView(scroll);
    }

    void loadCoinList() {
        new Thread(() -> {
            try {
                JSONArray contracts = get(BASE + "/api/v1/contracts/active");
                ArrayList<String> fresh = new ArrayList<>();
                for(int i=0;i<contracts.length();i++){
                    JSONObject c=contracts.getJSONObject(i);
                    if(!"USDT".equalsIgnoreCase(c.optString("settleCurrency"))) continue;
                    if(!"Open".equalsIgnoreCase(c.optString("status"))) continue;
                    String symbol=c.optString("symbol","");
                    if(!symbol.isEmpty()) fresh.add(symbol);
                }
                Collections.sort(fresh, String.CASE_INSENSITIVE_ORDER);
                ui.post(() -> { coinSymbols.clear(); coinSymbols.addAll(fresh); if(coinAdapter!=null) coinAdapter.notifyDataSetChanged(); });
            } catch(Exception ignored) {}
        }).start();
    }

    String selectedContract(){
        String raw=coinSearch==null?"":coinSearch.getText().toString().trim().toUpperCase(Locale.US);
        int p=raw.lastIndexOf("("); int q=raw.lastIndexOf(")");
        if(p>=0&&q>p) raw=raw.substring(p+1,q).trim();
        raw=raw.replace(" ","");
        return raw.isEmpty()?"XBTUSDTM":raw;
    }

    void analyzeSelected(){
        final String sym=selectedContract();
        analyzeBtn.setEnabled(false);
        resultView.setText("АНАЛИЗ\n\nЗагрузка 1D + 4H + 1H + 15M + 5M…");
        statusView.setText("Проверяю данные KuCoin…");
        new Thread(() -> {
            try {
                Contract c=loadContract(sym);
                Signal s=analyze(c);
                String text=renderSignal(s);
                ui.post(() -> { resultView.setText(text); statusView.setText("Готово"); analyzeBtn.setEnabled(true); });
            } catch(Exception e){
                ui.post(() -> { resultView.setText("ОЖИДАНИЕ\n\nОшибка анализа: "+cleanError(e)); statusView.setText("Готово"); analyzeBtn.setEnabled(true); });
            }
        }).start();
    }

    String cleanError(Exception e){
        String m=e.getMessage(); return m==null?e.getClass().getSimpleName():m;
    }

    Contract loadContract(String sym)throws Exception{
        JSONObject o=getObj(BASE+"/api/v1/contracts/"+URLEncoder.encode(sym,"UTF-8"));
        return new Contract(o.getJSONObject("data"));
    }

    String renderSignal(Signal s){
        StringBuilder z=new StringBuilder();
        z.append("ОЖИДАНИЕ • ").append(s.direction).append("\n");
        z.append("ВХОДА ").append(s.entryAllowed?"РАЗРЕШЕН: "+s.direction:"НЕТ — ОЖИДАНИЕ").append("\n\n");
        z.append("Направление: ").append(s.direction).append("\n");
        z.append("Оценка подтверждения: ").append(s.confirmation).append("/100\n\n");
        if(!s.entryAllowed) z.append("ВХОД ЗАБЛОКИРОВАН: 4Ч/1Ч НЕ СОГЛАСОВАНЫ\n\n");
        else z.append("ВХОД ПОДТВЕРЖДЁН: 4Ч/1Ч СОГЛАСОВАНЫ\n\n");
        z.append("LONG: ").append(fmt1(s.longScore)).append("   SHORT: ").append(fmt1(s.shortScore)).append("\n");
        z.append("1D: ").append(s.d1).append("\n");
        z.append("4Ч: ").append(s.h4).append("\n");
        z.append("1Ч: ").append(s.h1).append("\n");
        z.append("RSI 5М/15М/1Ч/4Ч/1D: ").append(fmt1(s.rsi5)).append(" / ").append(fmt1(s.rsi15)).append(" / ").append(fmt1(s.rsi1)).append(" / ").append(fmt1(s.rsi4)).append(" / ").append(fmt1(s.rsiD)).append("\n");
        z.append("ADX 1Ч: ").append(fmt1(s.adx1)).append(" +DI ").append(fmt1(s.pdi1)).append(" -DI ").append(fmt1(s.mdi1)).append("\n");
        z.append("VWAP 5М: ").append(fmtPrice(s.vwap5)).append(" • BB ").append(fmt2(s.bb5)).append("\n");
        z.append("Объём / средний: ").append(fmt2(s.volumeRatio)).append("\n");
        z.append("Дисбаланс стакана: ").append(fmtSignedPct(s.ob)).append("\n");
        z.append("Изменение OI ~30 мин: ").append(fmtSignedPct(s.oiChange)).append("\n");
        z.append("Фандинг: ").append(s.fundingAvailable?fmtSignedPct(s.funding):"N/A").append("\n");
        z.append("Mark-Index: ").append(fmtSignedPct(s.markIndexGap)).append("\n");
        z.append("Историческая устойчивость 1Ч: LONG ").append(fmt0(s.histLong*100)).append("% / SHORT ").append(fmt0(s.histShort*100)).append("%\n");
        z.append("ATR 1Ч / цена: ").append(fmt2(s.atrPct*100)).append("%\n\n");
        z.append("Фильтры: EMA20/50/200 • RSI • MACD • ADX/DI • VWAP • Bollinger • структура • объём • стакан • OI • funding • mark/index\n\n");
        z.append("Вход — ").append(s.entryAllowed?fmtPrice(s.entry):"—").append("\n");
        z.append("Стоп-лосс — ").append(s.entryAllowed?fmtPrice(s.sl):"—").append("\n");
        z.append("Тейк-профит 1 — ").append(s.entryAllowed?fmtPrice(s.tp1):"—").append("\n");
        z.append("Тейк-профит 2 — ").append(s.entryAllowed?fmtPrice(s.tp2):"—").append("\n");
        z.append("Тейк-профит 3 — ").append(s.entryAllowed?fmtPrice(s.tp3):"—").append("\n\n");
        z.append("Обновлено: ").append(new SimpleDateFormat("EEE MMM dd HH:mm:ss 'GMT'Z yyyy", Locale.US).format(new Date())).append("\n");
        z.append("закрытие свечи • строгий фильтр 1D+4H+1H • без гарантии результата");
        return z.toString();
    }

    Signal analyze(Contract c)throws Exception{
        Bars d1=getBars(c.symbol,1440,220), h4=getBars(c.symbol,240,220), h1=getBars(c.symbol,60,220), m15=getBars(c.symbol,15,220), m5=getBars(c.symbol,5,220);
        if(d1.n<205||h4.n<205||h1.n<205||m15.n<205||m5.n<205) throw new IOException("Недостаточно свечей для анализа");
        TF a=score(d1), b=score(h4), d=score(h1), e=score(m15), f=score(m5);
        double l=3*b.longScore+3*d.longScore+2*e.longScore+f.longScore+a.longScore;
        double sh=3*b.shortScore+3*d.shortScore+2*e.shortScore+f.shortScore+a.shortScore;
        double ob=orderBookImbalance(c.symbol); double fund=funding(c.symbol); double oi=oiChange30(c.symbol);
        double gap=c.index>0?(c.mark-c.index)/c.index:0;
        if(ob>0.08) l+=1; if(ob<-0.08) sh+=1;
        if(fund<0) l+=Math.min(.7,Math.abs(fund)*50); if(fund>0) sh+=Math.min(.7,Math.abs(fund)*50);
        if(gap>0.002) sh+=.5; if(gap<-.002) l+=.5;
        double histLong=historicalRate(h1,true), histShort=historicalRate(h1,false);
        l+=(histLong-.5)*2; sh+=(histShort-.5)*2;
        String direction=l>=sh?"LONG":"SHORT";
        double diff=Math.abs(l-sh); int confirmation=(int)Math.round(Math.max(0,Math.min(100,50+diff*3.0)));
        boolean primaryAgree=dir(b)==dir(d) && dir(b)!=0;
        boolean entryAllowed=primaryAgree && confirmation>=58;
        double price=c.mark>0?c.mark:c.price, atr=atr(h1); if(!Double.isFinite(atr)||atr<=0) atr=price*.0065;
        Signal s=new Signal(); s.symbol=c.symbol; s.direction=direction; s.confirmation=confirmation; s.entryAllowed=entryAllowed;
        s.longScore=l; s.shortScore=sh; s.d1=tag(a); s.h4=tag(b); s.h1=tag(d);
        s.rsi5=f.rsi; s.rsi15=e.rsi; s.rsi1=d.rsi; s.rsi4=b.rsi; s.rsiD=a.rsi;
        s.adx1=d.adx; s.pdi1=d.pdi; s.mdi1=d.mdi; s.vwap5=f.vwap; s.bb5=f.bb; s.volumeRatio=f.volumeRatio;
        s.ob=ob; s.oiChange=oi; s.funding=fund; s.fundingAvailable=true; s.markIndexGap=gap;
        s.histLong=histLong; s.histShort=histShort; s.atrPct=atr/price; s.entry=price;
        if(direction.equals("LONG")){s.sl=price-1.2*atr;s.tp1=price+1.5*atr;s.tp2=price+2.4*atr;s.tp3=price+3.6*atr;}
        else {s.sl=price+1.2*atr;s.tp1=price-1.5*atr;s.tp2=price-2.4*atr;s.tp3=price-3.6*atr;}
        return s;
    }

    int dir(TF x){return Integer.compare(x.longScore,x.shortScore);}
    String tag(TF x){ if(x.longScore-x.shortScore>=1)return "LONG ✓ (L"+fmt0(x.longScore)+" / S"+fmt0(x.shortScore)+")"; if(x.shortScore-x.longScore>=1)return "SHORT ✓ (L"+fmt0(x.longScore)+" / S"+fmt0(x.shortScore)+")"; return "ДРУГОЕ (L"+fmt0(x.longScore)+" / S"+fmt0(x.shortScore)+")"; }

    TF score(Bars b){
        int i=b.n-1; double[] em20=ema(b.c,20),em50=ema(b.c,50),em200=ema(b.c,200),rs=rsi(b.c,14),mc=macdHist(b.c),ad=adx(b,14),vw=vwap(b),bb=bbWidth(b.c,20); double vr=b.v[i]/Math.max(1e-9,avg(b.v,20,i)); double last=b.c[i];
        double L=0,S=0;
        if(last>em20[i])L++;else S++; if(last>em50[i])L++;else S++; if(last>em200[i])L++;else S++;
        if(last>vw[i])L+=.5;else S+=.5; if(rs[i]>55)L++;else if(rs[i]<45)S++; if(mc[i]>0)L++;else S++;
        if(Double.isFinite(ad[i])&&ad[i]>20){if(last>em20[i]&&em20[i]>em50[i])L++;if(last<em20[i]&&em20[i]<em50[i])S++;}
        double mid=avg(b.c,20,i),sd=std(b.c,20,i); if(last>mid+sd)L+=.5;else if(last<mid-sd)S+=.5;
        if(vr>1.15){if(b.c[i]>b.o[i])L+=.5;else S+=.5;}
        if(i>=4){boolean hh=b.h[i]>b.h[i-2]&&b.l[i]>b.l[i-2],ll=b.h[i]<b.h[i-2]&&b.l[i]<b.l[i-2];if(hh)L+=.5;if(ll)S+=.5;if(last>b.c[i-3])L+=.5;else if(last<b.c[i-3])S+=.5;}
        double[] di=diSeries(b,14); TF x=new TF(); x.longScore=L;x.shortScore=S;x.net=L-S;x.rsi=rs[i];x.adx=ad[i];x.pdi=di[0];x.mdi=di[1];x.vwap=vw[i];x.bb=bb[i];x.volumeRatio=vr;return x;
    }

    double historicalRate(Bars b,boolean wantLong){int start=Math.max(200,b.n-100),wins=0,n=0;for(int i=start;i<b.n-3;i++){double e20=emaAt(b.c,20,i),e50=emaAt(b.c,50,i);int pred=b.c[i]>e20&&e20>e50?1:(b.c[i]<e20&&e20<e50?-1:0);if(pred==0)continue;n++;double f=b.c[i+3]/b.c[i]-1;if((wantLong&&pred>0&&f>0)||(!wantLong&&pred<0&&f<0))wins++;}return n==0?.5:(double)wins/n;}
    double orderBookImbalance(String sym)throws Exception{JSONObject d=getObj(BASE+"/api/v1/level2/snapshot?symbol="+URLEncoder.encode(sym,"UTF-8")).getJSONObject("data");JSONArray bids=d.optJSONArray("bids"),asks=d.optJSONArray("asks");double b=0,a=0;for(int i=0;i<Math.min(20,bids.length());i++)b+=bids.getJSONArray(i).optDouble(1);for(int i=0;i<Math.min(20,asks.length());i++)a+=asks.getJSONArray(i).optDouble(1);return b+a==0?0:(b-a)/(b+a);}
    double funding(String sym)throws Exception{try{JSONObject d=getObj(BASE+"/api/v1/funding-rate/"+URLEncoder.encode(sym,"UTF-8")+"/current").getJSONObject("data");return d.optDouble("value",0);}catch(Exception e){return 0;}}
    double oiChange30(String sym){try{String u=UTA+"/api/ua/v2/market/open-interest?symbol="+URLEncoder.encode(sym,"UTF-8")+"&interval=30min&pageSize=2";JSONArray a=getObj(u).getJSONArray("data");if(a.length()<2)return 0;double now=a.getJSONObject(0).optDouble("openInterest",0),old=a.getJSONObject(1).optDouble("openInterest",0);return old==0?0:(now-old)/old;}catch(Exception e){return 0;}}

    Bars getBars(String sym,int gran,int limit)throws Exception{long now=System.currentTimeMillis(),from=now-(long)gran*60*1000L*(limit+5);String u=BASE+"/api/v1/kline/query?symbol="+URLEncoder.encode(sym,"UTF-8")+"&granularity="+gran+"&from="+from+"&to="+now;JSONArray a=get(u);ArrayList<double[]> rows=new ArrayList<>();for(int i=0;i<a.length();i++){JSONArray r=a.getJSONArray(i);if(r.length()<7)continue;rows.add(new double[]{r.getDouble(0),r.getDouble(1),r.getDouble(2),r.getDouble(3),r.getDouble(4),r.getDouble(5)});}rows.sort(Comparator.comparingDouble(z->z[0]));if(rows.size()>limit)rows=new ArrayList<>(rows.subList(rows.size()-limit,rows.size()));Bars b=new Bars(rows.size());for(int i=0;i<rows.size();i++){double[] r=rows.get(i);b.t[i]=r[0];b.o[i]=r[1];b.h[i]=r[2];b.l[i]=r[3];b.c[i]=r[4];b.v[i]=r[5];}if(b.n>1&&System.currentTimeMillis()-b.t[b.n-1]<gran*60*1000L)b.n--;return b;}

    JSONArray get(String url)throws Exception{JSONObject o=getObj(url);Object d=o.get("data");return d instanceof JSONArray?(JSONArray)d:new JSONArray().put(d);}
    JSONObject getObj(String url)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(12000);c.setReadTimeout(15000);c.setRequestMethod("GET");c.setRequestProperty("User-Agent","KuCoinSignal6D/6.3");int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();String s=read(in);c.disconnect();JSONObject o=new JSONObject(s);if(!"200000".equals(o.optString("code")))throw new IOException("KuCoin "+o.optString("code"));return o;}
    String read(InputStream in)throws Exception{BufferedReader r=new BufferedReader(new InputStreamReader(in));StringBuilder s=new StringBuilder();String x;while((x=r.readLine())!=null)s.append(x);r.close();return s.toString();}

    double atr(Bars b){return atrSeries(b,14)[b.n-1];}
    static double[] ema(double[] x,int p){double[] y=new double[x.length];Arrays.fill(y,Double.NaN);double a=2.0/(p+1),s=0;for(int i=0;i<x.length;i++){s+=x[i];if(i==p-1){s/=p;y[i]=s;}else if(i>=p)y[i]=a*x[i]+(1-a)*y[i-1];}return y;}
    static double emaAt(double[] x,int p,int i){double[] e=ema(Arrays.copyOfRange(x,0,i+1),p);return e[e.length-1];}
    static double[] rsi(double[] x,int p){double[] y=new double[x.length];Arrays.fill(y,Double.NaN);if(x.length<=p)return y;double g=0,l=0;for(int i=1;i<=p;i++){double d=x[i]-x[i-1];if(d>=0)g+=d;else l-=d;}g/=p;l/=p;y[p]=l==0?100:100-100/(1+g/l);for(int i=p+1;i<x.length;i++){double d=x[i]-x[i-1];g=(g*(p-1)+Math.max(0,d))/p;l=(l*(p-1)+Math.max(0,-d))/p;y[i]=l==0?100:100-100/(1+g/l);}return y;}
    static double[] macdHist(double[] x){double[] a=ema(x,12),b=ema(x,26),m=new double[x.length];Arrays.fill(m,Double.NaN);for(int i=0;i<x.length;i++)if(Double.isFinite(a[i])&&Double.isFinite(b[i]))m[i]=a[i]-b[i];double[] clean=new double[x.length];for(int i=0;i<x.length;i++)clean[i]=Double.isFinite(m[i])?m[i]:0;double[] s=ema(clean,9),h=new double[x.length];for(int i=0;i<x.length;i++)h[i]=Double.isFinite(m[i])&&Double.isFinite(s[i])?m[i]-s[i]:0;return h;}
    static double[] atrSeries(Bars b,int p){double[] tr=new double[b.n],a=new double[b.n];Arrays.fill(a,Double.NaN);for(int i=0;i<b.n;i++)tr[i]=i==0?b.h[i]-b.l[i]:Math.max(b.h[i]-b.l[i],Math.max(Math.abs(b.h[i]-b.c[i-1]),Math.abs(b.l[i]-b.c[i-1])));double s=0;for(int i=0;i<b.n;i++){s+=tr[i];if(i==p-1)a[i]=s/p;else if(i>=p)a[i]=(a[i-1]*(p-1)+tr[i])/p;}return a;}
    static double[] adx(Bars b,int p){double[] out=new double[b.n];Arrays.fill(out,Double.NaN);if(b.n<p*2+1)return out;double[] tr=new double[b.n],plus=new double[b.n],minus=new double[b.n];for(int i=1;i<b.n;i++){tr[i]=Math.max(b.h[i]-b.l[i],Math.max(Math.abs(b.h[i]-b.c[i-1]),Math.abs(b.l[i]-b.c[i-1])));double up=b.h[i]-b.h[i-1],dn=b.l[i-1]-b.l[i];plus[i]=(up>dn&&up>0)?up:0;minus[i]=(dn>up&&dn>0)?dn:0;}double atr=0,sp=0,sm=0;for(int i=1;i<=p;i++){atr+=tr[i];sp+=plus[i];sm+=minus[i];}atr/=p;sp/=p;sm/=p;double prev=Double.NaN;for(int i=p;i<b.n;i++){if(i>p){atr=(atr*(p-1)+tr[i])/p;sp=(sp*(p-1)+plus[i])/p;sm=(sm*(p-1)+minus[i])/p;}double pdi=atr==0?0:100*sp/atr,mdi=atr==0?0:100*sm/atr,dx=pdi+mdi==0?0:100*Math.abs(pdi-mdi)/(pdi+mdi);prev=Double.isNaN(prev)?dx:(prev*(p-1)+dx)/p;out[i]=prev;}return out;}
    static double[] diSeries(Bars b,int p){double[] tr=new double[b.n],plus=new double[b.n],minus=new double[b.n];for(int i=1;i<b.n;i++){tr[i]=Math.max(b.h[i]-b.l[i],Math.max(Math.abs(b.h[i]-b.c[i-1]),Math.abs(b.l[i]-b.c[i-1])));double up=b.h[i]-b.h[i-1],dn=b.l[i-1]-b.l[i];plus[i]=(up>dn&&up>0)?up:0;minus[i]=(dn>up&&dn>0)?dn:0;}double atr=0,sp=0,sm=0;for(int i=1;i<=p;i++){atr+=tr[i];sp+=plus[i];sm+=minus[i];}atr/=p;sp/=p;sm/=p;for(int i=p+1;i<b.n;i++){atr=(atr*(p-1)+tr[i])/p;sp=(sp*(p-1)+plus[i])/p;sm=(sm*(p-1)+minus[i])/p;}return new double[]{atr==0?0:100*sp/atr,atr==0?0:100*sm/atr};}
    static double[] vwap(Bars b){double[] o=new double[b.n];double pv=0,v=0;for(int i=0;i<b.n;i++){double t=(b.h[i]+b.l[i]+b.c[i])/3;pv+=t*b.v[i];v+=b.v[i];o[i]=v==0?b.c[i]:pv/v;}return o;}
    static double[] bbWidth(double[] x,int p){double[] y=new double[x.length];for(int i=0;i<x.length;i++){if(i<p-1){y[i]=0;continue;}double m=avg(x,p,i),sd=std(x,p,i);y[i]=m==0?0:2*sd/m;}return y;}
    static double avg(double[] x,int p,int i){int s=Math.max(0,i-p+1);double z=0;for(int k=s;k<=i;k++)z+=x[k];return z/(i-s+1);}
    static double std(double[] x,int p,int i){int s=Math.max(0,i-p+1);double m=avg(x,p,i),z=0;for(int k=s;k<=i;k++){double d=x[k]-m;z+=d*d;}return Math.sqrt(z/(i-s+1));}
    static String fmt0(double x){return String.format(Locale.US,"%.0f",x);}
    static String fmt1(double x){return String.format(Locale.US,"%.1f",x);}
    static String fmt2(double x){return String.format(Locale.US,"%.2f",x);}
    static String fmtPrice(double x){return x>=100?String.format(Locale.US,"%.1f",x):x>=1?String.format(Locale.US,"%.4f",x):String.format(Locale.US,"%.8f",x);}
    static String fmtSignedPct(double x){return String.format(Locale.US,"%+.2f%%",x*100);}

    static class Contract{String symbol,display;double price,mark,index,openInterest;Contract(JSONObject o){symbol=o.optString("symbol");display=o.optString("displaySymbol",symbol);price=o.optDouble("lastTradePrice",0);mark=o.optDouble("markPrice",price);index=o.optDouble("indexPrice",0);openInterest=o.optDouble("openInterest",0);}}
    static class Signal{String symbol,direction,d1,h4,h1;int confirmation;boolean entryAllowed,fundingAvailable;double longScore,shortScore,rsi5,rsi15,rsi1,rsi4,rsiD,adx1,pdi1,mdi1,vwap5,bb5,volumeRatio,ob,oiChange,funding,markIndexGap,histLong,histShort,atrPct,entry,sl,tp1,tp2,tp3;}
    static class TF{double longScore,shortScore,net,rsi,adx,pdi,mdi,vwap,bb,volumeRatio;}
    static class Bars{int n;double[]t,o,h,l,c,v;Bars(int n){this.n=n;t=new double[n];o=new double[n];h=new double[n];l=new double[n];c=new double[n];v=new double[n];}}
}
