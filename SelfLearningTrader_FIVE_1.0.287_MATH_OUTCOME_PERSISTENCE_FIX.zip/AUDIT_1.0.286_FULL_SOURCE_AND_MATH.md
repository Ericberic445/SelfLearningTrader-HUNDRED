# SelfLearningTrader FIVE 1.0.286 — full source, scan and mathematical audit

## Scope

Reviewed the 1.0.286 source tree, including scanner, Master prediction flow, math snapshot and estimators, probability calibration, formula-expert selection, shadow outcome resolution, forecast persistence, history/statistics, background worker lifecycle, release metadata and the supplied 2026-11-26 runtime backup.

## Confirmed defects fixed in this audit

1. **Android release identity mismatch:** `buildozer.spec` declared 1.0.286 while Android numeric version and both config files still declared 1.0.285. Updated numeric version to 10286 and synchronized root/app config versions to 1.0.286. Release-identity regression tests now pass.
2. **MODEL stage processed the whole market:** the prior 1.0.285 logic treated 50 high-confidence predictions as a readiness target rather than a hard deep-analysis limit. If 50 forecasts did not reach 90% confidence, the program continued deep Master analysis across all 700+ contracts. Runtime logs show cycles 1202–1204 each reached the 1,800-second MODEL deadline, with 641/634/602 reported errors respectively; the code confirms most remaining contracts were counted as timed-out/skipped after the deadline. The expensive stage now receives the configured quick-ranked finalist pool (default 50), preserving priority contracts first, then filling remaining places from the ordinary quick-ranked pool. The pipeline is again quick market scan -> deep 50 -> 25 -> TOP-5.
3. **NumPy JSON persistence failure:** retained the 1.0.286 fix that converts NumPy arrays/scalars and Path values before JSON serialization and atomically replaces ledger files. TOP5 and LAST100 history writers use the same converter.

## Mathematical formula review

The 23 declared mathematical outputs and their integration were reviewed. Existing synthetic/regression coverage checks flat, rising, falling and noisy series; AR/ARIMA/SARIMA/GARCH behavior; Hurst/fractal bounds; Kalman/wavelet direction; timestamp alignment and gaps; TP/SL first-touch ordering; non-overlapping Bayesian blocks; Monte Carlo bounds; and calibration leakage/holdout rules.

**Important result from the supplied live backup:** the formulas are not yet empirically validated strongly enough to advise Master. The calibration archive has 250 observations across 70 independent cycles, but requires at least 80 cycles; `validated_heads` is empty. The math expert selector reports `no_expert_passed`. The ensemble remains `shadow_candidate`, with 269 rows; its validation accuracy is 0.4333 versus Master baseline 0.5333, and validation plan quality is 0.0613 versus Master baseline 0.1957 (validation lift -0.1154). Therefore no formula adviser is activated. This is the correct safety behavior: weak formulas remain shadow-only and cannot overwrite or veto Master forecasts.

The formula engine itself computes raw scores and path probabilities, but those are not proof of predictive accuracy. The Bayesian and Monte Carlo heads remain neutral/unvalidated until their own chronological holdout gates pass. The math layer's `math_learning_enabled` is false; formula coefficients are not autonomously trained. Formula improvements must be based on additional matured, independent observations and out-of-sample validation, not hand-tuned weights.

## Challenger integrity

No Challenger weights, model files, snapshots, state, initialization, training, promotion, or prediction logic were edited by this audit. The scanner and persistence fixes do not change Challenger architecture or state.

## Verification

- `PYTHONPATH=. pytest -q`: **358 passed, 24 subtests passed**.
- `python -m compileall -q app tests`: passed.
- Release identity: 1.0.286 / Android numeric version 10286 / both configs 1.0.286.
- Source ZIP integrity: checked after packaging.

## Remaining verification boundary

No APK build or live Android/KuCoin run was performed here. Therefore Top5 persistence and the shorter 50-candidate MODEL stage are verified by source-level regression tests, not yet by a new phone runtime log. Live mathematical predictive accuracy cannot be certified until the app accumulates enough independent matured shadow observations and passes its chronological validation gates.
