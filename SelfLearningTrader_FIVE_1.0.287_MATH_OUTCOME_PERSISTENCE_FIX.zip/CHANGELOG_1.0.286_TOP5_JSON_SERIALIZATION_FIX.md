# SelfLearningTrader FIVE 1.0.286 — persistence, scan-pool and release-integrity fixes

- Convert NumPy arrays/scalars and Path objects to JSON-native values in all forecast/history writers.
- Use atomic replacement for JSON ledger writes.
- Bound expensive Master MODEL analysis to the configured quick-ranked finalist pool (default 50), while preserving priority contracts first; the existing 25 -> TOP-5 ranking remains.
- Synchronize release identity: app version 1.0.286, Android numeric version 10286, root and app config versions 1.0.286.
- Mathematical formula definitions and weights were not changed. Formula advisers remain shadow-only until their own chronological validation gates pass.
- Challenger weights, snapshots, state, initialization, training, promotion and prediction logic were not changed.

Verification: `PYTHONPATH=. pytest -q` — 358 passed, 24 subtests passed; `python -m compileall -q app tests` — passed.
See `AUDIT_1.0.286_FULL_SOURCE_AND_MATH.md` for findings and runtime evidence.
