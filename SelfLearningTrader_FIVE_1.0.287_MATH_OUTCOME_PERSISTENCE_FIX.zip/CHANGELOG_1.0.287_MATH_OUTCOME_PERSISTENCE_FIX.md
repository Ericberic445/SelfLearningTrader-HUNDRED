# SelfLearningTrader FIVE 1.0.287 — Math outcome persistence fix

- Fixed math expert and ensemble history rows being written only once while outcomes were still pending. Existing rows now receive later resolved expert, baseline, candidate-ensemble, and active-ensemble outcomes by prediction ID.
- Preserved prediction-time expert scores and candidate signatures; only outcome fields are refreshed. A resolved non-negative outcome is never replaced by a later pending/missing `-1`.
- Prevented duplicate cumulative math-expert statistics when an already resolved outcome is seen again.
- Added a regression test for pending-to-resolved updates and stable candidate signatures.
- No UI changes. Challenger code/state untouched. Selector thresholds and promotion gates unchanged; no expert/ensemble is force-activated.

Validation: `python -m compileall -q app`; full test suite: 358 passed, 24 subtests passed. No APK build or on-device/KuCoin test performed.
