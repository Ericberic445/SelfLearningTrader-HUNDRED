from pathlib import Path
from core.engine import LearningEngine


def test_engine_read_json_honors_dict_default_for_missing_or_invalid_file(tmp_path):
    engine = LearningEngine.__new__(LearningEngine)
    missing = tmp_path / 'missing.json'
    assert engine._read_json(missing, {}) == {}
    broken = tmp_path / 'broken.json'
    broken.write_text('{not-json', encoding='utf-8')
    assert engine._read_json(broken, {}) == {}
    assert engine._read_json(missing) == []


def test_engine_read_json_accepts_string_path_and_explicit_list_default(tmp_path):
    engine = LearningEngine.__new__(LearningEngine)
    missing = tmp_path / 'missing-list.json'
    assert engine._read_json(str(missing), ['safe']) == ['safe']
    missing.write_text('[1, 2]', encoding='utf-8')
    assert engine._read_json(str(missing), {}) == [1, 2]



def test_engine_write_json_serializes_nested_numpy_values_atomically(tmp_path):
    import json
    import numpy as np

    engine = LearningEngine.__new__(LearningEngine)
    target = tmp_path / 'predictions.json'
    payload = {
        'features': {'vector': np.asarray([1.25, 2.5], dtype=np.float32)},
        'probability': np.float64(0.875),
        'count': np.int64(3),
    }

    engine._write_json(target, [payload])

    saved = json.loads(target.read_text(encoding='utf-8'))
    assert saved[0]['features']['vector'] == [1.25, 2.5]
    assert saved[0]['probability'] == 0.875
    assert saved[0]['count'] == 3
    assert not target.with_suffix('.json.tmp').exists()


def test_engine_append_json_keeps_all_top5_rows_when_one_has_numpy_diagnostics(tmp_path):
    import json
    import numpy as np

    engine = LearningEngine.__new__(LearningEngine)
    target = tmp_path / 'contract_predictions.json'
    engine._append_json(target, {'id': 'forecast-1', 'prediction': 'LONG',
                                 'diagnostics': {'vector': np.asarray([0.1, 0.9])}})
    engine._append_json(target, {'id': 'forecast-2', 'prediction': 'SHORT',
                                 'diagnostics': {'score': np.float32(0.7)}})

    saved = json.loads(target.read_text(encoding='utf-8'))
    assert [row['id'] for row in saved] == ['forecast-1', 'forecast-2']
    assert saved[0]['diagnostics']['vector'] == [0.1, 0.9]
    assert saved[1]['diagnostics']['score'] == float(np.float32(0.7))
