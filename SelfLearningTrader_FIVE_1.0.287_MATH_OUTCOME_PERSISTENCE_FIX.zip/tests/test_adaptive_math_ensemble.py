import sys
from pathlib import Path

APP_DIR = Path(__file__).resolve().parents[1] / 'app'
if str(APP_DIR) not in sys.path:
    sys.path.insert(0, str(APP_DIR))

from core.model import ModelManager, MATH_LENS_FORMULAS, MATH_TIMEFRAMES


def test_every_directional_formula_in_all_three_lenses_expands_over_all_timeframes():
    by_tf = {}
    for tf in MATH_TIMEFRAMES:
        snap = {
            'math_markov': 0.7, 'math_hurst': 0.8, 'math_wavelet': 0.5,
            'math_ar': 0.6, 'math_arima': -0.4, 'math_sarima': 0.3,
            'math_mean_reversion': -0.2, 'math_cointegration': 0.4,
            'math_correlation': 0.5, 'math_trend_deviation': -0.3,
            'math_bayesian': 0.7, 'math_kalman': 0.2,
            'math_direction': 0.55, 'math_monte_carlo': 0.7,
            'math_ptp1': 0.8, 'math_ptp2': 0.7, 'math_ptp3': 0.6,
            'math_psl': 0.2, 'math_trend_direction': 0.8,
            'math_benchmark_direction': 0.6, 'math_target_sign': 1.0,
        }
        by_tf[tf] = snap
    candidates = ModelManager._individual_math_expert_predictions({'_by_timeframe': by_tf})
    expected = sum(len(v) for v in MATH_LENS_FORMULAS.values()) * len(MATH_TIMEFRAMES)
    assert len(candidates) == expected
    assert any(k.startswith('C1|MARKOV|') for k in candidates)
    assert any(k.startswith('C2|ARIMA_111|') for k in candidates)
    assert any(k.startswith('C3|TP1_PROBABILITY|') for k in candidates)
    assert candidates['C2|ARIMA_111|1h']['prediction'] == 'SHORT'
    assert candidates['C3|SL_PROBABILITY|4h']['score'] > 0


def test_ensemble_selector_can_select_any_number_of_independently_validated_formulas():
    rows = []
    names = [f'C{i%3+1}|FORMULA_{i}|{tf}' for i, tf in enumerate(
        ('5m','15m','1h','4h','1d','15m','1h','4h','1d'), 1)]
    for i in range(180):
        actual = 'LONG' if i % 2 == 0 else 'SHORT'
        sign = 1.0 if actual == 'LONG' else -1.0
        experts = {name: {'score': 0.7 * sign, 'prediction': actual,
                          'outcome_score': 3, 'resolved': True}
                   for name in names}
        rows.append({'prediction_id': str(i), 'time': i + 1,
                     'baseline_prediction': 'SHORT' if actual == 'LONG' else 'LONG',
                     'baseline_outcome_score': 0, 'candidate_experts': list(names),
                     'candidate_ensemble_outcome_score': 3,
                     'actual_direction': actual, 'experts': experts})
    state = ModelManager._evaluate_math_ensemble_selector(rows)
    assert state['status'] == 'validated'
    assert state['candidate_combo_validation_rows'] == 30
    assert len(state['candidate_experts']) == len(names)
    assert len(state['selected_experts']) == len(names)
    assert state['selected_count'] > 3
    assert set(state['selected_experts']) == set(names)


def test_ensemble_selector_requires_individual_plan_outcomes():
    rows = []
    for i in range(100):
        actual = 'LONG' if i % 2 == 0 else 'SHORT'
        sign = 1.0 if actual == 'LONG' else -1.0
        rows.append({'prediction_id': str(i), 'time': i + 1,
                     'baseline_prediction': 'SHORT' if actual == 'LONG' else 'LONG',
                     'baseline_outcome_score': 0, 'actual_direction': actual,
                     'experts': {'C1|MARKOV|5m': {'score': 0.9 * sign,
                                                  'prediction': actual}}})
    state = ModelManager._evaluate_math_ensemble_selector(rows)
    assert state['status'] == 'no_ensemble_passed'
    assert state['selected_experts'] == []


def test_ensemble_selector_stays_inactive_without_temporal_validation_rows():
    rows = [{'time': i, 'actual_direction': 'LONG', 'baseline_prediction': 'LONG',
             'baseline_outcome_score': 1, 'experts': {'C1|MARKOV|5m': {'score': 0.8, 'outcome_score': 1}}} for i in range(79)]
    state = ModelManager._evaluate_math_ensemble_selector(rows)
    assert state['status'] == 'collecting'
    assert state['selected_experts'] == []


def test_shadow_candidate_is_not_live_until_exact_combo_outcomes_validate():
    manager = ModelManager.__new__(ModelManager)
    manager._math_ensemble_selector_cache = {
        'status': 'shadow_candidate',
        'candidate_experts': ['C1|MARKOV|5m', 'C2|AR|1h', 'C3|KALMAN|4h'],
        'selected_experts': [],
        'contextual_ensembles': {},
    }
    assert manager.candidate_math_ensemble('TREND_UP|MID') == [
        'C1|MARKOV|5m', 'C2|AR|1h', 'C3|KALMAN|4h']
    assert manager.active_math_ensemble('TREND_UP|MID') == []


def test_formula_plan_profile_uses_only_prior_resolved_expert_outcomes_and_context():
    manager = ModelManager.__new__(ModelManager)
    rows = []
    for i in range(40):
        rows.append({
            'time': i + 1,
            'context_key': 'TREND_UP|MID',
            'experts': {
                'C1|MARKOV|1h': {
                    'resolved': True,
                    'outcome_score': 2 if i % 4 else 0,
                    'mfe_atr': 2.0 + (i % 5) * 0.1,
                    'mae_atr': 0.5 + (i % 3) * 0.1,
                }
            },
        })
    manager._load_lens_performance = lambda: {'math_expert_rows': rows}
    profile = manager.math_expert_plan_profile('C1|MARKOV|1h', 'TREND_UP|MID')
    assert profile['status'] == 'validated'
    assert profile['source'] == 'context'
    assert profile['n'] == 40
    assert 0.25 <= profile['sl'] <= 4.0
    assert profile['tp1'] < profile['tp2'] < profile['tp3']


def test_formula_plan_profile_stays_cold_without_enough_resolved_master_samples():
    manager = ModelManager.__new__(ModelManager)
    manager._load_lens_performance = lambda: {'math_expert_rows': [
        {'time': i, 'experts': {'C2|AR|4h': {'resolved': True, 'outcome_score': 1,
         'mfe_atr': 1.8, 'mae_atr': 0.7}}} for i in range(29)
    ]}
    profile = manager.math_expert_plan_profile('C2|AR|4h')
    assert profile['status'] == 'collecting'
    assert profile['n'] == 29


def test_invalid_timeframe_snapshot_is_not_counted_as_a_live_formula_expert():
    by_tf = {}
    for tf in MATH_TIMEFRAMES:
        by_tf[tf] = {
            'math_markov': 0.7, 'math_hurst': 0.8, 'math_wavelet': 0.5,
            'math_ar': 0.6, 'math_arima': -0.4, 'math_sarima': 0.3,
            'math_mean_reversion': -0.2, 'math_cointegration': 0.4,
            'math_correlation': 0.5, 'math_trend_deviation': -0.3,
            'math_bayesian': 0.7, 'math_kalman': 0.2,
            'math_direction': 0.55, 'math_monte_carlo': 0.7,
            'math_ptp1': 0.8, 'math_ptp2': 0.7, 'math_ptp3': 0.6,
            'math_psl': 0.2, 'math_trend_direction': 0.8,
            'math_benchmark_direction': 0.6, 'math_target_sign': 1.0,
            '_math_data_quality': {'status': 'ready'},
        }
    by_tf['1h']['_math_data_quality'] = {
        'status': 'insufficient_contiguous_candles', 'contiguous_rows': 9}
    candidates = ModelManager._individual_math_expert_predictions({'_by_timeframe': by_tf})
    per_tf = sum(len(v) for v in MATH_LENS_FORMULAS.values())
    assert len(candidates) == per_tf * 4
    assert not any(key.endswith('|1h') for key in candidates)


def test_diagnostics_merge_does_not_overwrite_the_full_mtf_candidate_map():
    from core.engine import LearningEngine
    candidates = {f'C1|FORMULA_{i}|{tf}': {'score': .2, 'prediction': 'LONG'}
                  for i, tf in enumerate(MATH_TIMEFRAMES)}
    candidates.update({f'C2|FORMULA_{i}|{tf}': {'score': -.2, 'prediction': 'SHORT'}
                       for i, tf in enumerate(MATH_TIMEFRAMES)})
    legacy = {f'LEGACY_{i}': {'score': .1, 'prediction': 'LONG'} for i in range(15)}
    item = {'prediction': 'WAIT'}
    LearningEngine._apply_math_expert_candidates(item, {'math_expert_predictions': legacy}, candidates)
    assert item['prediction'] == 'WAIT'
    assert item['math_expert_predictions'] == candidates
    assert item['math_expert_candidate_count'] == 10


def test_wait_forecast_can_add_independent_formula_and_ensemble_training_rows(tmp_path):
    import json
    from core.engine import LearningEngine

    class FakeMM:
        def __init__(self):
            self.lens_performance = tmp_path / 'master_lens_performance.json'
            self.saved = None
        def _load_lens_performance(self):
            if self.saved is not None:
                return self.saved
            return {'actors': {}, 'math_experts': {}, 'math_expert_rows': [], 'math_ensemble_rows': []}
        def refresh_math_expert_selector(self, performance):
            performance['math_expert_selector'] = {'status': 'collecting'}
        def _write_json(self, path, data):
            self.saved = data
            Path(path).write_text(json.dumps(data), encoding='utf-8')
        def update_learning_state(self, **kwargs):
            return None

    engine = LearningEngine.__new__(LearningEngine)
    engine.cfg = {}
    engine.data = tmp_path
    engine.mm = FakeMM()
    engine._resolved_learning_rows = lambda: []
    engine._count_resolved_logs = lambda: 0
    engine._append_learning_audit = lambda *args, **kwargs: None
    engine._read_json = lambda path: json.loads(Path(path).read_text()) if Path(path).exists() else {}
    engine._write_json = lambda path, data: Path(path).write_text(json.dumps(data), encoding='utf-8')
    engine._load_exp = lambda: None

    item = {
        'id': 'wait-forecast-1', 'contract': 'AAAUSDTM', 'time': 100,
        'resolved': True, 'wait_learning_resolved': True, 'wait_learning_target': 2,
        'math_expert_training_eligible': True,
        'math_expert_baseline_prediction': 'WAIT',
        'math_expert_baseline_shadow_direction': 'SHORT',
        'market_regime': {'label': 'TRANSITION'}, 'math_features': {'math_garch': .5},
        'math_expert_predictions': {
            'C1|MARKOV|5m': {'score': .7, 'prediction': 'LONG', 'lens': 'C1', 'formula': 'MARKOV', 'timeframe': '5m'},
            'C2|AR|1h': {'score': .5, 'prediction': 'LONG', 'lens': 'C2', 'formula': 'AR', 'timeframe': '1h'},
        },
        'math_expert_plans': {},
        'math_expert_outcomes': {
            'MASTER_BASELINE': {'result': 'SL', 'outcome_score': 0},
            'C1|MARKOV|5m': {'result': 'WAITING', 'outcome_score': -1,
                             'observation_complete': True, 'mfe_atr': 1.1, 'mae_atr': .7, 'bars_observed': 48},
            'C2|AR|1h': {'result': 'TP1', 'outcome_score': 1,
                         'observation_complete': True, 'tp1_hit': True, 'mfe_atr': 2.0, 'mae_atr': .4, 'bars_observed': 20},
        },
        'math_ensemble_candidate_experts': ['C1|MARKOV|5m', 'C2|AR|1h'], 'math_ensemble_selected_experts': [],
        'math_ensemble_outcome': {'result': 'WAITING', 'outcome_score': -1},
    }
    engine._append_experience([item])
    saved = engine.mm.saved
    assert saved is not None
    assert len(saved['math_expert_rows']) == 1
    row = saved['math_expert_rows'][0]
    assert row['actual_direction'] == 'LONG'
    assert row['experts']['C1|MARKOV|5m']['resolved'] is True
    assert row['experts']['C1|MARKOV|5m']['outcome_score'] == -1
    assert row['experts']['C2|AR|1h']['outcome_score'] == 1
    assert saved['math_ensemble_rows'][0]['actual_direction'] == 'LONG'
    assert saved['math_ensemble_rows'][0]['master_action_prediction'] == 'WAIT'

    # The same prediction is resolved later. Its original candidate signature
    # must remain fixed while pending outcome cells are updated in-place.
    item['math_expert_outcomes']['C1|MARKOV|5m'] = {
        'result': 'TP2', 'outcome_score': 2, 'observation_complete': True,
        'tp1_hit': True, 'tp2_hit': True, 'mfe_atr': 2.2, 'mae_atr': .5, 'bars_observed': 60}
    item['math_ensemble_outcome'] = {'result': 'TP1', 'outcome_score': 1, 'observation_complete': True}
    engine._append_experience([item])
    updated = engine.mm.saved
    assert len(updated['math_expert_rows']) == 1
    assert len(updated['math_ensemble_rows']) == 1
    assert updated['math_expert_rows'][0]['experts']['C1|MARKOV|5m']['outcome_score'] == 2
    assert updated['math_expert_rows'][0]['experts']['C1|MARKOV|5m']['mfe_atr'] == 2.2
    assert updated['math_ensemble_rows'][0]['candidate_ensemble_outcome_score'] == 1
    assert updated['math_ensemble_rows'][0]['candidate_experts'] == ['C1|MARKOV|5m', 'C2|AR|1h']


def test_ensemble_selector_uses_wait_labels_instead_of_discarding_them():
    names = ['C1|MARKOV|5m', 'C2|AR|1h', 'C3|KALMAN|4h']
    rows = []
    for i in range(180):
        if i % 3 == 0:
            actual = 'WAIT'
            score = 0.0
            outcome = -1
        else:
            actual = 'LONG' if i % 2 == 0 else 'SHORT'
            score = 0.8 if actual == 'LONG' else -0.8
            outcome = 3
        experts = {name: {'score': score, 'prediction': actual,
                          'outcome_score': outcome, 'resolved': True}
                   for name in names}
        rows.append({'prediction_id': str(i), 'time': i + 1,
                     'baseline_prediction': ('SHORT' if actual == 'LONG' else 'LONG') if actual != 'WAIT' else 'SHORT',
                     'baseline_outcome_score': 0, 'candidate_experts': list(names),
                     'candidate_ensemble_outcome_score': outcome if outcome >= 0 else -1,
                     'actual_direction': actual, 'experts': experts})
    state = ModelManager._evaluate_math_ensemble_selector(rows)
    assert state['rows'] == 180
    assert state['status'] == 'validated'
    assert set(state['selected_experts']) == set(names)
    assert state['validation_coverage'] > 0.60


def test_master_dynamically_selects_any_individually_validated_formula_and_can_select_none():
    manager = ModelManager.__new__(ModelManager)
    manager._math_expert_selector_cache = {
        'status': 'validated',
        'experts': {
            'C1|MARKOV|5m': {'status': 'validated', 'validation_lift': 0.10},
            'C2|AR|1h': {'status': 'validated', 'validation_lift': 0.05},
            'C3|KALMAN_TREND|4h': {'status': 'validated', 'validation_lift': 0.08},
            'C1|UNVALIDATED|1d': {'status': 'rejected_validation', 'validation_lift': 0.20},
        },
        'contextual_experts': {},
    }
    manager._math_ensemble_selector_cache = {}
    selected = manager.select_master_math_advisors('TREND_UP|MID', {
        'C1|MARKOV|5m': {'score': 0.7, 'prediction': 'LONG'},
        'C2|AR|1h': {'score': -0.6, 'prediction': 'SHORT'},
        'C3|KALMAN_TREND|4h': {'score': 0.01, 'prediction': 'WAIT'},
        'C1|UNVALIDATED|1d': {'score': 0.9, 'prediction': 'LONG'},
    })
    assert selected['selected_experts'] == ['C1|MARKOV|5m', 'C2|AR|1h']
    assert selected['selected_count'] == 2
    assert selected['eligible_count'] == 3
    assert selected['advice_strength'] == 0.0  # live path consumes per-formula advisers, not aggregate strength
    assert len(selected['advisors']) == 2
    assert selected['advisors'][0]['name'] == 'C1|MARKOV|5m'
    assert selected['advisors'][1]['name'] == 'C2|AR|1h'

    ignored = manager.select_master_math_advisors('TREND_UP|MID', {
        'C1|MARKOV|5m': {'score': 0.01, 'prediction': 'WAIT'},
        'C2|AR|1h': {'score': 0.02, 'prediction': 'WAIT'},
    })
    assert ignored['selected_experts'] == []
    assert ignored['advice_score'] == 0.0
    assert ignored['advice_strength'] == 0.0
    assert ignored['advisors'] == []


def test_contextual_formula_rejection_overrides_global_formula_pass():
    manager = ModelManager.__new__(ModelManager)
    manager._math_expert_selector_cache = {
        'status': 'validated',
        'experts': {'C1|MARKOV|5m': {'status': 'validated', 'validation_lift': 0.10}},
        'contextual_experts': {
            'RANGE|HIGH': {'rows': 90, 'experts': {
                'C1|MARKOV|5m': {'status': 'rejected_validation', 'validation_lift': -0.02}}}
        },
    }
    manager._math_ensemble_selector_cache = {}
    result = manager.select_master_math_advisors('RANGE|HIGH', {
        'C1|MARKOV|5m': {'score': 0.8, 'prediction': 'LONG'}
    })
    assert result['selected_experts'] == []
    assert result['advice_strength'] == 0.0


def test_opposing_formula_advisers_are_evaluated_individually_without_consensus_veto():
    manager = ModelManager.__new__(ModelManager)
    manager._math_expert_selector_cache = {
        'status': 'validated',
        'experts': {
            'C1|MARKOV|5m': {'status': 'validated', 'validation_lift': 0.08},
            'C2|AR|1h': {'status': 'validated', 'validation_lift': 0.08},
        },
        'contextual_experts': {},
    }
    manager._math_ensemble_selector_cache = {}
    result = manager.select_master_math_advisors('TREND_UP|MID', {
        'C1|MARKOV|5m': {'score': 0.8, 'prediction': 'LONG'},
        'C2|AR|1h': {'score': -0.8, 'prediction': 'SHORT'},
    })
    assert result['considered_experts'] == ['C1|MARKOV|5m', 'C2|AR|1h']
    assert result['selected_experts'] == ['C1|MARKOV|5m', 'C2|AR|1h']
    assert result['status'] == 'individual_advisers_active'
    assert [x['prediction'] for x in result['advisors']] == ['LONG', 'SHORT']
    assert all(x['advice_strength'] > 0 for x in result['advisors'])
    assert result['advice_score'] == 0.0
    assert result['advice_strength'] == 0.0


def test_legacy_5m_formula_history_is_migrated_without_inventing_other_timeframes(tmp_path):
    import json

    manager = ModelManager(tmp_path, config={})
    manager.lens_performance.parent.mkdir(parents=True, exist_ok=True)
    manager._write_json(manager.lens_performance, {
        'actors': {}, 'combinations': {},
        'math_expert_rows': [{
            'prediction_id': 'legacy-1', 'time': 1, 'baseline_outcome_score': 1,
            'experts': {
                'MARKOV': {'prediction': 'LONG', 'score': 0.7, 'outcome_score': 2, 'resolved': True},
                'MATH_CONSENSUS_BASELINE': {'prediction': 'LONG', 'score': 0.2, 'outcome_score': 1, 'resolved': True},
            },
        }],
    })
    loaded = manager._load_lens_performance()
    experts = loaded['math_expert_rows'][0]['experts']
    assert experts['MARKOV']['outcome_score'] == 2
    assert experts['C1|MARKOV|5m']['outcome_score'] == 2
    assert experts['C1|MARKOV|5m']['legacy_source_key'] == 'MARKOV'
    assert 'C1|MARKOV|15m' not in experts
    assert 'C1|MARKOV|1h' not in experts
    assert 'MATH_CONSENSUS_BASELINE' in experts
    assert loaded['math_expert_formula_key_schema'] == 2
