from unittest.mock import patch

from app.core.engine import LearningEngine


class FakeExchange:
    symbol_count = 12
    def __init__(self, symbol='XBTUSDTM', timeout=25):
        self.futures_symbol = symbol
        self.timeout = timeout
        self._request_gap = 0.2

    def set_symbol(self, symbol):
        self.futures_symbol = str(symbol).upper().replace('-', '')

    def all_tickers(self):
        return [{'symbol': f'COIN{i}USDTM', 'price': 100.0} for i in range(self.symbol_count)]

    def active_symbols(self):
        return [{'contract': f'COIN{i}USDTM', 'display': f'COIN{i}-USDT', 'turnover': 1_000_000 + i}
                for i in range(self.symbol_count)]


class WorkerEngine:
    instances = []
    confidence = 0.90

    def __init__(self, root, exchange, config, **kwargs):
        self.root = root
        self.exchange = exchange
        self.cfg = config
        self.init_options = kwargs
        type(self).instances.append(self)

    def _quick_candidate(self, item):
        self.exchange.set_symbol(item['contract'])
        return {'contract': item['contract'], 'symbol': item['display'], 'price': 100.0,
                'quick_score': 0.8, 'quality': 0.9, 'turnover24h': item['turnover']}

    def _scan_train_and_predict(self, item, scan_history=800, run_id=None):
        self.exchange.set_symbol(item['contract'])
        return {'contract': item['contract'], 'exchange_symbol': item['contract'],
                'symbol': item['display'], 'prediction': 'LONG', 'prediction_probability': self.confidence, 'price': 100.0,
                'edge_score': 0.8, 'quality': 0.9, 'turnover24h': item['turnover'],
                'features': {}, 'run_id': run_id}


def test_full_scan_reuses_quick_engine_but_isolates_model_engine_per_symbol(tmp_path):
    WorkerEngine.instances = []
    engine = LearningEngine.__new__(LearningEngine)
    engine.root = tmp_path
    engine.cfg = {'scan_workers': 4, 'scan_model_workers': 2,
                  'scan_deep_candidates': 8, 'scan_second_stage_candidates': 5,
                  'history_limit': 1200, 'scan_request_gap': 0.2, 'scan_model_request_gap': 0.2}
    engine.exchange = FakeExchange()
    engine._stage25_validate = lambda rows, progress=None, cancel_event=None: list(rows)
    engine._persist_scan_prediction = lambda row: None
    engine.readiness = lambda: {'ready': False}

    with patch('app.core.exchange.KuCoin', FakeExchange), patch('app.core.engine.LearningEngine', WorkerEngine):
        rows, total, quick_ok, errors, diag = engine.scan_all()

    assert total == 12
    assert quick_ok == 12
    assert errors == 0
    assert len(rows) == 5
    # Quick scan reuses a worker engine, while each MODEL candidate gets an
    # isolated engine; MODEL workers skip the already-completed global ledger scan.
    assert 11 <= len(WorkerEngine.instances) <= 16
    assert diag['timings_seconds']['total'] >= 0


def test_scan_pipeline_scales_to_700_symbols_and_still_returns_top5(tmp_path):
    class Exchange700(FakeExchange):
        symbol_count = 700
    WorkerEngine.instances = []
    engine = LearningEngine.__new__(LearningEngine)
    engine.root = tmp_path
    engine.cfg = {'scan_workers': 4, 'scan_model_workers': 2,
                  'scan_deep_candidates': 50, 'scan_second_stage_candidates': 25,
                  'history_limit': 1200, 'scan_request_gap': 0.2, 'scan_model_request_gap': 0.2}
    engine.exchange = Exchange700()
    engine._stage25_validate = lambda rows, progress=None, cancel_event=None: list(rows)
    engine._persist_scan_prediction = lambda row: None
    engine.readiness = lambda: {'ready': False}
    with patch('app.core.exchange.KuCoin', Exchange700), patch('app.core.engine.LearningEngine', WorkerEngine):
        rows, total, quick_ok, errors, diag = engine.scan_all()
    assert total == 700
    assert quick_ok == 700
    assert errors == 0
    assert len(rows) == 5
    assert len({r['contract'] for r in rows}) == 5
    assert diag['deep_candidates'] == 50
    assert diag['model_candidates_processed'] == 50
    assert diag['early_stop_target'] == 50
    assert diag['early_stop_confidence'] == 0.90
    assert diag['early_stop_qualified_count'] == 50
    assert diag['early_stop_reached'] is True
    assert diag['second_stage_candidates'] == 25
    # The quick pass ranks the full market; only its top 50 candidates enter
    # the expensive Master pass before the existing 25 -> TOP-5 stages.
    assert 50 <= len(WorkerEngine.instances) <= 55
    assert all(instance.init_options.get('initialize_ledgers') is False for instance in WorkerEngine.instances)
    assert diag['timings_seconds']['total'] >= 0


def test_model_stage_timeout_returns_partial_scan_instead_of_waiting_forever(tmp_path):
    import time

    class SlowWorkerEngine(WorkerEngine):
        def _scan_train_and_predict(self, item, scan_history=800, run_id=None):
            time.sleep(2.0)
            return super()._scan_train_and_predict(item, scan_history, run_id)

    class Exchange12(FakeExchange):
        symbol_count = 12

    engine = LearningEngine.__new__(LearningEngine)
    engine.root = tmp_path
    engine.cfg = {'scan_workers': 4, 'scan_model_workers': 2,
                  'scan_deep_candidates': 8, 'scan_second_stage_candidates': 5,
                  'scan_model_stage_timeout_seconds': 1,
                  'history_limit': 1200, 'scan_request_gap': 0.2, 'scan_model_request_gap': 0.2}
    engine.exchange = Exchange12()
    engine._stage25_validate = lambda rows, progress=None, cancel_event=None: list(rows)
    engine._persist_scan_prediction = lambda row: None
    engine.readiness = lambda: {'ready': False}

    started = time.monotonic()
    with patch('app.core.exchange.KuCoin', Exchange12), patch('app.core.engine.LearningEngine', SlowWorkerEngine):
        rows, total, quick_ok, errors, diag = engine.scan_all()
    elapsed = time.monotonic() - started

    assert total == 12
    assert quick_ok == 12
    assert elapsed < 1.8
    assert diag['model_stage_timed_out'] is True
    assert diag['model_stage_timeout_seconds'] == 1
    assert diag['breakdown']['Модель'] >= 2
    assert errors >= 2


def test_user_cancel_does_not_wait_for_a_slow_model_worker(tmp_path):
    import threading
    import time

    entered = threading.Event()
    cancel_event = threading.Event()

    class SlowWorkerEngine(WorkerEngine):
        def _scan_train_and_predict(self, item, scan_history=800, run_id=None):
            entered.set()
            time.sleep(3.0)
            return super()._scan_train_and_predict(item, scan_history, run_id)

    class Exchange12(FakeExchange):
        symbol_count = 12

    engine = LearningEngine.__new__(LearningEngine)
    engine.root = tmp_path
    engine.cfg = {'scan_workers': 4, 'scan_model_workers': 2,
                  'scan_deep_candidates': 8, 'scan_second_stage_candidates': 5,
                  'scan_model_stage_timeout_seconds': 30,
                  'history_limit': 1200, 'scan_request_gap': 0.2, 'scan_model_request_gap': 0.2}
    engine.exchange = Exchange12()
    engine._stage25_validate = lambda rows, progress=None, cancel_event=None: list(rows)
    engine._persist_scan_prediction = lambda row: None
    engine.readiness = lambda: {'ready': False}

    def request_cancel():
        if entered.wait(3.0):
            time.sleep(0.1)
            cancel_event.set()
    threading.Thread(target=request_cancel, daemon=True).start()

    started = time.monotonic()
    with patch('app.core.exchange.KuCoin', Exchange12), patch('app.core.engine.LearningEngine', SlowWorkerEngine):
        rows, total, quick_ok, errors, diag = engine.scan_all(cancel_event=cancel_event)
    elapsed = time.monotonic() - started

    assert elapsed < 1.8
    assert diag.get('cancelled') is True


def test_full_scan_publishes_master_top5_without_waiting_for_math_deadline(tmp_path):
    WorkerEngine.instances = []
    engine = LearningEngine.__new__(LearningEngine)
    engine.root = tmp_path
    engine.cfg = {'scan_workers': 4, 'scan_model_workers': 2,
                  'scan_deep_candidates': 8, 'scan_second_stage_candidates': 5,
                  'history_limit': 1200, 'scan_request_gap': 0.2, 'scan_model_request_gap': 0.2}
    engine.exchange = FakeExchange()
    def forbidden_math_call(*args, **kwargs):
        raise AssertionError('math stage must not run on the TOP-5 scan path')
    engine._stage25_validate = forbidden_math_call
    engine._last_stage25_timed_out = True
    engine._persist_scan_prediction = lambda row: None
    engine.readiness = lambda: {'ready': False}
    with patch('app.core.exchange.KuCoin', FakeExchange), patch('app.core.engine.LearningEngine', WorkerEngine):
        rows, total, quick_ok, errors, diag = engine.scan_all()
    assert len(rows) == 5
    assert all(row['prediction'] == 'LONG' for row in rows)
    assert diag.get('math_stage_timed_out') is False
    assert len(engine._pending_math_shadow_candidates) == 8


def test_math_shadow_worker_persists_formula_observations_without_overwriting_master(tmp_path):
    import json
    import time

    engine=LearningEngine.__new__(LearningEngine)
    engine.data=tmp_path/'data'; engine.data.mkdir()
    engine.logs=tmp_path/'logs'; engine.logs.mkdir()
    engine.cfg={}
    engine._log=lambda message: None
    row={'id':'forecast-1','contract':'AAAUSDTM','exchange_symbol':'AAAUSDTM',
         'prediction':'LONG','p_long':0.8,'entry':100.0,'sl':98.0,'tp1':102.0,
         'math_expert_predictions':{'C1|FORMULA|5m':{'prediction':'SHORT'}},
         'math_expert_plans':{'C1|FORMULA|5m':{'prediction':'SHORT','entry':100.0}},
         'math_converged':True}
    pred_path=engine.logs/'AAAUSDTM_predictions.json'
    pending_path=engine.logs/'AAAUSDTM_pending.json'
    pred_path.write_text(json.dumps([{'id':'forecast-1','prediction':'LONG','entry':100.0}]),encoding='utf-8')
    pending_path.write_text(json.dumps([{'id':'forecast-1','prediction':'LONG','entry':100.0}]),encoding='utf-8')
    engine._pending_math_shadow_candidates=[dict(row)]
    engine._pending_math_shadow_cycle=7
    engine._last_issued_top5=[{'id':'forecast-1'}]
    engine._stage25_validate=lambda rows,progress=None,cancel_event=None:[dict(row)]
    assert engine.start_math_shadow_worker()['status']=='started'
    worker_thread=engine._math_shadow_thread
    worker_thread.join(timeout=5)
    assert not worker_thread.is_alive()
    saved=json.loads((engine.data/'math_shadow_observations.json').read_text(encoding='utf-8'))
    assert saved['observations'][0]['run_id']==7
    assert saved['observations'][0]['math_expert_predictions']['C1|FORMULA|5m']['prediction']=='SHORT'
    # Formula direction and levels are shadow data; the issued Master forecast is immutable.
    persisted=json.loads(pred_path.read_text(encoding='utf-8'))[0]
    assert persisted['prediction']=='LONG'
    assert persisted['entry']==100.0
    assert persisted['math_expert_predictions']['C1|FORMULA|5m']['prediction']=='SHORT'



def test_math_shadow_worker_queues_later_cycles_without_dropping_them(tmp_path):
    import json
    import time
    from threading import Event

    engine=LearningEngine.__new__(LearningEngine)
    engine.data=tmp_path/'data'; engine.data.mkdir()
    engine.logs=tmp_path/'logs'; engine.logs.mkdir()
    engine.cfg={}
    engine._log=lambda message: None
    first_started=Event(); release_first=Event()
    def validate(rows,progress=None,cancel_event=None):
        if rows[0]['id']=='forecast-a':
            first_started.set()
            assert release_first.wait(3)
        return [dict(row, math_expert_predictions={'C1|F|5m':{'prediction':'LONG'}}) for row in rows]
    engine._stage25_validate=validate
    engine._pending_math_shadow_candidates=[{'id':'forecast-a','contract':'AAAUSDTM','prediction':'LONG'}]
    engine._pending_math_shadow_cycle=1
    engine._last_issued_top5=[{'id':'forecast-a'}]
    assert engine.start_math_shadow_worker()['status']=='started'
    first_thread=engine._math_shadow_thread
    assert first_started.wait(2)
    engine._pending_math_shadow_candidates=[{'id':'forecast-b','contract':'BBBUSDTM','prediction':'SHORT'}]
    engine._pending_math_shadow_cycle=2
    engine._last_issued_top5=[{'id':'forecast-b'}]
    queued=engine.start_math_shadow_worker()
    assert queued['status']=='queued'
    release_first.set()
    first_thread.join(timeout=5)
    assert not first_thread.is_alive()
    saved=json.loads((engine.data/'math_shadow_observations.json').read_text(encoding='utf-8'))
    by_id={row['id']:row for row in saved['observations']}
    assert set(by_id)=={'forecast-a','forecast-b'}
    assert by_id['forecast-a']['run_id']==1
    assert by_id['forecast-b']['run_id']==2


def test_math_shadow_observations_resolve_independently_and_feed_formula_validation(tmp_path):
    import json
    import numpy as np
    from types import SimpleNamespace

    class ShadowExchange:
        def set_symbol(self, contract):
            self.contract = contract
        def candles(self, timeframe, limit):
            assert timeframe == '5min'
            return {'time': np.asarray([1_000_300, 1_000_600, 1_000_900, 1_001_200]),
                    'high': np.asarray([102.0, 102.0, 102.0, 102.0]),
                    'low': np.asarray([99.0, 99.0, 99.0, 99.0])}

    class ShadowModel:
        def __init__(self):
            self.performance = {'math_expert_rows': []}
            self.lens_performance = tmp_path/'lens_performance.json'
        def _load_lens_performance(self):
            return self.performance
        def refresh_math_expert_selector(self, performance):
            performance['math_expert_selector'] = {'status': 'collecting'}
        def _write_json(self, path, value):
            pass

    engine = LearningEngine.__new__(LearningEngine)
    engine.data = tmp_path/'data'; engine.data.mkdir()
    engine.cfg = {'max_forecast_lifetime_bars': 4, 'post_sl_recheck_bars': 1}
    engine.exchange = ShadowExchange()
    engine.mm = ShadowModel()
    engine._log = lambda message: None
    engine.set_symbol = lambda contract: engine.exchange.set_symbol(contract)
    def resolve(item, highs, lows, recheck_bars=3):
        item['math_expert_outcomes'] = {
            name: {'result': 'TP1', 'outcome_score': 1, 'observation_complete': True,
                   'tp1_hit': True, 'bars_observed': len(highs)}
            for name in item['math_expert_plans']}
    engine._resolve_math_shadow_outcomes = resolve
    record = {
        'id': 'shadow-1', 'contract': 'AAAUSDTM', 'time': 1_000_000,
        'status': 'computed_shadow_only', 'outcomes_resolved': False,
        'math_expert_baseline_prediction': 'WAIT',
        'math_expert_baseline_plan_prediction': 'SHORT',
        'math_expert_baseline_plan': {'prediction': 'SHORT', 'entry': 100, 'sl': 98, 'tp1': 102, 'tp2': 103, 'tp3': 104},
        'math_expert_predictions': {'C1|AR|5m': {'prediction': 'LONG', 'score': 0.7, 'lens': 'C1', 'formula': 'AR', 'timeframe': '5m'}},
        'math_expert_plans': {'C1|AR|5m': {'prediction': 'LONG', 'entry': 100, 'sl': 98, 'tp1': 102, 'tp2': 103, 'tp3': 104}},
        'math_expert_context_key': 'TREND_UP|MID',
    }
    path = engine.data/'math_shadow_observations.json'
    path.write_text(json.dumps({'version': 1, 'observations': [record]}), encoding='utf-8')

    result = engine.resolve_math_shadow_observations()

    assert result['resolved'] == 1
    assert result['training_rows_added'] == 1
    assert engine.mm.performance['math_expert_rows'][0]['prediction_id'] == 'shadow-1'
    assert engine.mm.performance['math_expert_rows'][0]['baseline_outcome_score'] == 1
    assert engine.mm.performance['math_expert_rows'][0]['actual_direction'] == 'SHORT'
    assert engine.mm.performance['math_expert_rows'][0]['experts']['C1|AR|5m']['outcome_score'] == 1
    saved = json.loads(path.read_text(encoding='utf-8'))['observations'][0]
    assert saved['outcomes_resolved'] is True
    assert saved['status'] == 'resolved_shadow_only'


def test_early_stop_falls_back_to_available_candidates_when_50_confident_forecasts_are_not_found(tmp_path):
    class Exchange12(FakeExchange):
        symbol_count = 12
    WorkerEngine.instances = []
    WorkerEngine.confidence = 0.89
    engine = LearningEngine.__new__(LearningEngine)
    engine.root = tmp_path
    engine.cfg = {'scan_workers': 4, 'scan_model_workers': 2,
                  'scan_deep_candidates': 50, 'scan_second_stage_candidates': 25,
                  'history_limit': 1200, 'scan_request_gap': 0.2, 'scan_model_request_gap': 0.2}
    engine.exchange = Exchange12()
    engine._stage25_validate = lambda rows, progress=None, cancel_event=None: list(rows)
    engine._persist_scan_prediction = lambda row: None
    engine.readiness = lambda: {'ready': False}
    with patch('app.core.exchange.KuCoin', Exchange12), patch('app.core.engine.LearningEngine', WorkerEngine):
        rows, total, quick_ok, errors, diag = engine.scan_all()
    WorkerEngine.confidence = 0.90
    assert total == 12 and quick_ok == 12 and errors == 0
    assert len(rows) == 5
    assert diag['early_stop_reached'] is False
    assert diag['early_stop_qualified_count'] == 0
    assert diag['model_candidates_processed'] == 12
    assert diag['second_stage_candidates'] == 12
