import json
from core.config import load


def test_271_migrates_only_legacy_default_wait_threshold(tmp_path):
    legacy=tmp_path/'legacy.json'
    legacy.write_text(json.dumps({'wait_direction_threshold':0.005}),encoding='utf-8')
    cfg=load(legacy)
    assert cfg['wait_direction_threshold']==0.0045
    assert json.loads(legacy.read_text())['wait_direction_threshold']==0.0045

    custom=tmp_path/'custom.json'
    custom.write_text(json.dumps({'wait_direction_threshold':0.006}),encoding='utf-8')
    assert load(custom)['wait_direction_threshold']==0.006
