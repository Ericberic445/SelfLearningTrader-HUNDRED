# SelfLearningTrader FIVE 1.0.285 — confidence early-stop scan and TOP-5 +40m recheck

## Scanner: 50 → 25 → TOP-5
- Preserved the existing 50 → 25 → TOP-5 selection stages and existing ranking criteria.
- The fast market pre-scan still obtains the lightweight 5-minute market data and ranks the full active-symbol universe; it does not calculate Master direction probabilities.
- The expensive Master analysis now consumes candidates in the existing quick-rank order and stops submitting further candidates as soon as 50 LONG/SHORT Master forecasts with `prediction_probability >= 0.90` have completed. Those 50 are passed to the existing 25-candidate stage.
- If fewer than 50 qualifying forecasts exist after all ranked candidates have been processed, the previous all-results fallback remains in place.
- Diagnostics now record model candidates processed, early-stop target, threshold, qualifying count, and whether early stop was reached.

## TOP-5 +40-minute candle check
- Added a delayed check 40 minutes after TOP-5 publication.
- The check refreshes TOP-5 contracts using the original prediction IDs and also includes active unresolved forecasts on those contracts.
- Existing long-running forecasts are included in the same additional background refresh; the existing long-running scheduler and its configured interval are not modified.
- If every actionable forecast from that TOP-5 reaches terminal resolution (including completion of any pending post-SL audit), the next full scan starts immediately. Otherwise unresolved TOP-5 forecasts are moved into the existing long-running states (`LONG_RUNNING_WAITING`, `WAITING_TP2`, or `WAITING_TP3`) without changing their original Entry/SL/TP. The existing hourly full-scan schedule remains in force.
- The new check runs in a background thread and does not block the full-market scan.

## Preserved
- No UI changes.
- No changes to Master training architecture, Challenger, C1, C2, or C3.
- Existing one-hour full-scan cadence remains the fallback schedule.
- Existing active-recheck timing and long-running scheduler are not changed.

## Verification
- `PYTHONPATH=. pytest -q`: 354 passed, 24 subtests passed.
- Python compilation and ZIP integrity checked for this release.
- APK build and live Android/KuCoin execution are not claimed.
