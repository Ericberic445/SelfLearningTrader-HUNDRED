import json
import os
import threading
import time
import traceback
from pathlib import Path

from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.metrics import dp
from kivy.utils import platform
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.uix.spinner import Spinner
from kivy.uix.textinput import TextInput
from kivy.uix.widget import Widget
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.popup import Popup
from kivy.uix.modalview import ModalView
from kivy.graphics import Color, RoundedRectangle


class ExpandedTouchButton(Button):
    """Normal Kivy button: the visible rectangle and the touch target are identical.

    Earlier builds used a larger invisible widget with a smaller canvas drawn
    inside it. On some Android/Kivy layouts that made the apparent button and
    the real touch rectangle feel offset. This version deliberately has one
    coordinate system: what is visible is exactly what receives the touch.
    """
    def __init__(self, **kwargs):
        # Legacy visual_width/visual_height arguments are accepted so older
        # call sites remain compatible, but they no longer create a separate
        # hit rectangle.
        kwargs.pop('visual_width', None)
        kwargs.pop('visual_height', None)
        kwargs.pop('visual_radius', None)
        super().__init__(**kwargs)
        self.background_normal = ''
        self.background_down = ''
        self.background_disabled_normal = ''
        self.background_color = (0, 0, 0, 0)
        self._normal_visual = (0.08, 0.105, 0.13, 1)
        self._pressed_visual = (0.16, 0.22, 0.28, 1)
        with self.canvas.before:
            self._bg_color = Color(*self._normal_visual)
            self._bg_rect = RoundedRectangle(radius=[dp(2)])
        self.bind(pos=self._update_visual, size=self._update_visual, state=self._update_visual)
        Clock.schedule_once(lambda dt: self._update_visual(), 0)

    def set_visual_colors(self, normal, pressed):
        self._normal_visual = normal
        self._pressed_visual = pressed
        self._update_visual()

    def _update_visual(self, *_):
        self._bg_rect.pos = self.pos
        self._bg_rect.size = self.size
        self._bg_color.rgba = self._pressed_visual if self.state == 'down' else self._normal_visual


# Kept as an alias for compatibility with older code/docs.
TouchArea = None

from core.calculator import calculate_position
from core.backup import export_backup, list_backups, restore_backup, verify_backup_source, verify_all_backups
from core.config import load
from core.engine import LearningEngine
from core.exchange import KuCoin


class UI(BoxLayout):
    def __init__(self, engine, **kw):
        super().__init__(orientation='vertical', padding=(dp(12), dp(8)), spacing=dp(6), **kw)
        self.engine = engine
        self._last_prediction = None
        self._scan_rows = []
        self._symbols = []
        self._filter_mode = 'all'
        self._detail_open = False
        self._log_open = False
        self._log_lines = []
        self._nav_mode = 'scanner'
        self._scan_running = False
        self._scan_worker_active = False
        self._scan_cancel_event = None
        self._scan_paused = False
        self._auto_scan_started = False
        self._last_top5 = []
        self._manual_wait_id = None
        self._manual_wait_symbol = None
        self._top5_history = []
        self._last_saved_cycle = 0
        self._history_path = Path(App.get_running_app().user_data_dir) / 'top5_history.json' if App.get_running_app() else None
        self._last100_path = Path(App.get_running_app().user_data_dir) / 'top5_last100.json' if App.get_running_app() else None
        self._top5_last100 = []
        self._last100_expanded_index = None
        self._session_path = Path(App.get_running_app().user_data_dir) / 'session_state.json' if App.get_running_app() else None
        self._bg_root = (Path(os.environ.get('ANDROID_PRIVATE', str(App.get_running_app().user_data_dir if App.get_running_app() else Path.home()))) / 'stl_generational_v15_3' / 'runtime')
        self._bg_root.mkdir(parents=True, exist_ok=True)
        self._bg_state_path = self._bg_root / 'background_scan_state.json'
        self._bg_control_path = self._bg_root / 'background_scan_control.json'
        self._bg_lock_path = self._bg_root / 'background_scan.lock'
        self._runtime_log_path = self._bg_root / 'runtime_diagnostics.log' 
        self._manual_request_path = self._bg_root / 'manual_prediction_request.json'
        self._monitor_request_path = self._bg_root / 'prediction_monitor_request.json'
        self._bg_poll_event = None
        self._bg_resume_wait_event = None
        self._bg_stop_requested = False
        self._stop_watchdog_event = None
        self._resume_requested = False
        self._bg_start_retry_event = None
        self._bg_start_attempts = 0
        self._backup_screen_generation = 0
        self._runtime_import_running = False
        self._backup_import_list_running = False
        self._load_top5_history()
        self._restore_session_state()

        self._bg = (0.02, 0.03, 0.04, 1)
        self._panel = (0.055, 0.075, 0.095, 1)
        self._panel2 = (0.08, 0.105, 0.13, 1)
        self._accent = (0.03, 0.55, 1, 1)
        self._green = (0.05, 0.75, 0.38, 1)
        self._red = (0.88, 0.16, 0.16, 1)
        self._text = (0.93, 0.95, 0.98, 1)
        self._muted = (0.62, 0.68, 0.75, 1)
        Window.clearcolor = self._bg

        def style_button(b, accent=False, fs=14):
            normal = self._accent if accent else self._panel2
            pressed = (0.02, 0.34, 0.72, 1) if accent else (0.16, 0.22, 0.28, 1)
            b.color = self._text
            b.font_size = f'{fs}sp'
            if isinstance(b, ExpandedTouchButton):
                b.set_visual_colors(normal, pressed)
            return b

        self.style_button = style_button

        # Dashboard: almost the entire screen is information.  The only
        # persistent action is the small ⋮ button at the bottom-right.
        header = BoxLayout(size_hint_y=None, height=dp(54), spacing=dp(8))
        title_box = BoxLayout(orientation='vertical', spacing=0)
        self.title = Label(text='SelfLearningTrader', font_size='20sp', bold=True,
                           halign='left', valign='middle', color=self._text,
                           size_hint_y=None, height=dp(30))
        self.title.bind(size=lambda o, v: setattr(o, 'text_size', (v[0], None)))
        title_box.add_widget(self.title)
        sub = Label(text='Самообучающаяся модель', font_size='11sp',
                    halign='left', valign='middle', color=self._muted,
                    size_hint_y=None, height=dp(20))
        sub.bind(size=lambda o, v: setattr(o, 'text_size', (v[0], None)))
        title_box.add_widget(sub)
        header.add_widget(title_box)
        self.refresh_btn = style_button(ExpandedTouchButton(text='ОБНОВИТЬ', size_hint_x=None, width=dp(82), height=dp(44)), fs=10)
        self.refresh_btn.bind(on_release=self.refresh_view)
        header.add_widget(self.refresh_btn)
        self.bg_chip = Label(text='● В фоне\nРаботает', font_size='11sp',
                             halign='center', valign='middle', color=self._green,
                             size_hint_x=None, width=dp(86))
        self.bg_chip.bind(size=lambda o, v: setattr(o, 'text_size', v))
        header.add_widget(self.bg_chip)
        self.add_widget(header)

        def panel(height=None, orientation='vertical', pad=8, spacing=4):
            # Kivy NumericProperty values (including BoxLayout.height) cannot be None.
            # The cycle card intentionally has dynamic height, so omit the height
            # argument entirely when no fixed height is requested.
            kwargs = {
                'orientation': orientation,
                'spacing': dp(spacing),
                'padding': dp(pad),
                'size_hint_y': None,
            }
            if height is not None:
                kwargs['height'] = dp(height)
            box = BoxLayout(**kwargs)
            with box.canvas.before:
                c = Color(*self._panel)
                r = RoundedRectangle(radius=[dp(10)])
            box._panel_color, box._panel_rect = c, r
            box.bind(pos=lambda o, v: setattr(o._panel_rect, 'pos', v),
                     size=lambda o, v: setattr(o._panel_rect, 'size', v))
            return box

        # Always-visible readiness status.  This is the important status the
        # user asked to see without opening a menu.
        self.readiness_card = panel(78, orientation='horizontal', pad=10, spacing=10)
        self.readiness_icon = Label(text='●', font_size='28sp', bold=True, color=self._muted,
                                    size_hint_x=None, width=dp(42), halign='center', valign='middle')
        self.readiness_icon.bind(size=lambda o, v: setattr(o, 'text_size', v))
        self.readiness_card.add_widget(self.readiness_icon)
        ready_text_box = BoxLayout(orientation='vertical', spacing=0)
        self.readiness_title = Label(text='МОДЕЛЬ ОБУЧАЕТСЯ — 0/10', font_size='16sp', bold=True,
                                     color=self._text, halign='left', valign='middle',
                                     size_hint_y=None, height=dp(30))
        self.readiness_title.bind(size=lambda o, v: setattr(o, 'text_size', (v[0], None)))
        self.readiness_subtitle = Label(text='Собираю и проверяю прогнозы', font_size='11sp',
                                        color=self._muted, halign='left', valign='middle',
                                        size_hint_y=None, height=dp(24))
        self.readiness_subtitle.bind(size=lambda o, v: setattr(o, 'text_size', (v[0], None)))
        ready_text_box.add_widget(self.readiness_title)
        ready_text_box.add_widget(self.readiness_subtitle)
        self.readiness_card.add_widget(ready_text_box)
        self.add_widget(self.readiness_card)

        # Three compact metrics, matching the reference design.
        self.metrics_box = panel(70, orientation='horizontal', pad=7, spacing=2)
        self.metric_labels = {}
        for key, title_txt in (('resolved','Проверено'), ('accuracy','Точность'), ('recent','Последние 100')):
            col = BoxLayout(orientation='vertical', spacing=0)
            l1 = Label(text=title_txt, font_size='10sp', color=self._muted,
                       halign='center', valign='middle', size_hint_y=None, height=dp(22))
            l1.bind(size=lambda o, v: setattr(o, 'text_size', v))
            l2 = Label(text='—', font_size='16sp', bold=True, color=self._text,
                       halign='center', valign='middle', size_hint_y=None, height=dp(28))
            l2.bind(size=lambda o, v: setattr(o, 'text_size', v))
            col.add_widget(l1); col.add_widget(l2)
            self.metric_labels[key] = l2
            self.metrics_box.add_widget(col)
        self.add_widget(self.metrics_box)

        self.cycle_card = panel(None, orientation='vertical', pad=8, spacing=1)
        self.cycle_card.bind(minimum_height=self.cycle_card.setter('height'))
        self.cycle_title = Label(text='Текущий цикл  •  Ожидание', font_size='13sp', bold=True,
                                 color=self._text, halign='left', valign='middle',
                                 size_hint_y=None, height=dp(24))
        self.cycle_title.bind(size=lambda o, v: setattr(o, 'text_size', (v[0], None)))
        self.cycle_detail = Label(text='Сканирование рынка — 670+ монет\nПроверка прогнозов — готовится',
                                  font_size='10sp', color=self._muted, halign='left', valign='top',
                                  size_hint_y=None, height=dp(36))
        self.cycle_detail.bind(size=lambda o, v: setattr(o, 'text_size', (v[0], None)))
        self.cycle_detail.bind(texture_size=lambda o, v: setattr(o, 'height', max(dp(34), v[1] + dp(2))))
        self.cycle_card.add_widget(self.cycle_title)
        self.cycle_card.add_widget(self.cycle_detail)
        self.add_widget(self.cycle_card)

        self.status_card = Label(text='Запускаю самообучение...', font_size='11sp',
                                 halign='left', valign='middle', color=self._muted,
                                 size_hint_y=None, height=dp(42), padding=(dp(6), dp(4)))
        self.status_card.bind(size=lambda o, v: setattr(o, 'text_size', (max(dp(120), v[0]-dp(12)), None)))
        self.status_card.bind(texture_size=lambda o, v: setattr(o, 'height', max(dp(42), v[1] + dp(10))))
        self.add_widget(self.status_card)

        self.main_menu_box = BoxLayout(orientation='vertical', spacing=dp(8), size_hint_y=None,
                                       height=0, opacity=0, disabled=True)
        self._main_menu_buttons = []
        # Kept as a hidden compatibility container.  The actual menu is a Popup
        # so opening it never shifts the work area or steals touch coordinates.
        menu_items = [
            ('ПОЛУЧИТЬ 5 ПРОГНОЗОВ', lambda *_: self.request_five_predictions()),
            ('ПРОГНОЗ ПО МОНЕТЕ', lambda *_: self.open_manual_coin_forecast()),
            ('КАЛЬКУЛЯТОР', lambda *_: self.open_calculator_menu()),
            ('СТАТИСТИКА МОДЕЛИ', lambda *_: self.show_readiness()),
            ('ПОСЛЕДНИЕ 100 МОНЕТ TOP-5', lambda *_: self.show_last100_top5()),
            ('НАСТРОЙКИ', lambda *_: self._menu_navigate('settings')),
            ('РЕЗЕРВНАЯ КОПИЯ', lambda *_: self.show_backup()),
            ('ЭКСПОРТ RUNTIME-ЛОГА', lambda *_: self.export_runtime_log()),
            ('ИМПОРТ RUNTIME-ЛОГА', lambda *_: self.import_runtime_log()),
        ]
        for txt, handler in menu_items:
            b = style_button(ExpandedTouchButton(text=txt, size_hint_y=None, height=dp(46)), fs=11)
            b.bind(on_release=handler)
            self._main_menu_buttons.append(b)
        self.menu_stop_btn = style_button(ExpandedTouchButton(text='СТОП', size_hint_y=None, height=dp(1)), accent=True, fs=12)
        self.menu_stop_btn.opacity = 0; self.menu_stop_btn.disabled = True

        self.scroll = ScrollView(do_scroll_x=False, do_scroll_y=True, bar_width=dp(4), scroll_timeout=250)
        self.content = BoxLayout(orientation='vertical', size_hint_y=None, size_hint_x=1, spacing=dp(7),
                                 padding=(0, 0, 0, dp(18)))
        self.content.bind(minimum_height=self.content.setter('height'))
        self.scroll.add_widget(self.content)
        self.add_widget(self.scroll)

        self.top_title = Label(text='ТОП-5 ПРОГНОЗОВ', font_size='18sp', bold=True,
                               halign='left', valign='middle', color=self._text, size_hint_y=None, height=dp(34))
        self.top_title.bind(size=lambda o, v: setattr(o, 'text_size', (v[0], None)))
        self.content.add_widget(self.top_title)
        self.results_box = BoxLayout(orientation='vertical', spacing=dp(7), size_hint_y=None)
        self.results_box.bind(minimum_height=self.results_box.setter('height'))
        self.content.add_widget(self.results_box)

        self.selected_label = Label(text='', font_size='11sp', color=self._muted, halign='left',
                                    valign='middle', size_hint_y=None, height=0, opacity=0)
        self.selected_label.bind(size=lambda o,v:setattr(o,'text_size',(v[0],None)))
        self.content.add_widget(self.selected_label)

        self.calc_box = BoxLayout(orientation='vertical', spacing=dp(6), size_hint_y=None, height=0)
        self.calc_box.bind(minimum_height=self.calc_box.setter('height'))
        self.content.add_widget(self.calc_box)

        # FIX: the scan control is outside the scrolling content.
        # cycle/status text changes height during every scan, so a button inside
        # self.content inevitably moved up/down.  The action bar has a fixed
        # screen position and only the button state changes.
        self.scan_action_bar = BoxLayout(orientation='vertical', size_hint_y=None,
                                         height=dp(60), padding=(0, dp(4)), spacing=0)
        self.stop_btn = ExpandedTouchButton(text='СТОП', size_hint_y=1, opacity=0, disabled=True)
        self.stop_btn.set_visual_colors(self._red, (0.65, 0.08, 0.08, 1))
        self.stop_btn.bind(on_release=self.stop_scan)
        self.scan_action_bar.add_widget(self.stop_btn)
        self.add_widget(self.scan_action_bar)
        self.log_box = Label(text='', font_size='12sp', halign='left', valign='top', color=self._muted,
                             size_hint_y=None, height=0, opacity=0, padding=(dp(8), dp(6)))
        self.log_box.bind(width=lambda o, v: setattr(o, 'text_size', (max(dp(100), v-dp(14)), None)))
        self.content.add_widget(self.log_box)
        self.bottom_spacer = Widget(size_hint_y=None, height=dp(12))
        self.content.add_widget(self.bottom_spacer)

        # Fixed bottom-right ⋮ control.  It does not overlap the scroll area.
        footer = BoxLayout(size_hint_y=None, height=dp(56), orientation='horizontal')
        footer.add_widget(Widget())
        self.control_btn = style_button(ExpandedTouchButton(text='⋮', size_hint_x=None, width=dp(56), height=dp(50)), fs=24)
        self.control_btn.bind(on_release=self.toggle_main_menu)
        footer.add_widget(self.control_btn)
        self.add_widget(footer)

        self._menu_popup = None
        self._stop_control_allowed = True
        self._dashboard_refresh_event = Clock.schedule_interval(lambda dt: self._refresh_dashboard(), 5.0)
        Window.bind(size=self._on_resize)
        Clock.schedule_once(lambda dt: self._on_resize(), 0.1)
        # Foreground-service startup is owned by TraderApp.on_start().
        # Do not start the Android service here as well: doing both from UI
        # construction and Activity startup can issue two service starts during
        # the same Android lifecycle transition and can crash the Activity when
        # it is resumed/recreated. Symbol discovery remains independent.
        Clock.schedule_once(lambda dt: self.refresh_symbols(None, auto=True), 0.20)
        Clock.schedule_once(lambda dt: self._refresh_dashboard(), 0.40)
    def _ensure_foreground_service(self):
        """Start or attach to the Android foreground service on every real app launch.

        The UI process may be recreated while the service is still alive, and the
        first Android service start can occasionally be delayed.  We therefore
        attach immediately when possible and retry a few times if no heartbeat
        appears.  A deliberate user STOP is never overridden.
        """
        if platform != 'android':
            return
        try:
            state = self._read_bg_state()
            if self._service_state_live(state):
                self._scan_running = True
                self._scan_worker_active = True
                self._scan_paused = False
                self._bg_start_attempts = 0
                if self._bg_poll_event is None:
                    self._bg_poll_event = Clock.schedule_interval(self._poll_foreground_scan, 0.5)
                return
            # Do not override a deliberate STOP state.
            if str(state.get('status','')) == 'stopped' and bool(state.get('user_stopped', False)):
                self._scan_running = False
                self._scan_worker_active = False
                self._scan_paused = True
                self._sync_stop_button_visibility()
                return
            self._bg_start_attempts = 0
            self._start_foreground_scan()
            Clock.schedule_once(lambda dt: self._retry_foreground_start(), 2.5)
        except Exception as exc:
            self.append_log('Ошибка автозапуска фонового режима: ' + str(exc))
            Clock.schedule_once(lambda dt: self._retry_foreground_start(), 2.0)

    def _retry_foreground_start(self):
        if platform != 'android':
            return
        try:
            state = self._read_bg_state()
            if self._service_state_live(state):
                self._bg_start_attempts = 0
                if self._bg_poll_event is None:
                    self._bg_poll_event = Clock.schedule_interval(self._poll_foreground_scan, 0.5)
                return
            if str(state.get('status','')) == 'stopped' and bool(state.get('user_stopped', False)):
                return
            if self._bg_start_attempts >= 6:
                self.append_log('Не удалось подтвердить запуск фонового сервиса после 3 попыток')
                self._scan_running = False
                self._scan_worker_active = False
                self._scan_paused = False
                self._bg_stop_requested = False
                self.status_card.text = 'Фоновый сервис не запустился.\nНажми ОБНОВИТЬ для повторного запуска.'
                self._sync_stop_button_visibility()
                return
            self._bg_start_attempts += 1
            self.append_log(f'Повторный запуск фонового сервиса: попытка {self._bg_start_attempts}/6')
            self._start_foreground_scan()
            Clock.schedule_once(lambda dt: self._retry_foreground_start(), 2.5)
        except Exception as exc:
            self.append_log('Ошибка повторного запуска фонового режима: ' + str(exc))
            if self._bg_start_attempts < 3:
                self._bg_start_attempts += 1
                Clock.schedule_once(lambda dt: self._retry_foreground_start(), 2.0)

    def refresh_view(self, *_):
        """Refresh state and recover a stale/dead Android foreground service.

        A refresh must be useful even when the last poll already marked the
        local worker as dead. In that case the old implementation only
        redrew the same stale state and never restarted the service.
        """
        try:
            state = self._read_bg_state()
            status = str(state.get('status', ''))
            live = self._service_state_live(state)

            if platform == 'android':
                if live:
                    # The service is alive: only synchronize the dashboard.
                    self._scan_running = status in ('running', 'stopping', 'ready_idle')
                    self._scan_worker_active = self._scan_running
                    self._scan_paused = False
                    if self._bg_poll_event is None:
                        self._bg_poll_event = Clock.schedule_interval(self._poll_foreground_scan, 0.5)
                    self._poll_foreground_scan(0)
                    self.append_log('Ручное обновление: фоновый сервис отвечает')
                elif status in ('running', 'stopping', 'ready_idle'):
                    # The state file says the service is alive, but its
                    # heartbeat is stale. Treat it as dead and recover it.
                    # Do not wait for the old process: its lock will be
                    # reclaimed by the service if the owner is stale.
                    self._scan_running = False
                    self._scan_worker_active = False
                    self._scan_paused = False
                    self._bg_stop_requested = False
                    self.append_log('Ручное обновление: фоновый сервис не отвечает — запускаю восстановление')
                    self._start_foreground_scan()
                else:
                    # stopped/error/empty state: refresh only. A deliberate
                    # STOP must not be silently turned into a new scan.
                    self._refresh_dashboard()
                    self.append_log('Ручное обновление состояния')
            else:
                self._refresh_dashboard()
                if self._scan_running or self._scan_paused:
                    self._poll_foreground_scan(0)
                self.append_log('Ручное обновление состояния')
            self._refresh_dashboard()
        except Exception as exc:
            self.append_log('Ошибка обновления: ' + str(exc))
    def _refresh_dashboard(self):
        try:
            r=self.engine.readiness()
            gs=self.engine.global_stats()
            ready=bool(r.get('ready'))
            score=int(r.get('score',0))
            if ready:
                self.readiness_icon.text='✓'; self.readiness_icon.color=self._green
                self.readiness_title.text=f'МОДЕЛЬ ГОТОВА — {score}/10'
                self.readiness_title.color=self._green
                self.readiness_subtitle.text='Все критерии пройдены. Можно получать новые 5 прогнозов.'
            else:
                self.readiness_icon.text='◔'; self.readiness_icon.color=(1,0.78,0.05,1)
                self.readiness_title.text=f'МОДЕЛЬ ОБУЧАЕТСЯ — {score}/10'
                self.readiness_title.color=(1,0.78,0.05,1)
                missing=r.get('reasons') or []
                self.readiness_subtitle.text=('Не пройдены: '+', '.join(missing[:2])) if missing else 'Собираю и проверяю прогнозы'
            self.metric_labels['resolved'].text=f"{int(gs.get('resolved',0)):,}".replace(',',' ')
            acc=gs.get('accuracy'); self.metric_labels['accuracy'].text='—' if acc is None else f'{acc:.1%}'
            recent=r.get('recent100_directional_accuracy'); self.metric_labels['recent'].text='—' if recent is None else f'{recent:.1%}'
            st=self._read_bg_state()
            phase=str(st.get('phase','READY'))
            status=str(st.get('status',''))
            live=self._service_state_live(st)
            if status in ('running','stopping') and live:
                self.bg_chip.text='● В фоне\nРаботает'; self.bg_chip.color=self._green
                self.cycle_title.text=f"Текущий цикл  •  {phase}"
                done=int(st.get('done_count',0) or 0); total=int(st.get('total',0) or 0)
                if total:
                    if phase == 'MODEL':
                        self.cycle_detail.text=f"Глубокий AI-анализ — {done}/{total}\n{st.get('message','') or 'Проверка лучших кандидатов'}"
                    else:
                        self.cycle_detail.text=f"Быстрый проход рынка — {done}/{total} ({done/total:.0%})\n{st.get('message','') or 'Проверка прогноза'}"
                else:
                    self.cycle_detail.text=f"{st.get('message','Самообучение активно')}\nПроверка прогнозов выполняется в фоне"
            elif status == 'ready_idle' and live:
                self.bg_chip.text='● В фоне\nГотова'; self.bg_chip.color=self._green
                self.cycle_title.text='Текущий цикл  •  Готова'
                self.cycle_detail.text='Старые прогнозы проверяются автоматически\nНовые 5 — только по твоей команде'
            elif status in ('running','stopping','ready_idle') and not live:
                self.bg_chip.text='● В фоне\nНе отвечает'; self.bg_chip.color=self._red
                self.cycle_title.text='Текущий цикл  •  Сервис не отвечает'
                self.cycle_detail.text='Heartbeat отсутствует. Нажми ОБНОВИТЬ для восстановления.'
            elif status=='error':
                self.bg_chip.text='● Ошибка'; self.bg_chip.color=self._red
                self.cycle_title.text='Текущий цикл  •  Ошибка'
                self.cycle_detail.text=str(st.get('error','Неизвестная ошибка'))
            else:
                self.bg_chip.text='● В фоне\nОжидание'; self.bg_chip.color=self._muted
                self.cycle_title.text='Текущий цикл  •  Ожидание'
                self.cycle_detail.text='Автоматическое самообучение готовится\nЗапуск произойдёт после открытия приложения'
            self._poll_manual_prediction(st)
            self._sync_stop_button_visibility()
            self._update_ready_menu_label()
        except Exception:
            pass

    def _apply_manual_result(self, result):
        if result.get('request_id') != self._manual_wait_id: return
        self._manual_wait_id=None; self._manual_wait_symbol=None
        self.results_box.clear_widgets()
        if result.get('error'):
            self.status_card.text='РУЧНОЙ ПРОГНОЗ\nОшибка: '+str(result.get('error')); return
        r=result.get('prediction') or {}
        self._last_prediction=dict(r); self.selected_label.height=dp(24)
        self.selected_label.text=f"Ручной прогноз: {r.get('symbol','—')} [{r.get('exchange_symbol','—')}]"
        self.status_card.text=self._prediction_text(r); self.build_calculator(r)

    def _poll_manual_prediction(self, state=None):
        try:
            req_id=self._manual_wait_id
            if not req_id: return
            st=state or self._read_bg_state()
            result=st.get('manual_prediction_result') or {}
            if result.get('request_id') != req_id: return
            self._manual_wait_id=None
            self._manual_wait_symbol=None
            self.results_box.clear_widgets()
            if result.get('error'):
                self.status_card.text='РУЧНОЙ ПРОГНОЗ\nОшибка: '+str(result.get('error'))
                return
            r=result.get('prediction') or {}
            if not r:
                self.status_card.text='РУЧНОЙ ПРОГНОЗ\nОтвет модели пуст.'
                return
            self._last_prediction=dict(r)
            self.selected_label.height=dp(24)
            self.selected_label.text=f"Ручной прогноз: {r.get('symbol','—')} [{r.get('exchange_symbol','—')}]"
            self.status_card.text=self._prediction_text(r)
            self.build_calculator(r)
            self.top_title.text='РУЧНОЙ ПРОГНОЗ'
            back=self.style_button(ExpandedTouchButton(text='← НА ГЛАВНУЮ', size_hint_y=None, height=dp(48)), fs=12)
            back.bind(on_release=lambda *_: self.bottom_nav('scanner'))
            self.results_box.add_widget(back)
            self.append_log(f"Ручной прогноз получен: {r.get('symbol','—')} {r.get('prediction','WAIT')}")
        except Exception as e:
            self.append_log('Ошибка отображения ручного прогноза: '+str(e))

    def _register_fixed_touch(self, widget, handler, pad=0):
        # Compatibility no-op.  V14.1 deliberately uses ordinary Kivy button
        # hitboxes; the previous global touch router caused apparent offsets.
        return None

    def _on_resize(self, *_):
        self.content.width = max(dp(240), self.scroll.width-dp(2))
        self.results_box.width = self.content.width
        self.calc_box.width = self.content.width
        if hasattr(self, 'bottom_spacer'):
            self.bottom_spacer.height = max(dp(76), self.height * 0.07)
        self._layout_calculator_if_ready()

    def _layout_calculator_if_ready(self):
        if hasattr(self, 'calc_grid') and self.calc_box.height > 0:
            try:
                self._layout_calculator()
            except Exception:
                pass

    def toggle_fullscreen(self, *_):
        # Fullscreen is now automatic.  Kept as a compatibility method for
        # older callers; the user no longer needs a dedicated FULL button.
        try:
            Window.fullscreen = True
        except Exception:
            pass

    def _menu_navigate(self, mode):
        self.main_menu_box.disabled = True
        self.main_menu_box.opacity = 0
        self.main_menu_box.height = 0
        self.control_btn.text = '☰'
        if mode == 'scanner':
            self.bottom_nav('scanner')
        elif mode == 'analysis':
            self.bottom_nav('analysis')
        elif mode == 'model':
            self.bottom_nav('model')
        elif mode == 'settings':
            self.bottom_nav('settings')

    def toggle_main_menu(self, *_):
        """Open/close a stable in-app menu overlay.

        The previous Popup-based menu could terminate/minimize the Android
        activity on some Kivy/Android combinations. A ModalView keeps the menu
        inside the Kivy activity and does not create a second popup window.
        """
        if self._menu_popup is not None:
            self._close_menu_popup()
            return
        try:
            self._update_ready_menu_label()
            modal = ModalView(size_hint=(1, 1), auto_dismiss=False, background_color=(0, 0, 0, 0.72),
                              background='', overlay_color=(0, 0, 0, 0.72))
            panel = BoxLayout(orientation='vertical', spacing=dp(8), padding=dp(12),
                              size_hint=(0.92, 0.82), pos_hint={'center_x': 0.5, 'center_y': 0.5})
            scroll = ScrollView(do_scroll_x=False, do_scroll_y=True, bar_width=dp(4))
            inner = BoxLayout(orientation='vertical', spacing=dp(8), padding=(0, dp(2)), size_hint_y=None)
            inner.bind(minimum_height=inner.setter('height'))
            handlers = [
                self.request_five_predictions,
                self.open_manual_coin_forecast,
                self.open_calculator_menu,
                self.show_readiness,
                lambda *_: self.show_last100_top5(),
                lambda *_: self._menu_navigate('settings'),
                self.show_backup,
                self.export_runtime_log,
                self.import_runtime_log,
            ]
            for i, source_btn in enumerate(self._main_menu_buttons):
                b = self.style_button(ExpandedTouchButton(text=str(source_btn.text), size_hint_y=None, height=dp(52)),
                                      accent=(i == 0 and not source_btn.disabled), fs=12)
                b.disabled = bool(source_btn.disabled)
                b.opacity = float(source_btn.opacity)
                b.bind(on_release=lambda btn, fn=handlers[i]: self._run_menu_handler(fn))
                inner.add_widget(b)
            if self._scan_running or self._scan_paused or self._bg_stop_requested:
                self._sync_menu_stop()
                stop_b = self.style_button(ExpandedTouchButton(text=self.menu_stop_btn.text, size_hint_y=None, height=dp(52)), accent=True, fs=12)
                stop_b.disabled = bool(self._bg_stop_requested and self._scan_paused)
                stop_b.bind(on_release=lambda *_: self._run_menu_handler(self.stop_scan))
                inner.add_widget(stop_b)
            close_b = self.style_button(ExpandedTouchButton(text='ЗАКРЫТЬ МЕНЮ', size_hint_y=None, height=dp(48)), fs=11)
            close_b.bind(on_release=lambda *_: self._close_menu_popup())
            inner.add_widget(close_b)
            scroll.add_widget(inner)
            panel.add_widget(scroll)
            modal.add_widget(panel)
            self._menu_popup = modal
            modal.bind(on_dismiss=lambda *_: setattr(self, '_menu_popup', None))
            modal.open()
        except Exception:
            self._menu_popup = None
            try:
                self.append_log('Ошибка открытия меню: ' + traceback.format_exc())
                self.status_card.text = 'Ошибка открытия меню. Подробности записаны в runtime-лог.'
            except Exception:
                pass

    def _run_menu_handler(self, fn):
        self._close_menu_popup()
        try:
            Clock.schedule_once(lambda dt: fn(), 0)
        except Exception:
            try:
                self.append_log('Ошибка действия меню: ' + traceback.format_exc())
            except Exception:
                pass

    def _close_menu_popup(self):
        if self._menu_popup is not None:
            try: self._menu_popup.dismiss()
            except Exception: pass
            self._menu_popup = None

    def _menu_scan_action(self, *_):
        # Do not duplicate the button binding; menu_stop_btn is contextual.
        try:
            self.menu_stop_btn.unbind(on_release=self.stop_scan)
        except Exception:
            pass
        if self._scan_running:
            self.stop_scan(None)
        elif self._scan_paused:
            self.stop_scan(None)
        else:
            self.scan(None)
        Clock.schedule_once(lambda dt: self._sync_menu_stop(), 0.15)

    def _set_stop_button_visual(self):
        if not hasattr(self, 'stop_btn'):
            return
        if self._scan_paused and not self._scan_running:
            self.stop_btn.set_visual_colors(self._green, (0.03, 0.48, 0.24, 1))
        else:
            self.stop_btn.set_visual_colors(self._red, (0.65, 0.08, 0.08, 1))

    def _set_stop_control_screen(self, allowed):
        """Reserve a fixed action area for STOP/RESUME on the scanner screen."""
        self._stop_control_allowed = bool(allowed)
        if hasattr(self, 'scan_action_bar'):
            self.scan_action_bar.height = dp(60) if allowed else 0
        if hasattr(self, 'stop_btn'):
            self.stop_btn.opacity = 1 if allowed else 0
            self.stop_btn.disabled = not allowed

    def _sync_stop_button_visibility(self):
        if not hasattr(self, 'stop_btn'):
            return
        visible_here = bool(getattr(self, '_stop_control_allowed', False))
        self.stop_btn.opacity = 1 if visible_here else 0
        self.stop_btn.disabled = not visible_here
        if self._scan_paused:
            # Once STOP has been requested, immediately show the RESUME state.
            # While the service is still acknowledging STOP the button remains
            # disabled, so a second tap cannot race the service transition.
            self.stop_btn.text = 'ВОЗОБНОВИТЬ СКАНИРОВАНИЕ'
            self.stop_btn.disabled = bool(self._bg_stop_requested)
        elif self._scan_running or self._bg_stop_requested:
            self.stop_btn.text = 'СТОП'
            self.stop_btn.disabled = False
        else:
            self.stop_btn.text = 'ЗАПУСТИТЬ СКАНИРОВАНИЕ'
            self.stop_btn.disabled = False
        self._set_stop_button_visual()

    def _sync_menu_stop(self):
        if not hasattr(self, 'menu_stop_btn'):
            return
        if self._scan_paused:
            self.menu_stop_btn.text = 'ВОЗОБНОВИТЬ СКАНИРОВАНИЕ'
        elif self._scan_running:
            self.menu_stop_btn.text = 'СТОП'
        else:
            self.menu_stop_btn.text = 'ЗАПУСТИТЬ СКАНИРОВАНИЕ'

    def _update_ready_menu_label(self):
        if not self._main_menu_buttons:
            return
        try:
            r=self.engine.readiness()
            b=self._main_menu_buttons[0]
            b.text=(f'ПОЛУЧИТЬ 5 ПРОГНОЗОВ  •  ГОТОВА {int(r.get("score",0))}/10' if r.get('ready')
                    else f'МОДЕЛЬ ОБУЧАЕТСЯ  •  {int(r.get("score",0))}/10')
            b.disabled=not r.get('ready')
            b.opacity=1 if r.get('ready') else .55
        except Exception:
            pass

    def _hide_main_menu(self):
        self.main_menu_box.disabled=True
        self.main_menu_box.opacity=0
        self.main_menu_box.height=0
        self._close_menu_popup()

    def request_five_predictions(self, *_):
        self._hide_main_menu()
        try:
            r=self.engine.readiness()
            if not r['ready']:
                self.show_readiness()
                return
            state=self._read_bg_state()
            if self._service_state_live(state):
                # The learning service is already alive.  Do not start a second
                # Android service; just deliver a one-shot prediction request.
                self._write_bg_control(False, run_id=state.get('run_id'), prediction_request=True)
                self._scan_running=True
                self._scan_paused=False
                self.status_card.text='🟢 МОДЕЛЬ ГОТОВА. Запрошен новый полный скан рынка для TOP-5 прогнозов.'
                self.top_title.text='НОВЫЕ 5 ПРОГНОЗОВ'
                if self._bg_poll_event is None:
                    self._bg_poll_event=Clock.schedule_interval(self._poll_foreground_scan,0.5)
            else:
                self._write_bg_control(False, run_id=None, prediction_request=True)
                self.status_card.text='🟢 МОДЕЛЬ ГОТОВА. Запускаю новый полный скан рынка для TOP-5 прогнозов.'
                self.top_title.text='НОВЫЕ 5 ПРОГНОЗОВ'
                self._start_foreground_scan(request_only=True)
            self.append_log('Запрошен новый TOP-5 после готовности модели')
        except Exception as e:
            self.status_card.text='Не удалось запросить прогнозы: ' + str(e)

    def _write_manual_request(self, symbol):
        try:
            self._manual_request_path.parent.mkdir(parents=True, exist_ok=True)
            payload = {'request_id': str(int(time.time()*1000)), 'symbol': str(symbol).upper(), 'created_at': int(time.time())}
            tmp = self._manual_request_path.with_suffix('.tmp')
            tmp.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
            tmp.replace(self._manual_request_path)
            return payload
        except Exception as e:
            raise RuntimeError('Не удалось создать запрос ручного прогноза: ' + str(e))

    def open_manual_coin_forecast(self, *_):
        self._hide_main_menu()
        box=BoxLayout(orientation='vertical', spacing=dp(8), padding=dp(12))
        info=Label(text='Введи монету, например BTC, ETH или SOL.\nАвтоматическое самообучение при этом не останавливается.',
                   color=self._muted, font_size='11sp', size_hint_y=None, height=dp(52), halign='left', valign='middle')
        info.bind(size=lambda o,v:setattr(o,'text_size',(v[0],None)))
        box.add_widget(info)
        inp=TextInput(text='', hint_text='BTC / ETH / SOL', multiline=False, size_hint_y=None, height=dp(48))
        box.add_widget(inp)
        matches=Label(text='', color=self._muted, font_size='11sp', size_hint_y=None, height=dp(46), halign='left', valign='top')
        matches.bind(size=lambda o,v:setattr(o,'text_size',(v[0],None)))
        box.add_widget(matches)
        run= self.style_button(ExpandedTouchButton(text='ПОЛУЧИТЬ ПРОГНОЗ', size_hint_y=None, height=dp(52)), accent=True, fs=12)
        box.add_widget(run)
        cancel=self.style_button(ExpandedTouchButton(text='ОТМЕНА', size_hint_y=None, height=dp(46)), fs=11)
        box.add_widget(cancel)
        pop=Popup(title='ПРОГНОЗ ПО МОНЕТЕ', content=box, size_hint=(0.92,0.55), auto_dismiss=False, separator_height=0)
        def update_matches(*_):
            q=inp.text.strip().upper().replace('USDT','').replace('-','')
            if not q:
                matches.text='Примеры: BTC-USDT, ETH-USDT, SOL-USDT'
                return
            vals=[]
            for item in self._symbols:
                d=str(item.get('display','')).upper().replace('-USDT','').replace('USDT','')
                if q in d:
                    vals.append(item.get('display'))
                if len(vals)>=6: break
            matches.text=('Найдено: '+', '.join(vals)) if vals else 'В текущем списке не найдено — можно ввести тикер вручную.'
        def submit(*_):
            raw=inp.text.strip().upper()
            if not raw:
                matches.text='Введи тикер монеты.'; return
            if raw.endswith('-USDT'):
                symbol=raw
            elif raw.endswith('USDT'):
                symbol=raw[:-4]+'-USDT'
            else:
                symbol=raw+'-USDT'
            try:
                req=self._write_manual_request(symbol)
                pop.dismiss()
                self._nav_mode='scanner'
                self._clear_work_area()
                self.top_title.text='РУЧНОЙ ПРОГНОЗ'
                self.status_card.text=f'Запрос принят: {symbol}.\nАвтоматическое сканирование и самообучение продолжаются независимо.'
                self.results_box.clear_widgets()
                wait=Label(text='AI готовит прогноз по выбранной монете…', color=self._muted, font_size='13sp', size_hint_y=None, height=dp(70), halign='left', valign='middle')
                wait.bind(size=lambda o,v:setattr(o,'text_size',(v[0],None)))
                self.results_box.add_widget(wait)
                self._manual_wait_id=req['request_id']
                self._manual_wait_symbol=symbol
                self.append_log(f'Ручной прогноз запрошен: {symbol}')
                if platform == 'android' and not self._service_state_live(self._read_bg_state()):
                    self._start_foreground_scan()
                elif platform != 'android':
                    def desktop_manual():
                        try:
                            ex=KuCoin(symbol)
                            ex._request_gap=0.20
                            eng=LearningEngine(Path(App.get_running_app().user_data_dir),ex,self.engine.cfg)
                            eng.set_symbol(ex.futures_symbol)
                            if not eng.mm.has_champion(): eng.train_from_fresh()
                            r=eng.predict_and_store(manual=True,source='manual')
                            return {'request_id':req['request_id'],'prediction':r}
                        except Exception as e:
                            return {'request_id':req['request_id'],'error':str(e)}
                    def desktop_run():
                        result=desktop_manual()
                        Clock.schedule_once(lambda dt, result=result: self._apply_manual_result(result),0)
                    threading.Thread(target=desktop_run,daemon=True).start()
            except Exception as e:
                matches.text=str(e)
        inp.bind(text=update_matches); run.bind(on_release=submit); cancel.bind(on_release=lambda *_: pop.dismiss())
        update_matches()
        pop.open()

    def open_calculator_menu(self, *_):
        self._hide_main_menu()
        if self._last_top5:
            self._nav_mode='scanner'
            self._clear_work_area()
            self.top_title.text='КАЛЬКУЛЯТОР'
            self.status_card.text='Калькулятор использует первый прогноз из последнего TOP-5.'
            self.render_top5(self._last_top5)
            self.build_calculator(self._last_top5[0])
            self.scroll.scroll_y=0
        else:
            self.top_title.text='КАЛЬКУЛЯТОР'
            self.status_card.text='Калькулятор станет доступен после появления первого TOP-5.'

    def _stat_section(self, title, body, accent=None):
        box = BoxLayout(orientation='vertical', spacing=dp(4), padding=dp(10), size_hint_y=None)
        title_lbl = Label(text=title, font_size='13sp', bold=True, color=accent or self._text,
                          halign='left', valign='middle', size_hint_y=None, height=dp(24))
        title_lbl.bind(size=lambda o,v:setattr(o,'text_size',(v[0],None)))
        body_lbl = Label(text=body, font_size='10.5sp', color=self._muted,
                         halign='left', valign='top', size_hint_y=None)
        body_lbl.bind(size=lambda o,v:setattr(o,'text_size',(max(dp(180),v[0]-dp(8)),None)))
        body_lbl.bind(texture_size=lambda o,v:setattr(o,'height',max(dp(30),v[1]+dp(4))))
        box.add_widget(title_lbl); box.add_widget(body_lbl)
        box.bind(minimum_height=box.setter('height'))
        with box.canvas.before:
            c=Color(*self._panel2); r=RoundedRectangle(radius=[dp(8)])
        box._stat_c,box._stat_r=c,r
        box.bind(pos=lambda o,v:setattr(o._stat_r,'pos',v),size=lambda o,v:setattr(o._stat_r,'size',v))
        return box

    def show_readiness(self, *_):
        self._hide_main_menu()
        self._nav_mode='model'
        self._clear_work_area()
        self.top_title.text='СТАТИСТИКА МОДЕЛИ'
        try:
            r=self.engine.readiness()
            d=self.engine.detailed_stats()
            self.results_box.clear_widgets()
            def pct(v): return '—' if v is None else f'{v:.1%}'
            def ratio(n,dn): return f'{n}/{dn}' if dn else '0/0'
            def rate(n,dn): return '—' if not dn else f'{n/dn:.1%}'
            score=int(r['score'])
            head=('ГОТОВА' if r['ready'] else 'ОБУЧАЕТСЯ')
            self.status_card.text=(f'МОДЕЛЬ {head} — {score}/10\n'
                                   f'Эта страница показывает, из каких данных получились проценты и почему критерии пройдены или нет.')

            a=d['actionable']; allc=d['all']; r100=d['recent100']; r500=d['recent500']
            overview=(f"Всего сохранено прогнозов: {d['total_saved']}\n"
                      f"Полностью завершено: {allc['total']}\n"
                      f"Ожидают события: {d['pending']}\n"
                      f"LONG/SHORT завершено: {a['total']}\n"
                      f"LONG: {a['long']} | SHORT: {a['short']}\n"
                      f"Долгоиграющих сейчас: {d['active_long_running']}/10\n"
                      f"В очереди на слот: {d['queued_long_running']}\n"
                      f"Ожидают TP1: {d['waiting_tp1']} | TP2: {d['waiting_tp2']} | TP3: {d['waiting_tp3']}\n"
                      f"Общая точность: {rate(allc['correct'], allc['total'])}\n"
                      f"Точность LONG/SHORT: {rate(a['correct'], a['total'])}")
            self.results_box.add_widget(self._stat_section('1. ОБЩАЯ СТАТИСТИКА', overview, self._accent))

            targets=(f"TP1: {a['tp1']} из {a['total']} = {rate(a['tp1'],a['total'])}\n"
                     f"TP2: {a['tp2']} из {a['total']} = {rate(a['tp2'],a['total'])}\n"
                     f"TP3: {a['tp3']} из {a['total']} = {rate(a['tp3'],a['total'])}\n"
                     f"SL до TP1: {a['sl']} из {a['total']} = {rate(a['sl'],a['total'])}\n"
                     f"Защищено после TP: {a.get('protected_exits',0)} из {a['total']}\n\n"
                     f"LONG — TP1 {rate(a['long_tp1'],a['long'])}, SL {rate(a['long_sl'],a['long'])}\n"
                     f"SHORT — TP1 {rate(a['short_tp1'],a['short'])}, SL {rate(a['short_sl'],a['short'])}")
            self.results_box.add_widget(self._stat_section('2. TP / SL — ИЗ ЧЕГО ПОЛУЧИЛСЯ ПРОЦЕНТ', targets, self._green))
            cs=d.get('confidence',{})
            def conf_line(key):
                q=cs.get(key,{})
                if not q.get('total'):
                    return f"{q.get('label',key)}: пока нет завершённых прогнозов"
                return (f"{q.get('label',key)}: {q['total']} прогнозов | "
                        f"подтверждено {q['confirmed']} ({rate(q['confirmed'],q['total'])}) | "
                        f"противоположное {q['opposite']} | "
                        f"средняя вероятность {pct(q.get('mean_confidence'))}")
            confidence=(conf_line('HIGH_80_PLUS')+'\n'+conf_line('MEDIUM_60_79')+'\n'+conf_line('LOW_BELOW_60')+'\n\n'
                        '80%+ — отдельный строгий разбор ошибок высокой уверенности.\n'
                        'Ниже 80% — результат не считается такой же ошибкой автоматически: программа проверяет, насколько исходная вероятность соответствовала факту, и ищет признаки, которые были недооценены или переоценены.')
            self.results_box.add_widget(self._stat_section('3. КАЛИБРОВКА ВЕРОЯТНОСТЕЙ', confidence, self._accent))

            recent=(f"Последние 100 торговых прогнозов: " + (f"{r100['total']} проверено\nТочность TP1: {rate(r100['correct'],r100['total'])}\nTP1: {rate(r100['tp1'],r100['total'])}\nSL до TP1: {rate(r100['sl'],r100['total'])}" if r100['total'] else 'ещё недостаточно данных') + '\n\n'
                    f"Последние 500 торговых прогнозов: " + (f"{r500['total']} проверено\nТочность TP1: {rate(r500['correct'],r500['total'])}\nTP1: {rate(r500['tp1'],r500['total'])}\nSL до TP1: {rate(r500['sl'],r500['total'])}" if r500['total'] else 'ещё недостаточно данных'))
            self.results_box.add_widget(self._stat_section('4. ТЕКУЩАЯ ДИНАМИКА', recent, self._text))

            validation=(f"Независимая валидация: {d['validation_rows']} строк тестовой выборки\n"
                        f"Принятых champion-моделей: {d['accepted_models']}\n"
                        f"Balanced accuracy: {d['balanced_accuracy']:.1%}\n"
                        f"LONG/SHORT precision: {d['directional_precision']:.1%}\n"
                        f"Доля активных прогнозов в валидации: {d['validation_action_rate']:.1%}\n\n"
                        "Эти строки — тестовые данные модели, а не количество реальных прогнозов. Они не должны смешиваться с блоком TP/SL выше.")
            self.results_box.add_widget(self._stat_section('5. НЕЗАВИСИМАЯ ВАЛИДАЦИЯ', validation, self._accent))

            why=("Проверено прогнозов — только полностью завершённые проверки.\n"
                 "Первый час — только начальное окно. Если TP1 и защитный уровень не достигнуты, прогноз остаётся в ожидании.\n"
                 "После TP1 защита переносится на Entry (безубыток); после TP2 — на TP1.\n"
                 "Возврат к Entry/TP1 после достигнутой цели НЕ считается ошибкой и НЕ записывается как SL.\n"
                 "SL считается отрицательным результатом только если цена достигла исходного SL ДО TP1.\n"
                 "TP1/TP2/TP3 — накопительные достижения. Основной результат — максимальный достигнутый TP.\n"
                 "Модель учится на глубине движения от Entry, MFE и достигнутом уровне, а не на последующем возврате к исходному SL.\n"
                 "Не более 10 долгоиграющих прогнозов проверяются одновременно; остальные стоят в очереди и не меняют исходные уровни.\n"
                 "При одновременном попадании исходного SL и TP1 в одной 5m-свече используется консервативное правило: SL считается первым.")
            self.results_box.add_widget(self._stat_section('6. ЧТО ОЗНАЧАЮТ ЦИФРЫ', why, self._muted))

            reasons='\n'.join('• '+x for x in r['reasons']) if r['reasons'] else '• Все критерии пройдены.'
            ready=(f"Текущая готовность: {score}/10\n\nНе пройдены критерии:\n{reasons}\n\n"
                    "10/10 означает прохождение заданных статистических критериев, а не гарантию прибыли.")
            self.results_box.add_widget(self._stat_section('7. ПОЧЕМУ СЕЙЧАС '+str(score)+'/10', ready, self._red if not r['ready'] else self._green))

            back=self.style_button(ExpandedTouchButton(text='← НА ГЛАВНУЮ',size_hint_y=None,height=dp(50)),fs=12)
            back.bind(on_release=lambda *_: self.bottom_nav('scanner'))
            self.results_box.add_widget(back)
        except Exception as e:
            self.status_card.text='Ошибка статистики: '+str(e)

    def toggle_more_actions(self, *_):
        # Compatibility alias: there is intentionally no separate MORE control.
        self.toggle_main_menu()

    def _run_more_action(self, fn):
        self._hide_more_actions()
        fn(None)

    def toggle_menu(self):
        self.toggle_main_menu()

    def export_runtime_log(self, *_):
        if getattr(self, '_runtime_export_running', False):
            return
        self._runtime_export_running = True
        self.status_card.text = 'RUNTIME-ЛОГ: экспортирую в Download…'
        self.append_log('Запущен экспорт runtime-лога (фон)')
        threading.Thread(target=self._runtime_export_worker, daemon=True).start()

    def _runtime_export_worker(self):
        try:
            parts = []
            if self._runtime_log_path.exists():
                parts.append(self._runtime_log_path.read_text(encoding='utf-8', errors='replace'))
            st = self._read_bg_state()
            tail = st.get('runtime_log_tail') or []
            if tail:
                parts.append('\n'.join(tail))
            text = '\n'.join(x for x in parts if x).strip() or 'No runtime diagnostics recorded yet.'
            if platform == 'android':
                from jnius import autoclass
                Environment = autoclass('android.os.Environment')
                MediaStore = autoclass('android.provider.MediaStore')
                ContentValues = autoclass('android.content.ContentValues')
                JString = autoclass('java.lang.String')
                JInteger = autoclass('java.lang.Integer')
                activity = autoclass('org.kivy.android.PythonActivity').mActivity
                resolver = activity.getContentResolver()
                values = ContentValues()
                log_name = f"SelfLearningTrader_HUNDRED_runtime_{time.strftime('%Y%m%d_%H%M%S')}.log"
                values.put(JString('_display_name'), JString(log_name))
                values.put(JString('mime_type'), JString('text/plain'))
                values.put(JString('relative_path'), JString(Environment.DIRECTORY_DOWNLOADS))
                values.put(JString('is_pending'), JInteger(1))
                collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
                uri = resolver.insert(collection, values)
                if uri is None:
                    raise RuntimeError('Android не создал файл в Downloads')
                stream = resolver.openOutputStream(uri)
                try:
                    stream.write(text.encode('utf-8'))
                finally:
                    stream.close()
                done = ContentValues()
                done.put(JString('is_pending'), JInteger(0))
                resolver.update(uri, done, None, None)
                result = (True, 'RUNTIME-ЛОГ ЭКСПОРТИРОВАН\nDownloads → ' + log_name)
            else:
                out = Path.home() / 'SelfLearningTrader_HUNDRED_runtime.log'
                out.write_text(text, encoding='utf-8')
                result = (True, 'RUNTIME-ЛОГ ЭКСПОРТИРОВАН\n' + str(out))
        except Exception as exc:
            result = (False, 'Ошибка экспорта runtime-лога: ' + str(exc))
        Clock.schedule_once(lambda dt, result=result: self._finish_runtime_export(result), 0)

    def _finish_runtime_export(self, result):
        self._runtime_export_running = False
        if self._nav_mode != 'backup':
            return
        ok, msg = result
        self.status_card.text = msg
        self.append_log(msg)

    def import_runtime_log(self, *_):
        """Find exported runtime logs without blocking the Android UI thread."""
        if self._runtime_import_running or self._nav_mode != 'backup':
            return
        self._runtime_import_running = True
        self.status_card.text = 'RUNTIME-ЛОГ: ищу файлы в Download…'
        threading.Thread(target=self._runtime_import_list_worker, daemon=True).start()

    def _runtime_import_list_worker(self):
        try:
            items = self._list_runtime_logs()
            result = (True, items, '')
        except Exception as exc:
            result = (False, [], str(exc))
        Clock.schedule_once(lambda dt, result=result: self._finish_runtime_import_list(result), 0)

    def _finish_runtime_import_list(self, result):
        self._runtime_import_running = False
        if self._nav_mode != 'backup':
            return
        ok, items, error = result
        if not ok:
            self.status_card.text = 'Ошибка поиска runtime-логов: ' + error
            self.append_log('Ошибка импорта runtime-лога: ' + error)
            return
        if not items:
            self.status_card.text = 'В Download нет экспортированных runtime-логов.'
            self.append_log('Импорт runtime-лога: файлы не найдены')
            return
        box = BoxLayout(orientation='vertical', spacing=dp(6), padding=dp(8))
        popup = Popup(title='Выберите runtime-лог', content=box, size_hint=(0.94,0.72), auto_dismiss=False)
        for name, src in items[:15]:
            b = self.style_button(ExpandedTouchButton(text=name, size_hint_y=None, height=dp(46)), fs=10)
            b.bind(on_release=lambda btn,n=name,s=src: (popup.dismiss(), Clock.schedule_once(lambda dt: self._import_runtime_log_source(n,s), 0)))
            box.add_widget(b)
        close = self.style_button(ExpandedTouchButton(text='ЗАКРЫТЬ', size_hint_y=None, height=dp(46)), fs=11)
        close.bind(on_release=lambda *_: popup.dismiss())
        box.add_widget(close)
        popup.open()

    def _list_runtime_logs(self):
        out=[]
        if platform != 'android':
            d=Path.home()
            return [(p.name,str(p)) for p in sorted(d.glob('SelfLearningTrader_HUNDRED_runtime_*.log'), key=lambda x:x.stat().st_mtime, reverse=True)]
        from jnius import autoclass
        activity=autoclass('org.kivy.android.PythonActivity').mActivity
        resolver=activity.getContentResolver()
        Build=autoclass('android.os.Build')
        if int(Build.VERSION.SDK_INT) >= 29:
            MediaStore=autoclass('android.provider.MediaStore')
            projection=['_id','_display_name','date_modified']
            cur=resolver.query(MediaStore.Downloads.EXTERNAL_CONTENT_URI, projection, None, None, 'date_modified DESC')
            if cur:
                try:
                    while cur.moveToNext():
                        name=str(cur.getString(cur.getColumnIndex('_display_name')))
                        if name.startswith('SelfLearningTrader_HUNDRED_runtime_') and name.endswith('.log'):
                            ident=cur.getLong(cur.getColumnIndex('_id'))
                            uri=MediaStore.Downloads.EXTERNAL_CONTENT_URI.buildUpon().appendPath(str(ident)).build()
                            out.append((name,str(uri.toString())))
                finally:
                    cur.close()
        else:
            Environment=autoclass('android.os.Environment')
            d=Path(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath())
            out=[(p.name,str(p)) for p in sorted(d.glob('SelfLearningTrader_HUNDRED_runtime_*.log'), key=lambda x:x.stat().st_mtime, reverse=True)]
        return out

    def _import_runtime_log_source(self, name, source):
        try:
            if str(source).startswith('content://'):
                from jnius import autoclass
                activity=autoclass('org.kivy.android.PythonActivity').mActivity
                Uri=autoclass('android.net.Uri')
                stream=activity.getContentResolver().openInputStream(Uri.parse(str(source)))
                chunks=[]
                buf=bytearray(65536)
                while True:
                    n=stream.read(buf)
                    if n < 0: break
                    chunks.append(bytes(buf[:n]))
                stream.close()
                text=''.join(x.decode('utf-8','replace') for x in chunks)
            else:
                text=Path(source).read_text(encoding='utf-8', errors='replace')
            if not text.strip():
                raise RuntimeError('Выбранный лог пустой')
            # Preserve imported diagnostics separately; never overwrite the live log.
            target=self._bg_root / ('imported_' + str(name))
            target.write_text(text, encoding='utf-8')
            self.status_card.text=f'RUNTIME-ЛОГ ИМПОРТИРОВАН\n{name}'
            self._log_lines.extend([x for x in text.splitlines() if x][-12:])
            self._log_lines=self._log_lines[-12:]
            if hasattr(self,'log_box'):
                self.log_box.text='\n'.join(self._log_lines)
            self.append_log('Импортирован runtime-лог: ' + str(name))
        except Exception as exc:
            self.status_card.text='Ошибка импорта runtime-лога: ' + str(exc)
            self.append_log('Ошибка импорта runtime-лога: ' + str(exc))

    def show_log_screen(self, *_):
        self.main_menu_box.disabled = True
        self.main_menu_box.opacity = 0
        self.main_menu_box.height = 0
        self.control_btn.text = '☰'
        self._nav_mode = 'analysis'
        self._clear_work_area()
        self.top_title.text = 'ЖУРНАЛ'
        self.status_card.text = 'Последние события работы программы.'
        self.log_box.opacity = 1
        self.log_box.height = max(dp(180), dp(24) * max(1, len(self._log_lines)))
        self.log_box.text = '\n'.join(self._log_lines[-50:]) if self._log_lines else 'Журнал пока пуст.'

    def toggle_log(self, *_):
        self._log_open = not self._log_open
        self.log_box.opacity = 1 if self._log_open else 0
        self.log_box.height = dp(120) if self._log_open else 0

    def append_log(self, text):
        line = f"{time.strftime('%Y-%m-%d %H:%M:%S')} [APP] {text}"
        try:
            self._runtime_log_path.parent.mkdir(parents=True, exist_ok=True)
            with self._runtime_log_path.open('a', encoding='utf-8') as fh:
                fh.write(line + '\n')
        except Exception:
            pass
        self._log_lines.append(str(text))
        self._log_lines = self._log_lines[-12:]
        self._save_session_state()
        if self._log_open:
            self.log_box.text = '\n'.join(self._log_lines)

    def _save_session_state(self):
        """Persist the visible app state so Android process recreation does not erase the work/results."""
        try:
            if not self._session_path:
                return
            data = {
                'last_top5': self._last_top5[:5],
                'scan_rows': self._scan_rows[:5],
                'status': self.status_card.text if hasattr(self, 'status_card') else '',
                'log_lines': self._log_lines[-12:],
                'nav_mode': self._nav_mode,
                'selected_text': self.selected_label.text if hasattr(self, 'selected_label') else '',
                'selected_height': self.selected_label.height if hasattr(self, 'selected_label') else 0,
                'saved_at': time.strftime('%Y-%m-%d %H:%M:%S'),
            }
            self._session_path.parent.mkdir(parents=True, exist_ok=True)
            self._session_path.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
        except Exception:
            pass

    def _restore_session_state(self):
        try:
            if not self._session_path or not self._session_path.exists():
                return
            data=json.loads(self._session_path.read_text(encoding='utf-8'))
            if isinstance(data, dict):
                if data.get('last_top5'):
                    self._last_top5=[dict(x) for x in data.get('last_top5', [])][:5]
                if data.get('scan_rows'):
                    self._scan_rows=[dict(x) for x in data.get('scan_rows', [])][:5]
                self._restored_status=data.get('status','')
                self._log_lines=list(data.get('log_lines', []))[-12:]
        except Exception:
            pass

    def _load_top5_history(self):
        try:
            if self._history_path and self._history_path.exists():
                data = json.loads(self._history_path.read_text(encoding='utf-8'))
                self._top5_history = data if isinstance(data, list) else []
                self._last_top5 = list(self._top5_history[0].get('rows', [])) if self._top5_history else []
            if self._last100_path and self._last100_path.exists():
                data100 = json.loads(self._last100_path.read_text(encoding='utf-8'))
                self._top5_last100 = data100 if isinstance(data100, list) else []
                self._top5_last100 = self._top5_last100[-100:]
            elif self._top5_history:
                # Migrate the existing 20 saved TOP-5 cycles into the new flat 100-position history.
                migrated = []
                for item in reversed(self._top5_history[:20]):
                    stamp = item.get('time', '—')
                    cycle = int(item.get('cycle', 0) or 0)
                    for rank, row in enumerate(list(item.get('rows') or [])[:5], 1):
                        migrated.append({
                            'time': stamp,
                            'cycle': cycle,
                            'rank': rank,
                            'symbol': str(row.get('symbol') or row.get('exchange_symbol') or '?'),
                            'prediction': str(row.get('prediction') or 'WAIT'),
                        })
                self._top5_last100 = migrated[-100:]
                if self._last100_path:
                    self._last100_path.parent.mkdir(parents=True, exist_ok=True)
                    self._last100_path.write_text(json.dumps(self._top5_last100, ensure_ascii=False), encoding='utf-8')
        except Exception:
            self._top5_history = []
            self._top5_last100 = []
            self._last_top5 = []
        self._manual_wait_id = None
        self._manual_wait_symbol = None

    def _save_top5_history(self):
        try:
            if self._history_path:
                self._history_path.parent.mkdir(parents=True, exist_ok=True)
                self._history_path.write_text(json.dumps(self._top5_history[:20], ensure_ascii=False), encoding='utf-8')
            if self._last100_path:
                self._last100_path.parent.mkdir(parents=True, exist_ok=True)
                self._last100_path.write_text(json.dumps(self._top5_last100[-100:], ensure_ascii=False), encoding='utf-8')
        except Exception as e:
            self.append_log('Не удалось сохранить историю TOP-5: ' + str(e))

    def _record_top5_history(self, rows, cycle=None):
        """Record one completed TOP-5 event and flatten it into the last 100 selected coins."""
        rows = [dict(x) for x in list(rows or [])[:5]]
        if not rows:
            return
        stamp = time.strftime('%Y-%m-%d %H:%M:%S')
        entry = {'time': stamp, 'rows': rows}
        if cycle is not None:
            entry['cycle'] = int(cycle or 0)
        self._top5_history.insert(0, entry)
        self._top5_history = self._top5_history[:20]
        history_keys = (
            'id', 'time', 'symbol', 'exchange_symbol', 'contract', 'price', 'prediction',
            'p_short', 'p_wait', 'p_long', 'entry', 'sl', 'tp1', 'tp2', 'tp3',
            'horizon_bars', 'resolved', 'actual', 'return', 'hit', 'result',
            'exit_reason', 'protected_exit', 'tp1_hit', 'tp2_hit', 'tp3_hit',
            'sl_hit', 'initial_sl_failure', 'mfe', 'mae', 'resolved_at',
            'verification_state', 'verification_elapsed_bars',
        )
        for rank, row in enumerate(rows, 1):
            history_item = {
                'time': stamp,
                'cycle': int(cycle or 0),
                'rank': rank,
                'symbol': str(row.get('symbol') or row.get('exchange_symbol') or '?'),
                'prediction': str(row.get('prediction') or 'WAIT'),
            }
            for key in history_keys:
                if key in row:
                    history_item[key] = row.get(key)
            # Keep the history row tied to the exact persisted prediction so
            # the expanded view can show the later TP/SL resolution.
            history_item['id'] = row.get('id') or history_item.get('id')
            history_item['contract'] = row.get('contract') or row.get('exchange_symbol')
            self._top5_last100.append(history_item)
        self._top5_last100 = self._top5_last100[-100:]
        self._save_top5_history()

    def _history_prediction_data(self, item):
        """Return the newest persisted prediction data for one history row."""
        merged = dict(item or {})
        pid = merged.get('id')
        contract = str(merged.get('contract') or merged.get('exchange_symbol') or '').strip()
        candidates = []
        try:
            if contract:
                candidates.append(self.engine.logs / f'{contract}_predictions.json')
            if not candidates:
                candidates = list(self.engine.logs.glob('*_predictions.json'))
            for path in candidates:
                try:
                    data = json.loads(path.read_text(encoding='utf-8'))
                except Exception:
                    continue
                if not isinstance(data, list):
                    continue
                if pid:
                    matches = [x for x in data if x.get('id') == pid]
                else:
                    matches = []
                if matches:
                    merged.update(matches[-1])
                    return merged
        except Exception:
            pass

        # Older last-100 entries did not store the prediction id. Recover the
        # original TOP-5 row by cycle/rank when it is still present in the
        # detailed TOP-5 history.
        try:
            cycle = int(merged.get('cycle', 0) or 0)
            rank = int(merged.get('rank', 0) or 0)
            for record in self._top5_history:
                if int(record.get('cycle', 0) or 0) != cycle:
                    continue
                rows = list(record.get('rows') or [])
                if 1 <= rank <= len(rows):
                    merged.update(rows[rank - 1])
                    break
        except Exception:
            pass
        return merged

    @staticmethod
    def _history_number(value):
        try:
            return f'{float(value):.8g}'
        except Exception:
            return '—'

    def _history_result_text(self, data):
        """Describe the existing TP1/TP2/TP3/SL resolution without changing it."""
        pred = str(data.get('prediction') or 'WAIT').upper()
        if pred not in ('LONG', 'SHORT'):
            return 'Результат: WAIT / торговый прогноз не сформирован'

        tp1 = bool(data.get('tp1_hit'))
        tp2 = bool(data.get('tp2_hit'))
        tp3 = bool(data.get('tp3_hit'))
        initial_sl = bool(data.get('initial_sl_failure')) or (bool(data.get('sl_hit')) and not tp1)
        resolved = bool(data.get('resolved'))
        protected = bool(data.get('protected_exit'))
        result = str(data.get('result') or '').upper()

        if tp3:
            return 'Результат: TP3 достигнут — успешное завершение'
        if initial_sl and not tp1:
            return 'Результат: SL до TP1 — прогноз неуспешный'
        if tp2:
            if protected or result == 'TP2':
                return 'Результат: TP2 достигнут — защита после TP2 сработала / прогноз завершён на TP2' if resolved else 'Результат: TP2 достигнут — ожидание TP3'
            return 'Результат: TP2 достигнут — ожидание TP3'
        if tp1:
            if protected or result == 'TP1':
                return 'Результат: TP1 достигнут — защита на Entry, безубыточный выход' if resolved else 'Результат: TP1 достигнут — ожидание TP2'
            return 'Результат: TP1 достигнут — ожидание TP2'
        state = str(data.get('verification_state') or '').upper()
        if not resolved or state in ('INITIAL_WAIT', 'LONG_RUNNING_WAITING', 'WAITING_TP2', 'WAITING_TP3', 'ACTIVE', 'QUEUED'):
            return 'Результат: ещё проверяется'
        return f'Результат: {result or "не определён"}'

    def _toggle_last100_item(self, index, row_box, detail_label, item):
        if self._last100_expanded_index == index:
            detail_label.text = ''
            detail_label.opacity = 0
            detail_label.height = 0
            row_box.height = dp(48)
            self._last100_expanded_index = None
            return

        # Only one history row is expanded at a time. Collapse the previous
        # row without rebuilding or navigating away from the current screen.
        previous = getattr(self, '_last100_expanded_widgets', {}).get(self._last100_expanded_index)
        if previous:
            prev_box, prev_detail = previous
            prev_detail.text = ''
            prev_detail.opacity = 0
            prev_detail.height = 0
            prev_box.height = dp(48)

        data = self._history_prediction_data(item)
        pred = str(data.get('prediction') or 'WAIT').upper()
        lines = [
            f'Направление: {pred}',
            f'Entry: {self._history_number(data.get("entry"))}',
            f'SL: {self._history_number(data.get("sl"))}',
            f'TP1: {self._history_number(data.get("tp1"))}',
            f'TP2: {self._history_number(data.get("tp2"))}',
            f'TP3: {self._history_number(data.get("tp3"))}',
        ]
        reached = [name for name, key in (('TP1', 'tp1_hit'), ('TP2', 'tp2_hit'), ('TP3', 'tp3_hit')) if bool(data.get(key))]
        lines.append('Достигнуто: ' + (', '.join(reached) if reached else 'нет'))
        if reached:
            lines.append('Максимум: ' + reached[-1])
        else:
            lines.append('Максимум: нет достигнутой цели')
        lines.append(self._history_result_text(data))
        if data.get('exit_reason'):
            lines.append('Причина выхода: ' + str(data.get('exit_reason')))
        if data.get('resolved_at'):
            lines.append('Проверен: ' + str(data.get('resolved_at')))

        detail_label.text = '\n'.join(lines)
        detail_label.opacity = 1
        detail_label.height = dp(12)
        detail_label.texture_update()
        detail_label.height = max(dp(132), detail_label.texture_size[1] + dp(16))
        row_box.height = dp(48) + detail_label.height + dp(6)
        self._last100_expanded_index = index

    def show_last100_top5(self, *_):
        # This is a dedicated history screen.  The background scanner poll
        # must not redraw the live TOP-5 over it while the service is running.
        self._nav_mode = 'last100'
        self._hide_more_actions()
        self._last100_expanded_index = None
        self._last100_expanded_widgets = {}
        self.top_title.text = 'ПОСЛЕДНИЕ 100 МОНЕТ TOP-5'
        self.status_card.text = 'Нажми на любую монету: строка развернётся прямо здесь и покажет Entry, SL, TP1–TP3 и фактический результат.'
        self.results_box.clear_widgets()
        if not self._top5_last100:
            self.results_box.add_widget(Label(text='История TOP-5 пока пуста. Она начнёт заполняться после завершения новых циклов.', color=self._muted, size_hint_y=None, height=dp(64), halign='left'))
            return
        for index, item in enumerate(reversed(self._top5_last100)):
            data = self._history_prediction_data(item)
            pred = str(data.get('prediction') or item.get('prediction') or 'WAIT').upper()
            badge, _badge_color = self._top5_result_badge(data)
            color = self._green if pred == 'LONG' else self._red if pred == 'SHORT' else self._panel2
            cycle = item.get('cycle', 0)
            txt = f"{item.get('time','—')}   #{item.get('rank','—')}   {item.get('symbol','?')}   {pred}   {badge}"
            if cycle:
                txt += f"   цикл {cycle}"

            row_box = BoxLayout(orientation='vertical', size_hint_y=None, height=dp(48), spacing=dp(3))
            header = ExpandedTouchButton(text=txt, size_hint_y=None, height=dp(48),
                                        background_normal='', background_color=color, color=self._text,
                                        font_size='11sp', halign='left', valign='middle', padding=(dp(10), dp(4)))
            header.bind(size=lambda o,v:setattr(o,'text_size',(max(dp(120),o.width-dp(18)),None)))
            detail = Label(text='', size_hint_y=None, height=0, opacity=0,
                           color=self._text, font_size='11sp', halign='left', valign='top',
                           padding=(dp(10), dp(7)))
            detail.bind(width=lambda o,v:setattr(o,'text_size',(max(dp(120),v-dp(20)),None)))
            detail.bind(texture_size=lambda o,v: setattr(o, 'height', max(dp(132), v[1] + dp(16)) if o.opacity else 0))
            header.bind(on_release=lambda btn, i=index, rb=row_box, dl=detail, x=dict(item): self._toggle_last100_item(i, rb, dl, x))
            row_box.add_widget(header)
            row_box.add_widget(detail)
            self._last100_expanded_widgets[index] = (row_box, detail)
            self.results_box.add_widget(row_box)
        back = self.style_button(ExpandedTouchButton(text='← НАЗАД К СКАНЕРУ', size_hint_y=None, height=dp(48)), fs=12)
        back.bind(on_release=lambda *_: self.bottom_nav('scanner'))
        self.results_box.add_widget(back)

    def _hide_more_actions(self):
        return None

    def _clear_work_area(self):
        self.results_box.clear_widgets()
        self.calc_box.clear_widgets()
        self.log_box.opacity = 0
        self.log_box.height = 0
        self._log_open = False
        self._hide_more_actions()
        self._detail_open = False
        self.selected_label.height = 0
        self.selected_label.text = ''

    def bottom_nav(self, mode):
        # Every tab is a real screen: clear the previous screen first.
        # Data/history stay in memory (and TOP-5 is persisted), but old widgets
        # are never left stacked underneath the new screen.
        self._nav_mode = mode
        try:
            self._clear_work_area()
            if mode == 'scanner':
                self.show_scanner()
            elif mode == 'analysis':
                self.show_analysis()
            elif mode == 'model':
                self.show_model()
            elif mode == 'settings':
                self.show_settings()
            self._sync_stop_button_visibility()
            self.scroll.scroll_y = 1
        except Exception as e:
            self.top_title.text = 'ОШИБКА РАЗДЕЛА'
            self.status_card.text = 'Не удалось открыть раздел.\n' + str(e)
            self.append_log('Ошибка навигации: ' + str(e))

    def clear_main(self):
        self._clear_work_area()
        self.status_card.text = ''

    def show_scanner(self):
        self._set_stop_control_screen(True)
        self.top_title.text = 'ТОП-5 ПРОГНОЗОВ'
        self.status_card.text = ('Последний TOP-5 сохранён.' if self._last_top5 else 'Когда модель достигнет готовности, открой ⋮ → ПОЛУЧИТЬ 5 ПРОГНОЗОВ.')
        self.render_top5(self._last_top5)
        self._sync_stop_button_visibility()
        self._sync_menu_stop()
        self._refresh_dashboard()

    def show_analysis(self):
        self._set_stop_control_screen(False)
        self.top_title.text = 'АНАЛИЗ'
        stats = self.engine.stats()
        last = self._last_prediction
        live_acc = stats['live_accuracy']
        live_acc_text = '—' if live_acc is None else f'{live_acc:.1%}'
        txt = (
            f"ПРОГНОЗОВ СОХРАНЕНО: {stats['predictions']}\n"
            f"ОЖИДАЮТ ПРОВЕРКИ: {stats['pending']}\n"
            f"ПРОВЕРЕНО: {stats['resolved']}\n"
            f"ПРАВИЛЬНЫХ: {stats['correct']}\n"
            f"LIVE ACCURACY: {live_acc_text}\n\n"
        )
        if last:
            self.selected_label.height = dp(24)
            self.selected_label.text = f"Анализ: {last['symbol']} [{last['exchange_symbol']}]"
            txt += self._prediction_text(last)
        else:
            txt += 'Выбери монету и запусти LIVE-прогноз.'
        self.status_card.text = txt
        self.stop_btn.opacity = 0
        self.stop_btn.disabled = True
        back = self.style_button(ExpandedTouchButton(text='← НА ГЛАВНУЮ', size_hint_y=None, height=dp(48)), fs=12)
        back.bind(on_release=lambda *_: self.bottom_nav('scanner'))
        self.results_box.add_widget(back)

    def show_model(self):
        self._set_stop_control_screen(False)
        self.top_title.text = 'AI МОДЕЛЬ'
        self.stop_btn.opacity = 0
        self.stop_btn.disabled = True
        self.results_box.clear_widgets()
        self.calc_box.clear_widgets()
        self.status_card.text = 'Проверяю состояние AI-модели...'

        # Training, self-learning and old-prediction verification are automatic
        # background operations.  There are deliberately no manual action
        # buttons here anymore.

        def inspect():
            try:
                ready = bool(self.engine.mm.has_champion())
                meta = {}
                if self.engine.mm.meta.exists():
                    meta = json.loads(self.engine.mm.meta.read_text(encoding='utf-8'))
                lines = [f"Статус champion-модели: {'ГОТОВА' if ready else 'НЕТ'}"]
                if meta:
                    lines += [
                        f"Признаков: {meta.get('feature_count', '—')}",
                        f"Строк: {meta.get('rows', '—')}",
                        f"Accuracy: {float(meta.get('accuracy', 0)):.3f}",
                        f"Balanced accuracy: {float(meta.get('balanced_accuracy', 0)):.3f}",
                    ]
                else:
                    lines.append('Обучи модель для текущего выбранного инструмента.')
                return '\n'.join(lines)
            except Exception as e:
                return 'Ошибка чтения состояния модели: ' + str(e)

        def apply(text):
            if self._nav_mode == 'model':
                self.status_card.text = text

        threading.Thread(target=lambda: Clock.schedule_once(lambda dt: apply(inspect()), 0), daemon=True).start()
        back = self.style_button(ExpandedTouchButton(text='← НА ГЛАВНУЮ', size_hint_y=None, height=dp(48)), fs=12)
        back.bind(on_release=lambda *_: self.bottom_nav('scanner'))
        self.results_box.add_widget(back)

    def show_settings(self):
        self._set_stop_control_screen(False)
        self.top_title.text = 'НАСТРОЙКИ'
        self.stop_btn.opacity = 0
        self.stop_btn.disabled = True
        self.status_card.text = 'Настройки реально изменяют параметры сканирования и обучения. Нажми Сохранить.'
        self.results_box.clear_widgets()
        self.calc_box.clear_widgets()
        grid = GridLayout(cols=2, spacing=dp(6), size_hint_y=None, padding=(0, dp(4)))
        grid.bind(minimum_height=grid.setter('height'))
        self._settings_inputs = {}
        specs = [
            ('История свечей', 'history_limit'), ('Горизонт, свечей', 'horizon_bars'),
            ('LONG threshold', 'long_threshold'), ('SHORT threshold', 'short_threshold'),
            ('Минимум строк обучения', 'min_training_rows'), ('Test fraction', 'test_fraction'),
            ('Переобучение каждые N результатов', 'retrain_batch_size'),
            ('Минимум прогнозов для готовности', 'readiness_min_resolved'),
            ('Минимальная точность готовности', 'readiness_min_accuracy')]
        for label, key in specs:
            grid.add_widget(Label(text=label, color=self._text, halign='left'))
            inp = TextInput(text=str(self.engine.cfg.get(key, '')), multiline=False, size_hint_y=None, height=dp(44))
            self._settings_inputs[key] = inp; grid.add_widget(inp)
        self.results_box.add_widget(grid)
        save = self.style_button(ExpandedTouchButton(text='СОХРАНИТЬ НАСТРОЙКИ', size_hint_y=None, height=dp(54)), accent=True, fs=13)
        save.bind(on_release=self.save_settings); self.results_box.add_widget(save)
        reset = self.style_button(ExpandedTouchButton(text='ВОССТАНОВИТЬ НАСТРОЙКИ ПО УМОЛЧАНИЮ', size_hint_y=None, height=dp(50)), fs=12)
        reset.bind(on_release=self.reset_settings); self.results_box.add_widget(reset)
        back = self.style_button(ExpandedTouchButton(text='← НА ГЛАВНУЮ', size_hint_y=None, height=dp(48)), fs=12)
        back.bind(on_release=lambda *_: self.bottom_nav('scanner'))
        self.results_box.add_widget(back)

    def show_backup(self, *_):
        # Backup is a dedicated screen.  A running background scanner may continue
        # to update its state, but it must never rebuild or replace this screen.
        self._backup_screen_generation += 1
        self._nav_mode = 'backup'
        self._set_stop_control_screen(False)
        self.top_title.text = 'РЕЗЕРВНАЯ КОПИЯ'
        self.stop_btn.opacity = 0; self.stop_btn.disabled = True
        self.results_box.clear_widgets()
        info=Label(text='Резервная копия сохраняет обученные модели, поколения, историю прогнозов, ошибки, статистику и состояние самообучения. Её можно перенести на другой телефон или планшет.', color=self._text, halign='left', valign='top', size_hint_y=None, height=dp(90))
        info.bind(size=lambda o,v:setattr(o,'text_size',(v[0],None)))
        self.results_box.add_widget(info)
        exp=self.style_button(ExpandedTouchButton(text='ЭКСПОРТ ОБУЧЕННОЙ МОДЕЛИ', size_hint_y=None, height=dp(54)), accent=True, fs=12)
        exp.bind(on_release=lambda *_: self._backup_ui_action(self.export_learning_backup)); self.results_box.add_widget(exp)
        imp=self.style_button(ExpandedTouchButton(text='ИМПОРТ ОБУЧЕННОЙ МОДЕЛИ', size_hint_y=None, height=dp(54)), fs=12)
        imp.bind(on_release=lambda *_: self._backup_ui_action(self.import_learning_backup)); self.results_box.add_widget(imp)
        chk=self.style_button(ExpandedTouchButton(text='ПРОВЕРИТЬ РЕЗЕРВНЫЕ КОПИИ И ОШИБКИ', size_hint_y=None, height=dp(54)), fs=12)
        chk.bind(on_release=lambda *_: self._backup_ui_action(self.check_backups_and_errors)); self.results_box.add_widget(chk)
        le=self.style_button(ExpandedTouchButton(text='ЭКСПОРТ RUNTIME-ЛОГА', size_hint_y=None, height=dp(50)), fs=11)
        le.bind(on_release=lambda *_: self._backup_ui_action(self.export_runtime_log)); self.results_box.add_widget(le)
        li=self.style_button(ExpandedTouchButton(text='ИМПОРТ RUNTIME-ЛОГА', size_hint_y=None, height=dp(50)), fs=11)
        li.bind(on_release=lambda *_: self._backup_ui_action(self.import_runtime_log)); self.results_box.add_widget(li)
        back=self.style_button(ExpandedTouchButton(text='← НА ГЛАВНУЮ', size_hint_y=None, height=dp(48)), fs=12)
        back.bind(on_release=lambda *_: self.bottom_nav('scanner')); self.results_box.add_widget(back)

    def _backup_ui_action(self, fn):
        """Run a backup/runtime action after the current Android touch event settles."""
        if self._nav_mode != 'backup':
            return
        Clock.schedule_once(lambda dt: self._safe_backup_ui_action(fn), 0)

    def _safe_backup_ui_action(self, fn):
        if self._nav_mode != 'backup':
            return
        try:
            fn()
        except Exception:
            self.status_card.text = 'Ошибка действия резервной копии. Подробности записаны в runtime-лог.'
            self.append_log('Ошибка backup/runtime UI action: ' + traceback.format_exc())

    def check_backups_and_errors(self, *_):
        """Run integrity checks off the Kivy UI thread so Android cannot kill/freeze the activity."""
        if getattr(self, '_backup_check_running', False):
            return
        self._backup_check_running = True
        self.status_card.text = 'ПРОВЕРКА: выполняю проверку в фоне…'
        self.append_log('Запущена полная проверка ошибок и резервных копий (фон)')
        # Disable the source button while the worker is reading ZIPs/JSON files.
        for child in list(self.results_box.children):
            if isinstance(child, ExpandedTouchButton) and 'ПРОВЕРИТЬ РЕЗЕРВНЫЕ' in child.text:
                child.disabled = True
        user_dir = Path(App.get_running_app().user_data_dir)
        threading.Thread(target=self._backup_check_worker, args=(user_dir,), daemon=True).start()

    def _backup_check_worker(self, user_dir):
        try:
            checks = []
            for rel in ('settings.json','session_state.json','top5_history.json','top5_last100.json'):
                path = user_dir / rel
                if path.exists():
                    try:
                        json.loads(path.read_text(encoding='utf-8'))
                        checks.append((rel, True, 'JSON OK'))
                    except Exception as exc:
                        checks.append((rel, False, str(exc)))

            model_errors = 0
            try:
                model_files = user_dir.rglob('*')
                for path in model_files:
                    if not path.is_file() or path.suffix.lower() not in ('.json', '.jsonl'):
                        continue
                    if path.name.endswith('.slbackup'):
                        continue
                    try:
                        if path.stat().st_size == 0:
                            raise ValueError('пустой файл')
                        if path.suffix.lower() == '.json':
                            json.loads(path.read_text(encoding='utf-8'))
                    except Exception as exc:
                        model_errors += 1
                        if len(checks) < 30:
                            try:
                                rel = str(path.relative_to(user_dir))
                            except Exception:
                                rel = path.name
                            checks.append((rel, False, str(exc)))
            except Exception as exc:
                model_errors += 1
                checks.append(('Файлы состояния/модели', False, str(exc)))

            checks.append(('Файлы состояния/модели', model_errors == 0, f'ошибок: {model_errors}'))
            bok, bmsg, bresults = verify_all_backups(user_dir)
            result = (True, checks, model_errors, bok, bmsg, bresults, '')
        except Exception as exc:
            result = (False, [], 0, False, '', [], str(exc))
        Clock.schedule_once(lambda dt, result=result: self._finish_backup_check(result), 0)

    def _finish_backup_check(self, result):
        try:
            if self._nav_mode != 'backup':
                self._backup_check_running = False
                return
            ok, checks, model_errors, bok, bmsg, bresults, error = result
            self._backup_check_running = False
            if not ok:
                self.status_card.text = 'Ошибка проверки: ' + str(error)
                self.append_log('Ошибка полной проверки: ' + str(error))
                return
            self.results_box.clear_widgets()
            all_ok = bok and model_errors == 0
            summary = '✓ ПРОВЕРКА ПРОЙДЕНА' if all_ok else '⚠ НАЙДЕНЫ ПРОБЛЕМЫ'
            color = self._green if all_ok else self._red
            self.results_box.add_widget(self._stat_section(summary, bmsg + '\nПроверка файлов состояния и JSON также выполнена.', color))
            lines = []
            for rel, item_ok, msg in checks:
                lines.append(('✓ ' if item_ok else '✗ ') + rel + ' — ' + msg)
            for r in bresults:
                lines.append(('✓ ' if r['ok'] else '✗ ') + r['name'] + ' — ' + r['message'])
            lab = Label(text='\n'.join(lines) if lines else 'Ошибок не обнаружено.', color=self._text, halign='left', valign='top', size_hint_y=None, text_size=(None, None))
            lab.bind(texture_size=lambda o, v: setattr(o, 'height', v[1]))
            self.results_box.add_widget(lab)
            back = self.style_button(ExpandedTouchButton(text='← НАЗАД', size_hint_y=None, height=dp(50)), fs=12)
            back.bind(on_release=lambda *_: self.show_backup())
            self.results_box.add_widget(back)
            self.status_card.text = summary
            self.append_log('Проверка завершена успешно' if all_ok else 'Проверка завершена: найдены ошибки')
        except Exception as exc:
            self._backup_check_running = False
            self.status_card.text = 'Ошибка отображения проверки: ' + str(exc)
            self.append_log('Ошибка отображения результата проверки: ' + str(exc))

    def export_learning_backup(self, *_):
        if getattr(self, '_backup_export_running', False):
            return
        self._backup_export_running = True
        self.status_card.text = 'РЕЗЕРВНАЯ КОПИЯ: создаю архив и проверяю его…'
        self.append_log('Запущен экспорт полной резервной копии (фон)')
        user_dir = Path(App.get_running_app().user_data_dir)
        threading.Thread(target=self._backup_export_worker, args=(user_dir,), daemon=True).start()

    def _backup_export_worker(self, user_dir):
        try:
            result = export_backup(user_dir)
        except Exception as exc:
            result = (False, 'Ошибка резервной копии: ' + str(exc))
        Clock.schedule_once(lambda dt, result=result: self._finish_backup_export(result), 0)

    def _finish_backup_export(self, result):
        try:
            if self._nav_mode != 'backup':
                self._backup_export_running = False
                return
            self._backup_export_running = False
            ok, msg = result
            self.status_card.text = msg
            self.append_log(msg)
        except Exception as exc:
            self._backup_export_running = False
            self.status_card.text = 'Ошибка отображения результата резервной копии: ' + str(exc)

    def import_learning_backup(self, *_):
        try:
            self.status_card.text = 'ИМПОРТ: ищу резервные копии в Download…'
            items = list_backups()
            if not items:
                self.status_card.text = 'В папке Download нет резервных копий.'
                self.append_log('Импорт резервной копии: файлы не найдены')
                return
            box = BoxLayout(orientation='vertical', spacing=dp(6), padding=dp(8))
            popup = Popup(title='Выберите резервную копию', content=box, size_hint=(0.94,0.72))
            for name, src in items[:10]:
                b = self.style_button(ExpandedTouchButton(text=name, size_hint_y=None, height=dp(48)), fs=10)
                b.bind(on_release=lambda btn,n=name,s=src: self._choose_backup_to_restore(popup,n,s))
                box.add_widget(b)
            close = self.style_button(ExpandedTouchButton(text='ЗАКРЫТЬ', size_hint_y=None, height=dp(46)), fs=11)
            close.bind(on_release=lambda *_: popup.dismiss())
            box.add_widget(close)
            popup.open()
        except Exception as e:
            self.status_card.text='Ошибка поиска резервных копий: '+str(e)
            self.append_log('Ошибка поиска резервных копий: '+str(e))

    def _choose_backup_to_restore(self, popup, name, source):
        try:
            popup.dismiss()
        except Exception:
            pass
        self._restore_selected_backup(name, source)

    def _restore_selected_backup(self, name, source):
        if getattr(self, '_backup_restore_running', False):
            return
        self._backup_restore_running = True
        self.status_card.text = 'ИМПОРТ: проверяю резервную копию…'
        self.append_log('Запущен импорт резервной копии: ' + str(name))
        user_dir = Path(App.get_running_app().user_data_dir)
        threading.Thread(target=self._backup_restore_worker, args=(user_dir,source,name), daemon=True).start()

    def _backup_restore_worker(self, user_dir, source, name):
        try:
            result = restore_backup(user_dir, source)
        except Exception as exc:
            result = (False, 'Ошибка импорта: ' + str(exc))
        Clock.schedule_once(lambda dt, result=result, name=name: self._finish_backup_restore(result,name), 0)

    def _finish_backup_restore(self, result, name):
        try:
            if self._nav_mode != 'backup':
                self._backup_restore_running = False
                return
            self._backup_restore_running = False
            ok, msg = result
            self.status_card.text = msg if ok else 'Ошибка импорта: ' + msg
            self.append_log(('Импортировано: ' if ok else 'Ошибка импорта: ') + str(name))
        except Exception as exc:
            self._backup_restore_running = False
            self.status_card.text = 'Ошибка отображения результата импорта: ' + str(exc)

    def save_settings(self, *_):
        try:
            numeric = {'history_limit': int, 'horizon_bars': int, 'long_threshold': float, 'short_threshold': float, 'min_training_rows': int, 'test_fraction': float, 'retrain_batch_size': int, 'readiness_min_resolved': int, 'readiness_min_accuracy': float}
            for k, fn in numeric.items(): self.engine.cfg[k] = fn(self._settings_inputs[k].text.strip())
            path = self.engine.root / 'settings.json'
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(self.engine.cfg, ensure_ascii=False, indent=2))
            self.status_card.text = 'Настройки сохранены. Новые параметры будут использоваться при следующем сканировании/обучении.'
            self.append_log('Настройки сохранены')
        except Exception as e:
            self.status_card.text = 'Ошибка сохранения настроек: ' + str(e)

    def reset_settings(self, *_):
        defaults = {'history_limit': 5000, 'horizon_bars': 12, 'long_threshold': 0.003, 'short_threshold': -0.003, 'min_training_rows': 500, 'test_fraction': 0.2, 'retrain_batch_size': 25, 'readiness_min_resolved': 1000, 'readiness_min_accuracy': 0.90}
        self.engine.cfg.update(defaults)
        for k, v in defaults.items():
            if hasattr(self, '_settings_inputs') and k in self._settings_inputs: self._settings_inputs[k].text = str(v)
        self.save_settings()

    def _write_bg_control(self, stop=False, run_id=None, prediction_request=False, user_stopped=None):
        try:
            self._bg_control_path.parent.mkdir(parents=True, exist_ok=True)
            payload = {'stop': bool(stop), 'prediction_request': bool(prediction_request)}
            if user_stopped is not None:
                payload['user_stopped'] = bool(user_stopped)
            if run_id is not None:
                payload['run_id'] = int(run_id)
            tmp = self._bg_control_path.with_suffix('.tmp')
            tmp.write_text(json.dumps(payload), encoding='utf-8')
            tmp.replace(self._bg_control_path)
        except Exception:
            pass

    def _read_bg_state(self):
        try:
            if self._bg_state_path.exists():
                return json.loads(self._bg_state_path.read_text(encoding='utf-8'))
        except Exception:
            pass
        return {}

    def _write_monitor_request(self, action, prediction=None):
        try:
            self._bg_root.mkdir(parents=True, exist_ok=True)
            payload={'action':str(action)}
            if prediction is not None:
                payload['prediction']=dict(prediction)
            tmp=self._monitor_request_path.with_suffix('.tmp')
            tmp.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
            tmp.replace(self._monitor_request_path)
            return True
        except Exception as exc:
            self.append_log('Ошибка запроса мониторинга: '+str(exc))
            return False

    def start_selected_monitor(self, prediction):
        if not prediction or not prediction.get('contract'):
            return
        self._write_monitor_request('start', prediction)
        self.status_card.text = (
            f'🔎 НАБЛЮДЕНИЕ: {prediction.get("symbol","—")}\n'
            f'Проверяю изменения рынка каждые N секунд.\n'
            'При существенном изменении появится предупреждение.'
        )
        self.append_log(f'Запущено наблюдение за {prediction.get("symbol","—")}')
        Clock.schedule_once(lambda dt:self._refresh_dashboard(), 0.5)

    def stop_selected_monitor(self, *_):
        self._write_monitor_request('stop')
        self.status_card.text='Наблюдение за выбранной монетой остановлено.'
        self.append_log('Наблюдение остановлено')

    def _update_monitor_ui(self, state):
        mon=state.get('monitor') or {}
        if not mon.get('active'): return
        pred=mon.get('prediction') or {}; sym=pred.get('symbol','—'); alerts=list(mon.get('alerts') or []); pos=mon.get('position') or {}
        lines=[]
        if alerts: lines=['⚠️ ВНИМАНИЕ — '+sym]+[str(a.get('message','')) for a in alerts[-3:]]
        elif pos.get('status')=='OPEN':
            move=float(pos.get('unrealized_move_pct',0) or 0); lines=[f'🟢 ПОЗИЦИЯ: {sym} | {pos.get("direction",pred.get("prediction"))} x{pos.get("leverage",1)}',f'Вход: {pos.get("entry_price")} | Сейчас: {pos.get("current_price")}',f'Движение от фактического входа: {move:+.2f}%']
            if pos.get('post_tp3_learning'): lines.append(f'После TP3: +{float(pos.get("max_extension_beyond_tp3_pct",0) or 0):.2f}% максимального продолжения')
        elif self._nav_mode=='scanner' and self._detail_open: lines=[f'🔎 НАБЛЮДЕНИЕ: {sym}','Существенных изменений не обнаружено.','Проверка продолжается автоматически.']
        if lines: self.status_card.text='\n'.join(lines)

    def _service_state_live(self, state=None):
        state = state or self._read_bg_state()
        status = str(state.get('status',''))
        if status not in ('starting','running','stopping','ready_idle'):
            return False
        hb = int(state.get('heartbeat_at',0) or 0)
        if hb <= 0:
            return False
        return (int(time.time()) - hb) <= 30

    def _start_foreground_scan(self, request_only=False):
        self._bg_stop_requested = False
        current = self._read_bg_state()
        if self._service_state_live(current):
            if request_only:
                self._write_bg_control(False, run_id=current.get('run_id'), prediction_request=True)
            if self._bg_poll_event is None:
                self._bg_poll_event = Clock.schedule_interval(self._poll_foreground_scan, 0.5)
            return
        run_id = int(current.get('run_id', 0) or 0) + 1
        self._write_bg_control(False, run_id=run_id, prediction_request=bool(request_only), user_stopped=False)
        self._scan_running = True
        self._scan_paused = False
        self._scan_worker_active = True
        self._scan_cancel_event = None
        self._detail_open = False
        self._scan_rows = []
        self._scan_seen = []
        self._scan_quick_ok = 0
        self._scan_errors = 0
        self.stop_btn.opacity = 1; self.stop_btn.disabled = False; self.stop_btn.height = dp(52); self.stop_btn.text = 'СТОП'
        self._sync_stop_button_visibility()
        self.results_box.clear_widgets(); self._hide_more_actions()
        self.top_title.text = 'ТОП-5 ЛУЧШИХ КАНДИДАТОВ'
        self.status_card.text = 'AI СКАНИРУЕТ РЫНОК...\nФоновый режим запускается.'
        try:
            self.append_log('RUNTIME: preparing Android Foreground Service')
            from jnius import autoclass
            activity = autoclass('org.kivy.android.PythonActivity').mActivity
            self.append_log('RUNTIME: PythonActivity acquired')
            service_class = 'org.selflearningtrader.selflearningtrader.ServiceScanner'
            self.append_log('RUNTIME: loading ' + service_class)
            service = autoclass(service_class)
            self.append_log('RUNTIME: ServiceScanner class loaded')
            # IMPORTANT: start the generated python-for-android service through
            # its generated start() helper.  Calling Android
            # startForegroundService(Intent(...)) directly does not populate
            # the service intent extras (entrypoint, python home/path,
            # foreground notification data, etc.) that PythonService requires.
            # That caused the service process to be created without a valid
            # Python service payload and the background worker never reached
            # its heartbeat.
            try:
                # Use the generated p4a service helper with an explicit valid
                # notification icon/title. This avoids the empty-icon path on
                # newer Android/p4a combinations while preserving p4a's full
                # service intent payload.
                self.append_log('RUNTIME: calling generated ServiceScanner.start()')
                service.start(activity, 'icon', 'SelfLearningTrader', 'Фоновое самообучение', '')
                self.append_log('RUNTIME: ServiceScanner.start() returned successfully')
            except Exception as first_exc:
                # Fallback to the exact Intent generated by p4a. This keeps all
                # required PythonService extras while bypassing a failing Java
                # convenience wrapper on devices with stricter service startup.
                intent = service.getDefaultIntent(activity, 'icon', 'SelfLearningTrader', 'Фоновое самообучение', '')
                activity.startService(intent)
                self.append_log('RUNTIME: ServiceScanner.start() failed: ' + repr(first_exc))
                self.append_log('RUNTIME: calling generated getDefaultIntent() fallback')
                self.append_log('Foreground Service: fallback Intent start used: ' + str(first_exc))
            if self._bg_poll_event is not None:
                try: self._bg_poll_event.cancel()
                except Exception: pass
            self._bg_poll_event = Clock.schedule_interval(self._poll_foreground_scan, 0.5)
            self.append_log('Foreground Service: generated p4a service.start() requested; waiting for heartbeat')
        except Exception as exc:
            self.append_log('RUNTIME SERVICE START EXCEPTION: ' + traceback.format_exc())
            self._scan_running = False
            self._scan_worker_active = False
            self.stop_btn.disabled = False
            self.stop_btn.text = 'ЗАПУСТИТЬ СКАНИРОВАНИЕ'
            self._scan_paused = False
            self.status_card.text = 'Не удалось запустить фоновый режим:\n' + str(exc)
            self.append_log('Ошибка запуска фонового режима: ' + str(exc))

    def _poll_foreground_scan(self, _dt):
        if not self._scan_running and not self._scan_paused:
            return
        state = self._read_bg_state()
        if self._nav_mode != 'scanner':
            # Background service continues, but UI screens such as BACKUP must
            # remain untouched.  Scanner rendering resumes when user returns.
            self._update_monitor_ui(state) if self._nav_mode == 'scanner' else None
            return
        self._update_monitor_ui(state)
        status = state.get('status')
        if not state:
            return
        try:
            self._update_ready_menu_label()
        except Exception:
            pass
        if status in ('running', 'stopping', 'ready_idle'):
            if not self._service_state_live(state):
                # During RESUME there is a deliberate gap between the old
                # service reaching STOPPED and the replacement service becoming
                # RUNNING/heartbeat-live.  Do not turn that transitional state
                # back into PAUSED/RESUME.  The user already pressed RESUME and
                # the replacement service is being started.
                if self._resume_requested:
                    return
                self._scan_running = False; self._scan_worker_active = False
                if self._nav_mode == 'scanner':
                    self.append_log('RUNTIME: heartbeat timeout; service state=' + repr(state))
                    self.status_card.text = 'Фоновый сервис не отвечает. Нажми ОБНОВИТЬ для восстановления.'
                return
            # The replacement service has now confirmed its heartbeat.  Only
            # here is it safe to clear the RESUME transition flag.  Clearing it
            # earlier allowed a stale STOPPED state to overwrite the new STOP UI
            # for a few seconds until the user pressed ОБНОВИТЬ.
            if self._resume_requested:
                self._resume_requested = False
                self.append_log('RESUME подтверждён новым фоновым сервисом')
            done = int(state.get('done_count', 0) or 0); total = int(state.get('total', 0) or 0)
            phase = str(state.get('phase', 'PRESCAN'))
            pct = (done / total * 100) if total else 0
            if status == 'ready_idle' and self._nav_mode == 'scanner':
                rr=state.get('readiness') or {}
                self.status_card.text=f'🟢 МОДЕЛЬ ГОТОВА: {int(rr.get("score",0))}/10\nНажми ⋮ → ПОЛУЧИТЬ 5 ПРОГНОЗОВ.'
            self._scan_errors = int(state.get('errors', 0) or 0)
            cycle_id = int(state.get('cycle', 0) or 0)
            state_rows = list(state.get('rows') or [])
            service_top5 = list(state.get('last_top5') or [])[:5]
            service_top5_cycle = int(state.get('last_top5_cycle', 0) or 0)
            # The service persists the last real TOP-5 independently of the current
            # scan phase. This prevents a fast VERIFY->PRESCAN transition from
            # making the UI miss a completed cycle.
            if service_top5 and service_top5_cycle and service_top5_cycle != self._last_saved_cycle:
                self._last_top5 = [dict(x) for x in service_top5]
                self._scan_rows = [dict(x) for x in service_top5]
                self._record_top5_history(self._last_top5, cycle=service_top5_cycle)
                self._last_saved_cycle = service_top5_cycle
            row = state.get('row')
            if phase == 'MODEL' and row and row.get('contract'):
                seen = {x.get('contract'): x for x in self._scan_seen}
                seen[row.get('contract')] = row
                self._scan_seen = list(seen.values())
            # A background scan may continue while the user is in Analysis,
            # AI Model, or Settings. Update scan data silently there; never
            # overwrite the active screen with Scanner widgets.
            if self._nav_mode == 'scanner':
                if phase == 'VERIFY':
                    self.status_card.text = (f'САМОПРОВЕРКА TOP-5 | Цикл {state.get("cycle", "—")}\n'
                                             f'Проверено прогнозов: {state.get("resolved_count",0)}/{state.get("resolved_total",len(state.get("prediction_ids",[])))}\n'
                                             'Проверяю Entry / SL / TP1 / TP2 / TP3.\n'
                                             'После проверки модель переобучится и начнёт новый поиск.')
                elif phase == 'LEARN':
                    self.status_card.text = (f'САМООБУЧЕНИЕ | Цикл {state.get("cycle", "—")}\n'
                                             f'Разобрано прогнозов: {state.get("resolved_count",0)}\n'
                                             'Анализирую ошибки и успешные результаты перед новым сканированием.')
                elif phase == 'READY':
                    rr=state.get('readiness') or {}
                    self.status_card.text = (f'🟢 МОДЕЛЬ ГОТОВА: {int(rr.get("score",0))}/10\n'
                                             'Самообучение продолжает проверять старые прогнозы.\n'
                                             'Для нового TOP-5 открой ⋮ и нажми «Получить 5 прогнозов».')
                elif phase in ('PRESCAN','SCAN','MODEL'):
                    self.status_card.text = (f'AI СКАНИРУЕТ РЫНОК... {pct:.0f}% | Цикл {cycle_id}\n'
                                         f'Проверено пар: {done}/{total}\n'
                                         f'Ошибок: {self._scan_errors}\n'
                                         'Предыдущий TOP-5 продолжает проверяться в фоне.\n'
                                         'Новый TOP-5 появится после полного прохода рынка.')
                    if self._last_top5:
                        self.render_top5(self._last_top5)
                    else:
                        self.results_box.clear_widgets()
                elif phase == 'WAIT_NEXT_SCAN':
                    remaining=int(state.get('next_scan_in',0) or 0)
                    mins,secs=divmod(max(0,remaining),60)
                    self.status_card.text = (f'ПРОВЕРКА TOP-5 | Цикл {cycle_id}\n'
                                         f'Старые прогнозы проверяются в фоне.\n'
                                         f'Следующий полный скан через {mins:02d}:{secs:02d}.')
                    if self._last_top5:
                        self.render_top5(self._last_top5)
                if phase == 'VERIFY' and state_rows:
                    self.render_top5(state_rows[:5])
                elif phase == 'NO_CANDIDATES':
                    self.results_box.clear_widgets()
                    empty = Label(text='Полный проход завершён. LONG/SHORT кандидатов пока нет.',
                                  font_size='13sp', color=self._muted, size_hint_y=None, height=dp(66),
                                  halign='left', valign='middle')
                    empty.bind(size=lambda o,v:setattr(o,'text_size',(v[0],None)))
                    self.results_box.add_widget(empty)
            return
        if status == 'stopped':
            if self._resume_requested:
                # A stale STOPPED snapshot may arrive between the old service
                # exit and the new service heartbeat. Do not overwrite RESUME.
                return
            self._scan_running = False; self._scan_worker_active = False; self._scan_paused = True
            self.stop_btn.text = 'ВОЗОБНОВИТЬ СКАНИРОВАНИЕ'; self.stop_btn.opacity = 1; self.stop_btn.disabled = False; self.stop_btn.height = dp(52)
            if self._nav_mode == 'scanner':
                self.status_card.text = 'Сканирование остановлено.\nУже найденные кандидаты сохранены.'
            self.append_log('Фоновое сканирование остановлено')
            if self._bg_poll_event is not None:
                self._bg_poll_event.cancel(); self._bg_poll_event = None
            self._save_session_state()
            return
        if status == 'done':
            rows = list(state.get('rows') or [])
            self._scan_running = False; self._scan_worker_active = False; self._scan_paused = False
            self._scan_rows = rows[:5]; self._last_top5 = [dict(x) for x in self._scan_rows]
            if self._last_top5:
                self._record_top5_history(self._last_top5)
            self.stop_btn.opacity = 1; self.stop_btn.disabled = False; self.stop_btn.height = dp(52); self.stop_btn.text = 'ЗАПУСТИТЬ СКАНИРОВАНИЕ'
            if self._nav_mode == 'scanner':
                self.render_top5(self._last_top5)
                self.status_card.text = f"СКАНИРОВАНИЕ ЗАВЕРШЕНО\nПроверено пар: {state.get('total',0)} | Свечи OK: {state.get('quick_count',0)} | Кандидатов: {len(self._scan_rows)}\nОшибок: {state.get('errors',0)}\nTOP-{len(self._scan_rows)} сохранён."
            self._write_bg_control(True, run_id=int(state.get('run_id', 0) or 0))
            self.append_log(f"Фоновое сканирование завершено: TOP-{len(self._scan_rows)}")
            if self._bg_poll_event is not None:
                self._bg_poll_event.cancel(); self._bg_poll_event = None
            self._save_session_state()
            return
        if status == 'error':
            self._scan_running = False; self._scan_worker_active = False; self._scan_paused = True
            self.stop_btn.opacity = 1; self.stop_btn.disabled = False; self.stop_btn.height = dp(52)
            self.stop_btn.text = 'ВОЗОБНОВИТЬ СКАНИРОВАНИЕ'
            if self._nav_mode == 'scanner':
                self.status_card.text = 'Ошибка фонового сканирования:\n' + str(state.get('error','неизвестная ошибка')) + '\nМожно запустить сканирование снова.'
            self.append_log('Ошибка фонового сканирования: ' + str(state.get('error','неизвестная ошибка')))
            if self._bg_poll_event is not None:
                self._bg_poll_event.cancel(); self._bg_poll_event = None

    def _resume_after_service_stop(self):
        """Resume through one deterministic state transition.

        The old implementation let the UI poll and the service poll race each
        other.  A stale STOPPED state could therefore overwrite a freshly
        requested RESUME and leave the red RESUME button on screen.
        """
        if self._bg_resume_wait_event is not None:
            return
        self._resume_requested = True
        state = self._read_bg_state()
        status = str(state.get('status',''))
        if status in ('running','stopping','starting'):
            # The old service has not acknowledged STOP yet.  Do not change the
            # local state back and forth; wait for one terminal STOPPED state.
            self.stop_btn.text = 'ВОЗОБНОВИТЬ СКАНИРОВАНИЕ'
            self.stop_btn.disabled = False
            self.stop_btn.opacity = 1
            self._set_stop_button_visual()
            self.status_card.text = 'Остановка фонового сканирования завершается…'
            self._bg_resume_wait_event = Clock.schedule_interval(self._poll_resume_service, 0.5)
            return
        self._finish_resume_transition()

    def _finish_resume_transition(self):
        """Atomically switch the UI to RUNNING before starting the new service."""
        if self._bg_resume_wait_event is not None:
            try: self._bg_resume_wait_event.cancel()
            except Exception: pass
            self._bg_resume_wait_event = None
        self._bg_stop_requested = False
        # Keep RESUME transition armed until the replacement service actually
        # reports a live heartbeat.  If this flag is cleared before the service
        # starts, the old STOPPED state can immediately overwrite the red STOP
        # button with green RESUME.
        self._resume_requested = True
        self._scan_paused = False
        self._scan_running = True
        self._scan_worker_active = True
        self.stop_btn.disabled = False
        self.stop_btn.text = 'СТОП'
        self._set_stop_button_visual()
        self._sync_stop_button_visibility()
        self.status_card.text = 'Запускаю фоновое сканирование…'
        self.append_log('Предыдущее фоновое сканирование остановлено — запускаю новое')
        self._start_foreground_scan()

    def _poll_resume_service(self, _dt):
        state = self._read_bg_state()
        status = str(state.get('status',''))
        if status in ('running','starting','stopping'):
            self.stop_btn.text = 'ВОЗОБНОВИТЬ СКАНИРОВАНИЕ'
            self.stop_btn.disabled = False
            self.stop_btn.opacity = 1
            self._set_stop_button_visual()
            self.status_card.text = 'Остановка фонового сервиса завершается…'
            return
        # Only a terminal STOPPED/empty/error state is allowed to start the
        # replacement service.  The local resume flag prevents the foreground
        # poller from turning this transition back into PAUSED.
        if status in ('stopped','error',''):
            self._finish_resume_transition()

    def _stop_watchdog(self, _dt):
        if not self._bg_stop_requested:
            if self._stop_watchdog_event is not None:
                try: self._stop_watchdog_event.cancel()
                except Exception: pass
                self._stop_watchdog_event = None
            return
        state = self._read_bg_state()
        status = str(state.get('status',''))
        if status == 'stopped' and bool(state.get('user_stopped', False)):
            self._bg_stop_requested = False
            self._scan_running = False
            self._scan_worker_active = False
            self._scan_paused = True
            self.stop_btn.text = 'ВОЗОБНОВИТЬ СКАНИРОВАНИЕ'
            self.stop_btn.disabled = False
            self.stop_btn.opacity = 1
            self._set_stop_button_visual()
            self._sync_menu_stop()
            self.status_card.text = 'Сканирование остановлено.\nУже найденные кандидаты сохранены.'
            if self._stop_watchdog_event is not None:
                try: self._stop_watchdog_event.cancel()
                except Exception: pass
                self._stop_watchdog_event = None
            return
        self._write_bg_control(True, user_stopped=True)
        self.stop_btn.text = 'ВОЗОБНОВИТЬ СКАНИРОВАНИЕ'
        self.stop_btn.disabled = False
        self.stop_btn.opacity = 1
        self._set_stop_button_visual()

    def stop_scan(self, *_):
        if platform == 'android' and (self._scan_running or self._scan_paused or self._bg_stop_requested):
            if self._scan_running:
                # Do not launch a second foreground service until the first one
                # has actually acknowledged the stop. This removes the race
                # that could crash the app on STOP -> immediate RESUME.
                self._bg_stop_requested = True
                self._resume_requested = False
                if self._bg_resume_wait_event is not None:
                    try: self._bg_resume_wait_event.cancel()
                    except Exception: pass
                    self._bg_resume_wait_event = None
                self._write_bg_control(True, user_stopped=True)
                if self._stop_watchdog_event is not None:
                    try: self._stop_watchdog_event.cancel()
                    except Exception: pass
                self._stop_watchdog_event = Clock.schedule_interval(self._stop_watchdog, 0.5)
                self._scan_running = False; self._scan_paused = True; self._scan_worker_active = False
                self.stop_btn.text = 'ВОЗОБНОВИТЬ СКАНИРОВАНИЕ'; self.stop_btn.opacity = 1; self.stop_btn.disabled = True; self.stop_btn.height = dp(52)
                self._set_stop_button_visual(); self._sync_stop_button_visibility()
                self.status_card.text = 'Остановка фонового сканирования...\nУже найденные кандидаты сохранены. Нажми «ВОЗОБНОВИТЬ» когда захочешь продолжить.'
                self.append_log('Пользователь остановил фоновое сканирование; кнопка переведена в режим ВОЗОБНОВИТЬ')
                self._save_session_state()
                return
            if self._scan_paused:
                self.append_log('Запрошено возобновление: жду завершения остановки')
                self._resume_after_service_stop()
                return
        # Desktop/non-Android fallback
        if self._scan_running:
            self._scan_paused = True; self._scan_running = False
            if self._scan_cancel_event is not None: self._scan_cancel_event.set()
            self.stop_btn.text = 'ВОЗОБНОВИТЬ СКАНИРОВАНИЕ'; self.stop_btn.opacity = 1; self.stop_btn.disabled = False; self.stop_btn.height = dp(52)
            self._sync_stop_button_visibility()
            self.status_card.text = 'Остановка сканирования...\nУже найденные кандидаты сохранены.'
            self.append_log('Пользователь остановил сканирование'); return
        if self._scan_paused and not self._scan_worker_active:
            self._scan_paused = False; self.stop_btn.text='СТОП'; self.stop_btn.opacity=1; self.stop_btn.disabled=False
            self.append_log('Пользователь возобновил сканирование'); self.scan(None)

    def refresh_symbols(self, _, auto=False):
        def f():
            try:
                items = self.engine.exchange.active_symbols()
                def apply(_dt):
                    self._symbols = items
                    self._save_session_state()
                    self.status_card.text = f'KuCoin: {len(items)} активных USDT-M контрактов.\nAI формирует TOP-5 — список всех монет скрыт.'
                    self.append_log(f'Рынок обновлён: {len(items)} контрактов')
                    if auto and not self._auto_scan_started:
                        self._auto_scan_started = True
                        bg=self._read_bg_state()
                        if platform == 'android' and self._service_state_live(bg):
                            # Android may recreate the UI process while the
                            # foreground learning service is still alive. Attach
                            # to that service instead of starting a second one.
                            self._scan_running = True
                            self._scan_worker_active = True
                            self._scan_paused = False
                            self.stop_btn.opacity = 1; self.stop_btn.disabled = False; self.stop_btn.height = dp(52); self.stop_btn.text = 'СТОП'
                            if self._bg_poll_event is None:
                                self._bg_poll_event = Clock.schedule_interval(self._poll_foreground_scan, 0.5)
                            self.append_log('Подключился к уже работающему фоновому циклу')
                        else:
                            Clock.schedule_once(lambda dt: self.scan(None), 0.3)
                Clock.schedule_once(apply, 0)
            except Exception as e:
                Clock.schedule_once(lambda dt: setattr(self.status_card, 'text', 'Ошибка получения рынка: '+str(e)), 0)
        threading.Thread(target=f, daemon=True).start()

    def filter_symbols(self, _, value):
        q = str(value or '').strip().upper().replace('-USDT', '').replace('USDTM', '')
        self.search_results.clear_widgets()
        if not q:
            self.search_results.height = 0
            return
        rows = []
        for x in self._symbols:
            if q in x['display'].upper() or q in x['contract'].upper() or q in str(x.get('base','')).upper(): rows.append(x)
            if len(rows) >= 8: break
        for x in rows:
            b = ExpandedTouchButton(text=f"{x['display']}   [{x['contract']}]", size_hint_y=None, height=dp(46),
                       background_normal='', background_color=self._panel2, color=self._text, font_size='13sp')
            b.bind(on_release=lambda btn, item=x: self.select_symbol(item)); self.search_results.add_widget(b)
        self.search_results.height = len(rows)*dp(49)

    def select_symbol(self, item):
        self.engine.set_symbol(item['contract'])
        self.search_results.clear_widgets(); self.search_results.height = 0
        self.selected_label.height = dp(24)
        self.selected_label.text = f"Выбрано: {item['display']} [{item['contract']}]"
        self.status_card.text = f"Выбрана {item['display']}. Для точного анализа нажми LIVE-ПРОГНОЗ или запусти обучение."
        self._last_prediction = None
        self.append_log(f"Выбран инструмент {item['display']}")

    def worker(self, fn, on_done=None):
        self.status_card.text = 'Выполняю операцию...\nНе закрывайте приложение.'
        def run():
            try: result = fn()
            except Exception as e: result = 'Ошибка: ' + str(e)
            Clock.schedule_once(lambda dt: self._finish(result, on_done), 0)
        threading.Thread(target=run, daemon=True).start()

    def _finish(self, result, on_done):
        if on_done: on_done(result)
        else: self.status_card.text = str(result)

    def train(self, *_):
        self.worker(lambda: self.engine.train_from_fresh(), lambda r: self._show_result('Обучение завершено', r))

    def _show_result(self, title, r):
        if isinstance(r, str): self.status_card.text = r; return
        self.status_card.text = (f'{title}\nСтрок: {r["rows"]}\nTrain: {r["train_rows"]} | Test: {r["test_rows"]}\n'
                                 f'Accuracy: {r["accuracy"]:.3f}\nBalanced: {r["balanced_accuracy"]:.3f}\nМодель принята: {r["accepted"]}')
        self.append_log(title)

    def predict(self, *_):
        self.worker(self.engine.predict_and_store, self._prediction_done)

    def _prediction_done(self, r):
        if isinstance(r, str): self.status_card.text = r; return
        self._detail_open = True; self._last_prediction = r
        self.selected_label.height = dp(24)
        self.selected_label.text = f"Анализ: {r['symbol']} [{r['exchange_symbol']}]"
        self.status_card.text = self._prediction_text(r)
        self.build_calculator(r)
        self.append_log(f"LIVE {r['symbol']}: {r['prediction']}")

    def _prediction_text(self, r):
        base = (f"{r['symbol']} [{r['exchange_symbol']}]\nПРОГНОЗ: {r['prediction']}\n"
                f"Вероятности: SHORT {r['p_short']:.1%} | WAIT {r['p_wait']:.1%} | LONG {r['p_long']:.1%}\n")
        if r['prediction'] == 'WAIT': return base + '\nТорговый вход не формируется: WAIT.\nСигнал сохранён для проверки.'
        return base + (f"\nEntry: {r['entry']:.8g}\nSL: {r['sl']:.8g}\nTP1: {r['tp1']:.8g}\nTP2: {r['tp2']:.8g}\nTP3: {r['tp3']:.8g}\n"
                        f"Горизонт: {r['horizon_bars']} × 5m\nСигнал сохранён для проверки.")

    def scan(self, *_):
        if self._scan_running or self._scan_worker_active: return
        if platform == 'android':
            self._start_foreground_scan()
            return
        self._scan_running = True; self._scan_paused = False; self._scan_worker_active = True; self._scan_cancel_event = threading.Event(); self._detail_open = False; self._scan_rows = []
        self.stop_btn.opacity = 1; self.stop_btn.disabled = False; self.stop_btn.height = dp(52); self.stop_btn.text = 'СТОП'
        self.results_box.clear_widgets(); self._hide_more_actions(); self.top_title.text = 'ТОП-5 ЛУЧШИХ КАНДИДАТОВ'; self.status_card.text = 'AI СКАНИРУЕТ РЫНОК...\nПроверяю доступные пары и формирую TOP-5.'
        # Do not post a UI update for every scanned contract: hundreds of
        # Clock callbacks can starve Kivy's rendering thread and make the screen
        # appear to build itself slowly.  The scanner runs in a worker thread;
        # UI progress is throttled to a small, predictable rate.
        progress_state = {'last': 0.0, 'pending': None}
        def progress(done, total, name, row, err, phase='PRESCAN'):
            now = __import__('time').monotonic()
            # Keep scan counters tied to actual successful/failed candle checks.
            # The previous build displayed OK=0 because these counters were never
            # incremented even when _quick_candidate() returned valid data.
            if phase == 'PRESCAN':
                if row is not None:
                    self._scan_quick_ok = getattr(self, '_scan_quick_ok', 0) + 1
                elif err is not None:
                    self._scan_errors = getattr(self, '_scan_errors', 0) + 1
            progress_state['pending'] = (done, total, name, row, err, phase)
            force = row is not None or done >= total
            if not force and now - progress_state['last'] < 0.20:
                return
            progress_state['last'] = now
            payload = progress_state['pending']
            def apply(_dt, payload=payload):
                if not self._scan_running or self._detail_open or self._nav_mode != 'scanner': return
                done, total, name, row, err, phase = payload
                if phase == 'PRESCAN':
                    pct = (done/total*100) if total else 0
                    self.status_card.text = (f'AI СКАНИРУЕТ РЫНОК... {pct:.0f}%\n'
                                             f'Проверено пар: {done}/{total}\n'
                                             f'Свечи OK: {getattr(self, "_scan_quick_ok",0)} | Ошибок: {getattr(self, "_scan_errors",0)}\n'
                                             'Формирую пул лучших кандидатов. Все монеты скрыты — показывается только TOP-5.')
                elif row:
                    seen = {x.get('contract'): x for x in getattr(self, '_scan_seen', [])}
                    seen[row.get('contract')] = row
                    self._scan_seen = list(seen.values())
                    self._scan_rows = sorted(
                        self._scan_seen,
                        key=lambda r: (r.get('prediction')!='WAIT', r.get('edge_score',-9), r.get('quality',0), r.get('turnover24h',0)),
                        reverse=True
                    )[:5]
                    self.render_top5()
                    self._save_session_state()
            Clock.schedule_once(apply, 0)
        def done(result):
            self._scan_running = False
            self._scan_worker_active = False
            if isinstance(result, str): self.status_card.text = result; return
            rows, total, quick_count, errors, diagnostics = result
            if isinstance(diagnostics, dict) and diagnostics.get('cancelled'):
                self._scan_paused = True
                self.stop_btn.opacity = 1
                self.stop_btn.disabled = False
                self.stop_btn.text = 'ВОЗОБНОВИТЬ СКАНИРОВАНИЕ'
                self._save_session_state()
                self.append_log('Сканирование остановлено. Можно возобновить.')
                return
            self._scan_paused = False
            unique = {r.get('contract'): r for r in rows}
            self._scan_rows = sorted(unique.values(), key=lambda r: (r.get('prediction')!='WAIT', r.get('edge_score',-9), r.get('quality',0), r.get('turnover24h',0)), reverse=True)[:5]
            self._last_top5 = [dict(x) for x in self._scan_rows]
            if self._last_top5:
                self._record_top5_history(self._last_top5)
            self.stop_btn.opacity = 1; self.stop_btn.disabled = False; self.stop_btn.height = dp(52); self.stop_btn.text = 'ЗАПУСТИТЬ СКАНИРОВАНИЕ'
            if self._nav_mode == 'scanner':
                self.render_top5(self._last_top5)
                bd=diagnostics.get('breakdown',{}) if isinstance(diagnostics,dict) else {}
                detail=(f"DNS/сеть: {bd.get('DNS/сеть',0)} | HTTP/сеть: {bd.get('HTTP/сеть',0)}\n"
                        f"API/ответ: {bd.get('API/ответ',0)} | Свечи/данные: {bd.get('Свечи/данные',0)}\n"
                        f"Обработка: {bd.get('Обработка данных',0)} | Модель: {bd.get('Модель',0)}")
                self.status_card.text = (f'СКАНИРОВАНИЕ ЗАВЕРШЕНО\nПроверено пар: {total} | Свечи OK: {quick_count} | Кандидатов: {len(self._scan_rows)}\n'
                                         f'Ошибок: {errors}\n{detail}\n'
                                         f'TOP-{len(self._scan_rows)} сохранён. Его можно открыть из Сканера → История TOP-5.')
            else:
                self.append_log(f'Сканирование завершено в фоне: TOP-{len(self._scan_rows)}, ошибок {errors}')
            if isinstance(diagnostics,dict):
                for sample in diagnostics.get('samples',[])[:10]:
                    self.append_log(f"Ошибка {sample.get('stage','')}: {sample.get('symbol','')} — {sample.get('category','')}: {sample.get('error','')}")
            self.append_log(f'Сканирование завершено: TOP-{len(self._scan_rows)}')
        def run_scan():
            self._scan_seen=[]; self._scan_quick_ok=0; self._scan_errors=0
            return self.engine.scan_all(progress=progress, cancel_event=self._scan_cancel_event)
        self.worker(run_scan, done)

    def _top5_result_badge(self, row):
        d=dict(row or {}); pred=str(d.get("prediction") or "WAIT").upper()
        if pred not in ("LONG","SHORT"): return "⚪ WAIT", self._panel2
        tp1=bool(d.get("tp1_hit")); tp2=bool(d.get("tp2_hit")); tp3=bool(d.get("tp3_hit")); initial_sl=bool(d.get("initial_sl_failure")) or (bool(d.get("sl_hit")) and not tp1); resolved=bool(d.get("resolved")); result=str(d.get("result") or "").upper()
        if tp3: return ("🟢 TP3+ ✓" if float(d.get("max_extension_beyond_tp3_pct",0) or 0)>0 else "🟢 TP3 ✓"), self._green
        if initial_sl and not tp1: return "🔴 SL ✕", self._red
        if tp2: return "🟡 TP2", (1.0,0.72,0.05,1)
        if tp1: return "🟡 TP1", (1.0,0.72,0.05,1)
        if not resolved or str(d.get("verification_state") or "").upper() in ("INITIAL_WAIT","LONG_RUNNING_WAITING","WAITING_TP2","WAITING_TP3","ACTIVE","QUEUED"): return "🟡 Проверяется…", (1.0,0.72,0.05,1)
        if result in ("SL","FAIL","FAILED"): return "🔴 SL ✕", self._red
        return "⚪ Не определён", self._panel2

    def render_top5(self, rows=None):
        rows=list(rows if rows is not None else self._scan_rows); self.results_box.clear_widgets()
        if not rows:
            empty=Label(text='Пока нет свежих прогнозов.\nОткрой ⋮ → ПОЛУЧИТЬ 5 ПРОГНОЗОВ, когда модель будет готова.',font_size='13sp',color=self._muted,size_hint_y=None,height=dp(66),halign='left',valign='middle'); empty.bind(size=lambda o,v:setattr(o,'text_size',(v[0],None))); self.results_box.add_widget(empty); return
        for rank,r in enumerate(rows,1):
            pred=r.get('prediction','WAIT'); conf=max(float(r.get('p_short',0) or 0),float(r.get('p_long',0) or 0),float(r.get('p_wait',0) or 0)); badge,badge_color=self._top5_result_badge(r); color=self._green if pred=='LONG' else self._red if pred=='SHORT' else self._panel2
            def f(v):
                try:return f'{float(v):.8g}'
                except Exception:return '—'
            if pred=='WAIT': txt=f'#{rank}  {r.get("symbol","?")}    WAIT    {conf:.0%}    {badge}\nНет достаточно сильного торгового преимущества'
            else: txt=f'#{rank}  {r.get("symbol","?")}    {pred}    {conf:.0%}    {badge}\nEntry {f(r.get("entry"))}    SL {f(r.get("sl"))}\nTP1 {f(r.get("tp1"))}    TP2 {f(r.get("tp2"))}    TP3 {f(r.get("tp3"))}'
            b=ExpandedTouchButton(text=txt,size_hint_y=None,height=dp(104),halign='left',valign='middle',background_normal='',background_color=color,color=self._text,font_size='12sp',padding=(dp(12),dp(7))); b.bind(size=lambda o,v:setattr(o,'text_size',(max(dp(120),o.width-dp(20)),None))); b.bind(on_release=lambda btn,x=dict(r):self.open_candidate(x)); self.results_box.add_widget(b)
        note=Label(text='Нажми на монету: уровни, плечо, фактический вход/выход и мониторинг.',font_size='10sp',color=self._muted,size_hint_y=None,height=dp(42),halign='left',valign='middle'); note.bind(size=lambda o,v:setattr(o,'text_size',(v[0],None))); self.results_box.add_widget(note)

    def show_top5_history(self, *_):
        self._hide_more_actions()
        self.top_title.text = 'ИСТОРИЯ TOP-5'
        self.status_card.text = 'Сохранённые результаты сканирования. Нажми запись, чтобы вернуть её на экран.'
        self.results_box.clear_widgets()
        if not self._top5_history:
            self.results_box.add_widget(Label(text='История пока пуста.', color=self._muted, size_hint_y=None, height=dp(48)))
            return
        for item in self._top5_history[:20]:
            stamp = item.get('time', '—')
            rows = item.get('rows', [])
            preview = ' | '.join(f"{r.get('symbol','?')} {r.get('prediction','WAIT')} {max(r.get('p_short',0),r.get('p_long',0),r.get('p_wait',0)):.0%}" for r in rows[:5])
            b = self.style_button(ExpandedTouchButton(text=f'{stamp}\n{preview}', size_hint_y=None, height=dp(62)), fs=11)
            b.bind(on_release=lambda _, x=list(rows): self._restore_top5(x))
            self.results_box.add_widget(b)
        back = self.style_button(ExpandedTouchButton(text='← НАЗАД К ТЕКУЩЕМУ TOP-5', size_hint_y=None, height=dp(48)), fs=12)
        back.bind(on_release=lambda *_: self.bottom_nav('scanner'))
        self.results_box.add_widget(back)

    def _restore_top5(self, rows):
        self._last_top5 = list(rows)
        self._scan_rows = list(rows)
        self.top_title.text = 'ТОП-5 ЛУЧШИХ КАНДИДАТОВ'
        self.status_card.text = 'Восстановлен сохранённый TOP-5. Это история, новый скан не запущен.'
        self.render_top5(self._last_top5)

    def open_candidate(self, r):
        self._detail_open=True; self.engine.set_symbol(r['contract']); self._last_prediction=dict(r); self.selected_label.height=dp(24); self.selected_label.opacity=1; self.selected_label.text=f"Анализ: {r['symbol']} [{r['exchange_symbol']}]"; self.status_card.text=self._prediction_text(r); self.build_calculator(r); self.scroll.scroll_y=0
        self.monitor_btn=ExpandedTouchButton(text=f'🔎 НАБЛЮДАТЬ: {r.get("symbol","МОНЕТОЙ")}',size_hint_y=None,height=dp(50),background_normal='',background_color=self._accent,color=self._text,font_size='12sp'); self.monitor_btn.bind(on_release=lambda *_:self.start_selected_monitor(r)); self.results_box.add_widget(self.monitor_btn)
        stopb=ExpandedTouchButton(text='■ ОСТАНОВИТЬ НАБЛЮДЕНИЕ',size_hint_y=None,height=dp(48),background_normal='',background_color=self._red,color=self._text,font_size='12sp'); stopb.bind(on_release=self.stop_selected_monitor); self.results_box.add_widget(stopb)
        back=ExpandedTouchButton(text='← НАЗАД К TOP-5',size_hint_y=None,height=dp(48),background_normal='',background_color=self._panel2,color=self._text,font_size='12sp'); back.bind(on_release=lambda *_:self.render_top5(self._scan_rows)); self.results_box.add_widget(back)

    def _write_position_request(self, action, prediction=None, position=None, exit_price=None):
        try:
            payload={'action':str(action)}
            if prediction is not None: payload['prediction']=dict(prediction)
            if position is not None: payload['position']=dict(position)
            if exit_price is not None: payload['exit_price']=float(exit_price)
            tmp=self._monitor_request_path.with_suffix('.tmp'); tmp.write_text(json.dumps(payload,ensure_ascii=False),encoding='utf-8'); tmp.replace(self._monitor_request_path); return True
        except Exception as exc: self.append_log('Ошибка запроса позиции: '+str(exc)); return False

    def enter_real_position(self, prediction):
        try:
            price=float(self.actual_entry.text.strip()); leverage=float(self.leverage.text)
            if price<=0: raise ValueError('Цена входа должна быть больше 0')
            pos={'entry_price':price,'leverage':leverage,'direction':str(self.direction.text).upper(),'margin_mode':str(self.margin_mode.text),'signal_entry':prediction.get('entry'),'signal_sl':prediction.get('sl'),'signal_tp1':prediction.get('tp1'),'signal_tp2':prediction.get('tp2'),'signal_tp3':prediction.get('tp3')}
            if self._write_position_request('start_position',prediction,pos): self.position_status.text=f'🟢 ВХОД: {price:.10g} | x{leverage:g}'
        except Exception as exc: self.position_status.text='Ошибка входа: '+str(exc)

    def close_real_position(self, prediction):
        try:
            price=float(self.actual_exit.text.strip())
            if price<=0: raise ValueError('Цена выхода должна быть больше 0')
            if self._write_position_request('close_position',prediction,exit_price=price): self.position_status.text=f'🔵 ВЫХОД: {price:.10g}'
        except Exception as exc: self.position_status.text='Ошибка закрытия: '+str(exc)

    def build_calculator(self, r):
        self.calc_box.clear_widgets(); title=Label(text='КАЛЬКУЛЯТОР / ПЛЕЧО / РЕАЛЬНАЯ ПОЗИЦИЯ',font_size='18sp',size_hint_y=None,height=dp(38),halign='left',valign='middle',color=self._text); title.bind(size=lambda o,v:setattr(o,'text_size',(v[0],None))); self.calc_box.add_widget(title)
        grid=GridLayout(cols=1,spacing=dp(5),size_hint_y=None,size_hint_x=1); grid.bind(minimum_height=grid.setter('height')); self.calc_grid=grid
        def field(value='',flt='float'): return TextInput(text=value,input_filter=flt,multiline=False,size_hint_y=None,height=dp(44))
        self.direction=Spinner(text=r.get('prediction') if r.get('prediction') in ('LONG','SHORT') else 'LONG',values=('LONG','SHORT'),size_hint_y=None,height=dp(44)); self.leverage=Spinner(text='1',values=('1','2','3','5','10','15','20','25','30','50','75','100'),size_hint_y=None,height=dp(44)); self.margin_mode=Spinner(text='CROSS',values=('CROSS','ISOLATED'),size_hint_y=None,height=dp(44)); self.balance=field('100'); self.margin=field('5')
        wait=r.get('prediction')=='WAIT'; self.entry=field('' if wait else f"{r.get('entry',0):.10g}"); self.sl=field('' if wait else f"{r.get('sl',0):.10g}"); self.tp1=field('' if wait else f"{r.get('tp1',0):.10g}"); self.tp2=field('' if wait else f"{r.get('tp2',r.get('tp1',0)):.10g}"); self.tp3=field('' if wait else f"{r.get('tp3',r.get('tp1',0)):.10g}"); self.actual_entry=field(''); self.actual_exit=field(''); self.mmr=field('0.50'); self.liqfee=field('0.06'); self.fee=field('0.06')
        self._calc_fields=[('Направление',self.direction),('Плечо x',self.leverage),('Маржа',self.margin_mode),('Баланс, USDT',self.balance),('Маржа позиции, USDT',self.margin),('Сигнальный Entry',self.entry),('SL',self.sl),('TP1',self.tp1),('TP2',self.tp2),('TP3',self.tp3),('Фактическая цена входа',self.actual_entry),('Фактическая цена выхода',self.actual_exit),('MMR %',self.mmr),('Liquidation fee %',self.liqfee),('Taker fee %',self.fee)]; self.calc_box.add_widget(grid)
        calc=ExpandedTouchButton(text='ПЕРЕСЧИТАТЬ ПО ПЛЕЧУ',size_hint_y=None,height=dp(54),background_normal='',background_color=self._accent,color=self._text); calc.bind(on_release=lambda *_:self.calculate(r)); self.calc_box.add_widget(calc)
        enter=ExpandedTouchButton(text='🟢 ВОЙТИ ПО ФАКТИЧЕСКОЙ ЦЕНЕ',size_hint_y=None,height=dp(54),background_normal='',background_color=self._green,color=self._text); enter.bind(on_release=lambda *_:self.enter_real_position(r)); self.calc_box.add_widget(enter)
        close=ExpandedTouchButton(text='🔵 ЗАКРЫТЬ ПОЗИЦИЮ ПО ФАКТИЧЕСКОЙ ЦЕНЕ',size_hint_y=None,height=dp(54),background_normal='',background_color=self._panel2,color=self._text); close.bind(on_release=lambda *_:self.close_real_position(r)); self.calc_box.add_widget(close)
        self.position_status=Label(text='Сначала реально войди на KuCoin, затем введи фактическую цену входа.',font_size='12sp',halign='left',valign='top',size_hint_y=None,height=dp(58),color=self._muted); self.position_status.bind(size=lambda o,v:setattr(o,'text_size',(v[0],None))); self.calc_box.add_widget(self.position_status)
        self.calc_out=Label(text='',font_size='14sp',halign='left',valign='top',size_hint_y=None,color=self._text); self.calc_out.bind(width=lambda o,v:setattr(o,'text_size',(max(dp(100),v-dp(8)),None))); self.calc_out.bind(texture_size=lambda o,v:setattr(o,'height',max(dp(120),v[1]+dp(18)))); self.calc_box.add_widget(self.calc_out)
        back=ExpandedTouchButton(text='← НА ГЛАВНУЮ',size_hint_y=None,height=dp(50),background_normal='',background_color=self._panel2,color=self._text); back.bind(on_release=lambda *_:self.bottom_nav('scanner')); self.calc_box.add_widget(back)
        for w in (self.direction,self.leverage,self.margin_mode,self.balance,self.margin,self.entry,self.sl,self.tp1,self.tp2,self.tp3,self.mmr,self.liqfee,self.fee): w.bind(text=lambda *_:self.calculate(r))
        self._layout_calculator(); self.calculate(r)

    def _layout_calculator(self):
        grid=self.calc_grid; grid.clear_widgets(); w=max(dp(240),self.calc_box.width); landscape=self.width>=self.height*1.15 and w>=dp(620); fields=self._calc_fields
        if landscape:
            grid.cols=2
            for name,widget in fields:
                row=BoxLayout(orientation='horizontal',spacing=dp(4),size_hint_y=None,height=dp(46)); lab=Label(text=name,size_hint_x=.52,halign='left',color=self._text); lab.bind(size=lambda o,v:setattr(o,'text_size',(v[0],None))); widget.size_hint_x=.48; row.add_widget(lab); row.add_widget(widget); grid.add_widget(row)
        else:
            grid.cols=1
            for name,widget in fields:
                row=BoxLayout(orientation='horizontal',spacing=dp(5),size_hint_y=None,height=dp(46)); lab=Label(text=name,size_hint_x=.46,halign='left',color=self._text); lab.bind(size=lambda o,v:setattr(o,'text_size',(v[0],None))); widget.size_hint_x=.54; row.add_widget(lab); row.add_widget(widget); grid.add_widget(row)

    def calculate(self,r):
        try:
            if r.get('prediction')=='WAIT' and not self.entry.text.strip(): self.calc_out.text='WAIT — торговый план не сформирован.'; return
            direction=self.direction.text.upper(); lev=float(self.leverage.text); bal=float(self.balance.text); margin=float(self.margin.text); entry=float(self.entry.text); sl=float(self.sl.text); tp1=float(self.tp1.text); tp2=float(self.tp2.text); tp3=float(self.tp3.text)
            mmr=float(self.mmr.text)/100; liq_fee=float(self.liqfee.text)/100; taker=float(self.fee.text)/100
            if direction=='LONG' and not(sl<entry<tp1<=tp2<=tp3): raise ValueError('LONG: SL < Entry < TP1 ≤ TP2 ≤ TP3')
            if direction=='SHORT' and not(sl>entry>tp1>=tp2>=tp3): raise ValueError('SHORT: SL > Entry > TP1 ≥ TP2 ≥ TP3')
            info=self.engine.exchange.contract_info()
            multiplier=float(info.get('multiplier',1.0) or 1.0); api_mmr=float(info.get('maintainMargin',mmr*100) or mmr*100)/100; api_fee=float(info.get('takerFeeRate',taker*100) or taker*100)/100
            if api_mmr>1: api_mmr/=100
            if api_fee>1: api_fee/=100
            c=calculate_position(entry,margin,lev,multiplier,direction,api_mmr,api_fee,liq_fee,bal,self.margin_mode.text,sl,tp1,tp2,tp3)
            liq=c['liquidation']; self.calc_out.text=(f'Направление: {direction}\nНоминал: {c["notional"]:.6f} USDT | Контрактов: {c["qty"]:.10g}\n'
                f'Маржа: {margin:.6f} | Баланс: {bal:.6f} | x{lev:g} | {self.margin_mode.text}\n\n'
                f'Entry: {entry:.10g}\nSL: {sl:.10g}\nTP1: {tp1:.10g} | TP2: {tp2:.10g} | TP3: {tp3:.10g}\n\n'
                f'P/L SL: {c["pnl_sl"]:.6f} USDT\nP/L TP1: {c["pnl_tp1"]:.6f} USDT\nP/L TP2: {c["pnl_tp2"]:.6f} USDT\nP/L TP3: {c["pnl_tp3"]:.6f} USDT\nR/R TP1: 1:{c["rr"]:.2f}\n\nЛиквидация: {liq if liq else "—"}')
        except Exception as e: self.calc_out.text='Ошибка расчёта: '+str(e)

    def back_to_top(self):
        self._detail_open=False; self.calc_box.clear_widgets(); self.status_card.text='TOP-5 сформирован автоматически. Выбери кандидата для подробного анализа.'; self.scroll.scroll_y=1

    def learn(self, *_):
        self.worker(self.engine.learning_cycle, lambda r:self._show_result('Цикл самообучения завершён', r[1] if isinstance(r,tuple) else r))

    def resolve(self, *_): self.worker(lambda:self.engine.resolve_pending(), lambda r:self._show_result('Проверка старых прогнозов завершена', {'rows':r,'train_rows':0,'test_rows':0,'accuracy':0,'balanced_accuracy':0,'accepted':'—'}))


class TraderApp(App):
    def on_pause(self):
        try:
            if hasattr(self, 'root') and self.root:
                self.root._save_session_state()
                # Never rebuild or start/stop the service from on_pause. Android
                # may call pause during transient Activity transitions. Keep the
                # existing service alive and persist only the UI/session state.
        except Exception:
            pass
        # Let Android background the Activity without treating pause as an exit.
        return True

    def on_stop(self):
        try:
            if hasattr(self, 'root') and self.root:
                self.root._save_session_state()
        except Exception:
            pass

    def on_start(self):
        """Start/recover the Android foreground service after Activity startup.

        Starting from UI.__init__ alone is not reliable on Android because the
        Activity/service bridge may not be ready yet.  on_start runs after the
        Kivy Activity is actually started, so it is the authoritative automatic
        background-service entry point.
        """
        try:
            if platform == 'android' and hasattr(self, 'root') and self.root:
                root = self.root
                root.append_log('RUNTIME: App.on_start -> ensuring foreground service')
                Clock.schedule_once(lambda dt: root._ensure_foreground_service(), 0.15)
        except Exception as exc:
            try:
                if hasattr(self, 'root') and self.root:
                    self.root.append_log('RUNTIME: App.on_start service ensure failed: ' + repr(exc))
            except Exception:
                pass

    def on_resume(self):
        # Resume must be deliberately lightweight. Rebuilding the whole Kivy
        # widget tree or starting an Android foreground service from on_resume
        # is unsafe on some Android/Kivy combinations and was the cause of the
        # Activity disappearing immediately after returning from background.
        try:
            if not (hasattr(self, 'root') and self.root):
                return
            root = self.root
            try:
                root._load_top5_history()
            except Exception as exc:
                root.append_log('RUNTIME: on_resume history load failed: ' + repr(exc))

            def recover(_dt):
                try:
                    Window.canvas.ask_update()
                    root.opacity = 1
                    root.disabled = False

                    # Keep the existing logical screen and widgets. Only refresh
                    # the already-created UI; do not call bottom_nav(), because
                    # that clears/rebuilds many widgets during the Android resume
                    # transition and can trigger native Activity instability.
                    root._refresh_dashboard()
                    state = root._read_bg_state()
                    if root._service_state_live(state):
                        root._scan_running = True
                        root._scan_worker_active = True
                        root._scan_paused = False
                        if root._bg_poll_event is None:
                            root._bg_poll_event = Clock.schedule_interval(root._poll_foreground_scan, 0.5)
                    elif str(state.get('status','')) == 'stopped' and bool(state.get('user_stopped', False)):
                        root._scan_running = False
                        root._scan_worker_active = False
                        root._scan_paused = True
                        root._sync_stop_button_visibility()
                    else:
                        # Do not start the Android service from on_resume. If
                        # the Activity itself was recreated, on_start() owns the
                        # single service-start path. If only the service died, the
                        # user can use the normal Update/scan action to restart it.
                        root.append_log('RUNTIME: on_resume -> service not confirmed; no service restart from resume')
                        root._sync_stop_button_visibility()
                    Clock.schedule_once(lambda dt: Window.canvas.ask_update(), 0.2)
                except Exception as exc:
                    try:
                        root.append_log('Ошибка безопасного восстановления экрана: ' + traceback.format_exc())
                    except Exception:
                        pass
            Clock.schedule_once(recover, 0.15)
        except Exception:
            pass

    def build(self):
        try:
            base=Path(__file__).resolve().parent/'config.json'; cfg=load(base)
            runtime_root=(Path(os.environ.get('ANDROID_PRIVATE', str(self.user_data_dir))) / 'stl_generational_v15_3' / 'runtime')
            runtime_root.mkdir(parents=True, exist_ok=True)
            user_cfg=runtime_root/'settings.json'
            legacy_cfg=Path(self.user_data_dir)/'settings.json'
            if not user_cfg.exists() and legacy_cfg.exists():
                try:
                    user_cfg.write_text(legacy_cfg.read_text(encoding='utf-8'), encoding='utf-8')
                except Exception:
                    pass
            if user_cfg.exists():
                try: cfg.update(json.loads(user_cfg.read_text(encoding='utf-8')))
                except Exception: pass
            return UI(LearningEngine(runtime_root,KuCoin(cfg['symbol']),cfg))
        except Exception as exc:
            # Never let an Android startup exception silently close the app.
            # Persist the complete traceback and expose the short error in the
            # UI so the failure is diagnosable on-device.
            try:
                log_path=Path(self.user_data_dir)/'startup_error.log'
                log_path.parent.mkdir(parents=True, exist_ok=True)
                log_path.write_text(traceback.format_exc(), encoding='utf-8')
            except Exception:
                pass
            box=BoxLayout(orientation='vertical', padding=dp(18), spacing=dp(12))
            box.add_widget(Label(text='SelfLearningTrader — ошибка запуска', font_size='18sp', bold=True,
                                 color=(0.95,0.95,0.98,1), size_hint_y=None, height=dp(48)))
            msg=Label(text=str(exc), font_size='12sp', color=(0.95,0.45,0.45,1),
                      halign='left', valign='top', size_hint_y=None)
            msg.bind(width=lambda o,v:setattr(o,'text_size',(max(dp(160),v-dp(4)),None)))
            msg.bind(texture_size=lambda o,v:setattr(o,'height',max(dp(80),v[1]+dp(8))))
            box.add_widget(msg)
            box.add_widget(Label(text='Подробный traceback сохранён в startup_error.log', font_size='11sp',
                                 color=(0.65,0.70,0.76,1), size_hint_y=None, height=dp(34)))
            return box


if __name__=='__main__': TraderApp().run()
