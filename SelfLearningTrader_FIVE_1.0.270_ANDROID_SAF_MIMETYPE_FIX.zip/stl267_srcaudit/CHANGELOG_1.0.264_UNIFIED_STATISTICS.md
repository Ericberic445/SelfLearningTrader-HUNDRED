# SelfLearningTrader FIVE 1.0.264 — unified statistics

## Root cause

Different screens used different definitions of “resolved”. The Analysis screen counted every row with `resolved=true`, including 167 initial-SL rows still awaiting post-SL verification and one excluded SIDEWAYS row. The model-statistics screen separately filtered final TP/SL outcomes and confidence >=70%. The main dashboard showed only the >=70% readiness sample under a label that implied all outcomes. The ordinary pending count also excluded WAIT.

## Changes

- Added one shared, ID-deduplicated statistics population. When an ID has multiple persisted states, the newest resolved/update timestamp is used.
- `resolved` / `final_outcomes` now mean final, valid TP/SL outcomes only.
- `pending` now includes all unresolved forecasts, including WAIT; LONG/SHORT and WAIT are also shown separately.
- Initial SL records awaiting their separate post-SL recheck are counted in `pending_post_sl_rechecks`, not as final outcomes or ordinary unresolved forecasts.
- Resolved records without a final TP/SL outcome (e.g. excluded/sideways records) are counted separately.
- Accuracy remains limited to final outcomes with original LONG/SHORT confidence >=70%; below-70% outcomes remain training-only. The strict >=80% sample remains separate.
- The dashboard, Analysis page, and Model Statistics page now use the same category definitions and denominators.
- No changes to forecast issuance, immutable direction/Entry/SL/TP, TP/SL lifecycle, mathematical models, learning labels, or UI layout.

## Backup audit reconciliation

For the supplied 2026-11-02 backup, the categories reconcile exactly:

- Unique forecasts: 1,429
- Final TP/SL outcomes: 810
- Awaiting first check: 451 (1 LONG/SHORT, 450 WAIT)
- Awaiting post-SL recheck: 167
- Resolved but excluded / without final TP/SL outcome: 1
- Accuracy sample >=70%: 349
- Training-only sample below 70%: 461
- Strict sample >=80%: 108

The disjoint outcome-state categories sum to all unique forecasts: 810 + 451 + 167 + 1 = 1,429.

## Verification

- `python -m py_compile app/core/engine.py app/main.py` — passed.
- `PYTHONPATH=. pytest -q` — 256 passed, 24 subtests passed.
- Re-ran the new aggregation against all 528 prediction logs from the supplied backup; counts and category reconciliation matched the audit above.
- APK has not yet been built or tested on the Android device.
