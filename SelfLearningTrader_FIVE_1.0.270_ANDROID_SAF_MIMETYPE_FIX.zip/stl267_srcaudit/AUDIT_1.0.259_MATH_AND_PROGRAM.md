# Audit results — SelfLearningTrader FIVE 1.0.259

## Confirmed implementation defects fixed

### A. Incorrect `_read_json` call in learning ledger reconciliation
`LearningEngine._read_json` previously accepted one positional argument, but the reconciliation path called it with `(path, {})`. The call raises `TypeError` and was recorded nine times in the supplied backup's learning errors. The helper now supports an explicit fallback and preserves list fallback behavior for existing journals.

### B. Unvalidated probability calibration applied to output
`apply_math_probability_calibration` previously applied a map whenever it had 100 samples and at least two x-points, without checking whether the corresponding head passed chronological holdout validation. This allowed failed/unvalidated calibration maps to alter exposed TP/SL, Monte Carlo, Bayesian, or movement probabilities. It now applies only heads present in `calibration['validated_heads']`.

## Verification

Full automated suite after fixes: **231 passed, 9 subtests passed**.

## Remaining verification boundaries

- Tests do not establish profitability or accuracy of forecasts.
- Actual KuCoin response behavior and Android foreground/background behavior require a built APK and device/runtime logs.
- Historical post-SL records missing event timestamps cannot be reconstructed safely without matching historical candles; this release does not fabricate those timestamps.
