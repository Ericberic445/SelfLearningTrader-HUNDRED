import json
from pathlib import Path

from app.core.engine import LearningEngine


def _forecast(pid, probability, success):
    return {
        'id': pid,
        'prediction': 'LONG',
        'prediction_probability': probability,
        'p_long': probability,
        'resolved': 1,
        'tp1_hit': bool(success),
        'trade_success': bool(success),
        'tp2_hit': False,
        'tp3_hit': False,
        'initial_sl_failure': not bool(success),
        'sl_hit': not bool(success),
        'features': {},
    }


def _engine(tmp_path, rows):
    engine = LearningEngine.__new__(LearningEngine)
    engine.logs = tmp_path / 'logs'
    engine.logs.mkdir()
    engine.cfg = {'accuracy_statistics_min_confidence': 0.70, 'strict_confidence_min': 0.80}
    (engine.logs / 'BTCUSDT_predictions.json').write_text(json.dumps(rows), encoding='utf-8')
    return engine


def test_overall_accuracy_excludes_below_70_but_keeps_70_to_79(tmp_path):
    rows = [
        _forecast('low-fail', 0.45, False),
        _forecast('mid-win', 0.72, True),
        _forecast('strict-fail', 0.85, False),
        _forecast('strict-win', 0.91, True),
    ]
    engine = _engine(tmp_path, rows)
    stats = engine.stats()
    assert stats['accuracy_sample'] == 3
    assert stats['training_only_resolved'] == 1
    assert stats['correct'] == 2
    assert stats['live_accuracy'] == 2 / 3
    assert stats['strict_sample'] == 2
    assert stats['strict_correct'] == 1
    assert stats['strict_errors'] == 1
    assert stats['strict_accuracy'] == 0.5


def test_confidence_buckets_use_original_chosen_direction_probability(tmp_path):
    rows = [
        _forecast('low', 0.45, False),
        _forecast('medium', 0.72, True),
        _forecast('strict', 0.85, False),
    ]
    engine = _engine(tmp_path, rows)
    stats = engine.confidence_stats(rows)
    assert stats['TRAINING_ONLY_BELOW_70']['total'] == 1
    assert stats['ACCURACY_70_79']['total'] == 1
    assert stats['STRICT_80_PLUS']['total'] == 1
    assert stats['STRICT_80_PLUS']['strict_successes'] == 0
    assert stats['STRICT_80_PLUS']['strict_errors'] == 1


def test_short_probability_is_used_for_short_forecasts(tmp_path):
    engine = _engine(tmp_path, [])
    assert engine._statistics_confidence({'prediction': 'SHORT', 'p_short': 0.83, 'p_long': 0.12}) == 0.83
    assert engine._statistics_confidence({'prediction': 'LONG', 'prediction_probability': 0.74, 'p_long': 0.51}) == 0.74


def test_low_confidence_forecasts_are_not_removed_from_learning_ledger(tmp_path):
    from app.core.features import FEATURES
    rows = [
        {**_forecast('low-learning', 0.42, False), 'time': 100, 'contract': 'BTCUSDT',
         'features': {name: 0.01 for name in FEATURES}},
        {**_forecast('high-learning', 0.88, True), 'time': 200, 'contract': 'ETHUSDT',
         'features': {name: 0.02 for name in FEATURES}},
    ]
    engine = _engine(tmp_path, rows)
    learning_rows = engine._resolved_learning_rows()
    assert {row['id'] for row in learning_rows} == {'low-learning', 'high-learning'}


def test_exactly_70_percent_counts_and_below_70_remains_training_only(tmp_path):
    from app.core.features import FEATURES
    rows = [
        {**_forecast('at-70', 0.70, True), 'time': 100, 'contract': 'BTCUSDT',
         'features': {name: 0.01 for name in FEATURES}},
        {**_forecast('below-70', 0.6999, False), 'time': 200, 'contract': 'ETHUSDT',
         'features': {name: 0.02 for name in FEATURES}},
    ]
    engine = _engine(tmp_path, rows)
    stats = engine.stats()
    assert stats['accuracy_sample'] == 1
    assert stats['training_only_resolved'] == 1
    assert {row['id'] for row in engine._resolved_learning_rows()} == {'at-70', 'below-70'}


def test_strict_report_success_and_error_use_final_tp_sl_outcome(tmp_path):
    rows = [
        _forecast('strict-win', 0.85, True),
        _forecast('strict-loss', 0.90, False),
    ]
    engine = _engine(tmp_path, rows)
    report = engine.confidence_stats(rows)
    strict = report['STRICT_80_PLUS']
    assert strict['strict_successes'] == 1
    assert strict['strict_errors'] == 1
    assert report['overall_accuracy_policy']['strict_successes'] == 1
    assert report['overall_accuracy_policy']['strict_errors'] == 1


def test_recent_100_and_500_are_based_only_on_70_plus_and_sorted_by_resolution(tmp_path):
    rows = []
    for i in range(510):
        # Reverse JSON order on purpose: rolling samples must use resolution time.
        probability = 0.50 if i >= 500 else 0.75
        rows.append({**_forecast(f'p{i}', probability, i % 2 == 0),
                     'time': 1000 + i, 'resolved_at': 1000 + i, 'contract': 'BTCUSDT'})
    rows.reverse()
    engine = _engine(tmp_path, rows)
    engine.root = tmp_path
    detail = engine.detailed_stats()
    assert detail['actionable']['total'] == 500
    assert detail['recent100']['total'] == 100
    assert detail['recent500']['total'] == 500
    # The newest 10 forecasts are <70%, so they are training-only and do not
    # displace older eligible forecasts from the recent-100 sample.
    assert detail['recent100']['long'] + detail['recent100']['short'] == 100


def test_statistics_categories_are_disjoint_and_wait_post_sl_are_visible(tmp_path):
    rows = [
        {'id': 'wait-pending', 'prediction': 'WAIT', 'resolved': 0, 'wait_learning_resolved': False},
        {'id': 'long-pending', 'prediction': 'LONG', 'resolved': 0},
        {'id': 'wait-learned', 'prediction': 'WAIT', 'resolved': 0, 'wait_learning_resolved': True},
        {'id': 'sl-recheck', 'prediction': 'SHORT', 'resolved': 1, 'initial_sl_failure': True,
         'sl_hit': True, 'tp1_hit': False, 'post_sl_recheck_pending': True},
        {**_forecast('final-win', 0.75, True), 'prediction': 'LONG'},
        {**_forecast('final-low', 0.55, False), 'prediction': 'SHORT'},
        {'id': 'excluded-sideways', 'prediction': 'LONG', 'resolved': 1, 'result': 'SIDEWAYS'},
    ]
    engine = _engine(tmp_path, rows)
    engine.root = tmp_path
    stats = engine.stats()
    detail = engine.detailed_stats()

    assert stats['predictions'] == 7
    assert stats['resolved'] == stats['final_outcomes'] == 2
    assert stats['raw_resolved'] == 4
    assert stats['pending'] == 2
    assert stats['pending_directional'] == 1
    assert stats['wait_pending'] == 1
    assert stats['wait_learning_resolved'] == 1
    assert stats['pending_post_sl_rechecks'] == 1
    assert stats['excluded_resolved'] == 1
    assert stats['accuracy_sample'] == 1
    assert stats['training_only_resolved'] == 1
    assert (stats['resolved'] + stats['pending'] + stats['pending_post_sl_rechecks'] +
            stats['excluded_resolved'] + stats['wait_learning_resolved']) == stats['predictions']

    assert detail['all']['total'] == 2
    assert detail['actionable']['total'] == 1
    assert detail['pending'] == 2
    assert detail['pending_wait'] == 1
    assert detail['wait_learning_resolved'] == 1
    assert detail['pending_post_sl_rechecks'] == 1
    assert detail['excluded_resolved'] == 1
