import numpy as np

from app.core.features import _rsi, add_features
from app.core.math_models import (
    MATH_FORMULA_VERSION,
    _bayesian,
    _fit_reliability_map,
    _first_passage_probabilities,
    compute_correlation_matrix,
    compute_math_snapshot,
)


def _bars(close):
    close = np.asarray(close, dtype=float)
    return {
        'time': np.arange(len(close), dtype=np.int64) * 300 + 1_800_000_000,
        'open': close.copy(),
        'high': close.copy(),
        'low': close.copy(),
        'close': close.copy(),
        'volume': np.full(len(close), 100.0),
    }


def test_flat_market_oscillators_are_neutral_not_bearish():
    close = np.full(80, 100.0)
    bars = _bars(close)
    features = add_features(bars)
    assert np.allclose(_rsi(close), 50.0)
    assert features['rsi'][-1] == 50.0
    assert features['bbpos'][-1] == 0.5
    assert features['regime_range_position'][-1] == 0.5
    assert features['regime_volatility_ratio'][-1] == 1.0


def test_bayesian_uses_disjoint_horizon_blocks_not_overlapping_windows():
    # 120 returns contain ten independent 12-bar blocks. All are positive.
    returns = np.full(120, 0.001)
    probability = _bayesian(returns, horizon=12)
    assert probability == 10.5 / 11.0
    # Insufficient independent blocks must remain neutral.
    assert _bayesian(np.full(119, 0.001), horizon=12) == 0.5


def test_timestamp_mismatch_disables_benchmark_votes_instead_of_positional_pairing():
    rng = np.random.default_rng(991)
    ret = rng.normal(0.0002, 0.001, 150)
    close = 100 * np.exp(np.cumsum(np.r_[0.0, ret]))
    benchmark = 50 * np.exp(np.cumsum(np.r_[0.0, ret]))
    times = np.arange(len(close), dtype=np.int64) * 300_000_000
    mismatched = compute_math_snapshot(
        close, benchmark_close=benchmark,
        candle_time=times, benchmark_time=times + 300_000_000 * 200,
    )
    assert mismatched['math_correlation'] == 0.0
    assert mismatched['math_cointegration'] == 0.0
    aligned = compute_math_snapshot(
        close, benchmark_close=benchmark,
        candle_time=times, benchmark_time=times,
    )
    assert aligned['math_correlation'] > 0.99


def test_correlation_matrix_sorts_unsorted_timestamps_and_rejects_insufficient_contiguous_rows():
    rng = np.random.default_rng(992)
    n = 80
    times = np.arange(n, dtype=np.int64) * 300
    returns = rng.normal(0.0, 0.001, n - 1)
    close = 100 * np.exp(np.cumsum(np.r_[0.0, returns]))
    order = np.arange(n)[::-1]
    sorted_result = compute_correlation_matrix(
        {'A': {'time': times, 'close': close}, 'B': {'time': times, 'close': close * 2}},
        min_overlap=30,
    )
    unsorted_result = compute_correlation_matrix(
        {'A': {'time': times[order], 'close': close[order]}, 'B': {'time': times[order], 'close': close[order] * 2}},
        min_overlap=30,
    )
    assert unsorted_result['symbols'] == ['A', 'B']
    assert unsorted_result['matrix'][0][1] > 0.999
    assert np.allclose(sorted_result['matrix'], unsorted_result['matrix'])

    sparse_times = np.r_[np.arange(41, dtype=np.int64) * 300, 12_000 + np.arange(39, dtype=np.int64) * 3_000]
    sparse_close = np.linspace(100.0, 101.0, len(sparse_times))
    sparse = compute_correlation_matrix(
        {'A': {'time': sparse_times, 'close': sparse_close}}, min_overlap=50,
    )
    assert sparse['symbols'] == []


def test_reliability_map_duplicate_probability_bins_are_sample_weighted():
    pairs = [(0.5, 1)] * 10 + [(0.5, 0)] * 30
    mapping = _fit_reliability_map(pairs)
    assert mapping['x'] == [0.5]
    # With identical x values, the pooled estimate must reflect all 40 samples.
    assert abs(mapping['y'][0] - (11.0 / 42.0)) < 1e-12


def test_math_formula_version_increment_invalidates_previous_calibration():
    assert MATH_FORMULA_VERSION == 8
    close = np.linspace(100.0, 101.0, 130)
    old_calibration = {
        'formula_version': MATH_FORMULA_VERSION - 1,
        'validated_heads': ['math_bayesian'],
        'maps': {'math_bayesian': {'n': 100, 'x': [0.0, 1.0], 'y': [0.0, 1.0]}},
    }
    result = compute_math_snapshot(close, probability_calibration=old_calibration)
    baseline = compute_math_snapshot(close)
    assert result['math_bayesian'] == baseline['math_bayesian']


def test_intrabar_same_candle_tp_and_sl_is_split_as_ambiguous_probability():
    sims = np.zeros((200, 3), dtype=float)
    close = np.full(130, 100.0)
    high = np.full(130, 101.0)
    low = np.full(130, 99.0)
    tp1, tp2, tp3, psl = _first_passage_probabilities(
        sims, 1.0, [0.005, 0.010, 0.015], 0.005,
        close=close, high=high, low=low, seed=19,
    )
    assert (tp1, tp2, tp3, psl) == (0.5, 0.0, 0.0, 0.5)


def test_prior_tp1_remains_a_hit_when_sl_occurs_in_a_later_candle():
    sims = np.asarray([[0.006, -0.006, 0.0]], dtype=float)
    close = np.full(130, 100.0)
    high = close.copy()
    low = close.copy()
    tp1, tp2, tp3, psl = _first_passage_probabilities(
        sims, 1.0, [0.005, 0.010, 0.015], 0.005,
        close=close, high=high, low=low, seed=20,
    )
    assert tp1 == 1.0
    assert tp2 == 0.0
    assert tp3 == 0.0
    assert psl == 0.0


def test_flat_oscillator_neutrality_uses_price_scale_not_absolute_dollar_threshold():
    close = 1e-10 * np.exp(np.linspace(0.0, 0.05, 80))
    bars = _bars(close)
    features = add_features(bars)
    assert features['rsi'][-1] > 99.0
    assert features['bbpos'][-1] > 0.5
    assert features['regime_range_position'][-1] > 0.5


def test_managed_stop_first_passage_keeps_tp1_after_breakeven_stop():
    # TP1 is reached on candle one. Candle two crosses the moved stop at entry.
    sims = np.asarray([[0.006, -0.001, 0.0]], dtype=float)
    close = np.full(130, 100.0)
    high = close.copy()
    low = close.copy()
    tp1, tp2, tp3, psl = _first_passage_probabilities(
        sims, 1.0, [0.005, 0.010, 0.015], 0.005,
        close=close, high=high, low=low, seed=21,
    )
    assert tp1 == 1.0
    assert tp2 == 0.0 and tp3 == 0.0
    assert psl == 0.0


def test_managed_stop_first_passage_allows_multiple_ordered_targets_in_one_bar():
    sims = np.asarray([[0.020, 0.0]], dtype=float)
    close = np.full(130, 100.0)
    high = close.copy()
    low = close.copy()
    tp1, tp2, tp3, psl = _first_passage_probabilities(
        sims, 1.0, [0.005, 0.010, 0.015], 0.005,
        close=close, high=high, low=low, seed=22,
    )
    assert (tp1, tp2, tp3, psl) == (1.0, 1.0, 1.0, 0.0)


def test_invalid_ohlc_does_not_get_forward_or_backward_filled():
    from app.core.math_models import _safe_prices
    values = np.asarray([100.0, np.nan, 105.0, 106.0])
    # The helper removes invalid values; compute_math_snapshot additionally
    # trims to the contiguous valid suffix so it cannot bridge the bad candle.
    assert np.array_equal(_safe_prices(values), np.asarray([100.0, 105.0, 106.0]))


def test_probability_validation_purges_overlapping_horizon_from_training():
    from app.core.math_models import _validate_math_probability_heads, CALIBRATION_FIELDS
    rows = []
    for cycle in range(100):
        p = {field: 0.8 if cycle % 2 else 0.2 for field in CALIBRATION_FIELDS}
        y = {label: bool(cycle % 2) for label in CALIBRATION_FIELDS.values()}
        rows.append({'time': cycle * 1800, 'horizon_seconds': 3600,
                     'cycle': cycle + 1, 'p': p, 'y': y})
    report = _validate_math_probability_heads(
        rows, lambda row: ('cycle', row['cycle']), min_samples=80,
        min_cycles=80, min_test_rows=10, min_brier_skill=-1.0, min_auc=0.0,
    )
    # The two latest training cycles overlap the first validation horizon and
    # must be purged rather than counted as independent training evidence.
    assert report['train_cycles'] == 73
    assert report['test_cycles'] == 25


def test_tp1_and_new_breakeven_stop_in_same_bar_remain_ambiguous():
    sims = np.asarray([[0.006, 0.0]], dtype=float)
    close = np.full(130, 100.0)
    high = np.full(130, 100.6)
    low = np.full(130, 99.4)
    tp1, tp2, tp3, psl = _first_passage_probabilities(
        sims, 1.0, [0.005, 0.010, 0.015], 0.005,
        close=close, high=high, low=low, seed=23,
    )
    assert tp1 == 0.5
    assert tp2 == 0.0 and tp3 == 0.0
    assert psl == 0.0
