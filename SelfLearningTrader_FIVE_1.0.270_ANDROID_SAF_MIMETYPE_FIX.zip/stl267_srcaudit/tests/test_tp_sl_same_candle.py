from app.core.engine import LearningEngine

PLAN={'prediction':'LONG','entry':100,'sl':95,'tp1':105,'tp2':110,'tp3':115}

def test_same_coarse_candle_without_intrabar_sequence_is_ambiguous_not_sl():
    out=LearningEngine._resolve_lens_plan(PLAN,[106],[94])
    assert out['result']=='AMBIGUOUS_INTRABAR'
    assert out['sl_hit'] is False
    assert out['tp1_hit'] is False
    assert out['intrabar_order_known'] is False

def test_tp1_first_then_sl_in_later_intrabar_candle_is_tp1():
    out=LearningEngine._resolve_lens_plan(PLAN,[106],[94],intrabar_bars={0:([106,106],[101,94])})
    assert out['result']=='TP1'
    assert out['tp1_hit'] is True
    assert out['sl_hit'] is False

def test_sl_first_then_tp1_in_later_intrabar_candle_is_sl():
    out=LearningEngine._resolve_lens_plan(PLAN,[106],[94],intrabar_bars={0:([101,106],[94,94])})
    assert out['result']=='SL'
    assert out['sl_hit'] is True
    assert out['tp1_hit'] is False

def test_same_intrabar_candle_with_both_barriers_remains_ambiguous():
    out=LearningEngine._resolve_lens_plan(PLAN,[106],[94],intrabar_bars={0:([106],[94])})
    assert out['result']=='AMBIGUOUS_INTRABAR'
    assert out['sl_hit'] is False
    assert out['tp1_hit'] is False

def test_existing_breakeven_stop_does_not_erase_confirmed_tp1():
    plan=dict(PLAN)
    out=LearningEngine._resolve_lens_plan(plan,[106,112],[99,99],recheck_bars=3,
        intrabar_bars={0:([106],[101]),1:([109,112],[100.5,99])})
    assert out['tp1_hit'] is True
    assert out['tp2_hit'] is False
    assert out['protected_exit'] is True
