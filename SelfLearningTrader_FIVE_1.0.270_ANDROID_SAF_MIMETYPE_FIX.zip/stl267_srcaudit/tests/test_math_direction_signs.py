import numpy as np

from app.core.math_models import _kalman, _wavelet_dwt, MATH_FORMULA_VERSION


def test_kalman_local_linear_trend_has_correct_direction():
    rising_log_prices = np.linspace(3.0, 3.12, 160)
    falling_log_prices = np.linspace(3.12, 3.0, 160)

    assert _kalman(rising_log_prices) > 0
    assert _kalman(falling_log_prices) < 0


def test_haar_wavelet_signed_detail_has_correct_direction():
    rising_returns = np.linspace(-0.001, 0.001, 128)
    falling_returns = -rising_returns

    assert _wavelet_dwt(rising_returns) > 0
    assert _wavelet_dwt(falling_returns) < 0


def test_math_formula_version_invalidates_old_probability_calibration():
    assert MATH_FORMULA_VERSION == 8
