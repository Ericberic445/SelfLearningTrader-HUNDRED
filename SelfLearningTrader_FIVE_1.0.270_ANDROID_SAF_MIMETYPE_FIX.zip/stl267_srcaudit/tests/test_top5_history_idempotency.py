"""Regression tests for TOP-5 history duplicates after service/Activity restarts."""
import ast
import json
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = (ROOT / "app" / "main.py").read_text(encoding="utf-8")
TREE = ast.parse(SRC)
UI_NODE = next(node for node in TREE.body if isinstance(node, ast.ClassDef) and node.name == "UI")


def get_method(name):
    node = next(item for item in UI_NODE.body if isinstance(item, ast.FunctionDef) and item.name == name)
    module = ast.Module(body=[node], type_ignores=[])
    ast.fix_missing_locations(module)
    from app.core.top5_history import forecast_probability
    ns = {"time": time, "json": json, "_forecast_probability_value": forecast_probability}
    exec(compile(module, "app/main.py", "exec"), ns)
    return ns[name]


class FakeUI:
    _record_top5_history = get_method("_record_top5_history")
    _load_top5_history = get_method("_load_top5_history")

    def __init__(self, history=None):
        self._top5_history = list(history or [])
        self._top5_last100 = []
        self._last_saved_cycle = 0
        self._history_path = None
        self._last100_path = None
        self._manual_wait_id = None
        self._manual_wait_symbol = None
        self.saved = 0

    def _save_top5_history(self):
        self.saved += 1

    def _history_time(self, value):
        return value

    def append_log(self, _message):
        pass


def rows(ids=("p1", "p2"), symbols=("AAA-USDT", "BBB-USDT")):
    return [
        {"id": pid, "contract": symbol.replace("-", ""), "symbol": symbol, "prediction": "LONG", "prediction_probability": 0.75}
        for pid, symbol in zip(ids, symbols)
    ]


def test_same_completed_cycle_is_not_recorded_twice():
    ui = FakeUI()
    assert ui._record_top5_history(rows(), cycle=60) is True
    assert ui._record_top5_history(rows(), cycle=60) is False
    assert len(ui._top5_history) == 1
    assert len(ui._top5_last100) == 2
    assert ui.saved == 1
    assert ui._last_saved_cycle == 60


def test_same_symbols_in_a_new_cycle_are_allowed():
    ui = FakeUI()
    assert ui._record_top5_history(rows(("p1", "p2")), cycle=60) is True
    assert ui._record_top5_history(rows(("p3", "p4")), cycle=61) is True
    assert len(ui._top5_history) == 2
    assert ui._top5_history[0]["cycle"] == 61


def test_legacy_path_deduplicates_same_prediction_ids_not_symbols():
    ui = FakeUI()
    assert ui._record_top5_history(rows(), cycle=None) is True
    assert ui._record_top5_history(rows(), cycle=None) is False
    assert ui._record_top5_history(rows(("p3", "p4")), cycle=None) is True
    assert len(ui._top5_history) == 2


def test_load_restores_last_saved_cycle_from_history(tmp_path):
    history = [
        {"time": "2026-10-12 05:00:00", "cycle": 60, "rows": rows()},
        {"time": "2026-10-12 04:30:00", "cycle": 59, "rows": rows(("p3", "p4"))},
    ]
    history_path = tmp_path / "top5_history.json"
    history_path.write_text(json.dumps(history), encoding="utf-8")
    ui = FakeUI()
    ui._history_path = history_path
    ui._load_top5_history()
    assert ui._last_saved_cycle == 60
    assert len(ui._top5_history) == 2
    assert ui._top5_history[0]["rows"][0]["top5_issued_at"] == "2026-10-12 05:00:00"
    assert ui._top5_history[0]["rows"][0]["top5_cycle"] == 60


def test_load_removes_legacy_replayed_cycles_and_duplicate_positions(tmp_path):
    top_rows = rows(("p1", "p2"))
    history = [
        {"time": f"2026-10-12 05:0{i}:00", "cycle": 60, "rows": top_rows}
        for i in range(5)
    ]
    history_path = tmp_path / "top5_history.json"
    last100_path = tmp_path / "top5_last100.json"
    history_path.write_text(json.dumps(history), encoding="utf-8")
    repeated_positions = []
    for i in range(5):
        for rank, row in enumerate(top_rows, 1):
            repeated_positions.append({"time": f"2026-10-12 05:0{i}:00", "cycle": 60,
                                       "rank": rank, "symbol": row["symbol"],
                                       "prediction": row["prediction"], "id": row["id"],
                                       "prediction_probability": row["prediction_probability"]})
    last100_path.write_text(json.dumps(repeated_positions), encoding="utf-8")

    ui = FakeUI()
    ui._history_path = history_path
    ui._last100_path = last100_path
    ui._load_top5_history()

    assert len(ui._top5_history) == 1
    assert len(ui._top5_last100) == 2
    assert ui._last_saved_cycle == 60
    assert ui._last_top5[0]["id"] == "p1"
    assert ui.saved == 1


def test_malformed_cycle_metadata_does_not_wipe_valid_history(tmp_path):
    history = [
        {"time": "2026-10-12 05:00:00", "cycle": "bad-cycle", "rows": rows()},
        {"time": "2026-10-12 04:30:00", "cycle": 60, "rows": rows(("p3", "p4"))},
    ]
    history_path = tmp_path / "top5_history.json"
    history_path.write_text(json.dumps(history), encoding="utf-8")
    ui = FakeUI()
    ui._history_path = history_path
    ui._load_top5_history()
    assert len(ui._top5_history) == 2
    assert ui._last_saved_cycle == 60


def test_top5_issuance_timestamp_is_saved_for_cycle_and_each_coin():
    ui = FakeUI()
    issued_at = 1791781200
    assert ui._record_top5_history(rows(), cycle=73, issued_at=issued_at) is True
    event = ui._top5_history[0]
    assert event["issued_at"] == issued_at
    assert event["time"] == issued_at
    assert all(row["top5_issued_at"] == issued_at for row in event["rows"])
    assert all(row["top5_cycle"] == 73 for row in event["rows"])
    assert all(item["time"] == issued_at for item in ui._top5_last100)
    assert all(item["top5_issued_at"] == issued_at for item in ui._top5_last100)


def test_legacy_manual_history_preserves_existing_prediction_timestamp():
    ui = FakeUI()
    candidate_rows = rows()
    for row in candidate_rows:
        row["top5_issued_at"] = 1791781200
    assert ui._record_top5_history(candidate_rows, cycle=None) is True
    assert ui._top5_history[0]["issued_at"] == 1791781200


def test_new_cycle_overwrites_stale_prediction_timestamp(monkeypatch):
    ui = FakeUI()
    candidate_rows = rows()
    for row in candidate_rows:
        row["top5_issued_at"] = 1791781200
        row["top5_cycle"] = 60
    monkeypatch.setattr(time, 'time', lambda: 1791789999)
    assert ui._record_top5_history(candidate_rows, cycle=75) is True
    event = ui._top5_history[0]
    assert event['issued_at'] == 1791789999
    assert all(row['top5_issued_at'] == 1791789999 for row in event['rows'])
    assert all(row['top5_cycle'] == 75 for row in event['rows'])


def test_last100_history_excludes_wait_and_below_70_but_keeps_them_in_full_cycle():
    ui = FakeUI()
    candidates = [
        {"id": "long70", "contract": "AAAUSDT", "symbol": "AAA-USDT", "prediction": "LONG", "prediction_probability": 0.70},
        {"id": "short80", "contract": "BBBUSDT", "symbol": "BBB-USDT", "prediction": "SHORT", "prediction_probability": 0.80},
        {"id": "low90", "contract": "CCCUSDT", "symbol": "CCC-USDT", "prediction": "LONG", "prediction_probability": 0.69},
        {"id": "wait99", "contract": "DDDUSDT", "symbol": "DDD-USDT", "prediction": "WAIT", "prediction_probability": 0.99},
    ]
    assert ui._record_top5_history(candidates, cycle=88) is True
    assert len(ui._top5_history[0]["rows"]) == 4
    assert [item["symbol"] for item in ui._top5_last100] == ["AAA-USDT", "BBB-USDT"]
    assert [item["issued_prediction_probability"] for item in ui._top5_last100] == [0.70, 0.80]


def test_last100_migration_removes_waits_low_confidence_and_duplicate_ids_across_cycles(tmp_path):
    history_path = tmp_path / 'top5_history.json'
    last100_path = tmp_path / 'top5_last100.json'
    rows = [
        {'id': 'same-forecast', 'cycle': 10, 'rank': 1, 'symbol': 'AAA-USDT',
         'prediction': 'LONG', 'prediction_probability': 0.82, 'time': 100, 'top5_issued_at': 100},
        {'id': 'same-forecast', 'cycle': 11, 'rank': 1, 'symbol': 'AAA-USDT',
         'prediction': 'LONG', 'prediction_probability': 0.82, 'time': 200, 'top5_issued_at': 200},
        {'id': 'wait-row', 'cycle': 11, 'rank': 2, 'symbol': 'BBB-USDT',
         'prediction': 'WAIT', 'prediction_probability': 0.99},
        {'id': 'low-row', 'cycle': 11, 'rank': 3, 'symbol': 'CCC-USDT',
         'prediction': 'SHORT', 'prediction_probability': 0.69},
        {'id': 'good-row', 'cycle': 11, 'rank': 4, 'symbol': 'DDD-USDT',
         'prediction': 'SHORT', 'prediction_probability': 0.75},
    ]
    history_path.write_text(json.dumps([]), encoding='utf-8')
    last100_path.write_text(json.dumps(rows), encoding='utf-8')
    ui = FakeUI()
    ui._history_path = history_path
    ui._last100_path = last100_path
    ui._load_top5_history()
    assert [row['id'] for row in ui._top5_last100] == ['same-forecast', 'good-row']
    assert ui._top5_last100[0]['cycle'] == 11
    assert ui._top5_last100[0]['top5_issued_at'] == 200
    assert ui.saved == 1


def test_republishing_same_forecast_does_not_double_count_last100():
    ui = FakeUI()
    first = rows(('same', 'other'), ('AAA-USDT', 'BBB-USDT'))
    assert ui._record_top5_history(first, cycle=100, issued_at=1000) is True
    # A later TOP-5 cycle may republish the same forecast ID; it remains a new
    # cycle event in full history but only one performance sample in last-100.
    assert ui._record_top5_history(first, cycle=101, issued_at=2000) is True
    assert len(ui._top5_history) == 2
    assert len(ui._top5_last100) == 2
    assert all(item['cycle'] == 101 for item in ui._top5_last100)
    assert all(item['top5_issued_at'] == 2000 for item in ui._top5_last100)


def test_last100_sync_persists_canonical_resolution_without_changing_issuance_fields(tmp_path):
    import numpy as np
    sync_method = get_method('_sync_top5_last100_from_logs')

    class Engine:
        def __init__(self, logs):
            self.logs = logs

    class SyncUI:
        _sync_top5_last100_from_logs = sync_method
        def __init__(self, logs):
            self.engine = Engine(logs)
            self._top5_last100 = [{
                'id': 'forecast-1', 'prediction': 'LONG', 'entry': 100.0,
                'sl': 98.0, 'tp1': 102.0, 'issued_prediction_probability': 0.77,
                'prediction_probability': 0.77, 'resolved': 0,
            }]
            self.saved = 0
        def _save_top5_history(self):
            self.saved += 1

    logs = tmp_path / 'logs'
    logs.mkdir()
    (logs / 'AAA_predictions.json').write_text(json.dumps([{
        'id': 'forecast-1', 'resolved': 1, 'result': 'TP2', 'tp1_hit': True,
        'tp2_hit': True, 'resolved_at': 1234, 'prediction': 'LONG',
        'entry': 100.0, 'sl': 98.0, 'tp1': 102.0, 'prediction_probability': 0.99,
    }]), encoding='utf-8')
    ui = SyncUI(logs)
    ui._sync_top5_last100_from_logs()
    item = ui._top5_last100[0]
    assert item['resolved'] == 1
    assert item['result'] == 'TP2'
    assert item['tp2_hit'] is True
    assert item['entry'] == 100.0
    assert item['sl'] == 98.0
    assert item['tp1'] == 102.0
    assert item['issued_prediction_probability'] == 0.77
    assert item['prediction_probability'] == 0.77
    assert ui.saved == 1
