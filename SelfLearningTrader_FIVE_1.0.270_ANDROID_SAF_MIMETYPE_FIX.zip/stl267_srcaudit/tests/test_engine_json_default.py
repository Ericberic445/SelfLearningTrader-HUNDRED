from pathlib import Path
from core.engine import LearningEngine


def test_engine_read_json_honors_dict_default_for_missing_or_invalid_file(tmp_path):
    engine = LearningEngine.__new__(LearningEngine)
    missing = tmp_path / 'missing.json'
    assert engine._read_json(missing, {}) == {}
    broken = tmp_path / 'broken.json'
    broken.write_text('{not-json', encoding='utf-8')
    assert engine._read_json(broken, {}) == {}
    assert engine._read_json(missing) == []
