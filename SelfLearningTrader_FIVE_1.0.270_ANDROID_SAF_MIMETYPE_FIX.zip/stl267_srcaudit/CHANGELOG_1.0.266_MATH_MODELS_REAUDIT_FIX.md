# SelfLearningTrader FIVE 1.0.266 — mathematical model audit fixes

## Formula version
- `MATH_FORMULA_VERSION` increased from 7 to 8. Previous probability maps are intentionally not reused because target/stop event definitions and Monte Carlo path construction changed.

## Managed TP/SL first-passage probabilities
- Simulated paths now follow the same protective-stop state machine as live forecasts: original SL before TP1, breakeven after TP1, TP1 after TP2.
- TP1/TP2/TP3 remain credited after later protective stops.
- Multiple ordered TP levels may be crossed in one candle when the favorable extreme passes them in order.
- A same-candle touch of the active protective stop and the next TP is unresolved and receives half credit rather than invented chronology.
- Calibration labels now use the same state machine as the probability model.

## Temporal validation and calibration
- Calibration samples record their forecast horizon in seconds.
- Chronological validation purges training cycles whose label horizon overlaps the validation period. Promotion requires at least 80 independent scan cycles and 100 matured samples so the 75/25 holdout can retain at least 20 validation cycles.
- Timestamp arrays are normalized before computing horizon duration, avoiding seconds/milliseconds mismatch.
- New v8 calibration accumulates only from forecasts generated under formula v8. v7 samples are not relabeled with the new formula.

## Monte Carlo
- Simulated log-return paths retain their step returns.
- Historical upper/lower wick pairs are sampled jointly, conditioned on simulated return quantile bins, preserving empirical dependence between candle return and OHLC excursions.
- OHLC wick history is expanded to the 720-return window.

## SARIMA and data quality
- SARIMA can use up to 720 returns and requires at least six seasonal cycles; noisy seasonal coefficients are shrunk toward zero according to available seasonal history.
- Price/OHLC sanitation no longer forward-fills or back-fills invalid values. Computation uses the valid suffix after the most recent invalid candle to avoid manufacturing a return across a corrupted bar.

## Validation
- Added regression tests for managed stops, multiple ordered targets in one candle, temporal embargo, and invalid-price handling.
- Full test suite result recorded after final packaging.
