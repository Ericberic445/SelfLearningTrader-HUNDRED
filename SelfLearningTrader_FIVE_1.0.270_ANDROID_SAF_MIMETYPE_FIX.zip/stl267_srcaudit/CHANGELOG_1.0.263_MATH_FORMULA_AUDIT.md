# SelfLearningTrader FIVE 1.0.263 — math formula audit fixes

- Corrected flat-market RSI, Bollinger-band position, range position and zero-volatility ratio to neutral values.
- Replaced overlapping Bayesian horizon observations with disjoint horizon blocks to avoid false effective sample size.
- Updated Monte Carlo TP/SL first-passage calculation to include sampled recent intrabar High/Low excursions and conservative same-candle SL precedence.
- Prevented benchmark calculations from falling back to positional pairing when timestamp inputs are supplied but do not align.
- Sorted/deduplicated correlation-matrix timestamps and rejected series without sufficient contiguous returns.
- Corrected sample weighting when reliability-map bins collapse to duplicate probability coordinates.
- Incremented `MATH_FORMULA_VERSION` to 6 and release version to 1.0.263, invalidating prior probability calibration maps.
- Statistics, UI and forecast lifecycle rules were not changed.
