# SelfLearningTrader FIVE 1.0.263 — Intrabar First-Touch Fix

## User-defined outcome rule

The first barrier reached determines the outcome. A later SL cannot erase a TP milestone already reached. A later TP cannot erase an SL already reached.

## Changes

- Added KuCoin 1-minute candle support for resolving conflicting events inside a 5-minute candle.
- If TP1 is reached in an earlier 1-minute candle and the price later reaches the original SL / active protective stop, the confirmed TP milestone is retained.
- If SL is reached in an earlier 1-minute candle, the forecast is recorded as SL even if a later 1-minute candle reaches TP.
- If TP and SL are both inside the same 1-minute candle, OHLC data cannot establish chronology. The forecast remains `WAITING_INTRABAR_ORDER`, excluded from statistics and training rather than being incorrectly forced to SL or TP.
- Applied the same ambiguity rule to lens/combination outcome evaluation.
- Monte Carlo first-passage estimates no longer systematically assign same-candle ties to SL; ambiguous probability mass is split neutrally.
- Math calibration skips unresolved same-candle TP/SL labels.
- Incremented `MATH_FORMULA_VERSION` from 6 to 7 so prior calibration maps are invalidated and rebuilt for the changed outcome semantics.
- Updated the in-app explanation. No other UI layout or statistics calculations were changed.

## Verification

- Python compilation: passed.
- Full pytest suite: 254 passed, 24 subtests passed.
- Additional focused TP/SL ordering tests cover TP-first, SL-first, and same-1m ambiguity.

## Limitation

KuCoin 1-minute OHLC resolves order across separate 1-minute candles. If both barriers are inside the same 1-minute candle, OHLC still cannot prove the tick-by-tick order. Such a case is deliberately left unclassified rather than inventing a result.
