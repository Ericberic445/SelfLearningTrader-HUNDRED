# SelfLearningTrader FIVE 1.0.261 — one-shot post-SL recovery

## Behaviour
- On startup, a background one-shot recovery scans per-contract `*_pending.json` logs for resolved forecasts awaiting post-SL recheck.
- If `sl_event_time` is absent, fetches 5-minute KuCoin Futures candles over the forecast's maximum 8-hour lifecycle plus the post-SL observation window, verifies the historical window is sufficiently complete and contiguous, and reconstructs the first SL candle.
- Checks the three closed candles after SL for TP1/TP2/TP3 recovery and updates the canonical pending record, matching prediction log record, and verification fields without changing original direction, confidence, Entry, SL, or TP levels.
- If a complete, contiguous historical window proves the SL event cannot be reconstructed, removes that forecast ID from pending/prediction logs and visible TOP5 history stores. It does not erase aggregate experience/statistics ledgers.
- Network errors, incomplete candle windows, or missing IDs are not considered proof of unrecoverability. Those rows remain for retry on a later app start.
- After all eligible rows are recovered or conclusively removed, writes `.post_sl_recovery_v1_done.json`; later starts skip the routine.

## Self-removal clarification
The routine self-disables after completion and leaves only a small marker. Android apps cannot reliably delete a Python module from their installed APK at runtime; the source module remains in the APK. It does not run again after the completion marker is written.

## Validation
- Added four focused tests covering recovery, network retry, conclusive removal, and marker behavior.
- Full test suite and APK/device execution must be validated before claiming production runtime success.
