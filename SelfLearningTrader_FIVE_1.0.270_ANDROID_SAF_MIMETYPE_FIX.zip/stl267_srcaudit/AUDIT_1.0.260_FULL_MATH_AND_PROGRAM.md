# SelfLearningTrader FIVE 1.0.260 — audit results

## Exact source inspected

- Base source: `/mnt/data/math_audit_work`, the project source corresponding to the 1.0.259 fix package, checked against the 2026-10-29 backup findings.
- Release identity synchronized to `1.0.260` / Android numeric version `10260`.
- Verification: `PYTHONPATH=/mnt/data/math_audit_work pytest -q` → **235 passed, 24 subtests passed**; `python -m compileall -q app tests` succeeded.
- No APK was built or run on a physical Android device. Network/KuCoin behavior and Android background lifecycle therefore remain runtime verification items.

## Changes made in 1.0.260

### 1. Canonical statistics corrected

`LearningEngine._reconcile_learning_ledgers()` now rebuilds both `total_*` and `current_*` outcome counters from the same deduplicated eligible resolved prediction ledger. `_append_experience()` no longer increments trade totals using replay rows/observation rows; after a resolution batch it recomputes the outcome counters from canonical resolved predictions. This prevents `total_tp1=0` while `current_tp1=355`, and prevents replay observations from being counted as additional trades. The reconciliation continues to exclude post-SL rows whose required recheck is pending.

### 2. TOP-5 history resolution synchronization corrected

Added `UI._sync_top5_last100_from_logs()`. On opening the last-100 screen, it builds one index over the per-contract prediction logs and writes current resolution state (`resolved`, TP/SL flags, result, verification state, post-SL recheck state, timestamps and related outcome fields) back into `top5_last100.json`. Issuance-time direction, entry/SL/TP levels and issuance confidence are preserved; later state changes cannot rewrite the original signal. This replaces repeated full-directory reads per row with a single index pass.

### 3. Invalid TP/SL distance inputs no longer create false barrier hits

In `compute_math_snapshot()`, nonpositive or nonfinite target distances are discarded rather than clamped to zero. A zero-distance TP could otherwise count a path as touching the target without a positive move. A nonpositive or nonfinite stop distance now returns neutral path probabilities instead of evaluating a meaningless barrier. Regression tests cover both cases.

### 4. Added mathematical contract tests

Added synthetic flat, monotonic-up, monotonic-down and noisy-market tests for all declared `MATH_FEATURES`, checking that all declared features exist and are finite, probability outputs remain in [0,1], TP1 ≥ TP2 ≥ TP3, and WAIT path probabilities remain neutral. Existing regression tests continue to cover ARIMA/SARIMA fitting, GARCH constraints, cointegration gate, wavelet/Markov behavior, directional TP/SL path probabilities, benchmark alignment, calibration gating, and seed reproducibility.

## Formula-by-formula implementation review

| Model/feature | Code-path reviewed | Result / boundary |
|---|---|---|
| Markov | `_markov` | Three return-sign states; no-history and constant series neutral. Regression tests pass. |
| Probability of movement | simulated terminal move vs volatility threshold | Finite and bounded; it is non-directional and should not be treated as LONG/SHORT probability. |
| AR | `_ols_ar` | Least-squares AR(p), guarded for short samples. |
| ARIMA(1,1,1) | `_arima_111` | Fits ARMA(1,1) on differenced log-price returns with bounded CSS search; finite synthetic-series test passes. |
| Seasonal AR | `_sarima_101_101` | Multiplicative seasonal AR with constrained cross-term; synthetic test passes. Seasonal period is hard-coded as 12 in the current caller. |
| GARCH(1,1) | `_fit_garch11`, `_garch` | Constrained nonnegative coefficients and alpha+beta < 1; zero-volatility and synthetic fit tests pass. Output feature is normalized volatility, not a signed direction forecast. |
| Hurst / fractal dimension | `_hurst` and `2-H` | Bounded and finite; short/constant series return neutral H=0.5. This is an estimator, not an exact Hurst calculation. |
| Mean reversion | `_mean_reversion` | Detrends log-price before reversion estimate; constant/short series neutral. |
| Cointegration | `_relative_spread` | Engle-Granger residual regression + approximate residual ADF gate. Code itself documents approximate critical values; it is not an exact finite-sample p-value. |
| Correlation | `_correlation` and timestamp matching | Pair returns are matched on identical timestamps when timestamp arrays are present; missing/insufficient overlap returns neutral. |
| Return/volatility correlation | `_return_vol_correlation` | Correlation of returns with absolute returns; finite and bounded. |
| Trend deviation | `_trend_deviation` | Detrended residual normalized by residual SD; neutral if insufficient variation. |
| Entropy | `_entropy` | Histogram entropy normalized by log2(bins); constant/short series neutral. |
| Wavelet | `_wavelet_dwt` | Multilevel Haar detail feature; regression tests cover alternating, step and flat inputs. |
| Kalman | `_kalman` | Two-state local-linear trend filter; price-level shift invariance test passes. |
| Monte Carlo | `_monte_carlo_paths` / `_monte_carlo` | 2,000 paths in main snapshot, fitted AR(1)+GARCH volatility, empirical standardized innovations, stable seed. Output estimates terminal positive-return probability; it is not a guaranteed calibrated probability. |
| Bayesian | `_bayesian` | Beta-Bernoulli estimate of positive cumulative log-return windows with Jeffreys prior. Overlapping horizon windows are correlated, as noted in source; interpret as a descriptive estimate until independent calibration. |
| Change point | `_change_point` | Recent split-mean difference normalized by SD; bounded. It is a recent-change score, not a formal significance test. |
| TP1/TP2/TP3 and SL | first-passage scan of Monte Carlo paths | Counts each target only if hit before original SL; monotonic target order enforced. Invalid barrier distances are now rejected. A path touching neither target nor SL is not counted as either event. |
| Probability calibration | `fit_math_probability_calibration`, `apply_math_probability_calibration` | Chronological group holdout and per-head promotion gate. Only heads in `validated_heads` are calibrated; unvalidated maps cannot change published outputs. |

## Other program behavior reviewed

- Original forecast ID and issuance probability are retained in TOP-5 history; the new synchronization updates outcome fields only.
- The 100-entry screen is intentionally a filtered list: LONG/SHORT only, original selected-direction confidence ≥70%. It is not the count of all scanned coins or all forecasts.
- The detailed TOP-5 history retains only the latest 20 scan cycles (up to 100 positions including WAIT); the separate confidence-filtered list can retain up to 100 eligible forecast IDs.
- The original direction/Entry/SL/TP must not be overwritten by later opposite signals; the history synchronization explicitly preserves those fields.
- Forecast result statistics exclude post-SL cases still awaiting required recheck.
- Model promotion, scanning and background service have unit tests, but these cannot prove the behavior of the Android process while the screen is locked or of live KuCoin endpoints.

## Remaining issues / limits, not falsely marked fixed

1. The backup contains **131** post-SL recheck-pending predictions, and some lack `sl_event_time`. The backup does not include enough verified historical candle data to reconstruct those event timestamps safely. They remain pending/excluded until actual historical candles can recover them or the app observes sufficient data.
2. The independent calibration sample is still too small/weak for several probability heads. This is not automatically a formula-implementation error; the code has to be correct separately from the question of whether a model predicts well.
3. The ADF cointegration critical value is approximate, and the Bayesian horizon windows overlap. These are implementation/model-design limitations documented above, not hidden as confirmed defects.
4. No APK/device integration test was run in this audit. Network errors, Android battery policies, service restart and live market response must be verified from runtime logs/device behavior.
5. The audit is source/test-based and covers all mathematical feature code paths and key lifecycle/statistics flows, but it does not claim mathematical proof of every estimator for every possible input or guaranteed trading profitability.
