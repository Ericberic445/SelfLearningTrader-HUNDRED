# SelfLearningTrader FIVE 1.0.262 — mathematical direction fixes

## Confirmed formula defects corrected

1. **Kalman local-linear-trend direction was inverted.**
   The filter estimates a one-step predicted level. The old feature used
   `current_observation - predicted_next_level`, which assigns a negative
   directional score to a rising local trend and a positive score to a falling
   local trend. It now uses `predicted_next_level - current_observation`.

2. **Haar wavelet signed detail was inverted.**
   The old detail coefficient used `(left - right) / sqrt(2)`. For a rising
   sequence this is negative, despite the feature being routed as a signed
   directional signal. It now uses `(right - left) / sqrt(2)`, so positive
   recent changes produce a positive feature and negative changes produce a
   negative feature.

3. **Probability calibration version advanced from 4 to 5.**
   Historical calibration maps were learned with the previous feature semantics.
   They must not be carried into the corrected formula release. Existing raw
   historical records tagged with version 4 remain historical data and are not
   silently relabeled as version 5.

## Regression tests

Added explicit rising/falling synthetic-series tests for both directional
features and a formula-version invalidation test. Full test suite result is
recorded with the release build.

## Verification

- Full test suite: **242 passed, 24 subtests passed**.
- `python -m compileall -q app tests`: passed.
- Android APK/device runtime test: not run in this environment.
