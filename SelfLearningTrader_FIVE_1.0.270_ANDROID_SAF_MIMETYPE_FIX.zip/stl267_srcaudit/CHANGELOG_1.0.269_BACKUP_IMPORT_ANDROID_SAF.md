# SelfLearningTrader FIVE 1.0.269 — Android backup import

## Changes
- Fixed the manual file-picker integration: activity results are now registered with `android.activity.bind`, not `PythonActivity.bind`.
- Added Android Storage Access Framework `ACTION_OPEN_DOCUMENT` picker to the backup import dialog.
- Manual picker accepts ZIP/SLBACKUP files from any location exposed by Android's document provider; the selected archive is validated before restore.
- Automatic backup discovery now queries MediaStore on mounted external volumes, rather than relying only on the primary external alias/Downloads directory.
- Automatic discovery accepts both `.slbackup` and `.slbackup.zip` filenames.
- Backup restoration still verifies the archive manifest and checksums before writing restored data.
- Bumped app release identity to 1.0.269 / Android version code 10269.

## Android storage limitation
Android does not allow an ordinary app to crawl every private app directory or every provider's private storage. MediaStore discovery covers indexed shared external storage on mounted volumes. The SAF picker provides user-authorized access to other files/locations exposed by Android's document providers.

## Validation
- Python compilation: `app/main.py`, `app/core/backup.py`
- Test suite: 268 passed, 24 subtests passed.
- APK build and device-level Android picker interaction still require GitHub Actions/device verification.
