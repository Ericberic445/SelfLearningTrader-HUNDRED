# 1.0.260 — full math review and statistics fixes

- Recompute `total_*` and `current_*` outcome counters from the same deduplicated canonical resolved prediction ledger at startup reconciliation and after resolution batches.
- Prevent replay/observation rows from being counted as extra resolved trades.
- Synchronize saved TOP-5 last-100 resolution fields from per-contract prediction logs while preserving immutable issuance fields and confidence.
- Reject nonpositive/nonfinite TP/SL distances rather than clamping them into zero-distance barriers.
- Add regression tests for invalid barrier distances and all math-feature output contracts across flat, rising, falling and noisy synthetic markets.
- Release identity synchronized to 1.0.260 / numeric version 10260.
- Verification: 235 passed, 24 subtests passed; compileall succeeded.
- Not claimed fixed: 131 historical post-SL records awaiting recheck, some missing event timestamps; no APK/device/live exchange integration test in this build.
