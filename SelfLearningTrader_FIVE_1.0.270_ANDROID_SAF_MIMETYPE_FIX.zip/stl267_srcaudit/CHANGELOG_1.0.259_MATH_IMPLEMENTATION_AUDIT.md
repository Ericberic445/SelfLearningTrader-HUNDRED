# SelfLearningTrader FIVE 1.0.259 — math implementation audit fixes

## Fixed

1. `LearningEngine._read_json` now accepts an explicit fallback value. This fixes the existing call that read `learning_ledger_reconciliation.json` with `{}` as the fallback but previously raised `TypeError` because `_read_json` accepted only `path`. List-backed journals retain `[]` as their default.
2. Probability calibration maps are now applied only to probability heads explicitly approved by the chronological holdout validation (`validated_heads`). Previously a map with at least 100 rows could transform a live probability even when that head had failed or had not passed independent validation. This was inconsistent with the validation gate used by directional scoring.
3. Added regression tests for both behaviors.
4. Synchronized package version metadata to 1.0.259 / numeric version 10259.

## Verification

- Full test suite: 231 passed, 9 subtests passed.
- Focused math/reference tests: included in the full suite.
- This verifies covered code paths and regression cases. It does not claim that mathematical models predict market outcomes reliably or that an APK has been built/run on a physical Android device.
