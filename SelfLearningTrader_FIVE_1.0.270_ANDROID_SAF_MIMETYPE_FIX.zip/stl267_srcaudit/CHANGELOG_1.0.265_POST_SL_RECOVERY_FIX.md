# SelfLearningTrader FIVE 1.0.265 — POST-SL recovery repair

## Root cause
The 1.0.261 recovery module searched only `*_pending.json`. The 2026-11-02 backup contained 167 eligible `post_sl_recheck_pending` records in 81 `*_predictions.json` archives and zero eligible records in pending queues. The old one-shot marker could then make the module report completion without processing the durable prediction records.

## Changes
- Scan both `*_predictions.json` and `*_pending.json`; deduplicate using `(contract, prediction_id)`.
- Existing legacy v1 marker does not suppress work when eligible records are found in either store.
- Use a v2 completion marker. Write it only when no records remain retryable; remove a stale v2 marker when transient failures remain.
- Update every matching existing prediction and pending copy after recovery.
- Delete only matching `(contract, prediction_id)` records after a complete, contiguous eight-hour history proves that the original SL was never touched.
- Treat incomplete candle windows, gaps, malformed OHLC, missing IDs, invalid required fields, and API/network failures as retryable rather than proof of unrecoverability.
- Reuse one exchange client per contract during a recovery run.
- Run recovery before the normal market scan to prevent concurrent JSON writes. The market scan still starts if recovery encounters an error.

## Tests
- Prediction-only record is recovered despite an old v1 marker.
- Prediction-only record is removed only after conclusive full-history validation.
- Incomplete history remains queued for retry.
- Both prediction and pending copies are updated.
- Existing recovery, network-error, removal, and marker tests remain passing.

Full test suite: `python -m pytest -q` — 260 passed, 24 subtests passed.

APK build and live KuCoin execution were not performed.
