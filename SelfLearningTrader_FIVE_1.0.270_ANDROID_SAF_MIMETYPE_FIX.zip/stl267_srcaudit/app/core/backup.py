import hashlib
import io
import json
import os
import shutil
import tempfile
import time
import zipfile
from pathlib import Path

BACKUP_PREFIX = "SelfLearningTrader_backup_"
BACKUP_EXT = ".slbackup"
FORMAT_VERSION = 2


def _safe_name():
    return f"{BACKUP_PREFIX}{time.strftime('%Y%m%d_%H%M%S')}_{int(time.time()*1000)%1000:03d}{BACKUP_EXT}"


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _zip_userdata(user_dir: Path) -> bytes:
    user_dir = Path(user_dir)
    bio = io.BytesIO()
    files = []
    with zipfile.ZipFile(bio, "w", zipfile.ZIP_DEFLATED) as z:
        for path in sorted(user_dir.rglob("*")):
            if not path.is_file():
                continue
            rel = path.relative_to(user_dir).as_posix()
            if rel.endswith(BACKUP_EXT) or rel.startswith("cache/") or rel.startswith("tmp/"):
                continue
            try:
                data = path.read_bytes()
                z.writestr(rel, data)
                files.append({"path": rel, "size": len(data), "sha256": _sha256_bytes(data)})
            except OSError:
                continue
        included = {str(x.get("path", "")) for x in files}
        learning_required = [
            "stl_generational_v15_3/runtime/models_v8_self_learning/GLOBAL/champion.npz",
            "stl_generational_v15_3/runtime/models_v8_self_learning/GLOBAL/champion.json",
        ]
        learning_optional = [
            "stl_generational_v15_3/runtime/models_v8_self_learning/GLOBAL/master_decision.npz",
            "stl_generational_v15_3/runtime/models_v8_self_learning/GLOBAL/master_decision.json",
            "stl_generational_v15_3/runtime/data/global_experience.npz",
            "stl_generational_v15_3/runtime/data/master_decision_experience.npz",
            "stl_generational_v15_3/runtime/data/training_batch_state.json",
            "stl_generational_v15_3/runtime/data/experience_stats.json",
            "stl_generational_v15_3/runtime/models_v8_self_learning/GLOBAL/outcome_model.npz",
            "stl_generational_v15_3/runtime/models_v8_self_learning/GLOBAL/outcome_model.json",
            "stl_generational_v15_3/runtime/models_v8_self_learning/GLOBAL/shared_master_base.json",
            "stl_generational_v15_3/runtime/models_v8_self_learning/GLOBAL/master_learning_state.json",
            "stl_generational_v15_3/runtime/models_v8_self_learning/GLOBAL/master_lens_performance.json",
            "stl_generational_v15_3/runtime/data/experience_schema_v2.json",
            "stl_generational_v15_3/runtime/data/learning_audit.jsonl",
        ]
        manifest = {
            "format": FORMAT_VERSION,
            "created": int(time.time()),
            "app_state": "full_user_data",
            "backup_type": "FULL_LEARNING_STATE",
            "description": "SelfLearningTrader full Master trade-outcome learning state backup with fixed lenses and per-file checksums",
            "file_count": len(files),
            "files": files,
            "learning_state": {
                "required_files": learning_required,
                "missing_required": [p for p in learning_required if p not in included],
                "included_optional": [p for p in learning_optional if p in included],
                "master_model_present": "stl_generational_v15_3/runtime/models_v8_self_learning/GLOBAL/champion.npz" in included,
                "experience_present": "stl_generational_v15_3/runtime/data/global_experience.npz" in included,
            },
        }
        z.writestr("BACKUP_MANIFEST.json", json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True))
    return bio.getvalue()


def verify_backup_bytes(data: bytes, require_learning_state=False) -> tuple[bool, str, dict]:
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            bad = z.testzip()
            if bad:
                return False, f"Повреждён файл внутри архива: {bad}", {}
            names = z.namelist()
            if 'BACKUP_MANIFEST.json' not in names:
                return False, 'Нет BACKUP_MANIFEST.json.', {}
            manifest = json.loads(z.read('BACKUP_MANIFEST.json').decode('utf-8'))
            if manifest.get('app_state') != 'full_user_data':
                return False, 'Неподдерживаемый тип резервной копии.', manifest
            entries = manifest.get('files') or []
            checked = 0
            missing = []
            bad_hash = []
            for item in entries:
                rel = str(item.get('path',''))
                if not rel or rel not in names:
                    missing.append(rel)
                    continue
                raw = z.read(rel)
                if int(item.get('size', len(raw))) != len(raw) or str(item.get('sha256','')) != _sha256_bytes(raw):
                    bad_hash.append(rel)
                checked += 1
            if missing:
                return False, f"Не хватает файлов в резервной копии: {len(missing)}", manifest
            if bad_hash:
                return False, f"Нарушены контрольные суммы: {len(bad_hash)}", manifest
            if int(manifest.get('file_count', checked)) != checked:
                return False, 'Количество файлов не совпадает с манифестом.', manifest
            if require_learning_state:
                if manifest.get('backup_type') != 'FULL_LEARNING_STATE':
                    return False, 'Это не резервная копия полного состояния обучения.', manifest
                learning = manifest.get('learning_state') or {}
                missing_required = list(learning.get('missing_required') or [])
                if missing_required:
                    return False, 'В резервной копии отсутствуют обязательные файлы обучения: ' + ', '.join(missing_required), manifest
                required = list(learning.get('required_files') or [])
                if not all(rel in names for rel in required):
                    return False, 'В резервной копии отсутствует обязательное состояние Master.', manifest
            return True, f"Архив исправен: {checked} файлов, контрольные суммы совпадают.", manifest
    except zipfile.BadZipFile:
        return False, 'Файл не является корректным ZIP-архивом.', {}
    except Exception as exc:
        return False, f'Ошибка проверки архива: {exc}', {}


def _android_download_write(name: str, data: bytes, mime_type: str = 'application/octet-stream') -> str | None:
    """Write *data* to the real public Android Downloads collection.

    Android 10+ uses MediaStore.Files explicitly through the nested Java class
    name.  We deliberately do not access ``MediaStore.Downloads`` as a Python
    attribute because pyjnius on some Android builds exposes nested classes
    differently (that was the source of the previous export failure).
    """
    try:
        from jnius import autoclass
        Environment = autoclass('android.os.Environment')
        BuildVersion = autoclass('android.os.Build$VERSION')
        JString = autoclass('java.lang.String')
        JInteger = autoclass('java.lang.Integer')
        PythonActivity = autoclass('org.kivy.android.PythonActivity')
        activity = PythonActivity.mActivity
        resolver = activity.getContentResolver()
        if int(BuildVersion.SDK_INT) >= 29:
            MediaStoreFiles = autoclass('android.provider.MediaStore$Files')
            ContentValues = autoclass('android.content.ContentValues')
            values = ContentValues()
            values.put(JString('_display_name'), JString(name))
            values.put(JString('mime_type'), JString(mime_type))
            values.put(JString('relative_path'), JString(Environment.DIRECTORY_DOWNLOADS + '/'))
            values.put(JString('is_pending'), JInteger(1))
            collection = MediaStoreFiles.getContentUri('external')
            uri = resolver.insert(collection, values)
            if uri is None:
                raise RuntimeError('Android не создал запись в Downloads')
            try:
                stream = resolver.openOutputStream(uri)
                if stream is None:
                    raise RuntimeError('Android не открыл файл Downloads для записи')
                try:
                    stream.write(data)
                    stream.flush()
                finally:
                    stream.close()
                done = ContentValues()
                done.put(JString('is_pending'), JInteger(0))
                resolver.update(uri, done, None, None)
            except Exception:
                try:
                    resolver.delete(uri, None, None)
                except Exception:
                    pass
                raise
            # Read the content back before reporting success. This guarantees
            # that the exported file is really readable from Downloads.
            check = resolver.openInputStream(uri)
            if check is None:
                raise RuntimeError('Android сохранил запись, но не дал прочитать файл обратно')
            try:
                returned = bytearray()
                buf = bytearray(1024 * 1024)
                while True:
                    n = check.read(buf)
                    if n < 0:
                        break
                    returned.extend(buf[:n])
            finally:
                check.close()
            if bytes(returned) != bytes(data):
                try:
                    resolver.delete(uri, None, None)
                except Exception:
                    pass
                raise RuntimeError('Проверка сохранённого файла не пройдена: содержимое отличается')
            return str(uri.toString())
        d = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath()
        os.makedirs(d, exist_ok=True)
        target = os.path.join(d, name)
        with open(target, 'wb') as f:
            f.write(data)
        if Path(target).read_bytes() != bytes(data):
            try:
                os.remove(target)
            except Exception:
                pass
            raise RuntimeError('Проверка сохранённого файла в Downloads не пройдена')
        return target
    except Exception as exc:
        raise RuntimeError('Android Download export failed: ' + str(exc)) from exc


def _android_download_list():
    """Find backup archives across MediaStore-visible shared storage volumes.

    Enumerates Android shared-storage MediaStore volumes and accepts both
    .slbackup and .slbackup.zip. Private app directories remain protected by
    Android and can be reached through the SAF manual picker.
    """
    out = []
    seen = set()
    try:
        from jnius import autoclass
        PythonActivity = autoclass('org.kivy.android.PythonActivity')
        activity = PythonActivity.mActivity
        resolver = activity.getContentResolver()
        sdk = int(autoclass('android.os.Build$VERSION').SDK_INT)

        if sdk >= 29:
            MediaStoreFiles = autoclass('android.provider.MediaStore$Files')
            projection = ['_id', '_display_name', 'date_modified']
            volumes = ['external']
            try:
                volume_names = autoclass('android.provider.MediaStore').getExternalVolumeNames(activity)
                iterator = volume_names.iterator()
                while iterator.hasNext():
                    volume = str(iterator.next())
                    if volume and volume not in volumes:
                        volumes.append(volume)
            except Exception:
                pass

            for volume in volumes:
                try:
                    collection = MediaStoreFiles.getContentUri(volume)
                    cur = resolver.query(collection, projection, None, None, 'date_modified DESC')
                    if not cur:
                        continue
                    try:
                        name_idx = cur.getColumnIndex('_display_name')
                        id_idx = cur.getColumnIndex('_id')
                        while cur.moveToNext():
                            name = str(cur.getString(name_idx)) if name_idx >= 0 else ''
                            lower = name.lower()
                            if not (lower.startswith(BACKUP_PREFIX.lower()) and (
                                lower.endswith(BACKUP_EXT.lower()) or
                                lower.endswith(BACKUP_EXT.lower() + '.zip')
                            )):
                                continue
                            ident = cur.getLong(id_idx)
                            uri = collection.buildUpon().appendPath(str(ident)).build()
                            uri_text = str(uri.toString())
                            if uri_text not in seen:
                                seen.add(uri_text)
                                out.append((name, uri_text))
                    finally:
                        cur.close()
                except Exception:
                    continue
        else:
            Environment = autoclass('android.os.Environment')
            roots = []
            try:
                roots.append(Path(Environment.getExternalStorageDirectory().getAbsolutePath()))
            except Exception:
                pass
            try:
                for java_path in activity.getExternalFilesDirs(None):
                    if java_path:
                        p = Path(str(java_path.getAbsolutePath()))
                        for _ in range(4):
                            p = p.parent
                        roots.append(p)
            except Exception:
                pass
            for root in dict.fromkeys(roots):
                try:
                    for pattern in (BACKUP_PREFIX + '*' + BACKUP_EXT,
                                    BACKUP_PREFIX + '*' + BACKUP_EXT + '.zip'):
                        for p in root.rglob(pattern):
                            if p.is_file():
                                key = str(p)
                                if key not in seen:
                                    seen.add(key)
                                    out.append((p.name, key))
                except Exception:
                    continue
    except Exception:
        pass
    out.sort(key=lambda item: item[0], reverse=True)
    return out


def _read_source(uri_or_path: str) -> bytes:
    if uri_or_path.startswith('content://'):
        from jnius import autoclass
        PythonActivity=autoclass('org.kivy.android.PythonActivity')
        Uri=autoclass('android.net.Uri')
        resolver=PythonActivity.mActivity.getContentResolver()
        stream=resolver.openInputStream(Uri.parse(uri_or_path))
        buf=bytearray(); chunk=bytearray(1024*1024)
        while True:
            n=stream.read(chunk)
            if n < 0: break
            buf.extend(chunk[:n])
        stream.close(); return bytes(buf)
    return Path(uri_or_path).read_bytes()


def export_backup(user_dir) -> tuple[bool, str]:
    data=_zip_userdata(Path(user_dir))
    ok, msg, manifest = verify_backup_bytes(data, require_learning_state=True)
    if not ok:
        return False, 'Резервная копия НЕ создана: ' + msg
    name=_safe_name()
    uri=_android_download_write(name, data, 'application/zip')
    if uri:
        try:
            saved = _read_source(uri)
            ok_saved, msg_saved, saved_manifest = verify_backup_bytes(saved, require_learning_state=True)
            if not ok_saved:
                return False, 'Файл в Download создан, но проверка сохранённой копии не пройдена: ' + msg_saved
            return True, f"Резервная копия обучения сохранена в Download: {name} ({saved_manifest.get('file_count',0)} файлов; Master и контрольные суммы проверены)"
        except Exception as exc:
            return False, 'Файл в Download создан, но не удалось подтвердить его содержимое: ' + str(exc)
    return False, 'Не удалось сохранить резервную копию именно в Download. Внутреннюю копию вместо неё не создавал.'

def list_backups():
    return _android_download_list()


def verify_backup_source(source) -> tuple[bool, str, dict]:
    try:
        data = _read_source(source)
        return verify_backup_bytes(data, require_learning_state=True)
    except Exception as exc:
        return False, f'Не удалось прочитать резервную копию: {exc}', {}


def verify_all_backups(user_dir) -> tuple[bool, str, list]:
    items = list_backups()
    local = sorted(Path(user_dir).glob(BACKUP_PREFIX+'*'+BACKUP_EXT), key=lambda p:p.stat().st_mtime, reverse=True)
    seen = {name for name,_ in items}
    items += [(p.name, str(p)) for p in local if p.name not in seen]
    if not items:
        return True, 'Резервных копий не найдено.', []
    results=[]; bad=0
    for name, src in items:
        ok,msg,manifest = verify_backup_source(src)
        results.append({'name':name,'ok':ok,'message':msg,'file_count':manifest.get('file_count',0)})
        bad += 0 if ok else 1
    return bad == 0, f'Проверено резервных копий: {len(results)}. Ошибок: {bad}.', results


def restore_backup(user_dir, source) -> tuple[bool, str]:
    data=_read_source(source)
    ok,msg,_=verify_backup_bytes(data, require_learning_state=True)
    if not ok:
        return False, 'Резервная копия не прошла проверку: ' + msg
    bio=io.BytesIO(data)
    with zipfile.ZipFile(bio) as z:
        names=z.namelist()
        manifest=json.loads(z.read('BACKUP_MANIFEST.json').decode('utf-8'))
        for n in names:
            p=Path(n)
            if p.is_absolute() or '..' in p.parts:
                return False, 'Резервная копия содержит небезопасный путь.'
        user_dir=Path(user_dir); user_dir.mkdir(parents=True, exist_ok=True)
        stage=Path(tempfile.mkdtemp(prefix='slt_restore_', dir=str(user_dir.parent)))
        try:
            z.extractall(stage)
            # Copy only after the complete archive has passed checksum validation.
            for src in stage.rglob('*'):
                if not src.is_file() or src.name=='BACKUP_MANIFEST.json': continue
                rel=src.relative_to(stage); dst=user_dir/rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src,dst)
        finally:
            shutil.rmtree(stage, ignore_errors=True)
    return True, f'Обученная модель и накопленное состояние восстановлены. Проверено файлов: {manifest.get("file_count",0)}. Перезапусти приложение.'
