"""One-time repair of legacy post-SL forecasts with a missing SL timestamp.

Scans both per-contract prediction archives and pending queues. A legacy
completion marker never suppresses a scan when eligible records still exist.
Transient/incomplete history is retryable and is never deleted.
"""
from pathlib import Path
import json
import math
import time

from .exchange import KuCoin
from .engine import _timestamp_seconds

MARKER_NAME = '.post_sl_recovery_v2_done.json'
LEGACY_MARKER_NAME = '.post_sl_recovery_v1_done.json'
RECHECK_BARS = 3
BAR_SECONDS = 300
MAX_LIFETIME_BARS = 96


def _read(path, default):
    try:
        value = json.loads(path.read_text(encoding='utf-8'))
        return value if isinstance(value, type(default)) else default
    except Exception:
        return default


def _write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.recovery.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
    tmp.replace(path)


def _normalized_times(bars):
    try:
        return [_timestamp_seconds(x) for x in bars['time']]
    except Exception:
        return []


def _contiguous(times):
    return bool(times) and all(
        times[i] - times[i - 1] == BAR_SECONDS for i in range(1, len(times))
    )


def _first_sl_index(item, bars):
    direction = str(item.get('prediction', '')).upper()
    try:
        sl = float(item.get('sl'))
        entry_time = _timestamp_seconds(item.get('time', 0))
    except (TypeError, ValueError, OverflowError):
        return None
    if direction not in ('LONG', 'SHORT') or not math.isfinite(sl) or sl <= 0 or entry_time <= 0:
        return None
    times = _normalized_times(bars)
    if not times:
        return None
    highs, lows = bars['high'], bars['low']
    start = next((i for i, stamp in enumerate(times) if stamp >= entry_time), None)
    if start is None:
        return None
    stop = min(len(times), start + MAX_LIFETIME_BARS + 1)
    for i in range(start, stop):
        try:
            high, low = float(highs[i]), float(lows[i])
        except (TypeError, ValueError, OverflowError, IndexError):
            return None
        if not (math.isfinite(high) and math.isfinite(low)):
            return None
        touched = low <= sl if direction == 'LONG' else high >= sl
        if touched:
            return i
    return None


def _recover_record(item, exchange):
    """Return (status, updated_record); status is recovered/unrecoverable/retry."""
    if not isinstance(item, dict) or not item.get('post_sl_recheck_pending'):
        return 'skip', item
    direction = str(item.get('prediction', '')).upper()
    try:
        sl = float(item.get('sl'))
        issue = _timestamp_seconds(item.get('time', 0))
    except (TypeError, ValueError, OverflowError):
        return 'retry', item
    if direction not in ('LONG', 'SHORT') or not math.isfinite(sl) or sl <= 0 or issue <= 0:
        return 'retry', item

    try:
        sl_ts = _timestamp_seconds(item.get('sl_event_time') or 0)
        if sl_ts > 0:
            start = sl_ts - 2 * BAR_SECONDS
            end = sl_ts + (RECHECK_BARS + 2) * BAR_SECONDS
            bars = exchange.candles_between('5min', start, end)
            times = _normalized_times(bars)
            if not times or not _contiguous(times):
                return 'retry', item
            idx = min(range(len(times)), key=lambda i: abs(times[i] - sl_ts))
            if abs(times[idx] - sl_ts) > BAR_SECONDS:
                return 'retry', item
        else:
            # Fetch the complete 8-hour forecast lifetime plus post-SL bars.
            end_time = issue + (MAX_LIFETIME_BARS + RECHECK_BARS + 2) * BAR_SECONDS
            bars = exchange.candles_between('5min', issue, end_time)
            raw_times = _normalized_times(bars)
            if (len(raw_times) < MAX_LIFETIME_BARS or
                    raw_times[0] > issue + BAR_SECONDS or
                    raw_times[-1] < issue + MAX_LIFETIME_BARS * BAR_SECONDS or
                    not _contiguous(raw_times)):
                return 'retry', item
            try:
                highs_check = [float(x) for x in bars['high']]
                lows_check = [float(x) for x in bars['low']]
                if (len(highs_check) != len(raw_times) or len(lows_check) != len(raw_times) or
                        not all(math.isfinite(x) for x in highs_check + lows_check)):
                    return 'retry', item
            except Exception:
                return 'retry', item
            idx = _first_sl_index(item, bars)
            if idx is None:
                # A complete, contiguous lifecycle with valid price data and no
                # SL touch is the only basis for conclusive removal.
                return 'unrecoverable', item
            sl_ts = raw_times[idx]
            item['sl_event_time'] = sl_ts
            item['sl_event_index'] = int(idx)

        # Require three consecutive closed candles strictly after the SL candle.
        a, b = idx + 1, idx + 1 + RECHECK_BARS
        times = _normalized_times(bars)
        if b > len(times) or any(times[j] - times[j - 1] != BAR_SECONDS for j in range(a, b)):
            return 'retry', item

        highs, lows = bars['high'], bars['low']
        levels = []
        for label in ('tp1', 'tp2', 'tp3'):
            try:
                value = float(item.get(label))
                if math.isfinite(value) and value > 0:
                    levels.append((label.upper(), value))
            except (TypeError, ValueError, OverflowError):
                pass
        hit = None
        for label, level in reversed(levels):
            crossed = (any(float(highs[j]) >= level for j in range(a, b))
                       if direction == 'LONG' else
                       any(float(lows[j]) <= level for j in range(a, b)))
            if crossed:
                hit = label
                break

        item.update({
            'post_sl_recheck_pending': False,
            'post_sl_recheck_complete': True,
            'post_sl_recheck_bars': RECHECK_BARS,
            'post_sl_recovery': bool(hit),
            'post_sl_recovery_level': hit,
            'post_sl_recovery_bars': None,
            'verification_state': 'COMPLETED_SL_POST_RECHECK',
            'post_sl_recovery_rebuilt': True,
            'post_sl_recovery_rebuilt_at': int(time.time()),
        })
        if hit:
            item['direction_confirmed'] = True
            item['direction_target'] = direction
            item['direction_confirmation_source'] = 'POST_SL_RECOVERY'
            item['learning_interpretation'] = 'DIRECTION_RIGHT_ENTRY_TIMING_WRONG'
        return 'recovered', item
    except Exception:
        # Network/API failures and malformed responses are temporary uncertainty.
        return 'retry', item


def _record_key(contract, row, fallback):
    pid = str(row.get('id') or '').strip()
    return (contract, pid) if pid else (contract, f'__missing_id_{fallback}')


def run_once(root, log_callback=None):
    """Repair eligible post-SL rows across both prediction and pending stores."""
    root = Path(root)
    marker = root / MARKER_NAME
    logs = root / 'logs'
    prediction_paths = ({p.stem[:-len('_predictions')]: p
                         for p in logs.glob('*_predictions.json')} if logs.exists() else {})
    pending_paths = ({p.stem[:-len('_pending')]: p
                      for p in logs.glob('*_pending.json')} if logs.exists() else {})

    # Predictions are the durable archive; pending is a queue/cache. Merge both
    # sources by (contract,id), retaining fields from either copy.
    wanted = {}
    for contract, path in pending_paths.items():
        rows = _read(path, [])
        if not isinstance(rows, list):
            continue
        for index, row in enumerate(rows):
            if isinstance(row, dict) and row.get('post_sl_recheck_pending'):
                key = _record_key(contract, row, f'pending_{index}')
                wanted[key] = dict(row)
    for contract, path in prediction_paths.items():
        rows = _read(path, [])
        if not isinstance(rows, list):
            continue
        for index, row in enumerate(rows):
            if isinstance(row, dict) and row.get('post_sl_recheck_pending'):
                key = _record_key(contract, row, f'prediction_{index}')
                merged = dict(wanted.get(key, {}))
                # Durable prediction row wins conflicts; pending fills missing data.
                merged.update(row)
                wanted[key] = merged

    # A legacy v1 marker with zero work must not hide records in predictions.
    # If there are no eligible rows, either marker is safe to respect.
    if marker.exists() and not wanted:
        return {'status': 'already_complete', 'recovered': 0, 'removed': 0, 'retry': 0}
    if (root / LEGACY_MARKER_NAME).exists() and not wanted:
        return {'status': 'already_complete', 'recovered': 0, 'removed': 0, 'retry': 0}
    if not wanted:
        _write(marker, {'completed': True, 'completed_at': int(time.time()),
                        'recovered': 0, 'removed': 0, 'retry': 0})
        return {'status': 'complete', 'recovered': 0, 'removed': 0, 'retry': 0}

    recovered_keys, removed_keys = set(), set()
    recovered = removed = retry = 0
    exchanges = {}
    for key, item in wanted.items():
        contract, pid = key
        if pid.startswith('__missing_id_'):
            retry += 1
            continue
        if contract not in exchanges:
            exchanges[contract] = KuCoin(contract)
        status, updated = _recover_record(dict(item), exchanges[contract])
        if status == 'recovered':
            recovered += 1
            recovered_keys.add(key)
            for store in (pending_paths, prediction_paths):
                path = store.get(contract)
                if not path:
                    continue
                rows = _read(path, [])
                changed = False
                if isinstance(rows, list):
                    for row in rows:
                        if isinstance(row, dict) and str(row.get('id') or '') == pid:
                            row.update(updated)
                            changed = True
                if changed:
                    _write(path, rows)
        elif status == 'unrecoverable':
            removed += 1
            removed_keys.add(key)
        elif status == 'retry':
            retry += 1
        if log_callback:
            try:
                log_callback(f'POST-SL recovery {contract}: {status}')
            except Exception:
                pass

    # Remove only conclusive failures, and only matching contract+ID records.
    if removed_keys:
        for store in (pending_paths, prediction_paths):
            for contract, path in store.items():
                rows = _read(path, [])
                if not isinstance(rows, list):
                    continue
                kept = [row for row in rows if not (
                    isinstance(row, dict) and
                    (contract, str(row.get('id') or '')) in removed_keys
                )]
                if len(kept) != len(rows):
                    _write(path, kept)
        for path in (root / 'top5_last100.json', root / 'data' / 'top5_last100.json',
                     root / 'top5_history.json', root / 'data' / 'top5_history.json'):
            rows = _read(path, [])
            if isinstance(rows, list):
                kept = [row for row in rows if not (
                    isinstance(row, dict) and any(
                        str(row.get('id') or '') == pid for _, pid in removed_keys
                    )
                )]
                if len(kept) != len(rows):
                    _write(path, kept)

    if retry == 0:
        _write(marker, {'completed': True, 'completed_at': int(time.time()),
                        'recovered': recovered, 'removed': removed, 'retry': 0})
    else:
        # Remove a stale marker so next startup will retry the unresolved rows.
        try:
            marker.unlink(missing_ok=True)
        except Exception:
            pass
    return {'status': 'complete' if retry == 0 else 'retry_pending',
            'recovered': recovered, 'removed': removed, 'retry': retry}
