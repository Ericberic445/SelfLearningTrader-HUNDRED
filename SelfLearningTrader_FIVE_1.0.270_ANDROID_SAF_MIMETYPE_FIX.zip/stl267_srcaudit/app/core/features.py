import numpy as np

BASE_FEATURES = [
    'ret1','ret3','ret8','rsi','ema12d','ema26d','macd','macds',
    'atrpct','bbpos','volz','rangepct','trend','volatility'
]
MTF_FEATURES = [
    'rsi_15','trend_15','volz_15', 'rsi_1h','trend_1h','volz_1h',
    'rsi_4h','trend_4h','volz_4h', 'rsi_1d','trend_1d','volz_1d'
]
MARKET_FEATURES = ['book_imbalance','oi_change','funding','liquidation_bias']
FEATURES = BASE_FEATURES + MTF_FEATURES + MARKET_FEATURES

# Separate causal inputs for the market-regime classifier. Keeping this head
# separate preserves compatibility of the existing Master direction model.
REGIME_FEATURES = [
    'ret1', 'ret3', 'ret8', 'rsi', 'ema12d', 'ema26d', 'macd', 'macds',
    'atrpct', 'bbpos', 'volz', 'rangepct', 'trend', 'volatility',
    'trend_15', 'trend_1h', 'trend_4h', 'trend_1d',
    'regime_efficiency', 'regime_persistence', 'regime_reversal_rate',
    'regime_range_pct', 'regime_range_position', 'regime_volatility_ratio',
    'regime_mtf_alignment',
]
REGIME_NAMES = {0: 'TREND_DOWN', 1: 'RANGE', 2: 'TRANSITION', 3: 'TREND_UP'}


def _arr(df, name):
    return np.asarray(df[name], dtype=float)


def _ema(a, span):
    a = np.asarray(a, dtype=float)
    out = np.empty_like(a); out[0] = a[0] if len(a) else 0.0
    alpha = 2.0 / (span + 1.0)
    for i in range(1, len(a)):
        out[i] = alpha * a[i] + (1-alpha) * out[i-1]
    return out


def _rolling_mean(a, n):
    out = np.full(len(a), np.nan)
    if len(a) >= n:
        cs = np.cumsum(np.r_[0.0, a])
        out[n-1:] = (cs[n:] - cs[:-n]) / n
    return out


def _rolling_std(a, n):
    out = np.full(len(a), np.nan)
    if len(a) >= n:
        for i in range(n-1, len(a)):
            out[i] = np.std(a[i-n+1:i+1], ddof=1)
    return out


def _rolling_mean_std(a, n):
    return _rolling_mean(a,n), _rolling_std(a,n)


def _rsi(c, n=14):
    """Wilder-smoothed RSI; a flat series is neutral (50), not oversold (0)."""
    c = np.asarray(c, dtype=float)
    if not len(c):
        return np.asarray([], dtype=float)
    d = np.diff(c, prepend=c[0])
    up = np.maximum(d, 0.0); dn = np.maximum(-d, 0.0)
    au = _ema_alpha(up, 1.0/n); ad = _ema_alpha(dn, 1.0/n)
    total = au + ad
    out = np.full(len(c), 50.0, dtype=float)
    # Scale the zero-movement tolerance to the instrument's price level.
    valid = total > np.maximum(np.abs(c) * 1e-12, 1e-15)
    out[valid] = 100.0 * au[valid] / total[valid]
    return out


def _ema_alpha(a, alpha):
    a=np.asarray(a,float); out=np.empty_like(a)
    if not len(a): return out
    out[0]=a[0]
    for i in range(1,len(a)): out[i]=alpha*a[i]+(1-alpha)*out[i-1]
    return out


def add_features(df):
    t=np.asarray(df['time']); c=_arr(df,'close'); h=_arr(df,'high'); l=_arr(df,'low'); v=_arr(df,'volume')
    n=len(c); x={'time':t.copy(),'close':c.copy(),'open':_arr(df,'open'),'high':h.copy(),'low':l.copy(),'volume':v.copy()}
    ret1=np.full(n,np.nan); ret3=np.full(n,np.nan); ret8=np.full(n,np.nan)
    if n>1: ret1[1:]=c[1:]/c[:-1]-1
    if n>3: ret3[3:]=c[3:]/c[:-3]-1
    if n>8: ret8[8:]=c[8:]/c[:-8]-1
    e12=_ema(c,12); e26=_ema(c,26); mac=e12-e26
    pc=np.r_[c[0],c[:-1]]; tr=np.maximum.reduce([h-l,np.abs(h-pc),np.abs(l-pc)])
    atr=_ema_alpha(tr,1/14)
    mid,sd=_rolling_mean_std(c,20); vm,vs=_rolling_mean_std(v,30)
    bbpos = np.full(n, np.nan, dtype=float)
    bb_valid = np.isfinite(mid) & np.isfinite(sd)
    bb_tolerance = np.maximum(np.abs(mid) * 1e-12, 1e-15)
    bb_moving = bb_valid & (sd > bb_tolerance)
    bb_flat = bb_valid & ~bb_moving
    bbpos[bb_moving] = (c[bb_moving] - (mid[bb_moving] - 2*sd[bb_moving])) / (4*sd[bb_moving])
    bbpos[bb_flat] = 0.5
    x.update({
      'ret1':ret1,'ret3':ret3,'ret8':ret8,'rsi':_rsi(c),'ema12d':c/(e12+1e-12)-1,
      'ema26d':c/(e26+1e-12)-1,'macd':mac/(c+1e-12),'macds':_ema(mac,9)/(c+1e-12),
      'atrpct':atr/(c+1e-12),'bbpos':bbpos,
      'volz':(v-vm)/(vs+1e-12),'rangepct':(h-l)/(c+1e-12),'trend':(e12-e26)/(c+1e-12),
      'volatility':_rolling_std(ret1,30)
    })
    # Causal regime descriptors. These use only candles at or before index i.
    # They are intentionally kept outside FEATURES so old direction-model
    # weights remain loadable while the new regime head is introduced.
    efficiency=np.full(n,np.nan); persistence=np.full(n,np.nan); reversals=np.full(n,np.nan)
    range_pct=np.full(n,np.nan); range_pos=np.full(n,np.nan); vol_ratio=np.full(n,np.nan)
    for i in range(n):
        if i >= 12:
            net=abs(c[i]/c[i-12]-1.0)
            path=float(np.nansum(np.abs(ret1[i-11:i+1])))
            efficiency[i]=float(np.clip(net/(path+1e-12),0.0,1.0))
            direction=np.sign(c[i]-c[i-12])
            rr=np.sign(ret1[i-11:i+1]); rr=rr[np.isfinite(rr)&(rr!=0)]
            persistence[i]=float(np.mean(rr==direction)) if len(rr) and direction!=0 else 0.0
            reversals[i]=float(np.mean(rr[1:]!=rr[:-1])) if len(rr)>1 else 0.0
        if i >= 23:
            hi=float(np.max(h[i-23:i+1])); lo=float(np.min(l[i-23:i+1]))
            range_pct[i]=(hi-lo)/(c[i]+1e-12)
            range_tolerance=max(abs(float(c[i]))*1e-12,1e-15)
            range_pos[i]=(0.5 if hi-lo <= range_tolerance else float(np.clip((c[i]-lo)/(hi-lo),0.0,1.0)))
        if i >= 47:
            short=float(np.nanstd(ret1[i-11:i+1])); long=float(np.nanstd(ret1[i-47:i+1]))
            vol_ratio[i]=(1.0 if short <= 1e-12 and long <= 1e-12 else float(short/(long+1e-12)))
    x.update({'regime_efficiency':efficiency,'regime_persistence':persistence,
              'regime_reversal_rate':reversals,'regime_range_pct':range_pct,
              'regime_range_position':range_pos,'regime_volatility_ratio':vol_ratio,
              'regime_mtf_alignment':np.full(n,np.nan)})
    return x


def _nearest_values(target_t, source_t, source, source_tf_seconds=None):
    tt=np.asarray(target_t); st=np.asarray(source_t); out={}
    if len(st)==0:
        return None
    order=np.argsort(st); st=st[order]
    # Candle timestamps are candle OPEN times. A higher-timeframe feature is
    # available only after that candle's full duration has elapsed.
    scale = 1_000_000 if np.nanmax(np.abs(st)) > 1e14 else (1000 if np.nanmax(np.abs(st)) > 1e11 else 1)
    available = st + int(source_tf_seconds or 0) * scale
    idx=np.searchsorted(available,tt,side='right')-1
    valid=idx>=0
    idx=np.clip(idx,0,len(st)-1)
    for k,a in source.items():
        if k=='time': continue
        aa=np.asarray(a)
        if len(aa)!=len(source_t): raise ValueError(f'MTF feature {k} length {len(aa)} != time length {len(source_t)}')
        values=aa[order][idx].astype(float, copy=True)
        values[~valid]=np.nan
        out[k]=values
    return out


def align_mtf(base, frames):
    x={k:np.asarray(v).copy() for k,v in base.items()}
    target=x['time']; n=len(target)
    suffixes={'15min':('15',900),'1hour':('1h',3600),'4hour':('4h',14400),'1day':('1d',86400)}
    for tf,(suf,seconds) in suffixes.items():
        if tf not in frames or len(frames[tf]['time'])==0:
            for k in ('rsi','trend','volz'): x[f'{k}_{suf}']=np.full(n,np.nan)
            continue
        z=add_features(frames[tf]); vals=_nearest_values(target,z['time'],z,seconds)
        for k in ('rsi','trend','volz'): x[f'{k}_{suf}']=vals[k]
    # Alignment is a context feature, not a direction vote: fraction of higher
    # timeframes that agree with the local EMA trend sign.
    base_sign=np.sign(np.asarray(x.get('trend',np.zeros(n)),float))
    mtf=[]
    for name in ('trend_15','trend_1h','trend_4h','trend_1d'):
        z=np.asarray(x.get(name,np.full(n,np.nan)),float)
        mtf.append(np.isfinite(z) & (np.sign(z)==base_sign) & (base_sign!=0))
    valid=np.zeros(n,dtype=float); count=np.zeros(n,dtype=float)
    for name in ('trend_15','trend_1h','trend_4h','trend_1d'):
        z=np.asarray(x.get(name,np.full(n,np.nan)),float)
        valid += np.isfinite(z).astype(float)
        count += (np.isfinite(z) & (np.sign(z)==base_sign) & (base_sign!=0)).astype(float)
    x['regime_mtf_alignment']=np.where(valid>0,count/np.maximum(valid,1),np.nan)
    for c in MARKET_FEATURES:
        if c not in x: x[c]=np.zeros(n,dtype=float)
    return x


def make_labels(x,horizon,long_threshold,short_threshold):
    c=np.asarray(x['close'],float); n=len(c); fut=np.full(n,np.nan); h=int(horizon)
    if h>0 and n>h: fut[:-h]=c[h:]/c[:-h]-1
    y=np.full(n,np.nan)
    y[fut>=long_threshold]=2; y[fut<=short_threshold]=0
    mid=(fut<long_threshold)&(fut>short_threshold); y[mid]=1
    z={k:np.asarray(v).copy() for k,v in x.items()}; z['target']=y
    return z


def make_regime_labels(x, horizon, long_threshold, short_threshold):
    """Label historical regimes from future path shape, never from current inputs.

    Classes: 0 downtrend, 1 range, 2 transition/ambiguous, 3 uptrend.
    The returned target is for training only; no future-derived field is added
    to REGIME_FEATURES.
    """
    c=np.asarray(x['close'],float); h=np.asarray(x['high'],float); l=np.asarray(x['low'],float)
    atr=np.asarray(x.get('atrpct',np.full(len(c),np.nan)),float)
    n=len(c); horizon=max(2,int(horizon)); target=np.full(n,np.nan)
    if n<=horizon: return {**x,'regime_target':target}
    for i in range(n-horizon):
        start=float(c[i]); end=float(c[i+horizon])
        if not np.isfinite(start) or start<=0 or not np.isfinite(end): continue
        future=c[i+1:i+horizon+1]
        step=np.diff(np.r_[start,future])/(np.r_[start,future][:-1]+1e-12)
        path=float(np.sum(np.abs(step)))
        net=float(end/start-1.0)
        efficiency=float(abs(net)/(path+1e-12))
        nonzero=np.sign(step[np.isfinite(step)&(step!=0)])
        direction_persistence=float(np.mean(nonzero==np.sign(net))) if len(nonzero) and net!=0 else 0.0
        a=float(atr[i]) if i<len(atr) and np.isfinite(atr[i]) else 0.0
        threshold=max(abs(float(long_threshold)),abs(float(short_threshold)),a*np.sqrt(horizon)*0.30)
        if net>=threshold and efficiency>=0.35 and direction_persistence>=0.55:
            target[i]=3
        elif net<=-threshold and efficiency>=0.35 and direction_persistence>=0.55:
            target[i]=0
        elif abs(net)<threshold and efficiency<0.35:
            target[i]=1
        else:
            target[i]=2
    return {**x,'regime_target':target}
