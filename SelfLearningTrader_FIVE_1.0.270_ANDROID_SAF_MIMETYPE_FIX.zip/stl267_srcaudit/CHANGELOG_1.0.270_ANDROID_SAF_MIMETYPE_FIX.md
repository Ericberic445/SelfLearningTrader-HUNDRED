# SelfLearningTrader FIVE 1.0.270 — Android backup import picker fix

## Changes
- Fixed SAF picker crash: removed `Intent.EXTRA_MIME_TYPES` being populated with `java.util.ArrayList`. Android expects a Java `String[]` for this extra; `ACTION_OPEN_DOCUMENT` now uses `*/*`, then validates the selected archive before restore.
- Automatic discovery enumerates MediaStore external volume names as well as the legacy `external` collection.
- Automatic discovery recognizes both `.slbackup` and `.slbackup.zip` names.
- Manual SAF selection remains available for files in document providers and locations that MediaStore cannot index.
- Backup manifest/checksum validation and staged restore behavior are unchanged.
- Trading, forecasting, Master/Challenger learning logic and UI layout were not intentionally changed.

## Android storage boundary
Automatic scanning cannot read every protected/private app folder on modern Android. It searches shared-storage files exposed through MediaStore on mounted external volumes. The manual Android document picker is the user-authorized route for locations outside that index.

## Validation
- Python compilation: `app/main.py`, `app/core/backup.py`.
- Test suite: 268 passed, 24 subtests passed.
- Device-level SAF picker test and APK build are not yet verified; run GitHub Actions and test on the Samsung device before replacing the installed build.
