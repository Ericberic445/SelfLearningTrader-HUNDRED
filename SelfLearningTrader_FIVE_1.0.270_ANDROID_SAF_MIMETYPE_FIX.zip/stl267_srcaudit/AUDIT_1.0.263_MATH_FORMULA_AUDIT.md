# SelfLearningTrader FIVE 1.0.263 — mathematical formula audit

## Scope

Audited the source project supplied as `SelfLearningTrader_FIVE_1.0.261_POST_SL_RECOVERY.zip`. Changes are limited to mathematical feature and probability calculations, plus release/formula version metadata and regression tests. Statistics, forecast lifecycle rules, UI and scanner behavior were not intentionally changed.

## Confirmed formula defects corrected

1. **Flat-market RSI was 0 instead of neutral 50.** With no gains and no losses, the previous epsilon-based RS calculation returned an oversold reading. RSI now returns 50 when smoothed gains plus losses are effectively zero. The tolerance is price-scale-aware, so low-priced contracts are not incorrectly treated as flat.
2. **Flat-market Bollinger position was 0 instead of 0.5.** A zero-width band placed a flat price at the lower edge. It now reports the band midpoint; the zero-width tolerance is price-scale-aware.
3. **Flat-market range position was 0 instead of 0.5.** A zero-width high/low range now reports the midpoint with a price-scale-aware tolerance.
4. **Flat-market volatility ratio was 0/undefined rather than neutral.** When both short and long volatility are effectively zero, the feature now returns 1.0.
5. **Bayesian horizon samples overlapped.** The old implementation counted highly overlapping horizon windows as independent Bernoulli observations and overstated confidence. It now uses disjoint horizon-sized return blocks anchored at the latest bar and remains neutral until at least ten blocks are available.
6. **TP/SL probabilities ignored intrabar High/Low.** Monte Carlo paths previously checked only simulated closes, while actual forecast resolution and calibration labels use candle highs/lows. First-passage probabilities now resample recent historical upper/lower wick excursions (last 121 candles) around simulated closes. If TP and SL are both touched in one simulated candle, SL wins, matching the conservative outcome resolver. A TP already reached on an earlier candle remains recorded if SL occurs later.
7. **Benchmark timestamp mismatch could silently fall back to positional pairing.** If timestamp arrays were supplied but malformed or mismatched, benchmark correlation/cointegration now remain neutral rather than pairing unrelated candles by array index.
8. **Correlation matrix accepted unsorted input and could retain series with too few contiguous returns.** Inputs are sorted, duplicate timestamps collapsed, and a series is retained only when it has enough contiguous returns.
9. **Reliability-map duplicate x-values were averaged without sample weights.** Duplicate probability bins are now pooled using raw success counts and their actual sample sizes before applying the Beta smoothing prior.

## Formula-by-formula review

| Model / feature | Audit result |
|---|---|
| Markov | Three return-sign states; constant/insufficient evidence is neutral. Directional score is a transition difference, not a probability. |
| Probability of movement | Non-directional absolute terminal-move probability, aligned to the configured horizon. |
| AR | Least-squares AR(3) one-step directional score, normalized by residual scale. |
| ARIMA | Fitted ARIMA(1,1,1) represented as ARMA(1,1) on log returns; bounded CSS estimator. |
| SARIMA | Multiplicative seasonal AR(1) x seasonal AR(1), season 12. Base timeline is 5-minute candles, so season 12 represents one hour. |
| GARCH | Constrained GARCH(1,1), alpha/beta nonnegative and alpha+beta below 1; output is a normalized volatility feature, not a direction vote. |
| Hurst / fractal | Variogram-style Hurst estimate on log-price levels, bounded to [0,1]; fractal dimension is 2-H. It is an estimator, not an exact statistic. |
| Mean reversion | Detrended log-price residual and OU-like half-life estimate; neutral when evidence is insufficient. |
| Cointegration | Engle-Granger residual regression plus augmented residual ADF gate. Critical value remains approximate, not an exact finite-sample p-value. |
| Correlation | Return correlation; timestamp-aware benchmark alignment and matrix inputs. Invalid alignment now yields neutral output. |
| Return/volatility correlation | Correlation between returns and absolute returns; risk descriptor only. |
| Trend deviation | Detrended residual score; contrarian sign by design. |
| Entropy | Normalized histogram entropy; complexity descriptor, not direction. |
| Wavelet | Multilevel Haar detail feature; positive detail corresponds to recent pairwise rises. |
| Kalman | Two-state local-linear level/slope filter; directional sign checked by rising/falling synthetic paths. |
| Monte Carlo | 2,000 paths, fitted AR(1)+GARCH volatility and empirical standardized innovations; intrabar excursions now included in TP/SL first-passage checks. It remains a model estimate, not a guaranteed calibrated probability. |
| Bayesian | Jeffreys Beta-Bernoulli estimate using non-overlapping horizon blocks; a historical base-rate estimate, not a conditional market-state model. |
| Change point | Recent split-mean shift score; change detector, not a formal significance test. |
| TP1/TP2/TP3/SL | First-touch probabilities use simulated close paths plus sampled historical High/Low excursions; same-candle TP/SL ambiguity is resolved as SL. Later SL does not erase an earlier TP milestone. |
| Probability calibration | Chronological scan-cycle holdout, raw issuance probabilities, per-head promotion gate and monotone reliability maps. Only individually validated heads can calibrate or vote. |

## Formula versioning

`MATH_FORMULA_VERSION` increased from 5 to 6. Previous calibration maps are therefore not reused for the changed formulas; new version-6 observations must mature and pass the existing chronological validation gate.

## Verification

- Full test suite: **251 passed, 24 subtests passed**.
- `python -m compileall -q app tests`: passed.
- Synthetic flat, rising, falling and noisy price paths were checked. Flat RSI/Bollinger/range features now return neutral values; rising/falling paths preserve directional sign; TP/SL path ordering and same-candle handling have regression coverage.
- No statistics code, UI code, or forecast lifecycle rules were changed.
- No APK or live KuCoin/device test is claimed by this source audit.

## Remaining limitations

1. Cointegration uses an approximate Engle-Granger residual critical value and does not claim an exact finite-sample p-value.
2. Historical wick excursions are resampled independently of simulated return innovations. This is materially closer to actual High/Low resolution than close-only barriers, but it does not reproduce the full joint distribution of OHLC bars or wick/volatility dependence.
3. Bayesian is still a historical unconditional horizon base rate. It must pass the chronological validation gate before influencing live directional selection.
4. AR/ARIMA/SARIMA/Markov outputs are directional scores, not calibrated probabilities. Probability calibration is applied only to the explicitly declared probability heads.
5. The math layer uses fixed estimators; `math_learning_enabled` remains false. The probability-calibration process can update after matured outcomes, but individual mathematical formula weights are not autonomously trained.
6. The audit is source/test-based. Android background execution, live KuCoin feeds, real scan timing and live predictive accuracy still require device/runtime verification.
