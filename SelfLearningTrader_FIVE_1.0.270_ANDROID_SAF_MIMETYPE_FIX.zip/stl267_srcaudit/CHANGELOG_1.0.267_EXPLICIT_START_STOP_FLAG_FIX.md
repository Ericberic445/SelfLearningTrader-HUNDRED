# SelfLearningTrader FIVE 1.0.267 — explicit START / persisted STOP fix

## Root cause
The visible ON/OFF toggle confirmed START by calling `scan()` directly. Unlike the legacy START button, it did not clear `background_scan_control.json` (`stop=true`, `user_stopped=true`). The Android service checks `stop` immediately at entry and exited with `SERVICE START blocked by user stop flag`. The UI could therefore display a start attempt while the service never entered its scan loop.

## Fix
- Added one explicit-start preparation transition used by the visible toggle and legacy START button.
- Cancels stale stop-watchdog/resume-wait callbacks, resets stale local scan flags, and atomically writes `stop=false`, `desired_running=true`, `user_stopped=false` before calling `scan()`.
- The service-replacement resume path also clears the persisted STOP before requesting the replacement service.
- No changes to prediction logic, TP/SL, statistics, mathematical models, training data, or UI layout.

## Verification
- Python compile check passed.
- Full test suite: 267 passed, 24 subtests passed.
- Android APK build and live device startup were not performed in this environment.
