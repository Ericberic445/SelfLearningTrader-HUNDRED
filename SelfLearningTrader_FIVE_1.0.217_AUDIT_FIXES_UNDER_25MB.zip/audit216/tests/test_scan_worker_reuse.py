from unittest.mock import patch

from app.core.engine import LearningEngine


class FakeExchange:
    symbol_count = 12
    def __init__(self, symbol='XBTUSDTM', timeout=25):
        self.futures_symbol = symbol
        self.timeout = timeout
        self._request_gap = 0.2

    def set_symbol(self, symbol):
        self.futures_symbol = str(symbol).upper().replace('-', '')

    def active_symbols(self):
        return [{'contract': f'COIN{i}USDTM', 'display': f'COIN{i}-USDT', 'turnover': 1_000_000 + i}
                for i in range(self.symbol_count)]


class WorkerEngine:
    instances = []

    def __init__(self, root, exchange, config):
        self.root = root
        self.exchange = exchange
        self.cfg = config
        type(self).instances.append(self)

    def _quick_candidate(self, item):
        self.exchange.set_symbol(item['contract'])
        return {'contract': item['contract'], 'symbol': item['display'], 'price': 100.0,
                'quick_score': 0.8, 'quality': 0.9, 'turnover24h': item['turnover']}

    def _scan_train_and_predict(self, item, scan_history=800, run_id=None):
        self.exchange.set_symbol(item['contract'])
        return {'contract': item['contract'], 'exchange_symbol': item['contract'],
                'symbol': item['display'], 'prediction': 'LONG', 'price': 100.0,
                'edge_score': 0.8, 'quality': 0.9, 'turnover24h': item['turnover'],
                'features': {}, 'run_id': run_id}


def test_full_scan_reuses_engine_per_worker_not_per_symbol(tmp_path):
    WorkerEngine.instances = []
    engine = LearningEngine.__new__(LearningEngine)
    engine.root = tmp_path
    engine.cfg = {'scan_workers': 4, 'scan_model_workers': 2,
                  'scan_deep_candidates': 8, 'scan_second_stage_candidates': 5,
                  'history_limit': 1200, 'scan_request_gap': 0.2, 'scan_model_request_gap': 0.2}
    engine.exchange = FakeExchange()
    engine._stage25_validate = lambda rows, progress=None, cancel_event=None: list(rows)
    engine._persist_scan_prediction = lambda row: None
    engine.readiness = lambda: {'ready': False}

    with patch('app.core.exchange.KuCoin', FakeExchange), patch('app.core.engine.LearningEngine', WorkerEngine):
        rows, total, quick_ok, errors, diag = engine.scan_all()

    assert total == 12
    assert quick_ok == 12
    assert errors == 0
    assert len(rows) == 5
    # At most one engine per active worker in each of the two scan phases.
    # A per-symbol implementation would create 12 + 8 instances instead.
    assert len(WorkerEngine.instances) <= 6
    assert diag['timings_seconds']['total'] >= 0


def test_scan_pipeline_scales_to_700_symbols_and_still_returns_top5(tmp_path):
    class Exchange700(FakeExchange):
        symbol_count = 700
    WorkerEngine.instances = []
    engine = LearningEngine.__new__(LearningEngine)
    engine.root = tmp_path
    engine.cfg = {'scan_workers': 4, 'scan_model_workers': 2,
                  'scan_deep_candidates': 50, 'scan_second_stage_candidates': 25,
                  'history_limit': 1200, 'scan_request_gap': 0.2, 'scan_model_request_gap': 0.2}
    engine.exchange = Exchange700()
    engine._stage25_validate = lambda rows, progress=None, cancel_event=None: list(rows)
    engine._persist_scan_prediction = lambda row: None
    engine.readiness = lambda: {'ready': False}
    with patch('app.core.exchange.KuCoin', Exchange700), patch('app.core.engine.LearningEngine', WorkerEngine):
        rows, total, quick_ok, errors, diag = engine.scan_all()
    assert total == 700
    assert quick_ok == 700
    assert errors == 0
    assert len(rows) == 5
    assert len({r['contract'] for r in rows}) == 5
    assert diag['deep_candidates'] == 50
    assert diag['second_stage_candidates'] == 25
    assert len(WorkerEngine.instances) <= 6
    assert diag['timings_seconds']['total'] >= 0
