# HUNDRED 1.0.214 — RESUME state fix

Fixed only the STOP -> RESUME foreground-service transition.

- If the replacement service is already STARTING/RUNNING with a fresh heartbeat, the UI immediately switches to STOP.
- RESUME no longer remains visible while the service is actually running.
- Terminal STOPPED/empty/non-live states still start a fresh foreground service.
- TOP-5, TOP-100, Master/Challenger, training, prediction and scanner logic are unchanged.
