# SelfLearningTrader FIVE 1.0.252 — mathematical accuracy audit

## Changes

- Bumped `MATH_FORMULA_VERSION` from 3 to 4 so legacy calibration samples are not reused after formula and sample-semantics corrections.
- Persisted raw probability heads at issuance separately from calibrated output values. Calibration samples now use raw values only; old formula-version rows and rows missing raw probabilities are marked as skipped once instead of being rescanned on every recheck.
- Added a chronological split grouped by scan cycle. Probability heads are validated only when the later holdout has enough rows/cycles and beats the training-prevalence baseline on raw Brier skill, training-fitted calibrated Brier skill, and AUC. Unvalidated Monte Carlo/Bayesian/TP1/TP2/TP3/SL heads are neutralized in directional lenses and risk ranking.
- Aligned the Bayesian estimator to the configured multi-bar horizon.
- Converted price series to log returns consistently and aligned price levels with the 120-return window.
- Aligned benchmark correlation/cointegration inputs on shared candle timestamps rather than truncating arrays by length.
- Treated exactly-zero Monte Carlo terminal paths as neutral (half a vote), preventing a flat market from producing a bearish probability of zero.
- Detrended the log-price series before estimating mean reversion, preventing a deterministic monotonic trend from being misclassified as a strong reversal signal.
- Forward-filled invalid/nonpositive prices rather than converting them to zero and creating extreme synthetic returns.
- Added regression tests for the above issues and preserved the UI and existing forecast lifecycle/outcome rules.

## Tests

- `python -m pytest -q`: 214 passed, 9 subtests passed.
- `python -m compileall -q app tests`: passed.

## Limitations

- The supplied backup contains formula-version-3 calibration rows that do not contain raw pre-calibration probabilities. They are diagnostic-only and are not reused to validate formula version 4.
- Current version-4 math probabilities must accumulate new matured observations before any probability head can pass independent validation. Until then, those probability heads do not affect directional selection.
- No APK was built and no live KuCoin scan was run in this audit environment. Runtime accuracy and wall-clock behavior remain unverified until tested on the device.
