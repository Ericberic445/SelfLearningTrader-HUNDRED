# SelfLearningTrader FIVE 1.0.248 — Accuracy guards

- Neutralize live `book_imbalance` because no causally aligned historical order-book series exists for training. This removes train/inference feature skew.
- Master direction updates now train a temporal candidate on older rows and promote only if balanced accuracy beats both the temporal majority baseline and incumbent on the later purged holdout. The held-out block is not included in the candidate saved by that cycle.
- Outcome-head incremental updates use the same temporal promotion gate; in-sample accuracy is no longer reported as model quality.
- TOP-25 ranking now prioritizes the math-stage `p_tp1 - p_sl` edge before direction-consensus score; missing probabilities rank last.
- No UI, forecast lifecycle, TP/SL outcome definitions, recheck queue, or archive schema changes.
- This is a guard against promoting unproven updates, not a guarantee that the observed forecast accuracy will immediately rise.
