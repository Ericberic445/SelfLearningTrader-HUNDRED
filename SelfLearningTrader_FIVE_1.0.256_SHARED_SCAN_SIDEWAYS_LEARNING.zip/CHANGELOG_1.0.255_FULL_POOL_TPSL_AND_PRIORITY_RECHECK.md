# SelfLearningTrader FIVE 1.0.255 — full-pool TP/SL verification

- Removed the fixed ten-forecast verification cap. Every active LONG/SHORT forecast in the pending pool is checked during each hourly resolution pass; one candle request advances all active forecasts for the same contract.
- Limited active TP/SL verification to the original forecast's maximum lifetime window (default 96 closed five-minute bars / 8 hours). A TP/SL crossed after that window no longer retroactively turns an expired forecast into a completed trade.
- For old pending forecasts whose original window is outside the recent candle cache, fetch the bounded historical window around the forecast issue time. If that historical request fails, keep the forecast pending for retry rather than inventing an outcome.
- If no TP/SL milestone occurred in the first eight hours, close the lifecycle as `EXPIRED_SIDEWAYS` / `SIDEWAYS`, set the observed regime to `RANGE_OR_CHOP`, and exclude it from trade statistics and training. TP1/TP2 partial milestones remain partial successes under the existing rules.
- Persist a contract-level priority queue when a pending forecast first reaches TP1/TP2/TP3 or SL. The next market analysis puts those contracts first in both the deep model stage and the math-validation stage, then stores the result as an observation only. The queue survives restarts and removes only contracts that completed the priority analysis. The old continuous model-direction recheck is no longer automatically queued or resumed; forecasts without TP/SL events wait.
- Set full-market scanning cadence to one hour, including migration of older persisted 30-minute settings. UI layout and original forecast direction/Entry/SL/TP lifecycle are unchanged.
- Added tests for full-pool resolution, priority queue persistence, hourly cadence, and sideways expiry.

Validation: Python compilation succeeded; `PYTHONPATH=. pytest -q` passed **223 tests and 9 subtests**. Android APK build and live KuCoin/tablet behavior were not verified in this environment.
