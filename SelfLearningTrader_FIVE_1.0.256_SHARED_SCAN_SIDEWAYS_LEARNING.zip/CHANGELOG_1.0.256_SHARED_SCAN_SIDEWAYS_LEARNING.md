# SelfLearningTrader FIVE 1.0.256 — shared hourly candle checks and sideways learning

- TP/SL outcome resolution now runs after the full hourly market pass, allowing all active forecasts to reuse the process-wide 5-minute candle cache populated by that pass.
- The fixed one-hour scan cadence remains unchanged; outcome-triggered analysis priority is queued for the next market pass.
- An unresolved LONG/SHORT forecast with no SL or TP hit after 96 five-minute bars (8 hours) closes as `EXPIRED_SIDEWAYS`.
- `EXPIRED_SIDEWAYS` remains excluded from trade statistics and trade-outcome labels, but is added to the direction-learning archive as a low-weight `WAIT` lesson. Available intermediate scan observations from the lifecycle are also included as direction-only samples.
- Original prediction direction and Entry/SL/TP levels are not rewritten.
- No UI redesign.
