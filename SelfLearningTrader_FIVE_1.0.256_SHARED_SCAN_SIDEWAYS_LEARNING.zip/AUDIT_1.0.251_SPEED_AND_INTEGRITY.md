# SelfLearningTrader FIVE 1.0.251 — source and runtime audit

## Scope

Reviewed the supplied 1.0.250 source archive together with the device backup `SelfLearningTrader_backup_20261021_181820_066.slbackup.zip`. The Android build uses `app/` as its source directory. The UI layout was not redesigned.

## Findings from the device backup

### Full-market scan

- Cycles 320 and 321 each scanned 695 active contracts; 694 passed the quick pre-scan.
- The funnel completed as intended: 50 deep-model candidates → 25 Stage-25 candidates → 5 TOP-5 results.
- Cycle 320 took 1,362 seconds (22m42s); cycle 321 took 1,344 seconds (22m24s).
- Cycle 321's model stage took 852 seconds; the previous cycle's model stage took 819 seconds. In cycle 321, the measured aggregate time inside `live_row()` was 3,264 worker-seconds, much larger than model prediction and diagnostics. This points to candle/API data acquisition as the main bottleneck, not the classifier calculation.
- The completed scan diagnostics reported three data errors, including one contract with too few 5m candles and two missing daily-candle responses. No MODEL-stage or math-stage deadline was hit in those two completed cycles.
- The snapshot of cycle 323 was still in PRESCAN at 637/695 contracts; its diagnostics still reflected the preceding completed cycle, so it is not treated as a completed-cycle benchmark.

### Active forecast rechecks

- The active recheck batch covered about 265 contracts and spanned roughly 75 minutes across service restart/resume events.
- At 18:13, the next batch was at 10/264 contracts. This queue is a separate bottleneck from TOP-5 publication and can accumulate behind earlier work.
- Each recheck worker previously initialized a `LearningEngine` with global-ledger migration/reconciliation enabled, even though the long-lived service engine had already done that work. Version 1.0.251 skips this redundant archive walk for recheck workers.

### Model readiness and history integrity

- The backup's readiness result was `ready=false`, score 3/14. Reported metrics included TP1 rate 44.54%, initial-SL rate 55.46%, recent-100 directional accuracy 42%, and directional precision 38.76%. The app should not be treated as ready for real trading based on this snapshot.
- The saved raw `top5_last100.json` contained 100 rows but only 71 unique contracts. Several identical forecast IDs appeared under different cycle IDs, and the legacy file still contained WAIT rows. Different coins appearing in multiple independent cycles is normal; re-counting the same prediction ID as multiple performance samples is not.
- Version 1.0.251 migrates the performance sample to unique prediction IDs and removes legacy WAIT/under-70% rows from that sample. The full cycle-level TOP-5 history and the underlying prediction/training archives remain separate and are not deleted by this cleanup.

## Changes in 1.0.251

1. **Multi-timeframe candle request sizing:** retain the full configured 5m base history. For each higher timeframe, request enough candles to cover the complete 5m timeline plus a configurable 200-bar warm-up. This avoids fetching 800/5,000 bars for every timeframe when only a much shorter higher-timeframe window is needed. For the common 800-bar scan history, the expected pagination count falls from about 20 candle requests per candidate to about 13 (approximately 35% fewer); for a 5,000-bar base history, from about 125 to about 43 (approximately 66% fewer), assuming KuCoin's usual ~200-row page size.
2. **Recheck worker initialization:** use `initialize_ledgers=False` for contract-specific recheck engines because the service engine has already migrated/reconciled the shared ledgers.
3. **TOP-5 performance history:** de-duplicate the same prediction ID across republished cycles in the last-100 performance sample, keeping the newest issuance timestamp; filter legacy WAIT and under-70% rows from that sample. Full cycle history is retained.
4. **Release consistency:** synchronized `config.json` with `app/config.json`, corrected the README's stale release identity, and advanced the package to version `1.0.251` / Android version code `10251`.

## Validation performed

- `python -m compileall -q app tests` — passed.
- `python -m pytest -q` — **202 passed, 9 subtests passed**.
- `python -m unittest discover -s tests -v` — **48 passed** before the new 1.0.251 regression tests were added.
- Tests cover the MTF request limits and representative feature convergence after the warm-up, recheck initialization, release identity/config consistency, TOP-5 history de-duplication, and the existing forecast lifecycle / TP-SL / validation gates.
- The existing LONG/SHORT forecast lifecycle remains observation-only until the original Entry/SL/TP outcome is resolved; this change does not add automatic reversals or change TP1/TP2/TP3/SL result definitions.

## Not verified here

- No live KuCoin benchmark was run after the patch. The request-count reduction is deterministic from the requested history lengths, but actual wall-clock improvement depends on network latency and API responses.
- No Android APK was built in this environment. The supplied GitHub Actions workflow is retained and the package/version/signing-key checks remain in place; the next device run is needed to validate the APK and real scan timings.
- This audit does not claim an increase in predictive accuracy. The readiness result in the supplied backup remains false; new matured forecasts and independent validation are required before readiness can change.
