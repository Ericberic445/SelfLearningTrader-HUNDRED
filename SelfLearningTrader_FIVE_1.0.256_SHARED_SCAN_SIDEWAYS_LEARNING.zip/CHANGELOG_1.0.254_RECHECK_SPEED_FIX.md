# SelfLearningTrader FIVE 1.0.254 — active recheck speed fix

## Changes

1. Active forecast rechecks call the same model analysis but skip `update_regime_training()`. That global cross-contract training-pool operation held a process-wide lock, reloaded up to 60,000 rows, sorted the pool, and could rewrite/compress it for every contract. Rechecks now use the current accepted regime model; the ordinary scan path remains responsible for updating regime training.
2. The regime trainer counts only new `(contract, candle-time)` rows that survive the retention cap. Incoming rows that are immediately discarded as too old no longer inflate `new_rows_since_train`.
3. When the retained pool has no new rows, it is not recompressed and rewritten. If the existing initial-training gate is due, training may still run from the already-loaded pool.

## Preserved behavior

- No changes to direction, features, prediction thresholds, Entry/SL/TP, forecast lifecycle, or TP/SL success rules.
- Active rechecks remain observation-only and do not create a new lifecycle or reverse the original forecast.
- Existing recheck queue policy is unchanged; no cycle is dropped or coalesced.
- Existing API retry behavior is unchanged to avoid silently losing checks during transient network failures.
- No counters or extra diagnostic logging added.
- Based on clean 1.0.252 source. The rejected 1.0.253 changes are excluded.

## Validation

- Targeted recheck, regime-learning, and release-identity tests passed: 19/19.
- Full test suite passed: 215 tests and 9 subtests.
