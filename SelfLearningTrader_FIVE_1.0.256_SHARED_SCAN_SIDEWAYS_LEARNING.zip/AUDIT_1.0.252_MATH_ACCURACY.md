# SelfLearningTrader FIVE 1.0.252 — math and predictive-quality audit

## Verified in source/tests

- Formula version bumped to 4; old version-3 calibration is deliberately invalidated.
- Raw probability values are persisted at issuance and calibration labels consume only those raw values. Already-calibrated probabilities cannot recursively become new training targets.
- Out-of-time validation splits on distinct scan cycles, not arbitrary rows. Promotion requires sufficient sample/cycle counts and improvement over the training-prevalence baseline in raw and training-fitted calibrated Brier skill plus AUC.
- Unvalidated probability heads are neutralized in directional scores, fixed mathematical lenses, and the TP1/SL ranking gate.
- Bayesian output is aligned to the configured horizon; return series use log returns; the level/return windows align.
- Benchmark correlation and cointegration use matching candle timestamps when available.
- Flat-market Monte Carlo output is neutral; a deterministic trend does not generate an artificial mean-reversion signal; invalid price points do not create extreme returns.
- Existing tests cover ARIMA/SARIMA finite behavior, GARCH parameter constraints, cointegration, first-passage TP/SL ordering, formula-version isolation, calibration monotonicity, temporal validation, readiness gates, forecast lifecycle, and archive synchronization.

## Findings in supplied device backup

- Legacy math calibration archive: 263 samples across 104 scan cycles, formula version 3. These values are already-calibrated outputs; the raw formula probabilities were not retained, so they cannot validly establish version-4 accuracy.
- Diagnostic-only chronological split of those legacy outputs: Monte Carlo AUC 0.389, Bayesian AUC 0.350, TP1 AUC 0.437, TP2 AUC 0.535, TP3 AUC 0.279, SL AUC 0.575. These are not accepted as validation for version 4; they show why the prior calibration must not be trusted as proof of predictive quality.
- The saved Master champion in the backup had validation accuracy 39.1% versus a 56.4% majority baseline; balanced accuracy was 58.9%, directional precision 38.8%, and the outcome head was 42.6% versus a 59.7% baseline. This model snapshot is not evidence of readiness for real trading.
- The backup's aggregate trade outcomes were 287 TP1-or-better out of 652 eligible completed forecasts (44.0%) and 365 initial SL (56.0%). These aggregate rates do not by themselves prove model skill or profitability.

## Verification

- `python -m pytest -q`: 214 passed, 9 subtests passed.
- `python -m compileall -q app tests`: passed.
- No ZIP was created for this audit pass, no upload was performed, no APK was built, and no live KuCoin run was performed.

## Not yet established

- Whether the version-4 math heads will pass their new independent validation after enough matured observations accumulate.
- Whether the full model improves out-of-time TP1 outcomes or net profitability after fees, slippage, funding, and leverage.
- Whether the changes preserve live scan/recheck timings on the Android device.
