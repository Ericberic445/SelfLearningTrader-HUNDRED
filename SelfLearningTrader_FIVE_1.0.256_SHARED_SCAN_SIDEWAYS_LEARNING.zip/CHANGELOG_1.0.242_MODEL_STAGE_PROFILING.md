# SelfLearningTrader FIVE 1.0.242 — Model-stage profiling

- Adds diagnostic-only timing for live-row construction, model prediction, prediction/challenger diagnostics, and lens-plan attachment.
- Adds aggregate timing fields to FULL_SCAN_DONE logs so the next runtime backup can identify the actual model-stage bottleneck before any further performance tuning.
- Keeps the same 692-ish full-market quick scan, 50-candidate deep model stage, 25-candidate Stage-25 validation, and TOP-5 selection pipeline.
- Does not change model inputs, probabilities, scoring, candidate ranking, direction, Entry/SL/TP, or forecast outcome rules.
- Internal timing metadata and cached candle payloads are removed before forecast persistence.
- Tests: scan worker reuse, active forecast recheck, and TOP-5 history idempotency pass. Android runtime performance remains to be verified from the next backup.
