# SelfLearningTrader FIVE 1.0.250 — full accuracy audit fixes

Changes based on 1.0.249 source and the 2026-10-21 device backup.

1. Direction training now excludes resolved TRADE rows whose target was derived from the forecast's own prediction / TP-SL outcome. Those rows remain available to the separate outcome head. Candle labels and direction-only observations retain their explicit experience kinds.
2. Bootstrap candle rows are explicitly tagged `HISTORICAL_CANDLE`; older rows with `history:` IDs are migrated from the legacy default `TRADE` tag. Label availability is stored as `resolved_time = candle_time + horizon_bars * 300`.
3. Model promotion now splits on unique timestamps and purges by elapsed seconds, using at least `horizon_bars * 300` seconds. Candidate acceptance requires improvement over baseline and incumbent in balanced accuracy and non-regression/improvement in ordinary accuracy. Outcome models split by result-resolution time.
4. KuCoin Futures order-book retrieval now uses the Futures L2 endpoint `/api/v1/level2/depth20` on `api-futures.kucoin.com`, records whether the snapshot is real/valid, the status and observation time, and persists that metadata with each prediction/experience row. Failure remains neutral zero but is no longer silently recorded as a valid observation.
5. TOP-25 score uses TP1-vs-SL calibrated edge only when both probability maps have at least 100 matured samples and 50 independent cycles. Before that, established stage score remains primary; this avoids trusting uncalibrated probabilities or double-counting them.
6. Independent direction validation now splits by target-availability (`resolved_time`) rather than forecast/candle creation time.

No UI changes. TP/SL lifecycle rules and the forecast recheck queue are unchanged. Actual live accuracy improvement is not claimed; it requires new completed forecasts and independent validation.
