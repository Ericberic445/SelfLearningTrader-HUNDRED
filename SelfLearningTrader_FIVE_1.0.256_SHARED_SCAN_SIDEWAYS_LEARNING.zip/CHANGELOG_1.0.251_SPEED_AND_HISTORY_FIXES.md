# SelfLearningTrader FIVE 1.0.251 — scan throughput and history integrity

- Keeps the full configured 5m base history while sizing higher-timeframe history to the same timeline plus a 200-bar warm-up. This reduces repeated KuCoin pagination without removing the 5m training/regime timeline or changing feature formulas.
- Recheck worker engines skip redundant global-ledger migration/reconciliation already performed by the long-lived service engine.
- TOP-5 last-100 performance history now contains eligible LONG/SHORT forecasts with probability at least 70%, de-duplicates prediction IDs across republished cycles, and keeps the newest issuance timestamp. Full cycle history and prediction archives remain intact.
- Root and Android config files are synchronized. Release identity is 1.0.251 / Android version code 10251.
- No UI layout redesign, no reduction of scan funnel stages, no changes to model promotion gates or original Entry/SL/TP lifecycle/outcome rules.
- Tests: 202 passed, 9 subtests passed. Live KuCoin timing and Android APK build remain to be verified.
