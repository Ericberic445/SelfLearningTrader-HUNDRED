# SelfLearningTrader FIVE 1.0.247 — incremental candle cache

Base: 1.0.242 source only. The TOP-5 forced-freshness/recalculation change from 1.0.246 is not included.

## Confirmed repeated work addressed

`KuCoin.candles()` previously paginated the requested candle history every time it was called, even when the same symbol/timeframe had just been fetched in a prior scan cycle. The quick pass and deep model use different history lengths (240 versus up to 5,000), and later cycles re-requested historical pages for already-seen contracts.

This version adds a process-wide cache of closed raw candle rows shared by scanner workers:
- Returns a cached history without a REST request only when the latest cached bar matches the latest fully closed candle and enough history is present.
- Reuses a longer cached history for shorter requests (e.g. 5,000 bars can serve a 240-bar quick pass).
- If new bars appeared and the gap is small, requests the delta, merges by timestamp, and verifies continuity before returning it.
- If the cache is missing, too short, too old, or the delta cannot be validated, falls back to the original full pagination path.
- Does not change indicators, ranking thresholds, model history length, math validation, TOP-5 selection, forecast rules, recheck queues, training, or UI.

## Verification

- Python compileall passed.
- Full test suite: 186 passed, 9 subtests passed.
- Added tests verify a valid cache hit makes no second REST request and a one-candle update uses a delta request.
- These are code tests, not an on-device benchmark. Expected gains are primarily after the first scan has populated cache; the first cold scan still needs to download history for the 50 deep candidates.
