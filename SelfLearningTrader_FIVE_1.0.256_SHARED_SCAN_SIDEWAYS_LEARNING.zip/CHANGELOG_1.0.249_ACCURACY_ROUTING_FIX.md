# SelfLearningTrader FIVE 1.0.249 — Accuracy routing fix

- Fixed TOP-25 ranking: `stage25_score` remains the primary ordering key. The TP1-minus-SL math edge is not used as a second primary score because those math probabilities already contribute to the math consensus and have not been independently calibrated.
- Order-book imbalance is now captured from the real live order book in forecast rows. Direction-head inputs remain neutral because the candle-history training set has no aligned historical order-book series. The outcome head may use the real snapshot saved with each resolved forecast; its training path preserves that feature. Liquidation bias remains neutral.
- Added regression tests for feature routing and ranking priority.
- No UI, TP/SL definitions, forecast queue, or archive schema changes.
- This enables collecting actual order-book snapshots for outcome learning; it does not claim an immediate accuracy increase. Older experience rows have zero-valued snapshots from previous versions and will remain in the archive.
