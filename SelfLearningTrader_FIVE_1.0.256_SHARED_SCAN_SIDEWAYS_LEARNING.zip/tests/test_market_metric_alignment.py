import numpy as np
from app.core.exchange import align_market_metric_history


def test_market_metrics_align_only_after_candle_close_and_never_from_future():
    candle_open = np.asarray([1_800_000_000_000, 1_800_000_300_000, 1_800_000_600_000], dtype=np.int64)
    oi = [
        {'ts': 1_800_000_300_000, 'openInterest': '100'},
        {'ts': 1_800_000_600_000, 'openInterest': '110'},
        {'ts': 1_800_000_900_000, 'openInterest': '120'},
    ]
    funding = [
        {'timepoint': 1_799_999_000_000, 'fundingRate': '0.001'},
        {'timepoint': 1_800_000_900_000, 'fundingRate': '-0.002'},
    ]
    out = align_market_metric_history(candle_open, oi, funding, candle_seconds=300)
    assert np.isnan(out['oi_change'][0])  # only one OI point known at first candle close
    np.testing.assert_allclose(out['oi_change'][1:], [0.1, 120/110-1], rtol=1e-6)
    # Future funding at the third candle close must not affect earlier candles.
    np.testing.assert_allclose(out['funding'][:2], [0.001, 0.001])
    assert out['funding'][2] == -0.002
    assert 0 <= out['coverage'] <= 1


def test_market_metric_alignment_accepts_seconds_and_microseconds():
    for scale in (1, 1_000, 1_000_000):
        t = 1_800_000_000 * scale
        out = align_market_metric_history(
            np.asarray([t, t + 300 * scale]),
            [{'ts': (t + 300 * scale), 'openInterest': 100},
             {'ts': (t + 600 * scale), 'openInterest': 110}],
            [{'timepoint': t, 'fundingRate': 0.0001}],
        )
        np.testing.assert_allclose(out['oi_change'][1], 0.1, rtol=1e-6)
        np.testing.assert_allclose(out['funding'], [0.0001, 0.0001])


def test_neutral_market_policy_prevents_live_only_oi_funding_from_training():
    from app.core.engine import LearningEngine
    engine = LearningEngine.__new__(LearningEngine)
    data = {
        'book_imbalance': np.asarray([0.2, -0.3]),
        'oi_change': np.asarray([0.01, -0.02]),
        'funding': np.asarray([0.0001, -0.0002]),
        'liquidation_bias': np.asarray([0.4, -0.5]),
        'target': np.asarray([2, 0]),
    }
    original_oi = data['oi_change'].copy()
    engine._apply_market_feature_policy(data, 'neutral')
    np.testing.assert_allclose(data['oi_change'], [0, 0])
    np.testing.assert_allclose(data['funding'], [0, 0])
    np.testing.assert_allclose(data['liquidation_bias'], [0, 0])
    # Historical training has no aligned order-book series; live inference now
    # neutralizes this feature as well, rather than leaking a live-only snapshot.
    np.testing.assert_allclose(data['book_imbalance'], [0, 0])
    np.testing.assert_allclose(original_oi, [0.01, -0.02])


def test_aligned_market_policy_preserves_verified_values():
    from app.core.engine import LearningEngine
    engine = LearningEngine.__new__(LearningEngine)
    data = {'oi_change': np.asarray([0.01]), 'funding': np.asarray([0.0001]),
            'liquidation_bias': np.asarray([0.0])}
    engine._apply_market_feature_policy(data, 'historical_aligned')
    np.testing.assert_allclose(data['oi_change'], [0.01])
    np.testing.assert_allclose(data['funding'], [0.0001])


def test_current_market_metrics_use_public_oi_and_funding_values():
    from app.core.exchange import KuCoin, BASE
    exchange = KuCoin.__new__(KuCoin)
    exchange.futures_symbol = 'AAAUSDTM'
    exchange._market_metrics_cache = {}
    exchange._market_metrics_status = 'not_checked'
    exchange.orderbook_imbalance = lambda: 0.15
    def request_json(base, path, params, timeout=5):
        if base == BASE:
            assert path == '/api/ua/v1/market/open-interest'
            return [{'ts': 1000, 'openInterest': '100'}, {'ts': 2000, 'openInterest': '110'}]
        assert path == '/api/v1/funding-rate/AAAUSDTM/current'
        return {'value': 0.0002}
    exchange._request_json_optional = request_json
    values = exchange.current_market_metrics()
    np.testing.assert_allclose(values['oi_change'], 0.1)
    np.testing.assert_allclose(values['funding'], 0.0002)
    np.testing.assert_allclose(values['book_imbalance'], 0.15)
    assert exchange._market_metrics_status == 'ok'
