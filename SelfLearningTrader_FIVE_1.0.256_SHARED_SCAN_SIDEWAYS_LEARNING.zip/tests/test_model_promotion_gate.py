import numpy as np
from app.core.model import ModelManager


def test_temporal_candidate_gate_refuses_small_samples(tmp_path):
    mm = ModelManager(tmp_path, config={"horizon_bars": 12})
    n = 80
    X = np.zeros((n, len(mm._new().weights)))
    y = np.arange(n) % 3
    times = np.arange(n, dtype=np.int64) * 300
    weights = np.ones(n)
    candidate, report = mm._temporal_candidate(X, y, times, weights, "direction")
    assert candidate is None
    assert report["status"] == "validation_accumulating"
    assert report["required_rows"] == 100


def test_temporal_candidate_gate_records_purged_holdout_and_baseline(tmp_path):
    mm = ModelManager(tmp_path, config={"horizon_bars": 12, "master_epochs": 100,
                                         "master_learning_rate": 0.03,
                                         "model_promotion_min_balanced_lift": 0.0})
    rng = np.random.default_rng(7)
    n = 240
    X = rng.normal(0, 0.2, (n, len(mm._new().weights)))
    # A stable, causal signal makes the temporal candidate testable.
    X[:, 0] = np.linspace(-2, 2, n)
    y = np.where(X[:, 0] < -0.45, 0, np.where(X[:, 0] > 0.45, 2, 1))
    times = np.arange(n, dtype=np.int64) * 300
    weights = np.ones(n)
    candidate, report = mm._temporal_candidate(X, y, times, weights, "direction")
    assert report["validation_rows"] > 0
    assert report["train_rows"] + report["validation_rows"] < n
    assert report["candidate_saved_without_holdout_rows"] is True
    assert report["test_start_time"] == int(times[int(n * 0.8)])
    assert report["status"] in ("accepted", "rejected")
    if candidate is not None:
        assert candidate.n_classes == 3
