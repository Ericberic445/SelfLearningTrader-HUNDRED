import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np

APP_DIR = Path(__file__).resolve().parents[1] / 'app'
if str(APP_DIR) not in sys.path:
    sys.path.insert(0, str(APP_DIR))

from core.math_models import _wavelet_proxy, _markov, _garch, compute_math_snapshot
from core.model import ModelManager


class MathModelRegressionTests(unittest.TestCase):
    def test_wavelet_detail_is_not_zero_by_construction(self):
        alternating = np.tile([-0.002, 0.002], 60)
        step = np.r_[np.full(112, -0.001), np.full(8, 0.002)]
        self.assertNotEqual(_wavelet_proxy(alternating), 0.0)
        self.assertNotEqual(_wavelet_proxy(step), 0.0)
        self.assertEqual(_wavelet_proxy(np.zeros(120)), 0.0)

    def test_markov_states_follow_return_sign_not_relative_quantile(self):
        up = np.linspace(0.0001, 0.002, 120)
        down = -np.linspace(0.0001, 0.002, 120)
        alternating = np.tile([-0.002, 0.002], 60)
        self.assertGreater(_markov(up), 0)
        self.assertLess(_markov(down), 0)
        self.assertEqual(_markov(np.zeros(120)), 0.0)
        # The last alternating move is positive, so the next transition is
        # predominantly to the negative state.
        self.assertLess(_markov(alternating), 0)

    def test_garch_zero_volatility_is_not_max_risk(self):
        self.assertEqual(_garch(np.zeros(120)), 0.0)
        close = np.full(130, 100.0)
        snapshot = compute_math_snapshot(close, seed=3)
        self.assertEqual(snapshot['math_garch'], 0.0)

    def test_tp_and_sl_are_independent_directional_path_probabilities(self):
        up_returns = np.full(120, 0.001)
        up_close = 100.0 * np.cumprod(np.r_[1.0, 1.0 + up_returns])
        long = compute_math_snapshot(up_close, forecast_direction='LONG', seed=5)
        short = compute_math_snapshot(up_close, forecast_direction='SHORT', seed=5)
        self.assertGreater(long['math_ptp1'], short['math_ptp1'])
        self.assertLess(long['math_psl'], short['math_psl'])
        self.assertGreaterEqual(long['math_ptp1'], long['math_ptp2'])
        self.assertGreaterEqual(long['math_ptp2'], long['math_ptp3'])
        noisy_returns = np.random.default_rng(17).normal(0.0001, 0.002, 120)
        noisy_close = 100.0 * np.cumprod(np.r_[1.0, 1.0 + noisy_returns])
        noisy = compute_math_snapshot(noisy_close, forecast_direction='LONG', seed=5)
        self.assertNotAlmostEqual(noisy['math_psl'], 1.0 - noisy['math_ptp1'])

    def test_pairwise_correlation_uses_benchmark_returns(self):
        rng = np.random.default_rng(17)
        benchmark_returns = rng.normal(0.0002, 0.002, 140)
        asset_returns = benchmark_returns * 1.7 + rng.normal(0, 0.0001, 140)
        benchmark_close = 100 * np.cumprod(np.r_[1.0, 1.0 + benchmark_returns])
        asset_close = 30 * np.cumprod(np.r_[1.0, 1.0 + asset_returns])
        without_benchmark = compute_math_snapshot(asset_close, seed=1)
        with_benchmark = compute_math_snapshot(asset_close, benchmark_close=benchmark_close, seed=1)
        self.assertEqual(without_benchmark['math_correlation'], 0.0)
        self.assertGreater(with_benchmark['math_correlation'], 0.95)

    def test_c3_increases_wait_when_sl_risk_increases(self):
        with tempfile.TemporaryDirectory() as td:
            manager = ModelManager(td, config={})
            master = np.asarray([0.10, 0.15, 0.75])
            row = {'features': {'trend': 0.01, 'trend_15': 0.01, 'trend_1h': 0.01,
                                'trend_4h': 0.01, 'trend_1d': 0.01}}
            base = {'math_direction': 0.7, 'math_target_sign': 1.0,
                    'math_monte_carlo': 0.8, 'math_ptp1': 0.8, 'math_ptp2': 0.7,
                    'math_ptp3': 0.5, 'math_garch': 0.3, 'math_psl': 0.1,
                    'math_entropy': 0.3, 'math_change_point': 0.1}
            risky = dict(base, math_psl=0.95)
            c3_base = manager._fixed_lens(master, row, base)['c3']['probs']
            c3_risky = manager._fixed_lens(master, row, risky)['c3']['probs']
            self.assertGreater(c3_risky[1], c3_base[1])
            self.assertLess(c3_risky[2], c3_base[2])


    def test_risk_only_math_features_do_not_create_directional_bias(self):
        import sys
        from core.engine import LearningEngine
        base = {
            'math_markov': 0.1, 'math_prob_move': 0.55, 'math_ar': 0.2,
            'math_arima': 0.1, 'math_sarima': 0.1, 'math_hurst': 0.8,
            'math_trend_direction': 0.0, 'math_mean_reversion': 0.05,
            'math_cointegration': 0.0, 'math_correlation': 0.9,
            'math_benchmark_direction': 0.0, 'math_trend_deviation': 0.0,
            'math_wavelet': 0.1, 'math_kalman': 0.1,
            'math_monte_carlo': 0.55, 'math_bayesian': 0.55,
            'math_garch': 0.1, 'math_entropy': 0.1, 'math_fractal': 0.9,
            'math_change_point': 0.1, 'math_return_vol_correlation': 0.8,
        }
        changed = dict(base, math_hurst=0.2, math_garch=0.99, math_entropy=0.99,
                       math_fractal=0.51, math_change_point=0.99,
                       math_return_vol_correlation=-0.99, math_correlation=-0.9)
        self.assertEqual(LearningEngine._math_method_scores(None, base, 'LONG'),
                         LearningEngine._math_method_scores(None, changed, 'LONG'))

    def test_path_probabilities_use_actual_tp_and_sl_distances(self):
        up_returns = np.full(120, 0.001)
        close = 100.0 * np.cumprod(np.r_[1.0, 1.0 + up_returns])
        near = compute_math_snapshot(close, forecast_direction='LONG', seed=9,
                                     target_log_distances=[0.001, 0.002, 0.003], stop_log_distance=0.001)
        far = compute_math_snapshot(close, forecast_direction='LONG', seed=9,
                                     target_log_distances=[0.02, 0.03, 0.04], stop_log_distance=0.02)
        self.assertGreaterEqual(near['math_ptp1'], near['math_ptp2'])
        self.assertGreaterEqual(near['math_ptp2'], near['math_ptp3'])
        self.assertGreater(near['math_ptp1'], far['math_ptp1'])
        self.assertGreaterEqual(near['math_psl'], far['math_psl'])

    def test_wait_has_neutral_direction_conditioned_path_probabilities(self):
        close = 100.0 * np.cumprod(np.r_[1.0, 1.0 + np.full(120, 0.001)])
        snapshot = compute_math_snapshot(close, forecast_direction='WAIT', seed=9)
        self.assertEqual(snapshot['math_ptp1'], 0.5)
        self.assertEqual(snapshot['math_ptp2'], 0.5)
        self.assertEqual(snapshot['math_ptp3'], 0.5)
        self.assertEqual(snapshot['math_psl'], 0.5)

    def test_selector_feature_names_match_vector_order(self):
        with tempfile.TemporaryDirectory() as td:
            manager = ModelManager(td, config={})
            expected = ['master_p_short', 'master_p_wait', 'master_p_long',
                        'c1_p_short', 'c1_p_wait', 'c1_p_long',
                        'c2_p_short', 'c2_p_wait', 'c2_p_long',
                        'c3_p_short', 'c3_p_wait', 'c3_p_long',
                        'conflict_m_c1', 'conflict_m_c2', 'conflict_m_c3',
                        'lens_agreement', 'math_consensus']
            self.assertEqual(list(manager.META_NAMES[:len(expected)]), expected)
            self.assertEqual(len(manager.META_NAMES), len(manager._selector_vector(
                {'features': {}}, np.asarray([0.2, 0.3, 0.5]),
                {k: {'probs': np.asarray([0.2, 0.3, 0.5])} for k in ('c1', 'c2', 'c3')})))


    def test_kalman_deviation_is_price_scale_invariant(self):
        from core.math_models import _kalman
        log_series = np.linspace(3.0, 3.08, 120)
        shifted = log_series + 5.0
        # Add the same local deviation to both series. Absolute level must not
        # suppress the deviation for the higher-priced asset.
        log_series[-1] += 0.02
        shifted[-1] += 0.02
        self.assertAlmostEqual(_kalman(log_series), _kalman(shifted), places=6)


if __name__ == '__main__':
    unittest.main(verbosity=2)

class FullEconometricModelTests(unittest.TestCase):
    def test_arima_and_sarima_are_fitted_and_finite(self):
        from core.math_models import _arima_111, _sarima_101_101
        rng = np.random.default_rng(901)
        n = 240
        noise = rng.normal(0.0, 0.001, n)
        arima_series = np.zeros(n)
        for i in range(1, n):
            arima_series[i] = 0.60*arima_series[i-1] + noise[i] + 0.25*noise[i-1]
        sarima_series = np.zeros(n)
        noise2 = rng.normal(0.0, 0.001, n)
        for i in range(13, n):
            sarima_series[i] = (0.25*sarima_series[i-1] + 0.35*sarima_series[i-12]
                                - 0.0875*sarima_series[i-13] + noise2[i])
        self.assertTrue(np.isfinite(_arima_111(arima_series)))
        self.assertTrue(np.isfinite(_sarima_101_101(sarima_series, season=12)))
        self.assertGreater(abs(_sarima_101_101(sarima_series, season=12)), 0.01)

    def test_garch_parameters_are_fitted_inside_stationary_region(self):
        from core.math_models import _fit_garch11
        rng = np.random.default_rng(902)
        n = 320
        z = rng.normal(size=n)
        r = np.zeros(n)
        v = np.full(n, 1e-6)
        for i in range(1, n):
            v[i] = 1e-8 + 0.12*r[i-1]**2 + 0.82*v[i-1]
            r[i] = np.sqrt(v[i])*z[i]
        variance, omega, alpha, beta = _fit_garch11(r)
        self.assertTrue(np.isfinite(variance) and variance >= 0)
        self.assertGreaterEqual(omega, 0)
        self.assertGreaterEqual(alpha, 0)
        self.assertGreaterEqual(beta, 0)
        self.assertLess(alpha+beta, 1.0)
        self.assertLess(abs(alpha-0.12), 0.15)

    def test_engle_granger_gate_distinguishes_cointegrated_from_independent_walks(self):
        from core.math_models import _relative_spread
        rng = np.random.default_rng(903)
        n = 240
        x = np.cumsum(rng.normal(0, 0.01, n))
        y = 1.2*x + rng.normal(0, 0.003, n)
        y[-1] += 2*np.std(y-x)
        cointegrated_score = _relative_spread(y, x)
        x2 = np.cumsum(rng.normal(0, 0.01, n))
        y2 = np.cumsum(rng.normal(0, 0.01, n))
        independent_score = _relative_spread(y2, x2)
        self.assertGreater(abs(cointegrated_score), 0.5)
        self.assertEqual(independent_score, 0.0)

    def test_move_probability_is_not_used_as_directional_vote(self):
        from core.math_models import compute_math_snapshot
        from core.engine import LearningEngine
        rng = np.random.default_rng(904)
        returns = rng.normal(0.0001, 0.001, 140)
        close = 100*np.exp(np.cumsum(np.r_[0.0, returns]))
        snap = compute_math_snapshot(close, seed=33)
        self.assertGreaterEqual(snap['math_prob_move'], 0.0)
        self.assertLessEqual(snap['math_prob_move'], 1.0)
        scores = LearningEngine._math_method_scores(None, snap, 'LONG')
        self.assertNotIn('prob_move', scores)


def test_first_passage_tp_probabilities_are_ordered_and_exclude_sl_first():
    returns = np.random.default_rng(905).normal(0.00005, 0.0015, 180)
    close = 100*np.exp(np.cumsum(np.r_[0.0, returns]))
    result = compute_math_snapshot(close, forecast_direction='LONG', seed=101,
                                   target_log_distances=[0.001, 0.002, 0.003],
                                   stop_log_distance=0.0015)
    assert 0.0 <= result['math_ptp3'] <= result['math_ptp2'] <= result['math_ptp1'] <= 1.0
    assert 0.0 <= result['math_psl'] <= 1.0
    assert result['math_ptp1'] + result['math_psl'] <= 1.0 + 1e-12


def test_probability_calibration_uses_only_matching_formula_version_and_is_monotone():
    from core.math_models import fit_math_probability_calibration, apply_math_probability_calibration, MATH_FORMULA_VERSION
    samples = []
    rng = np.random.default_rng(906)
    for i in range(120):
        p = (i+0.5)/120
        y = bool(rng.random() < p)
        samples.append({'id':str(i), 'time':i*300_000_000, 'cycle':i+1, 'formula_version':MATH_FORMULA_VERSION,
                        'p':{'math_prob_move':p,'math_monte_carlo':p,'math_bayesian':p,
                             'math_ptp1':p,'math_ptp2':p*0.8,'math_ptp3':p*0.6,'math_psl':1-p},
                        'y':{'move_hit':y,'positive_return':y,'tp1_before_sl':y,'tp2_before_sl':y,
                             'tp3_before_sl':y,'sl_before_tp1':not y}})
    samples.extend([{'id':'legacy','formula_version':MATH_FORMULA_VERSION-1,
                     'p':{'math_ptp1':1.0},'y':{'tp1_before_sl':True}}])
    fitted = fit_math_probability_calibration(samples, MATH_FORMULA_VERSION, min_samples=100)
    assert fitted['sample_count'] == 120
    mapping = fitted['maps']['math_ptp1']
    assert mapping['n'] == 120
    assert all(a <= b for a,b in zip(mapping['y'], mapping['y'][1:]))
    raw = {'math_target_sign':1.0,'math_prob_move':0.8,'math_ptp1':0.8,
           'math_ptp2':0.7,'math_ptp3':0.6,'math_psl':0.7}
    calibrated = apply_math_probability_calibration(raw, fitted, MATH_FORMULA_VERSION)
    assert calibrated['math_ptp1'] >= calibrated['math_ptp2'] >= calibrated['math_ptp3']
    assert calibrated['math_ptp1'] + calibrated['math_psl'] <= 1.0 + 1e-12


def test_math_calibration_recorder_labels_fixed_horizon_and_deduplicates(tmp_path):
    import json
    from core.engine import LearningEngine
    from core.math_models import MATH_FORMULA_VERSION
    engine = LearningEngine.__new__(LearningEngine)
    engine.data = tmp_path
    engine.cfg = {'horizon_bars':12}
    times = np.arange(100, dtype=np.int64)
    closes = np.full(100, 100.0)
    highs = np.full(100, 100.5)
    lows = np.full(100, 99.5)
    idx = 20
    highs[idx+2] = 101.5
    lows[idx+8] = 98.5
    row = {'id':'CAL-1','time':int(times[idx-1]),'math_formula_version':MATH_FORMULA_VERSION,
           'prediction':'LONG','horizon_bars':12,'entry':100.0,'sl':99.0,
           'tp1':101.0,'tp2':102.0,'tp3':103.0,
           'math_features':{'math_prob_move':0.4,'math_monte_carlo':0.6,'math_bayesian':0.55,
                            'math_ptp1':0.7,'math_ptp2':0.4,'math_ptp3':0.2,'math_psl':0.2},
           'math_calibration_raw':{'math_prob_move':0.31,'math_monte_carlo':0.61,'math_bayesian':0.52,
                                   'math_ptp1':0.65,'math_ptp2':0.35,'math_ptp3':0.15,'math_psl':0.25}}
    rows=[row]
    assert engine._record_math_calibration_from_predictions(rows,times,closes,highs,lows)
    assert row['math_calibration_recorded'] is True
    assert row['math_calibration_labels']['tp1_before_sl'] is True
    assert row['math_calibration_labels']['sl_before_tp1'] is False
    state=json.loads((tmp_path/'math_probability_calibration.json').read_text())
    assert len(state['samples']) == 1
    assert state['samples'][0]['p']['math_ptp1'] == 0.65
    assert state['samples'][0]['p']['math_bayesian'] == 0.52
    assert not engine._record_math_calibration_from_predictions(rows,times,closes,highs,lows)
    state=json.loads((tmp_path/'math_probability_calibration.json').read_text())
    assert len(state['samples']) == 1


def test_probability_calibration_does_not_count_many_coins_in_one_cycle_as_independent():
    from core.math_models import fit_math_probability_calibration, MATH_FORMULA_VERSION
    samples=[]
    for i in range(120):
        samples.append({'id':str(i),'cycle':7,'time':i*300_000_000,
                        'formula_version':MATH_FORMULA_VERSION,
                        'p':{'math_prob_move':0.5,'math_monte_carlo':0.5,'math_bayesian':0.5,
                             'math_ptp1':0.5,'math_ptp2':0.4,'math_ptp3':0.3,'math_psl':0.4},
                        'y':{'move_hit':True,'positive_return':True,'tp1_before_sl':True,
                             'tp2_before_sl':False,'tp3_before_sl':False,'sl_before_tp1':False}})
    fitted=fit_math_probability_calibration(samples, MATH_FORMULA_VERSION, min_samples=100, min_cycles=50)
    assert fitted['sample_count'] == 120
    assert fitted['independent_cycles'] == 1
    assert fitted['maps'] == {}


def test_full_correlation_matrix_uses_timestamp_aligned_returns():
    from core.math_models import compute_correlation_matrix
    rng=np.random.default_rng(907)
    n=180
    t=np.arange(n,dtype=np.int64)*300_000_000
    base=rng.normal(0,0.001,n-1)
    independent=rng.normal(0,0.001,n-1)
    a=100*np.exp(np.cumsum(np.r_[0.0,base]))
    b=50*np.exp(np.cumsum(np.r_[0.0,base*1.5+rng.normal(0,0.0001,n-1)]))
    c=30*np.exp(np.cumsum(np.r_[0.0,independent]))
    result=compute_correlation_matrix({'A':{'time':t,'close':a},
                                       'B':{'time':t,'close':b},
                                       'C':{'time':t,'close':c}}, min_overlap=30)
    assert result['symbols']==['A','B','C']
    matrix=np.asarray(result['matrix'])
    np.testing.assert_allclose(matrix,matrix.T,atol=1e-12)
    np.testing.assert_allclose(np.diag(matrix),1.0)
    assert matrix[0,1] > 0.95
    assert result['overlap_counts'][0][1] >= 170
    # A one-candle offset leaves insufficient exactly aligned returns.
    shifted=compute_correlation_matrix({'A':{'time':t,'close':a},
                                        'B':{'time':t+1,'close':b}}, min_overlap=30)
    assert len(shifted['symbols'])==2
    assert shifted['matrix'][0][1] == 0.0


def test_math_snapshot_preserves_raw_probabilities_before_calibration():
    from core.math_models import compute_math_snapshot, MATH_FORMULA_VERSION
    rng = np.random.default_rng(908)
    close = 100*np.exp(np.cumsum(np.r_[0.0, rng.normal(0.0001, 0.001, 140)]))
    calibration = {'formula_version': MATH_FORMULA_VERSION, 'maps': {
        'math_monte_carlo': {'n': 120, 'x': [0.0, 1.0], 'y': [0.1, 0.9]},
        'math_bayesian': {'n': 120, 'x': [0.0, 1.0], 'y': [0.2, 0.8]},
    }}
    result = compute_math_snapshot(close, horizon=12, seed=22, probability_calibration=calibration)
    raw = result['_math_raw_probabilities']
    assert raw['math_monte_carlo'] != result['math_monte_carlo']
    assert raw['math_bayesian'] != result['math_bayesian']
    assert 0 <= raw['math_ptp1'] <= 1

def test_bayesian_probability_matches_requested_horizon():
    from core.math_models import _bayesian
    # Each two-bar move is negative even though every other single bar is up.
    returns = np.tile(np.asarray([0.01, -0.03]), 70)
    one_bar = _bayesian(returns, horizon=1)
    two_bar = _bayesian(returns, horizon=2)
    assert one_bar > 0.45
    assert two_bar < 0.10


def test_flat_market_monte_carlo_is_neutral_not_bearish():
    from core.math_models import compute_math_snapshot
    close = np.full(150, 100.0)
    result = compute_math_snapshot(close, seed=7)
    assert result['math_monte_carlo'] == 0.5
    assert abs(result['math_consensus']) < 1e-9
    assert result['math_bayesian'] == 0.5

def test_mean_reversion_does_not_call_a_deterministic_trend_a_reversal():
    from core.math_models import _mean_reversion
    log_price = np.linspace(2.0, 2.15, 150)
    assert abs(_mean_reversion(log_price)) < 1e-6

def test_monte_carlo_direction_is_symmetric_for_mirrored_paths():
    from core.math_models import compute_math_snapshot
    rng = np.random.default_rng(909)
    noise = rng.normal(0, 0.0005, 150)
    up = 0.0003 + noise
    down = -0.0003 - noise
    a = compute_math_snapshot(100*np.exp(np.cumsum(np.r_[0.0, up])), seed=17)
    b = compute_math_snapshot(100*np.exp(np.cumsum(np.r_[0.0, down])), seed=17)
    assert a['math_monte_carlo'] > 0.5
    assert b['math_monte_carlo'] < 0.5
    assert abs((a['math_monte_carlo'] + b['math_monte_carlo']) - 1.0) < 0.03


def test_math_snapshot_benchmark_correlation_uses_timestamp_alignment():
    from core.math_models import compute_math_snapshot
    rng = np.random.default_rng(910)
    n = 180
    times = np.arange(n, dtype=np.int64) * 300_000 + 1_800_000_000_000
    benchmark_returns = rng.normal(0.0001, 0.001, n-1)
    benchmark = 100*np.exp(np.cumsum(np.r_[0.0, benchmark_returns]))
    asset = 40*np.exp(np.cumsum(np.r_[0.0, 1.7*benchmark_returns + rng.normal(0, 0.00005, n-1)]))
    keep = np.ones(n, dtype=bool)
    keep[[20, 21, 75, 76, 77, 132]] = False
    result = compute_math_snapshot(asset[keep], horizon=12, seed=31,
                                   benchmark_close=benchmark, candle_time=times[keep],
                                   benchmark_time=times)
    assert result['math_correlation'] > 0.90

def test_calibration_cycle_fallback_normalizes_epoch_timestamp_units():
    from core.math_models import fit_math_probability_calibration, MATH_FORMULA_VERSION
    samples = []
    base_seconds = 1_800_000_000
    for i in range(120):
        # Every row is 30 minutes apart; alternate common epoch units.
        seconds = base_seconds + i*1800
        scale = (1, 1_000, 1_000_000, 1_000_000_000)[i % 4]
        stamp = seconds*scale
        samples.append({'id':str(i), 'time':stamp, 'cycle':0,
                        'formula_version':MATH_FORMULA_VERSION,
                        'p':{'math_prob_move':0.5,'math_monte_carlo':0.5,'math_bayesian':0.5,
                             'math_ptp1':0.5,'math_ptp2':0.4,'math_ptp3':0.3,'math_psl':0.4},
                        'y':{'move_hit':bool(i%2),'positive_return':bool(i%2),
                             'tp1_before_sl':bool(i%2),'tp2_before_sl':bool(i%2),
                             'tp3_before_sl':bool(i%2),'sl_before_tp1':bool((i+1)%2)}})
    fitted = fit_math_probability_calibration(samples, MATH_FORMULA_VERSION, min_samples=100, min_cycles=50)
    assert fitted['independent_cycles'] == 120
    assert 'math_prob_move' in fitted['maps']


def test_math_probability_heads_require_out_of_time_skill_before_promotion():
    from core.math_models import fit_math_probability_calibration, MATH_FORMULA_VERSION
    samples = []
    for i in range(120):
        y = int(i % 2)
        # MC is deliberately inverted; Bayesian is genuinely predictive.
        mc = 0.9 if not y else 0.1
        bay = 0.9 if y else 0.1
        samples.append({'id':str(i), 'time':1_800_000_000_000+i*1_800_000, 'cycle':i+1,
                        'formula_version':MATH_FORMULA_VERSION,
                        'p':{'math_prob_move':bay, 'math_monte_carlo':mc, 'math_bayesian':bay,
                             'math_ptp1':bay, 'math_ptp2':bay, 'math_ptp3':bay, 'math_psl':mc},
                        'y':{'move_hit':bool(y), 'positive_return':bool(y), 'tp1_before_sl':bool(y),
                             'tp2_before_sl':bool(y), 'tp3_before_sl':bool(y), 'sl_before_tp1':bool(not y)}})
    fitted = fit_math_probability_calibration(samples, MATH_FORMULA_VERSION, min_samples=100, min_cycles=50)
    assert 'math_bayesian' in fitted['validated_heads']
    assert 'math_monte_carlo' not in fitted['validated_heads']
    assert fitted['validation']['heads']['math_monte_carlo']['auc'] < 0.5

def test_unvalidated_math_probability_heads_are_neutralized_in_direction_scores():
    from core.engine import LearningEngine
    snapshot = {'math_markov':0.0, 'math_ar':0.0, 'math_arima':0.0, 'math_sarima':0.0,
                'math_hurst':0.5, 'math_trend_direction':0.0, 'math_mean_reversion':0.0,
                'math_cointegration':0.0, 'math_correlation':0.0, 'math_benchmark_direction':0.0,
                'math_trend_deviation':0.0, 'math_wavelet':0.0, 'math_kalman':0.0,
                'math_monte_carlo':0.99, 'math_bayesian':0.99,
                '_probability_validation_enforced':True, '_validated_probability_heads':[]}
    scores = LearningEngine._math_method_scores(None, snapshot, 'LONG')
    assert scores['monte_carlo'] == 0.0
    assert scores['bayesian'] == 0.0


def test_old_math_formula_predictions_are_skipped_once_for_calibration(tmp_path):
    from core.engine import LearningEngine
    from core.math_models import MATH_FORMULA_VERSION
    engine = LearningEngine.__new__(LearningEngine)
    engine.data = tmp_path
    engine.cfg = {'horizon_bars':12}
    row = {'id':'OLD-1', 'time':10, 'math_formula_version':MATH_FORMULA_VERSION-1, 'prediction':'LONG'}
    changed = engine._record_math_calibration_from_predictions([row], np.arange(100), np.full(100,100.0),
                                                               np.full(100,101.0), np.full(100,99.0))
    assert changed is True
    assert row['math_calibration_skipped'] is True
    assert row['math_calibration_skip_reason'] == 'formula_version_mismatch'
    assert not (tmp_path/'math_probability_calibration.json').exists()

def test_fixed_lens_ignores_unvalidated_probability_heads():
    from core.model import ModelManager
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        manager = ModelManager(td, config={})
        master = np.asarray([0.25, 0.25, 0.50])
        row = {'features': {'trend':0.01,'trend_15':0.01,'trend_1h':0.01,'trend_4h':0.01,'trend_1d':0.01,
                            'volatility':0.01,'volz':0.1,'rsi':52,'bbpos':0.55}}
        base = {'math_direction':0.1,'math_target_sign':1.0,'math_trend_direction':0.1,
                'math_markov':0.1,'math_hurst':0.5,'math_wavelet':0.1,'math_ar':0.1,'math_arima':0.1,
                'math_sarima':0.1,'math_mean_reversion':0.1,'math_cointegration':0.0,'math_correlation':0.0,
                'math_benchmark_direction':0.0,'math_trend_deviation':0.0,'math_kalman':0.1,
                'math_monte_carlo':0.99,'math_bayesian':0.99,'math_ptp1':0.99,'math_ptp2':0.99,'math_ptp3':0.99,
                'math_garch':0.2,'math_psl':0.01,'_probability_validation_enforced':True,
                '_validated_probability_heads':[]}
        changed = dict(base, math_monte_carlo=0.01, math_bayesian=0.01, math_ptp1=0.01, math_ptp2=0.01, math_ptp3=0.01)
        a = manager._fixed_lens(master, row, base)
        b = manager._fixed_lens(master, row, changed)
        for lens in ('c1','c2','c3'):
            assert np.allclose(a[lens]['probs'], b[lens]['probs'])


def test_invalid_price_points_do_not_create_artificial_extreme_returns():
    from core.math_models import compute_math_snapshot, MATH_FEATURES
    rng = np.random.default_rng(911)
    returns = rng.normal(0.0001, 0.001, 150)
    close = 100*np.exp(np.cumsum(np.r_[0.0, returns]))
    damaged = close.copy()
    damaged[30] = np.nan
    damaged[70] = 0.0
    damaged[110] = np.inf
    a = compute_math_snapshot(close, seed=44)
    b = compute_math_snapshot(damaged, seed=44)
    assert all(np.isfinite(float(b[k])) for k in MATH_FEATURES)
    assert abs(b['math_direction']) < 1.0
    assert abs(b['math_consensus']) < 1.0
    assert abs(b['math_direction']-a['math_direction']) < 0.08
