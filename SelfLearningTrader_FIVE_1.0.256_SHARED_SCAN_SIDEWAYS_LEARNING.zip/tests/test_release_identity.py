import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_android_release_version_and_code_are_consistent():
    spec = (ROOT / 'buildozer.spec').read_text(encoding='utf-8')
    version = re.search(r'^version\s*=\s*(\S+)', spec, re.MULTILINE).group(1)
    code = int(re.search(r'^android\.numeric_version\s*=\s*(\d+)', spec, re.MULTILINE).group(1))
    major, minor, patch = (int(x) for x in version.split('.'))
    expected = major * 10000 + minor * 1000 + patch
    assert code == expected
    assert code > 10217
    for config_name in ('config.json', 'app/config.json'):
        config = json.loads((ROOT / config_name).read_text(encoding='utf-8'))
        assert config['version'] == version


def test_root_and_android_configs_are_identical():
    root_cfg = json.loads((ROOT / 'config.json').read_text(encoding='utf-8'))
    app_cfg = json.loads((ROOT / 'app' / 'config.json').read_text(encoding='utf-8'))
    assert root_cfg == app_cfg
