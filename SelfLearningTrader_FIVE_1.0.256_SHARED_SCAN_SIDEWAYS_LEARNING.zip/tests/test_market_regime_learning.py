import numpy as np

from app.core.features import REGIME_FEATURES, REGIME_NAMES, add_features, make_regime_labels
from app.core.model import ModelManager


def _bars(close, start=1_800_000_000):
    close = np.asarray(close, dtype=float)
    n = len(close)
    return {
        'time': start + np.arange(n, dtype=np.int64) * 300,
        'open': close.copy(),
        'high': close * 1.001,
        'low': close * 0.999,
        'close': close,
        'volume': np.full(n, 1000.0),
    }


def test_regime_features_are_causal_and_available_for_recent_rows():
    n = 180
    t = np.arange(n)
    close = 100 * np.exp(0.0007 * t + 0.0002 * np.sin(t / 3.0))
    x = add_features(_bars(close))
    local_names = [name for name in REGIME_FEATURES if name not in ('trend_15','trend_1h','trend_4h','trend_1d','regime_mtf_alignment')]
    for name in local_names:
        assert name in x
        assert np.isfinite(np.asarray(x[name])[-1])
    assert x['regime_efficiency'][-1] > 0.5
    # Altering only future candles must not change any feature at an earlier index.
    altered = close.copy()
    altered[120:] *= np.exp(np.linspace(0, 0.4, n - 120))
    y = add_features(_bars(altered))
    for name in local_names:
        np.testing.assert_allclose(np.asarray(x[name])[:120], np.asarray(y[name])[:120],
                                   equal_nan=True, rtol=1e-10, atol=1e-10)


def test_regime_labels_use_future_path_and_have_documented_classes():
    n = 500
    t = np.arange(n)
    # Alternating regimes: clean rise, range, clean fall, noisy transition.
    close = np.ones(n) * 100
    close[:125] = 100 * np.exp(0.001 * np.arange(125))
    close[125:250] = close[124] * np.exp(0.0015 * np.sin(np.arange(125) / 2.0))
    close[250:375] = close[249] * np.exp(-0.001 * np.arange(125))
    rng = np.random.default_rng(18)
    close[375:] = close[374] * np.exp(np.cumsum(rng.normal(0.0, 0.0015, n - 375)))
    x = add_features(_bars(close))
    labeled = make_regime_labels(x, 12, 0.003, -0.003)
    target = np.asarray(labeled['regime_target'])
    assert set(np.unique(target[np.isfinite(target)])).issubset(set(REGIME_NAMES))
    assert np.any(target[:100] == 3)  # TREND_UP
    assert np.any(target[250:350] == 0)  # TREND_DOWN
    assert np.any(target[130:235] == 1)  # RANGE
    assert np.all(np.isnan(target[-12:]))


def test_regime_head_trains_on_chronological_purged_multicontract_data(tmp_path):
    rng = np.random.default_rng(23)
    n_per_contract = 600
    times = 1_800_000_000 + np.arange(n_per_contract, dtype=np.int64) * 300
    data = {
        'time': np.tile(times, 5),
        'contract': np.repeat(np.asarray([f'COIN{i}' for i in range(5)]), n_per_contract),
        'target': np.tile(np.arange(n_per_contract, dtype=np.int8) % 4, 5),
    }
    for name in REGIME_FEATURES:
        data[name] = rng.normal(0.0, 1.0, len(data['time'])).astype(np.float32)
    # Make class separation learnable without using any future-derived input.
    data['regime_efficiency'] = (data['target'].astype(float) + rng.normal(0, .08, len(data['target']))).astype(np.float32)
    mm = ModelManager(tmp_path, config={'regime_min_rows': 500, 'regime_epochs': 3,
                                         'regime_learning_rate': .01})
    result = mm.train_regime(data, horizon_bars=12)
    assert result['status'] == 'regime_trained'
    assert result['rows'] == 3000
    assert result['validation_accuracy'] is not None
    assert mm._load_path(mm.regime_model, 'regime') is not None
    meta = mm._read_json(mm.regime_meta, {})
    assert meta['purge_gap_bars'] == 12
    assert meta['contract_count'] == 5
    assert meta['validation_protocol']['type'] == 'chronological_holdout'
    assert meta['validation_protocol']['future_labels_used_as_inputs'] is False
    assert meta['validation_protocol']['test_used_for_fit'] is False


def test_regime_pool_waits_for_multiple_contracts_and_rejects_weak_candidate(tmp_path):
    mm = ModelManager(tmp_path, config={'regime_min_rows': 500, 'regime_min_contracts': 5,
                                         'regime_retrain_new_rows': 500, 'regime_epochs': 2})
    n = 600
    times = 1_800_000_000 + np.arange(n, dtype=np.int64) * 300
    for contract_no in range(4):
        x = {'time': times, 'close': np.linspace(100, 120, n),
             'high': np.linspace(100, 120, n) * 1.001,
             'low': np.linspace(100, 120, n) * .999,
             'atrpct': np.full(n, .002)}
        for name in REGIME_FEATURES:
            x[name] = np.linspace(0.01, 0.2, n) if name == 'trend' else np.full(n, .5)
        result = mm.update_regime_training(x, f'COIN{contract_no}', 12, .003, -.003)
        assert result['status'] != 'regime_trained'
    x['regime_efficiency'] = np.linspace(.1, .9, n)
    result = mm.update_regime_training(x, 'COIN4', 12, .003, -.003)
    # The synthetic pool is nearly one-sided (a smooth rise). Enough contracts
    # must not be mistaken for a sufficiently diverse/validated regime model.
    assert result['status'] == 'regime_rejected_validation'
    assert mm._load_path(mm.regime_model, 'regime') is None


def test_regime_prediction_is_explicitly_unknown_without_features(tmp_path):
    mm = ModelManager(tmp_path)
    result = mm.market_regime({'features': {}})
    assert result['label'] == 'TRANSITION'
    assert result['source'] == 'insufficient_data'
    assert result['confidence'] == 0.0


def test_accepted_trained_regime_model_is_used_with_latest_feature_values(tmp_path):
    from app.core.model import NumpyClassifier
    mm = ModelManager(tmp_path)
    fake = NumpyClassifier(len(REGIME_FEATURES), 4)
    fake.predict_proba = lambda X: np.asarray([[.05, .10, .15, .70]])
    mm._write_json(mm.regime_meta, {
        'status': 'ready', 'rows': 5000, 'validation_accuracy': .48,
        'baseline_accuracy': .35, 'balanced_accuracy': .40,
        'class_metrics': {'TREND_DOWN': {'recall': .35}, 'TREND_UP': {'recall': .32}},
    })
    mm._load_path = lambda path, kind='direction': fake if kind == 'regime' else None
    row = {name: np.asarray([.01, .02]) for name in REGIME_FEATURES}
    result = mm.market_regime(row)
    assert result['source'] == 'trained_regime_model'
    assert result['label'] == 'TREND_UP'
    assert result['probabilities']['TREND_UP'] == .70


def test_badly_validated_regime_model_is_not_used_as_learned_signal(tmp_path):
    from app.core.model import NumpyClassifier
    mm = ModelManager(tmp_path)
    fake = NumpyClassifier(len(REGIME_FEATURES), 4)
    fake.predict_proba = lambda X: np.asarray([[.05, .10, .15, .70]])
    mm._write_json(mm.regime_meta, {
        'status': 'ready', 'rows': 60000, 'validation_accuracy': .29,
        'baseline_accuracy': .35, 'balanced_accuracy': .27,
        'class_metrics': {'TREND_DOWN': {'recall': .31}, 'TREND_UP': {'recall': .12}},
    })
    mm._load_path = lambda path, kind='direction': fake if kind == 'regime' else None
    row = {name: np.asarray([.01]) for name in REGIME_FEATURES}
    result = mm.market_regime(row)
    assert result['source'] == 'unvalidated_fallback_wait_guard'
    assert result['model_validation_accepted'] is False
    assert result['label'] == 'TRANSITION'
    assert 'fallback_estimate' in result


def test_missing_derived_regime_features_are_imputed_from_accepted_model(tmp_path):
    from app.core.model import NumpyClassifier
    mm = ModelManager(tmp_path)
    fake = NumpyClassifier(len(REGIME_FEATURES), 4)
    fake.means = np.arange(len(REGIME_FEATURES), dtype=float)
    fake.predict_proba = lambda X: np.asarray([[.05, .10, .15, .70]])
    mm._write_json(mm.regime_meta, {
        'status': 'ready', 'rows': 5000, 'validation_accuracy': .48,
        'baseline_accuracy': .35, 'balanced_accuracy': .40,
        'class_metrics': {'TREND_DOWN': {'recall': .35}, 'TREND_UP': {'recall': .32}},
    })
    mm._load_path = lambda path, kind='direction': fake if kind == 'regime' else None
    row = {name: np.asarray([.01]) for name in REGIME_FEATURES[:18]}
    result = mm.market_regime(row)
    assert result['source'] == 'trained_regime_model'
    assert set(result['imputed_features']) == set(REGIME_FEATURES[18:])


def test_unvalidated_regime_fallback_increases_wait_instead_of_confident_range(tmp_path):
    from app.core.model import NumpyClassifier
    from app.core.features import FEATURES
    mm = ModelManager(tmp_path, config={'min_direction_confidence': .55,
        'min_direction_edge': .06, 'regime_unvalidated_wait_boost': .12})
    fake = NumpyClassifier(len(__import__('app.core.features', fromlist=['FEATURES']).FEATURES), 3)
    fake.predict_proba = lambda X: np.asarray([[.20, .20, .60]])
    mm._load_path = lambda path, kind='direction': fake if kind == 'direction' else None
    mm._learning_state = lambda: {'resolved_total': 0, 'base_version': 0}
    mm._performance_features = lambda: []
    row = {name: np.asarray([.01]) for name in set(FEATURES + REGIME_FEATURES)}
    prediction, probs, extra = mm.predict_bundle(row)
    assert extra['market_regime']['source'] == 'unvalidated_fallback_wait_guard'
    assert extra['market_regime']['label'] == 'TRANSITION'
    assert extra['regime_wait_boost'] == .12
    assert prediction == 'WAIT'
    assert probs[1] > .20


def test_confident_range_regime_raises_wait_instead_of_forcing_direction(tmp_path):
    from app.core.model import NumpyClassifier
    mm = ModelManager(tmp_path, config={'min_direction_confidence': .55, 'min_direction_edge': .06})
    fake = NumpyClassifier(len(__import__('app.core.features', fromlist=['FEATURES']).FEATURES), 3)
    fake.predict_proba = lambda X: np.asarray([[.20, .20, .60]])
    mm._load_path = lambda path, kind='direction': fake if kind == 'direction' else None
    mm._learning_state = lambda: {'resolved_total': 0, 'base_version': 0}
    mm._performance_features = lambda: []
    mm.market_regime = lambda row: {
        'label': 'RANGE', 'probabilities': {'TREND_DOWN': .05, 'RANGE': .80,
        'TRANSITION': .10, 'TREND_UP': .05}, 'confidence': .80,
        'source': 'trained_regime_model', 'rows': 5000}
    from app.core.features import FEATURES
    row = {name: np.asarray([0.0]) for name in FEATURES}
    prediction, probs, extra = mm.predict_bundle(row)
    assert prediction == 'WAIT'
    assert probs[1] > .20
    assert extra['market_regime']['label'] == 'RANGE'
    assert extra['regime_wait_boost'] > 0


def test_stage25_decision_row_passes_regime_features_without_zero_imputation():
    from app.core.engine import _build_stage25_decision_row
    from app.core.features import FEATURES, REGIME_FEATURES
    features = {name: 0.25 for name in FEATURES}
    features.update({name: 0.5 for name in REGIME_FEATURES})
    features.pop('regime_efficiency')
    row = _build_stage25_decision_row(features)
    assert all(name in row for name in FEATURES)
    assert 'regime_features' in row
    assert np.isnan(row['regime_features']['regime_efficiency'][0])
    assert row['regime_features']['regime_persistence'][0] == 0.5
    assert row['trend'][0] == 0.5  # overlapping trend value is also part of regime inputs


def test_market_regime_reads_explicit_stage25_regime_namespace(tmp_path):
    from app.core.engine import _build_stage25_decision_row
    from app.core.features import FEATURES, REGIME_FEATURES
    mm = ModelManager(tmp_path)
    mm._write_json(mm.regime_meta, {'status': 'rejected_validation', 'rows': 60000,
        'validation_accuracy': .29, 'baseline_accuracy': .35, 'balanced_accuracy': .27,
        'class_metrics': {'TREND_DOWN': {'recall': .14}, 'TREND_UP': {'recall': .01}}})
    features = {name: 0.01 for name in FEATURES}
    features.update({name: 0.01 for name in REGIME_FEATURES})
    features.update({'regime_efficiency': .8, 'regime_persistence': .75,
                     'regime_reversal_rate': .1, 'regime_mtf_alignment': .75})
    row = _build_stage25_decision_row(features)
    result = mm.market_regime(row)
    assert result['source'] == 'unvalidated_fallback_wait_guard'
    assert result['source'] != 'insufficient_data'
    assert result['model_validation_accepted'] is False


def test_capped_out_old_regime_rows_do_not_trigger_retraining(tmp_path):
    # Existing pool is already at capacity. New rows from an older candle window
    # are immediately discarded by the retention cap and must not count as new data.
    from app.core.model import REGIME_NAMES
    pool_cap = 5000
    mm = ModelManager(tmp_path, config={
        'regime_training_pool_max_rows': pool_cap,
        'regime_min_rows': 500,
        'regime_min_contracts': 3,
        'regime_retrain_new_rows': 500,
    })
    n = pool_cap
    times = 1_800_000_000 + np.arange(n, dtype=np.int64) * 300
    contracts = np.repeat(np.asarray([f'OLD{i}' for i in range(5)]), n // 5)
    data = {
        'time': times,
        'contract': contracts,
        'target': np.arange(n, dtype=np.int8) % len(REGIME_NAMES),
    }
    for name in REGIME_FEATURES:
        data[name] = np.linspace(0.0, 1.0, n).astype(np.float32)
    np.savez_compressed(mm.regime_pool, **data)
    mm._write_json(mm.regime_meta, {'status': 'ready', 'new_rows_since_train': 250,
                                    'last_attempt_pool_rows': n})
    mm._load_path = lambda path, kind='direction': object() if kind == 'regime' else None

    x = add_features(_bars(np.linspace(100, 120, 700), start=1_700_000_000))
    for name in REGIME_FEATURES:
        if name not in x or len(np.asarray(x[name]).reshape(-1)) != len(x['time']):
            x[name] = np.full(len(x['time']), 0.5, dtype=float)
        else:
            x[name] = np.nan_to_num(np.asarray(x[name], dtype=float), nan=0.5, posinf=0.5, neginf=0.5)
    result = mm.update_regime_training(x, 'NEWOLD', 12, .003, -.003)
    assert result['status'] == 'regime_pool_unchanged'
    assert result['added_rows'] == 0
    assert result['pool_rows'] == pool_cap
    meta = mm._read_json(mm.regime_meta, {})
    assert meta['new_rows_since_train'] == 250
