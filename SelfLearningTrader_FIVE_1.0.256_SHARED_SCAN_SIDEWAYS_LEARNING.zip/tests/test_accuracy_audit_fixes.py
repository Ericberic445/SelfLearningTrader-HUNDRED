import numpy as np

from app.core.engine import LearningEngine
from app.core.exchange import KuCoin
from app.core.features import FEATURES
from app.core.model import ModelManager


def test_direction_training_excludes_trade_outcome_pseudolabels():
    engine = LearningEngine.__new__(LearningEngine)
    n = 4
    exp = {
        'time': np.arange(n, dtype=np.int64) * 300,
        'contract': np.asarray(['AAAUSDTM'] * n),
        'prediction_id': np.asarray(['history:AAA:1', 'trade1', 'obs1', 'trade2']),
        'experience_kind': np.asarray(['HISTORICAL_CANDLE', 'TRADE', 'ONLINE_DIRECTION_OBSERVATION', 'TRADE']),
        'target': np.asarray([2, 2, 0, 1]),
        'resolved_time': np.arange(n, dtype=np.int64) * 300 + 3600,
    }
    for feature in FEATURES:
        exp[feature] = np.zeros(n)
    out = engine._experience_for_direction_training(exp)
    assert out['prediction_id'].tolist() == ['history:AAA:1', 'obs1']
    assert 'TRADE' not in out['experience_kind']


def test_temporal_candidate_uses_seconds_embargo_and_unique_timestamps(tmp_path):
    mm = ModelManager(tmp_path, config={'horizon_bars': 12, 'master_epochs': 5,
                                         'model_promotion_min_balanced_lift': 0.0,
                                         'model_promotion_min_accuracy_lift': 0.0})
    # Four contracts per timestamp simulate the real global archive where row
    # counts do not correspond to elapsed candle time.
    stamps = np.repeat(np.arange(150, dtype=np.int64) * 300 + 1_800_000_000, 4)
    n = len(stamps)
    X = np.zeros((n, len(FEATURES)))
    X[:, 0] = np.repeat(np.linspace(-2, 2, 150), 4)
    y = np.where(X[:, 0] < -0.4, 0, np.where(X[:, 0] > 0.4, 2, 1))
    candidate, report = mm._temporal_candidate(X, y, stamps, np.ones(n), 'direction')
    assert report['split_by_unique_timestamps'] is True
    assert report['purge_gap_seconds'] >= 12 * 300
    assert report['train_test_gap_seconds'] >= 12 * 300
    assert report['train_max_time'] < report['test_start_time']
    assert report['test_min_time'] == report['test_start_time']


def test_orderbook_imbalance_uses_futures_l2_endpoint_and_marks_valid():
    ex = KuCoin('XBTUSDTM')
    seen = {}
    def fake_get(path, params):
        seen['path'] = path; seen['params'] = params
        return {'bids': [['100', '8'], ['99', '2']], 'asks': [['101', '5'], ['102', '5']]}
    ex._get_futures = fake_get
    value = ex.orderbook_imbalance()
    assert seen['path'] == '/api/v1/level2/depth20'
    assert seen['params']['symbol'] == 'XBTUSDTM'
    assert value == 0.0
    assert ex._orderbook_valid is True
    assert ex._orderbook_status == 'ok'


def test_orderbook_failure_is_not_marked_as_valid():
    ex = KuCoin('XBTUSDTM')
    def fail(path, params):
        raise RuntimeError('network down')
    ex._get_futures = fail
    assert ex.orderbook_imbalance() == 0.0
    assert ex._orderbook_valid is False
    assert 'network down' in ex._orderbook_status
