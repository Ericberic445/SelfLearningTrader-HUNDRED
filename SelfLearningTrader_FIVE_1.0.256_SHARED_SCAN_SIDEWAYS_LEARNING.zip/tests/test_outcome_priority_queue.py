import json
from pathlib import Path

from app.services import scanner


def test_first_tp_or_sl_event_queues_contract_once_and_persists_marker(tmp_path, monkeypatch):
    logs = tmp_path / 'logs'
    logs.mkdir()
    queue_path = tmp_path / 'outcome_analysis_priority.json'
    monkeypatch.setattr(scanner, 'ROOT', tmp_path)
    monkeypatch.setattr(scanner, 'OUTCOME_ANALYSIS_PRIORITY', queue_path)
    (logs / 'AAAUSDTM_pending.json').write_text(json.dumps([
        {'id': 'a', 'contract': 'AAAUSDTM', 'prediction': 'LONG', 'resolved': 0,
         'tp1_hit': True, 'tp2_hit': False, 'tp3_hit': False, 'sl_hit': False},
        {'id': 'b', 'contract': 'AAAUSDTM', 'prediction': 'LONG', 'resolved': 0,
         'tp1_hit': False, 'tp2_hit': False, 'tp3_hit': False, 'sl_hit': False},
    ]), encoding='utf-8')
    (logs / 'BBBUSDTM_pending.json').write_text(json.dumps([
        {'id': 'c', 'contract': 'BBBUSDTM', 'prediction': 'SHORT', 'resolved': 1,
         'result': 'SIDEWAYS', 'sl_hit': False, 'tp1_hit': False, 'tp2_hit': False, 'tp3_hit': False},
    ]), encoding='utf-8')

    queue = scanner._add_outcome_analysis_priority([])
    assert queue == ['AAAUSDTM']
    state = json.loads(queue_path.read_text(encoding='utf-8'))
    assert 'a' in state['triggered_forecast_ids']
    rows = json.loads((logs / 'AAAUSDTM_pending.json').read_text(encoding='utf-8'))
    assert 'outcome_priority_triggered' not in rows[0]
    assert scanner._add_outcome_analysis_priority([]) == ['AAAUSDTM']
    assert scanner._consume_outcome_analysis_priority(['AAAUSDTM']) == []


def test_resolved_tp_or_sl_adds_contract_to_priority_queue(tmp_path, monkeypatch):
    monkeypatch.setattr(scanner, 'ROOT', tmp_path)
    monkeypatch.setattr(scanner, 'OUTCOME_ANALYSIS_PRIORITY', tmp_path / 'outcome_analysis_priority.json')
    queue = scanner._add_outcome_analysis_priority([
        {'contract': 'CCC-USDTM', 'resolved': 1, 'result': 'TP1'},
        {'contract': 'DDDUSDTM', 'resolved': 1, 'result': 'SIDEWAYS'},
    ])
    assert queue == ['CCCUSDTM']
