import numpy as np
from app.core.model import ModelManager, FEATURES
from app.core.engine import LearningEngine


def test_book_imbalance_is_neutral_for_direction_but_preserved_for_outcome(tmp_path):
    mm = ModelManager(tmp_path)
    row = {name: np.asarray([0.0, 0.0]) for name in FEATURES}
    row['book_imbalance'] = np.asarray([0.42, -0.31])
    row['liquidation_bias'] = np.asarray([0.8, -0.7])
    direction = mm._feature_matrix(row, for_outcome=False)
    outcome = mm._feature_matrix(row, for_outcome=True)
    bi = FEATURES.index('book_imbalance')
    liq = FEATURES.index('liquidation_bias')
    np.testing.assert_allclose(direction[:, bi], [0.0, 0.0])
    np.testing.assert_allclose(outcome[:, bi], [0.42, -0.31])
    np.testing.assert_allclose(direction[:, liq], [0.0, 0.0])
    np.testing.assert_allclose(outcome[:, liq], [0.0, 0.0])


def test_outcome_policy_preserves_real_book_snapshot_but_direction_policy_neutralizes(tmp_path):
    engine = LearningEngine.__new__(LearningEngine)
    base = {'book_imbalance': np.asarray([0.2, -0.3]),
            'liquidation_bias': np.asarray([0.4, -0.5]),
            'oi_change': np.asarray([0.01, -0.02]),
            'funding': np.asarray([0.001, -0.002])}
    direction = {k: v.copy() for k, v in base.items()}
    outcome = {k: v.copy() for k, v in base.items()}
    engine._apply_market_feature_policy(direction, 'neutral')
    engine._apply_market_feature_policy(outcome, 'neutral', for_outcome=True)
    np.testing.assert_allclose(direction['book_imbalance'], [0, 0])
    np.testing.assert_allclose(outcome['book_imbalance'], [0.2, -0.3])
    np.testing.assert_allclose(outcome['liquidation_bias'], [0, 0])
    np.testing.assert_allclose(outcome['oi_change'], [0, 0])
    np.testing.assert_allclose(outcome['funding'], [0, 0])


def test_top25_ranking_does_not_make_tp1_sl_edge_a_duplicate_primary_key():
    # Ranking policy regression: stage25_score must remain the primary score;
    # p_tp1/p_sl are not yet independently calibrated and overlap with math consensus.
    rows = [
        {'stage25_score': 0.80, 'p_tp1': 0.52, 'p_sl': 0.10, 'p_tp2': 0.3, 'edge_score': 0.6, 'quality': 0.7},
        {'stage25_score': 0.75, 'p_tp1': 0.95, 'p_sl': 0.01, 'p_tp2': 0.7, 'edge_score': 0.8, 'quality': 0.9},
    ]
    ranked = LearningEngine._rank_stage25_candidates(rows)
    assert ranked[0]['stage25_score'] == 0.80


def test_fixed_directional_lenses_ignore_live_only_book_snapshot(tmp_path):
    mm = ModelManager(tmp_path)
    mm.meta.write_text('{"market_features_mode":"neutral"}', encoding='utf-8')
    row = {'trend': 0.01, 'trend_15': 0.02, 'trend_1h': 0.01, 'trend_4h': 0.01,
           'trend_1d': 0.02, 'volatility': 0.01, 'volz': 0.2, 'rsi': 55,
           'bbpos': 0.6, 'book_imbalance': 0.0, 'oi_change': 0.0, 'funding': 0.0}
    changed = dict(row, book_imbalance=0.9)
    master = np.asarray([0.2, 0.2, 0.6])
    math = {'math_markov': 0.2, 'math_hurst': 0.6, 'math_wavelet': 0.1,
            'math_ar': 0.1, 'math_arima': 0.1, 'math_sarima': 0.1,
            'math_mean_reversion': 0.0, 'math_cointegration': 0.0,
            'math_correlation': 0.0, 'math_trend_deviation': 0.0,
            'math_bayesian': 0.5, 'math_kalman': 0.1, 'math_direction': 0.2,
            'math_monte_carlo': 0.6, 'math_ptp1': 0.7, 'math_ptp2': 0.5,
            'math_ptp3': 0.3, 'math_psl': 0.2, 'math_target_sign': 1.0}
    a = mm._fixed_lens(master, row, math)
    b = mm._fixed_lens(master, changed, math)
    for lens in ('c1', 'c2', 'c3'):
        np.testing.assert_allclose(a[lens]['probs'], b[lens]['probs'])
