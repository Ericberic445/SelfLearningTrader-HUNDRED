import numpy as np

from app.core.engine import LearningEngine
from app.core.features import add_features
from app.core.exchange import TF_SECONDS


class FakeExchange:
    def __init__(self):
        self.calls = []
    def candles(self, tf, limit):
        self.calls.append((tf, limit))
        return {'time': np.arange(limit, dtype=np.int64), 'open': np.ones(limit),
                'high': np.ones(limit), 'low': np.ones(limit), 'close': np.ones(limit),
                'volume': np.ones(limit)}


def test_collect_keeps_full_base_history_and_covers_mtf_window_with_warmup():
    engine = LearningEngine.__new__(LearningEngine)
    engine.cfg = {'history_limit': 800,
                  'timeframes': ['5min', '15min', '1hour', '4hour', '1day']}
    engine.exchange = FakeExchange()
    frames = engine.collect()
    limits = dict(engine.exchange.calls)
    assert len(frames['5min']['time']) == 800
    assert limits == {'5min': 800, '15min': 467, '1hour': 267,
                      '4hour': 217, '1day': 203}
    # The same 800-bar 5m base timeline remains covered by every higher TF,
    # with 200 extra bars for recursive-feature warm-up.
    base_span_seconds = (800 - 1) * TF_SECONDS['5min']
    for tf in ('15min', '1hour', '4hour', '1day'):
        coverage_seconds = (limits[tf] - 200) * TF_SECONDS[tf]
        assert coverage_seconds >= base_span_seconds


def test_higher_timeframe_recent_features_converge_after_150_bar_warmup():
    # A shorter history ending at the same candle should preserve current MTF
    # RSI/trend/volume features to tight numerical tolerance.
    n = 600
    t = np.arange(n, dtype=np.int64) * TF_SECONDS['1day'] * 1000
    i = np.arange(n, dtype=float)
    close = 100.0 + 0.035 * i + 2.0 * np.sin(i / 5.0) + 0.7 * np.sin(i / 17.0)
    volume = 1000.0 + 80.0 * np.sin(i / 7.0) + (i % 13) * 2.0
    full = {'time': t, 'open': close * 0.999, 'high': close * 1.01,
            'low': close * 0.99, 'close': close, 'volume': volume}
    short = {k: np.asarray(v)[-203:] for k, v in full.items()}
    a = add_features(full)
    b = add_features(short)
    for feature in ('rsi', 'trend', 'volz'):
        assert np.isfinite(a[feature][-1]) and np.isfinite(b[feature][-1])
        assert abs(float(a[feature][-1]) - float(b[feature][-1])) < 1e-4
