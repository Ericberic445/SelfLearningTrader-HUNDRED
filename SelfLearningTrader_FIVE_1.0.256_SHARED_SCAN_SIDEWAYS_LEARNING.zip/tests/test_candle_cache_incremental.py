import numpy as np
from app.core.exchange import KuCoin, TF_SECONDS


def _rows(start_s, count, sec=300):
    out=[]
    for i in range(count):
        ts=(start_s+i*sec)*1000
        p=100.0+i*0.01
        out.append([ts, p, p+1, p-1, p+0.2, 10+i, 1000+i])
    return out


def test_closed_history_cache_hit_does_not_repeat_rest(monkeypatch):
    now=1_800_000_000
    monkeypatch.setattr('app.core.exchange.time.time', lambda: now)
    sec=TF_SECONDS['5min']; last=(now//sec)*sec-sec
    rows=_rows(last-239*sec, 240, sec)
    KuCoin._CANDLE_CACHE.clear(); KuCoin._CANDLE_KEY_LOCKS.clear()
    ex=KuCoin('CACHEHITUSDTM')
    calls=[]
    ex._get_futures=lambda path,params: calls.append((path,params)) or rows
    first=ex.candles('5min',240)
    second=ex.candles('5min',240)
    assert len(first['close'])==240 and len(second['close'])==240
    assert len(calls)==1
    assert np.array_equal(first['time'],second['time'])


def test_recent_cache_updates_with_delta_not_full_history(monkeypatch):
    now=1_800_000_000
    sec=TF_SECONDS['5min']; last=(now//sec)*sec-sec
    monkeypatch.setattr('app.core.exchange.time.time', lambda: now)
    rows=_rows(last-239*sec, 240, sec)
    KuCoin._CANDLE_CACHE.clear(); KuCoin._CANDLE_KEY_LOCKS.clear()
    ex=KuCoin('CACHEDELTAUSDTM')
    calls=[]
    def request(path, params):
        calls.append(params)
        if len(calls)==1:
            return rows
        return _rows(last-sec, 3, sec)
    ex._get_futures=request
    ex.candles('5min',240)
    monkeypatch.setattr('app.core.exchange.time.time', lambda: now+sec)
    updated=ex.candles('5min',240)
    assert len(calls)==2
    assert len(updated['close'])==240
    assert int(updated['time'][-1]//1_000_000)==last+sec
    assert 'from' in calls[1] and 'to' in calls[1]


def test_candles_between_fetches_and_sorts_bounded_historical_window(monkeypatch):
    now = 1_800_000_000
    monkeypatch.setattr('app.core.exchange.time.time', lambda: now)
    sec = TF_SECONDS['5min']
    start = now - 3600
    rows = _rows(start, 12, sec)[::-1]
    ex = KuCoin('HISTWINDOWUSDTM')
    calls = []
    ex._get_futures = lambda path, params: calls.append((path, params)) or rows

    result = ex.candles_between('5min', start, start + 11 * sec)

    assert len(calls) == 1
    assert calls[0][0] == '/api/v1/kline/query'
    assert calls[0][1]['from'] == start * 1000
    assert calls[0][1]['to'] == (start + 11 * sec) * 1000
    assert np.all(np.diff(result['time']) > 0)
    assert len(result['close']) == 12
