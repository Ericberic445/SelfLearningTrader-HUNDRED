import json
from pathlib import Path

DEFAULT = {
    "symbol":"BTC-USDT","timeframes":["5min","15min","1hour","4hour","1day"],
    "history_limit":1500,"horizon_bars":4,"long_threshold":0.003,
    "short_threshold":-0.003,"wait_learning_horizon_bars":48,"retrain_every":25,"retrain_batch_size":25,"min_training_rows":500,
    "test_fraction":0.2,"champion_min_accuracy":0.0,"refresh_seconds":60,"monitor_poll_seconds":20,"monitor_volume_change_pct":50,
    "monitor_price_change_pct":0.20,"monitor_orderbook_change":0.20,
    "monitor_alert_cooldown_seconds":60,"monitor_max_events_per_prediction":500,
    "wait_learning_weight":0.80,
    "readiness_min_resolved":1000,"readiness_min_validation_rows":1000,
    "readiness_min_accuracy":0.90,"readiness_min_recent_accuracy":0.90,
    "readiness_min_balanced_accuracy":0.60,"readiness_min_directional_precision":0.65,
    "readiness_min_action_rate":0.10,"readiness_min_recent_directional_accuracy":0.90,
    "readiness_min_tp1_rate":0.90,"readiness_max_sl_rate":0.10,
    "accuracy_statistics_min_confidence":0.70,"strict_confidence_min":0.80,
}

def load(path: Path):
    if not path.exists():
        path.write_text(json.dumps(DEFAULT,ensure_ascii=False,indent=2),encoding="utf-8")
    data=json.loads(path.read_text(encoding="utf-8"))
    out=DEFAULT.copy(); out.update(data); return out


def migrate_scan_runtime_settings(config, settings_path=None):
    """Migrate legacy scan timing and enforce the agreed one-hour scan cadence."""
    if not isinstance(config, dict):
        return config
    path = Path(settings_path) if settings_path is not None else None
    try:
        current = int(config.get("scan_model_stage_timeout_seconds", 1800) or 1800)
    except (TypeError, ValueError, OverflowError):
        current = 1800
    if current == 900:
        config["scan_model_stage_timeout_seconds"] = 1800
    # Full-market scans run on an hourly cadence. Older persisted settings
    # (notably 1800 seconds) must not silently override this project rule.
    config["scan_interval_seconds"] = 3600
    if path is not None and path.exists():
        try:
            saved = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(saved, dict):
                try:
                    saved_timeout = int(saved.get("scan_model_stage_timeout_seconds", 0) or 0)
                except (TypeError, ValueError, OverflowError):
                    saved_timeout = 0
                changed = False
                if saved_timeout == 900:
                    saved["scan_model_stage_timeout_seconds"] = 1800
                    changed = True
                if saved.get("scan_interval_seconds") != 3600:
                    saved["scan_interval_seconds"] = 3600
                    changed = True
                if changed:
                    tmp = path.with_suffix(path.suffix + ".tmp")
                    tmp.write_text(json.dumps(saved, ensure_ascii=False, indent=2), encoding="utf-8")
                    tmp.replace(path)
        except Exception:
            # A settings migration must never prevent the scanner from starting.
            pass
    return config
