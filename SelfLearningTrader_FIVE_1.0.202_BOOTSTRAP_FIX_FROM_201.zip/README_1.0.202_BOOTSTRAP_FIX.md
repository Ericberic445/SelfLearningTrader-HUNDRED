# SelfLearningTrader 1.0.202 — bootstrap fix

Based directly on the 1.0.201 working project.

Changes only:
- allow the first market scan to create the initial Master direction model when no Champion exists yet;
- keep `resolved_total=0`, `base_version=0`, and C1/C2/C3 inactive during this bootstrap;
- serialize global experience-schema migration so parallel scanner workers cannot race on `experience_schema_v2.tmp`;
- preserve the 1.0.201 backup behavior: backup export remains valid without Champion files.

No UI redesign and no change to the agreed Master/C1/C2/C3 learning architecture.
